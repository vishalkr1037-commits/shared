from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

ADDRESS_ID = "address_id"
LATITUDE = "latitude"
LONGITUDE = "longitude"


PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_ADDRESS_COORD
SCHEMA = table_schema("firmographics_entity_address_coord")
