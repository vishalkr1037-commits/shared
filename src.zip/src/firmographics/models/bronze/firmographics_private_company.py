from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
FPC_AS_OF_DATE = "fpc_as_of_date"
FPC_ITEM_TYPE = "item_type"
FPC_ITEM_VALUE = "item_value"

SCHEMA = table_schema("firmographics_private_company")
PATH = table_config.BRONZE_FIRMOGRAPHICS_PRIVATE_COMPANY
