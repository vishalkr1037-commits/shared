from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
ENTITY_PROFILE_TYPE = "entity_profile_type"
ENTITY_PROFILE = "entity_profile"


PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_PROFILES
SCHEMA = table_schema("firmographics_entity_profiles")
