from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FSYM_ID = "fsym_id"
CURRENCY = "currency"
PROPER_NAME = "proper_name"
FSYM_PRIMARY_EQUITY_ID = "fsym_primary_equity_id"
FSYM_PRIMARY_LISTING_ID = "fsym_primary_listing_id"
ACTIVE_FLAG = "active_flag"
FREF_SECURITY_TYPE = "fref_security_type"
FREF_LISTING_EXCHANGE = "fref_listing_exchange"
LISTING_FLAG = "listing_flag"
REGIONAL_FLAG = "regional_flag"
SECURITY_FLAG = "security_flag"
FSYM_REGIONAL_ID = "fsym_regional_id"
FSYM_SECURITY_ID = "fsym_security_id"
UNIVERSE_TYPE = "universe_type"


PATH = table_config.BRONZE_FIRMOGRAPHICS_SYM_HUB
SCHEMA = table_schema("firmographics_sym_hub")
