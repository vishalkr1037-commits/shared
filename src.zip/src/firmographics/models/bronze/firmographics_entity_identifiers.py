from src.common.table_config.table_config_interface import table_schema

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
ENTITY_ID_TYPE = "entity_id_type"
ENTITY_ID_VALUE = "entity_id_value"


PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_IDENTIFIERS
SCHEMA = table_schema("firmographics_entity_identifiers")
