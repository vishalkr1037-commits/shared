from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
NAICS_CODE = "naics_code"
RANK = "rank"


PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_NAICS_RANK
SCHEMA = table_schema("firmographics_entity_naics_rank")
