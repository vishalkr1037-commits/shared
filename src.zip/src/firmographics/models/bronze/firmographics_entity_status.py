from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
ENTITY_STATUS_CODE = "entity_status_code"
START_DATE = "start_date"
END_DATE = "end_date"


PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_STATUS
SCHEMA = table_schema("firmographics_entity_status")
