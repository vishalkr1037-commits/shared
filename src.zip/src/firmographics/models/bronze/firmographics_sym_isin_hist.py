from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

ISIN = "isin"
FSYM_ID = "fsym_id"
START_DATE = "start_date"
END_DATE = "end_date"
MOST_RECENT = "most_recent"


PATH = table_config.BRONZE_FIRMOGRAPHICS_SYM_ISIN_HIST
SCHEMA = table_schema("firmographics_sym_isin_hist")
