from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
ENTITY_PROPER_NAME = "entity_proper_name"
ISO_COUNTRY = "iso_country"
ENTITY_TYPE = "entity_type"


PATH = table_config.BRONZE_FIRMOGRAPHICS_SYM_ENTITY
SCHEMA = table_schema("firmographics_sym_entity")
