from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
ENTITY_NAME = "entity_name"
ENTITY_PROPER_NAME = "entity_proper_name"
PRIMARY_SIC_CODE = "primary_sic_code"
WEB_SITE = "web_site"
ENTITY_TYPE = "entity_type"
NACE_CODE = "nace_code"

PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_COVERAGE
SCHEMA = table_schema("firmographics_entity_coverage")
