from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

ADDRESS_ID = "address_id"
FACTSET_ENTITY_ID = "factset_entity_id"
LOCATION_CITY = "location_city"
STATE_PROVINCE = "state_province"
ISO_COUNTRY = "iso_country"

PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_ADDRESS
SCHEMA = table_schema("firmographics_entity_address")
