from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FSYM_ID = "fsym_id"
ISIN = "isin"


PATH = table_config.BRONZE_FIRMOGRAPHICS_SYM_ISIN
SCHEMA = table_schema("firmographics_sym_isin")
