from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FACTSET_ENTITY_ID = "factset_entity_id"
ENTITY_NAME_TYPE = "entity_name_type"
ENTITY_NAME_VALUE = "entity_name_value"


PATH = table_config.BRONZE_FIRMOGRAPHICS_ENTITY_NAMES
SCHEMA = table_schema("firmographics_entity_names")
