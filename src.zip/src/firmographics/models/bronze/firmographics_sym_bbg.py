from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FSYM_ID = "fsym_id"
BBG_ID = "bbg_id"
MOST_RECENT = "most_recent"

PATH = table_config.BRONZE_FIRMOGRAPHICS_SYM_BBG
SCHEMA = table_schema("firmographics_sym_bbg")
