from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FSYM_ID = "fsym_id"
TICKER_REGION = "ticker_region"


PATH = table_config.BRONZE_FIRMOGRAPHICS_SYM_TICKER_REGION
SCHEMA = table_schema("firmographics_sym_ticker_region")
