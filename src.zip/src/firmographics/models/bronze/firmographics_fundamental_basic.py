from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.firmographics.common.firmographics_table_config import table_config

FSYM_ID = "fsym_id"
DATE = "date"
FF_SALES = "ff_sales"

PATH = table_config.BRONZE_FIRMOGRAPHICS_FUNDAMENTAL_BASIC
SCHEMA = table_schema("firmographics_fundamental_basic")
