from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.firmographics.models.bronze.firmographics_entity_naics_rank as EntityNaicsRankModel
from src.firmographics.common.firmographics_table_config.table_config import (
    LANDING_TXT_LOCATION_FIRMOGRPAHICS_ENTITY_NAICS_RANK,
)


def process(
    spark: SparkSession,
    catalog_name: str,
    target_db_name: str,
    config: PipelineConfig,
):
    df = (
        spark.read.format("csv")
        .option("header", True)
        .option("sep", "|")
        .schema(EntityNaicsRankModel.SCHEMA)
        .option("recursiveFileLookup", "true")
        .load(LANDING_TXT_LOCATION_FIRMOGRPAHICS_ENTITY_NAICS_RANK)
    )

    df = df.withColumn("txt_file_name", F.col("_metadata.file_path"))
    df_with_naics_rank_data = df.filter(F.col("txt_file_name").contains("naics_rank")).select(
        F.col(EntityNaicsRankModel.FACTSET_ENTITY_ID),
        F.col(EntityNaicsRankModel.NAICS_CODE),
        F.col("txt_file_name"),
    )

    target_table = fully_qualified_table_name(
        catalog=catalog_name,
        database=target_db_name,
        table=EntityNaicsRankModel.PATH,
    )

    print(f"[INFO] Writing to table: {target_table}")

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(
        df_with_naics_rank_data
    )
