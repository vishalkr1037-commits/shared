from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.firmographics.models.bronze.firmographics_entity_address as EntityAddressModel
from src.firmographics.common.firmographics_table_config.table_config import (
    LANDING_TXT_LOCATION_FIRMOGRPAHICS_ENTITY_ADDRESS,
)


def process(
    spark: SparkSession,
    catalog_name: str,
    target_db_name: str,
    config: PipelineConfig,
):
    df = (
        spark.read.format("csv")
        .option("header", True)
        .option("sep", "|")
        .schema(EntityAddressModel.SCHEMA)
        .option("recursiveFileLookup", "true")
        .load(LANDING_TXT_LOCATION_FIRMOGRPAHICS_ENTITY_ADDRESS)
    )

    df = df.withColumn("txt_file_name", F.col("_metadata.file_path"))
    df_with_address_data = df.filter(F.col("txt_file_name").endswith("address.txt")).select(
        F.col(EntityAddressModel.ADDRESS_ID),
        F.col(EntityAddressModel.FACTSET_ENTITY_ID),
        F.col(EntityAddressModel.LOCATION_CITY),
        F.col(EntityAddressModel.STATE_PROVINCE),
        F.col(EntityAddressModel.ISO_COUNTRY),
        F.col("txt_file_name"),
    )

    target_table = fully_qualified_table_name(
        catalog=catalog_name,
        database=target_db_name,
        table=EntityAddressModel.PATH,
    )

    print(f"[INFO] Writing to table: {target_table}")

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(
        df_with_address_data
    )
