from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.firmographics.models.bronze.firmographics_sym_ticker_region as SymTickerRegionModel
from src.firmographics.common.firmographics_table_config.table_config import (
    LANDING_TXT_LOCATION_FIRMOGRPAHICS_SYMBOLOGY_TICKER_REGION,
)


def process(
    spark: SparkSession,
    catalog_name: str,
    target_db_name: str,
    config: PipelineConfig,
):
    df = (
        spark.read.format("csv")
        .option("header", "true")
        .option("sep", "|")
        .schema(SymTickerRegionModel.SCHEMA)
        .option("recursiveFileLookup", "true")
        .load(LANDING_TXT_LOCATION_FIRMOGRPAHICS_SYMBOLOGY_TICKER_REGION)
    )
    df = df.withColumn("txt_file_name", F.col("_metadata.file_path"))
    df_only_ticker_region = df.filter(F.col("txt_file_name").contains("ticker_region")).select(
        F.col(SymTickerRegionModel.FSYM_ID),
        F.col(SymTickerRegionModel.TICKER_REGION),
        F.col("txt_file_name"),
    )
    target_table = fully_qualified_table_name(
        catalog=catalog_name,
        database=target_db_name,
        table=SymTickerRegionModel.PATH,
    )

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(
        df_only_ticker_region
    )
