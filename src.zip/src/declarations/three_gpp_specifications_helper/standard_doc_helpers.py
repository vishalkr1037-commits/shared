import re
from typing import List, Optional

_REGEX_FOR_REMOVING_ANYTHING_THAT_IS_NOT_DOT_NUMBER_OR_HYPHEN = r"[^\d\.\-]"
_STANDARD_DOC_ID_PATTERN = re.compile(r"\d{2,3}\.\d{3,}|\d{5,}")
_SPECIAL_CASE_OF_NUMBER_WITH_EXTRA_ZEROS = "29\\."


def get_cleaned_standard_doc_id_number(standard_doc_id: Optional[str]) -> str:
    if not standard_doc_id:
        return ""
    return tranform_sep_to_standard_format_and_fix_if_broken_sep(standard_doc_id)


def get_standard_doc_id_with_prefix_and_number(standard_doc_id: str) -> str:
    if not standard_doc_id:
        return ""
    prefix = extract_prefix(standard_doc_id)
    cleaned_number = tranform_sep_to_standard_format_and_fix_if_broken_sep(standard_doc_id)
    return (prefix + " " + cleaned_number).strip()


def extract_prefix(standard_doc_id: str) -> str:
    if is_incorrect_prefix(standard_doc_id):
        return ""
    if standard_doc_id.replace("ETSI", "").strip()[:2].isalpha():
        return standard_doc_id.replace("ETSI", "").strip()[:2]
    return ""


def is_incorrect_prefix(standard_doc_id: str) -> bool:
    return any(
        keyword in standard_doc_id.lower() for keyword in ["other", "discussion", "report", "ls", "revised", "wi"]
    )


def remove_bracket_or_version(standards_doc_id: str) -> str:
    if "(" in standards_doc_id:
        return standards_doc_id.split("(")[0].strip()
    return remove_remaining_version(standards_doc_id)


def remove_remaining_version(standards_doc_id: str) -> str:
    if "v" in standards_doc_id.lower():
        return standards_doc_id.lower().split("v")[0].strip()
    return standards_doc_id.strip()


def tranform_sep_to_standard_format_and_fix_if_broken_sep(standard_doc_id: str) -> str:
    if not standard_doc_id:
        return ""

    transform_sep_to_standard = re.sub(
        _REGEX_FOR_REMOVING_ANYTHING_THAT_IS_NOT_DOT_NUMBER_OR_HYPHEN,
        "",
        transform_from_seps_format_to_standards_format(standard_doc_id),
    )

    if is_sep_with_dot(transform_sep_to_standard):
        return get_sep_with_dot_to_standard(transform_sep_to_standard)
    elif is_standard_without_dot(transform_sep_to_standard):
        return add_to_standard_dot(transform_sep_to_standard)
    elif is_sep_without_spaces(transform_sep_to_standard):
        return get_sep_to_standard_without_one_with_dot(transform_sep_to_standard)

    return transform_sep_to_standard


def transform_from_seps_format_to_standards_format(standards_doc_id: str) -> str:
    if not standards_doc_id:
        return ""

    standard_without_bracket_or_version = remove_bracket_or_version(standards_doc_id)
    standard_without_bracket_and_version = remove_remaining_version(standard_without_bracket_or_version)
    splited_standard_doc_id = standard_without_bracket_and_version.split()

    if len(splited_standard_doc_id) >= 3:
        if is_sep(splited_standard_doc_id[1]):
            return get_sep_to_standard_format(splited_standard_doc_id).upper()
        elif is_standard_with_spaces(standard_without_bracket_and_version, splited_standard_doc_id[1]):
            return get_standard_without_spaces_and_with_dot(splited_standard_doc_id).upper()
        elif is_gts_standard(splited_standard_doc_id[1]):
            return get_gts_sep_to_standard_format(splited_standard_doc_id).upper()
        elif is_tispan_with_spaces(standard_without_bracket_and_version, splited_standard_doc_id[2]):
            return get_tispan_without_spaces(splited_standard_doc_id).upper()
        elif is_tispan_with_out_spaces_and_with_extra_chars(
            standard_without_bracket_and_version, splited_standard_doc_id[2]
        ):
            return get_tispan_without_extra_chars(splited_standard_doc_id).upper()

    if len(splited_standard_doc_id) >= 2:
        if is_2g_sep(splited_standard_doc_id[1]):
            return get_2g_sep_to_standard_format(splited_standard_doc_id).upper()

    return standard_without_bracket_and_version.upper()


def is_sep_without_spaces(transform_sep_to_standard: str) -> bool:
    return (
        "." not in transform_sep_to_standard
        and transform_sep_to_standard.startswith("1")
        and len(transform_sep_to_standard) >= 5
    )


def get_sep_to_standard_without_one_with_dot(transform_sep_to_standard: str) -> str:
    return transform_sep_to_standard[1:2] + "." + transform_sep_to_standard[2:]


def is_standard_without_dot(standard_doc_id: str) -> bool:
    return "." not in standard_doc_id and not standard_doc_id.startswith("1") and len(standard_doc_id) >= 5


def add_to_standard_dot(standard: str) -> str:
    return standard[:2] + "." + standard[2:]


def is_sep_with_dot(transform_sep_to_standard: str) -> bool:
    if "." not in transform_sep_to_standard:
        return False

    first_part = transform_sep_to_standard.split(".")[0]
    return len(first_part) >= 3 and first_part.startswith("1")


def get_sep_with_dot_to_standard(transform_sep_to_standard: str) -> str:
    if transform_sep_to_standard.startswith("1"):
        return transform_sep_to_standard[1:]
    return transform_sep_to_standard


def is_standard_with_spaces(
    standard_without_bracket_or_version: str, splited_standard_doc_id_second_position: str
) -> bool:
    return "." not in standard_without_bracket_or_version and splited_standard_doc_id_second_position.isdigit()


def get_standard_without_spaces_and_with_dot(splited_standard_doc_id: List[str]) -> str:
    return f"{splited_standard_doc_id[0]} {splited_standard_doc_id[1]}.{splited_standard_doc_id[2]}"


def is_2g_sep(splited_standard_doc_id_second_position: str) -> bool:
    return len(splited_standard_doc_id_second_position) > 5 and splited_standard_doc_id_second_position.startswith("0")


def get_2g_sep_to_standard_format(splited_standard_doc_id: list) -> str:
    return f"{splited_standard_doc_id[0]} {splited_standard_doc_id[1][:5]}"


def is_gts_standard(splited_standard_doc_id_second_position: str) -> bool:
    return "gts" in splited_standard_doc_id_second_position


def get_gts_sep_to_standard_format(splited_standard_doc_id: list) -> str:
    return f"{splited_standard_doc_id[0]} {splited_standard_doc_id[1]} {splited_standard_doc_id[2].split('-')[0]}"


def is_tispan_with_spaces(
    standard_without_bracket_or_version: str, splited_standard_doc_id_second_position: str
) -> bool:
    return (
        "etsi es" in standard_without_bracket_or_version.lower() and len(splited_standard_doc_id_second_position) <= 3
    )


def get_tispan_without_spaces(splited_standard_doc_id: list) -> str:
    return f"{splited_standard_doc_id[0]} {splited_standard_doc_id[1]} {splited_standard_doc_id[2]}{splited_standard_doc_id[3][:2]}"


def is_tispan_with_out_spaces_and_with_extra_chars(
    standard_without_bracket_or_version: str, splited_standard_doc_id_second_position: str
) -> bool:
    return "etsi es" in standard_without_bracket_or_version.lower() and len(splited_standard_doc_id_second_position) > 3


def get_tispan_without_extra_chars(splited_standard_doc_id: list) -> str:
    return f"{splited_standard_doc_id[0]} {splited_standard_doc_id[1]} {splited_standard_doc_id[2][:3]}{splited_standard_doc_id[2][3:5]}"


def is_sep(splited_standard_doc_id_second_position: str) -> bool:
    return len(splited_standard_doc_id_second_position) >= 3 and splited_standard_doc_id_second_position.startswith("1")


def get_sep_to_standard_format(splited_standard_doc_id: list) -> str:
    return f"{splited_standard_doc_id[0]} {splited_standard_doc_id[1][1:]}.{splited_standard_doc_id[2]}"


def remove_letters(identifier: str) -> Optional[str]:
    if not identifier:
        return None
    return remove_zeros_on_special_standard_doc_ids(
        re.sub(_REGEX_FOR_REMOVING_ANYTHING_THAT_IS_NOT_DOT_NUMBER_OR_HYPHEN, "", identifier)
    )


def remove_zeros_on_special_standard_doc_ids(standard_doc_id: str) -> Optional[str]:
    if not standard_doc_id:
        return None
    if _SPECIAL_CASE_OF_NUMBER_WITH_EXTRA_ZEROS in standard_doc_id:
        return standard_doc_id.replace("-0", "-")
    return standard_doc_id


def is_valid_standard_doc_id(standard_doc_id: str) -> bool:
    if not standard_doc_id:
        return False
    return bool(_STANDARD_DOC_ID_PATTERN.search(standard_doc_id))


def remove_date_from_id(id: str) -> str:
    return id.split("_")[0]


def get_harmonized_standard_doc_id_number(standard_doc_id: str) -> str:
    if is_valid_standard_doc_id(standard_doc_id):
        return get_standard_doc_id_with_prefix_and_number(standard_doc_id)
    return standard_doc_id


def get_joined_standard_document_id_and_title(standard_doc_id: str, title: str) -> str:
    def is_empty(s):
        return s is None or s == ""

    if is_empty(standard_doc_id) and is_empty(title):
        return ""

    return " - ".join(s.strip() for s in [standard_doc_id, title] if not is_empty(s))


def get_release_from_version(standard_doc_id: Optional[str]) -> str:
    version = get_version_first_number_from_standard_doc_id(standard_doc_id)
    if not version:
        return ""

    clean_standard_doc_id = get_cleaned_standard_doc_id_number(standard_doc_id)
    if not clean_standard_doc_id:
        return ""

    try:
        standard_doc_id_first_number = int(clean_standard_doc_id.split(".")[0])
    except ValueError:
        return ""

    if standard_doc_id_first_number < 20:
        return get_release_from_version_smaller_than_20(version.split(".")[0])
    else:
        return get_release_from_version_bigger_than_20(version.split(".")[0])


def get_version_first_number_from_standard_doc_id(standard_doc_id: str) -> str:
    if not standard_doc_id:
        return ""
    if "v" in standard_doc_id.lower():
        return standard_doc_id.lower().split("v")[-1].strip()
    return ""


def get_release_from_version_smaller_than_20(version: str) -> str:
    version_map = {
        "1": "Phase 1",
        "2": "Phase 1",
        "3": "Phase 1",
        "4": "Phase 2",
        "5": "Phase 2+",
        "6": "Release 1997",
        "7": "Release 1998",
        "8": "Release 1999",
        "9": "Release 1999",
        "10": "Release 1999",
        "11": "Release 1999",
        "12": "Release 1999",
    }
    return version_map.get(version, "")


def get_release_from_version_bigger_than_20(version: str) -> str:
    if not version:
        return ""
    version_number = int(version) if version.isdigit() else -1
    if 3 < version_number < 30:
        return f"Release {version}"
    return ""


def get_release_mapped_on_version(standard_doc_id: Optional[str], release: Optional[str]) -> str:
    if release:
        return release

    return get_release_from_version(standard_doc_id)


def get_release_mapped_on_version_declarations(standard_doc_id: str, standard_doc_ref: str) -> str:
    release = get_release_from_version(standard_doc_id)

    if release:
        return release

    new_release = get_release_from_version(standard_doc_ref)
    return new_release if new_release else ""
