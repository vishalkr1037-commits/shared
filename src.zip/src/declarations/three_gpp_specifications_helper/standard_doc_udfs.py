import pandas as pd
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import StringType


def create_pandas_udf(helper_function, output_type=StringType(), is_multi_column=False):
    """
    Wrapper to create a Pandas UDF dynamically.

    :param helper_function: The helper function to apply in the UDF.
    :param output_type: The output type of the UDF (default: StringType).
    :param is_multi_column: Boolean indicating if the UDF handles multiple columns.
    :return: A Pandas UDF that applies the helper function.
    """

    if is_multi_column:

        @pandas_udf(output_type)
        def multi_col_udf(*cols: pd.Series) -> pd.Series:
            return pd.Series([helper_function(*row) for row in zip(*cols)])

        return multi_col_udf
    else:

        @pandas_udf(output_type)
        def single_col_udf(col: pd.Series) -> pd.Series:
            return col.apply(helper_function)

        return single_col_udf
