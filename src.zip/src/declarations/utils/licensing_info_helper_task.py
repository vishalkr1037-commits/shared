from pyspark.sql.functions import col, concat, lit, when

MAIN_URL = "https://www.via-la.com/licensing/"


class LicensingInfoHelper:

    @staticmethod
    def normalize_pool_program(standard_project):
        return (
            when(standard_project == "ATSC", lit("atsc"))
            .when(standard_project == "ATSC, 3.0", lit("atsc-3-0"))
            .when(standard_project == "AVC/H.264", lit("avc-h-264"))
            .when(standard_project == "DisplayPort", lit("displayport"))
            .when(standard_project == "EV, Charging", lit("ev-charging"))
            .when(standard_project == "EVS", lit("evs"))
            .when(standard_project == "HEVC (H.265)", lit("hevc"))
            .when(standard_project == "MPEG-2", lit("mpeg-2"))
            .when(standard_project == "MPEG-4 Visual", lit("mpeg-4-visual"))
            .when(standard_project == "QI Standard, Wireless, Power", lit("qi-wireless-power"))
            .when(standard_project == "VC-1", lit("vc-1"))
            .when(standard_project == "VVC", lit("vvc"))
            .otherwise(None)
        )

    @staticmethod
    def get_specific_licensing_terms(pool_name, standard_project, old_licensing_spec):
        specific_license_term = LicensingInfoHelper.normalize_pool_program(standard_project)
        return when(
            (pool_name == "Via LA") | (pool_name.isNull() & old_licensing_spec.contains("mpegla")),
            concat(lit(MAIN_URL), concat(specific_license_term, lit("/"))),
        ).otherwise(col("Specific Licensing Conditions"))

    @staticmethod
    def get_licensing_terms(pool_name, old_licensing_terms):
        return when(
            (pool_name == "Via LA") | (pool_name.isNull() & old_licensing_terms.contains("mpegla")),
            lit(MAIN_URL.replace("/licensing/", "")),
        ).otherwise(col("Licensing Terms"))
