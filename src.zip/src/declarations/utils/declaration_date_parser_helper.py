from pyspark.sql.functions import concat, lit, to_date, when


class HelperFunctionForParseDate:
    @staticmethod
    def parse_date(date):
        return (
            when(date.isNull(), lit(None))
            .when(date.rlike("^\\d{4}$"), to_date(concat(date, lit("-01-01")), "yyyy-MM-dd"))
            .when(date.rlike("^\\d{2}\\.\\d{2}\\.\\d{4}$"), to_date(date, "dd.MM.yyyy"))
            .when(date.rlike("^\\d{4}-\\d{2}-\\d{2}$"), to_date(date, "yyyy-MM-dd"))
            .when(date.rlike("^\\d{1,2}/\\d{1,2}/\\d{4}$"), to_date(date, "M/d/yyyy"))
            .when(date.rlike("^\\d{1,2}-\\w+-\\d{2}$"), to_date(date, "d-MMM-yy"))
            .when(date.rlike("^\\d{2}\\. \\D+ \\d{2}$"), to_date(date, "dd. MMM yy"))
            .when(date.rlike("^\\d* \\D*, \\d\\d\\d\\d"), to_date(date, "dd MMMM, yyyy"))
            .otherwise(None)
        )
