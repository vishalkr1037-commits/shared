from pyspark.sql.functions import array_join, filter, split


def split_string_to_set_array(set_col):
    return split(set_col, " \\| ")


def get_set_to_string(set_col):
    return array_join(filter(set_col, lambda x: x.isNotNull() & (x != "")), ", ")


def join_set(set_col):
    return array_join(set_col, " | ")
