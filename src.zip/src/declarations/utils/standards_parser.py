import html
import logging

import pandas as pd
from bs4 import BeautifulSoup
from pyspark.sql.functions import pandas_udf
from pyspark.sql.types import ArrayType, StringType

from src.declarations.utils.section_parsers.atsc_section_parser import (
    AtscEncodingSectionParser,
)
from src.declarations.utils.section_parsers.audio_encoding_section_parser import (
    AudioEncodingSectionParser,
)
from src.declarations.utils.section_parsers.etsi_section_parser import EtsiSectionParser
from src.declarations.utils.section_parsers.qi_section_parser import QiSectionParser
from src.declarations.utils.section_parsers.video_encoding_section_parser import (
    VideoEncodingSectionParser,
)

from .standard_docId_utility import parse


class StandardsParser:
    # Note: In legacy code, we had a separate UDF for cleaning audio encoding descriptions.
    # In replatformed code, we are using a single clean_description_udf for all technologies
    # Reason: BeautifulSoup does NOT provide structured parse error reporting like Jsoup (Legacy Java library)
    # And cannot fully replicate Jsoup’s Parser.getErrors() behavior in Python.
    @staticmethod
    @pandas_udf(returnType=StringType())
    def clean_description_udf(series: pd.Series) -> pd.Series:
        def clean_description(description):
            if description is None:
                return ""
            try:
                escaped_description = html.escape(description)  # Escape HTML entities
                doc = BeautifulSoup(escaped_description, "html.parser")
                return doc.get_text(separator=" ", strip=True)
            except Exception as e:
                logging.warning(f"Failed to clean description: {e}")
                return ""

        return series.apply(clean_description)

    @staticmethod
    @pandas_udf(returnType=ArrayType(ArrayType(StringType())))
    def extract_atsc_sections_udf(series: pd.Series) -> pd.Series:
        """
        Extract all ATSC sections from standards documents.

        Returns:
            List of [section_reference, section_content] pairs for each row
        """

        def extract_sections(description):
            if not description:
                return []

            try:
                # Parse the index
                index = AtscEncodingSectionParser.parse_index(description)

                if not index:
                    return []

                # Extract content for each section
                result = []
                for section_ref in index.keys():
                    section_content = AtscEncodingSectionParser.parse_section_content(description, index, section_ref)
                    result.append([section_ref, section_content])

                return result
            except Exception as e:
                logging.warning(f"Failed to extract ATSC sections: {e}")
                return []

        return series.apply(extract_sections)

    @staticmethod
    @pandas_udf(returnType=ArrayType(ArrayType(StringType())))
    def extract_etsi_sections_udf(series: pd.Series) -> pd.Series:
        """
        Extract all ETSI sections from standards documents.

        Returns:
            List of [section_reference, section_content] pairs for each row
        """

        def extract_sections(description):
            if not description:
                return []

            try:
                # Parse the index
                index = EtsiSectionParser.parse_index(description)

                if not index:
                    return []

                # Extract content for each section
                result = []
                for section_ref in index.keys():
                    section_content = EtsiSectionParser.parse_section_content(description, index, section_ref)
                    result.append([section_ref, section_content])

                return result
            except Exception as e:
                logging.warning(f"Failed to extract ETSI sections: {e}")
                return []

        return series.apply(extract_sections)

    @staticmethod
    @pandas_udf(returnType=ArrayType(ArrayType(StringType())))
    def extract_qi_sections_udf(series: pd.Series) -> pd.Series:
        """
        Extract all Qi sections from standards documents.

        Returns:
            List of [section_reference, section_content] pairs for each row
        """

        def extract_sections(description):
            if not description:
                return []

            try:
                # Parse the index
                index = QiSectionParser.parse_index(description)

                if not index:
                    return []

                # Extract content for each section
                result = []
                for section_ref in index.keys():
                    section_content = QiSectionParser.parse_section_content(description, index, section_ref)
                    result.append([section_ref, section_content])

                return result
            except Exception as e:
                logging.warning(f"Failed to extract Qi sections: {e}")
                return []

        return series.apply(extract_sections)

    @staticmethod
    @pandas_udf(returnType=ArrayType(ArrayType(StringType())))
    def extract_video_sections_udf(series: pd.Series) -> pd.Series:
        """
        Extract all video encoding standard sections from documents.
        Supports H.264, H.265, H.266, and AV1 standards.

        Returns:
            List of [section_reference, section_content] pairs for each row
        """

        def extract_sections(description):
            if not description:
                return []

            try:
                # Parse the index
                index = VideoEncodingSectionParser.parse_index(description)

                if not index:
                    return []

                # Extract content for each section
                result = []
                for section_ref in index.keys():
                    section_content = VideoEncodingSectionParser.parse_section_content(description, index, section_ref)
                    result.append([section_ref, section_content])

                return result
            except Exception as e:
                logging.warning(f"Failed to extract video sections: {e}")
                return []

        return series.apply(extract_sections)

    @staticmethod
    @pandas_udf(returnType=ArrayType(ArrayType(StringType())))
    def extract_audio_sections_udf(series: pd.Series) -> pd.Series:
        """
        Extract all audio encoding standard sections from documents.
        Supports OPUS, AAC, MPEG, and other audio codec standards.

        Returns:
            List of [section_reference, section_content] pairs for each row
        """

        def extract_sections(description):
            if not description:
                return []

            try:
                # Clean and parse the index
                description_cleaned = AudioEncodingSectionParser.clean_header_footer(description)
                index = AudioEncodingSectionParser.parse_index(description_cleaned)

                if not index:
                    return []

                # Extract content for each section
                # Use a modified approach: iterate through index and track position
                result = []
                index_list = list(index.items())
                working_text = description_cleaned

                for i, (section_ref, section_title) in enumerate(index_list):
                    # Calculate upper boundary
                    if i < len(index_list) - 1:
                        upper_boundary = f"{index_list[i + 1][0]} {index_list[i + 1][1]}"
                    else:
                        upper_boundary = "Annex"

                    lower_boundary = f"{section_ref} {section_title}"

                    # Extract section content
                    section_content = AudioEncodingSectionParser.extract_section_content(
                        working_text, lower_boundary, upper_boundary
                    )

                    result.append([section_ref, section_content])

                    # Update working text to skip past this section
                    if lower_boundary in working_text:
                        idx = working_text.find(lower_boundary)
                        working_text = working_text[idx + len(lower_boundary) :]

                return result
            except Exception as e:
                logging.warning(f"Failed to extract audio sections: {e}")
                return []

        return series.apply(extract_sections)

    @staticmethod
    @pandas_udf(returnType=StringType())
    def parse_etsi_standard_document_number_udf(series: pd.Series) -> pd.Series:
        """
        Extract the ETSI standard document number from the standard_document_id.

        Examples:
            "TS 102 003 v1.2.1" -> "02.003"
            "TR 101 234" -> "101.234"
            "CR 102 003" -> "02.003"

        Returns:
            Extracted standard document number or empty string if not found
        """

        def extract_document_number(standard_document_id):
            if not standard_document_id:
                return ""

            try:
                parsed = parse(standard_document_id)
                return parsed.number if parsed.number else ""
            except Exception as e:
                logging.warning(f"Failed to parse standard document number from '{standard_document_id}': {e}")
                return ""

        return series.apply(extract_document_number)
