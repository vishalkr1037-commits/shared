import hashlib
import logging

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType


class DeclarationsIdGeneratorHelper:
    @staticmethod
    def make_id_for_declaration_raw(a, b, c, d, e, f):
        return DeclarationsIdGeneratorHelper.create_sha1_id_from_strings(a, b, c, d, e, f)

    @staticmethod
    def make_id_for_declaration_etsi_raw(a, b, c, d, e, f, g, h):
        return DeclarationsIdGeneratorHelper.create_sha1_id_from_strings(a, b, c, d, e, f, g, h)

    @staticmethod
    def create_sha1_id_from_strings(*key_elements):
        default_value = "0"
        joiner = ""
        if not key_elements or all(k is None for k in key_elements):
            return default_value

        for key_value in key_elements:
            if key_value is not None:
                clean_value = str(key_value).replace(" ", "")
                joiner += clean_value
        if joiner == "":
            return default_value
        id_bytes = joiner.encode("utf-8")
        try:
            digest = hashlib.sha1()
            digest.update(id_bytes)
            return format(int.from_bytes(digest.digest(), byteorder="big"), "040x")
        except Exception as e:
            logging.error(e)

        return ""

    make_id_for_declaration_raw_udf = udf(
        lambda a, b, c, d, e, f: DeclarationsIdGeneratorHelper.make_id_for_declaration_raw(a, b, c, d, e, f),
        StringType(),
    )

    make_id_for_declaration_etsi_raw_udf = udf(
        lambda a, b, c, d, e, f, g, h: DeclarationsIdGeneratorHelper.make_id_for_declaration_etsi_raw(
            a, b, c, d, e, f, g, h
        ),
        StringType(),
    )
