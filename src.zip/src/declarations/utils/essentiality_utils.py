"""
Essentiality Pipeline - Utility Functions

Reusable utility module for SES 2.0 data preparation and vectorization pipelines.

Includes:
- Data loaders (declarations, standards, tokenized text, vectors)
- Text extraction utilities (claims, abstracts, sections)
- Text preprocessing (TextPreprocessor class)
- Data validation functions

Usage:
    from src.declarations.utils.essentiality_utils import (
        load_declarations,
        load_standards,
        TextPreprocessor,
        validate_preprocessed_data
    )
"""

# Download required NLTK data - Updated for Databricks (punkt_tab)
import re
import string
import unicodedata
from typing import Any, Dict, List

import contractions
import nltk
import pkg_resources
import pyspark.sql.functions as F
from nltk.corpus import stopwords, wordnet
from nltk.stem import WordNetLemmatizer
from nltk.tag import pos_tag
from nltk.tokenize import word_tokenize
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.types import ArrayType, StringType, StructField, StructType
from symspellpy import SymSpell, Verbosity

nltk_data_dir = "/root/nltk_data"
if nltk_data_dir not in nltk.data.path:
    nltk.data.path.insert(0, nltk_data_dir)

# Download required packages (including language-specific tagger)
packages = [
    "punkt_tab",
    "stopwords",
    "wordnet",
    "averaged_perceptron_tagger_eng",  # ← Language-specific tagger
    "omw-1.4",
]

for pkg in packages:
    try:
        nltk.download(pkg, download_dir=nltk_data_dir, quiet=True)
    except Exception:
        pass  # Continue if download fails

print("✓ NLTK packages downloaded")


# ============================================================================
# PART 1: DATA LOADER FUNCTIONS
# ============================================================================


def load_declarations(spark: SparkSession, tech: str, decl_path: str) -> DataFrame:
    """
    Load patent declarations for a given technology from Delta Lake

    Args:
        spark: SparkSession
        tech: Technology identifier (wifi, audio, video, qi, atsc, etsi, true_negative)
        config: Configuration dict with 'decl_path' key

    Returns:
        PySpark DataFrame with patent declarations

    Raises:
        Exception: If loading fails
    """
    print(f"Loading {tech} declarations...")

    # path = f"essentiality_v2/{config['decl_path']}"

    try:
        df = spark.read.format("delta").load(
            f"abfs://raw@lnipdevstorage.dfs.core.windows.net/release/test/essentiality_v2/{decl_path}"
        )
        print(f"  ✓ Loaded {df.count():,} declaration records")
        return df
    except Exception:
        print("  ⚠ Error loading declarations")
        raise


def load_standards(spark: SparkSession, tech: str, std_path: str) -> DataFrame:
    """
    Load standards data for a given technology from Delta Lake

    Args:
        spark: SparkSession
        tech: Technology identifier
        config: Configuration dict with 'std_path' key

    Returns:
        PySpark DataFrame with standards data

    Raises:
        Exception: If loading fails
    """
    print(f"Loading {tech} standards...")

    try:
        df = spark.read.format("delta").load(
            f"abfs://raw@lnipdevstorage.dfs.core.windows.net/release/test/essentiality_v2/{std_path}"
        )
        print(f"  ✓ Loaded {df.count():,} standards records")
        return df
    except Exception:
        print("  ⚠ Error loading standards")
        raise


def load_tokenized_text(spark: SparkSession, tech: str, text_type: str) -> DataFrame:
    """
    Load consolidated tokenized/preprocessed text from Delta Lake

    Args:
        spark: SparkSession
        tech: Technology identifier
        text_type: Type of text ('claims', 'abs_title', 'std_text')

    Returns:
        PySpark DataFrame with tokenized text filtered by technology

    Raises:
        ValueError: If text_type is unknown
        Exception: If loading fails
    """
    print(f"Loading {tech} tokenized {text_type}...")

    base_path = "abfs://ipdata@datapipelinelake.dfs.core.windows.net/ipdata/curated/essentiality_v2"

    if text_type == "claims":
        path = f"{base_path}/preprocessed_claims"
    elif text_type == "abs_title":
        path = f"{base_path}/preprocessed_abs_title"
    elif text_type == "std_text":
        path = f"{base_path}/preprocessed_std_text"
    else:
        raise ValueError(f"Unknown text_type: {text_type}")

    try:
        df = spark.read.format("delta").load(path).filter(F.col("tech") == tech)
        print(f"  ✓ Loaded {df.count():,} tokenized records")
        return df
    except Exception:
        print("  ⚠ Error loading tokenized text")
        raise


def load_vectors(spark: SparkSession, tech: str) -> DataFrame:
    """
    Load pre-trained vector embeddings for a technology

    Args:
        spark: SparkSession
        tech: Technology identifier

    Returns:
        PySpark DataFrame with vector embeddings

    Raises:
        Exception: If loading fails
    """
    print(f"Loading {tech} vectors...")

    base_path = "abfs://ipdata@datapipelinelake.dfs.core.windows.net/ipdata/curated/essentiality_v2"
    path = f"{base_path}/{tech}_vectors"

    try:
        df = spark.read.format("delta").load(path)
        print(f"  ✓ Loaded {df.count():,} vector records")
        return df
    except Exception:
        print("  ⚠ Error loading vectors")
        raise


# ============================================================================
# PART 2: TEXT EXTRACTION FUNCTIONS
# ============================================================================


def get_claims_text(df: DataFrame) -> DataFrame:
    """
    Extract claims text from patent declarations

    Args:
        df: PySpark DataFrame with 'publication_number' and 'claims' columns

    Returns:
        PySpark DataFrame with columns:
        - publication_number: Patent publication number
        - claim_id: Unique claim identifier
        - text: Claim content (200-2500 characters)

    Filters:
        - Claims array length > 5 characters
        - Individual claim length between 200-2500 characters

    Raises:
        Exception: If extraction fails
    """
    print("Extracting claims text...")

    # Define schema for claims array
    claims_schema = ArrayType(
        StructType(
            [
                StructField("claim_id", StringType(), nullable=False),
                StructField("claim_content", StringType(), nullable=False),
            ]
        )
    )

    try:
        result = (
            df.select("publication_number", "claims")
            .dropDuplicates()
            .filter(F.length(F.col("claims")) > 5)
            .withColumn("claims_explode", F.explode_outer(F.from_json(F.col("claims"), claims_schema)))
            .withColumn("claim_id", F.col("claims_explode.claim_id"))
            .withColumn("claim_content", F.col("claims_explode.claim_content"))
            .select("publication_number", "claim_id", "claim_content")
            .dropDuplicates()
            .filter(F.length(F.col("claim_content")).between(200, 2500))
            .withColumnRenamed("claim_content", "text")
        )

        print(f"  ✓ Extracted {result.count():,} claims")
        return result
    except Exception:
        print("  ⚠ Error extracting claims")
        raise


def get_abstract_title_text(df: DataFrame) -> DataFrame:
    """
    Extract abstract and title text from patent declarations

    Args:
        df: PySpark DataFrame with 'publication_number', 'abstract', 'title' columns

    Returns:
        PySpark DataFrame with columns:
        - publication_number: Patent publication number
        - abstract: Original patent abstract
        - title: Original patent title
        - text: Combined abstract and title (500-2600 characters)

    Filters:
        - Combined text length between 500-2600 characters

    Raises:
        Exception: If extraction fails
    """
    print("Extracting abstract & title text...")

    try:
        result = (
            df.select("publication_number", "abstract", "title")
            .dropDuplicates()
            .withColumn("abstract_title", F.concat_ws(" ", F.col("abstract"), F.col("title")))
            .filter(F.length(F.col("abstract_title")).between(500, 2600))
            .select("publication_number", "abstract", "title", F.col("abstract_title").alias("text"))
        )

        print(f"  ✓ Extracted {result.count():,} abstract/title records")
        return result
    except Exception:
        print("  ⚠ Error extracting abstract/title")
        raise


def get_section_text(df: DataFrame, tech: str) -> DataFrame:
    """
    Extract standards section text

    Args:
        df: PySpark DataFrame with section information
        tech: Technology identifier (determines section column name)

    Returns:
        PySpark DataFrame with columns:
        - most_meaningful_standard_document_id: Standard identifier
        - section_number: Section number within standard
        - text: Section content (>200 characters)

    Filters:
        - Section text length > 200 characters

    Special Handling:
        - Video technology uses 'enriched_most_meaningful_section_array' column
        - Other technologies use 'most_meaningful_section_array' column

    Raises:
        Exception: If extraction fails
    """
    print(f"Extracting standards section text for {tech}...")

    # Video uses different column name
    section_col = "enriched_most_meaningful_section_array" if tech == "video" else "most_meaningful_section_array"

    try:
        result = (
            df.select(F.col("most_meaningful_standard_document_id"), F.col(section_col))
            .dropDuplicates()
            .withColumn(section_col, F.explode_outer(F.col(section_col)))
            .withColumn("section_number", F.col(section_col).getItem(0))
            .withColumn("original_section_text", F.col(section_col).getItem(1))
            .select(
                F.col("most_meaningful_standard_document_id"), F.col("section_number"), F.col("original_section_text")
            )
            .filter(F.length(F.col("original_section_text")) > 200)
            .withColumnRenamed("original_section_text", "text")
        )

        print(f"  ✓ Extracted {result.count():,} section records")
        return result
    except Exception:
        print("  ⚠ Error extracting sections")
        raise


# ============================================================================
# PART 3: TEXT PREPROCESSING CLASS
# ============================================================================


class TextPreprocessor:
    """
    Enhanced text preprocessor for embedding models (Word2Vec, Doc2Vec, FastText)

    Preprocessing Pipeline:
    1. Unicode normalization (NFKD)
    2. Contraction expansion (e.g., "don't" → "do not")
    3. Lowercase conversion
    4. URL & email removal
    5. Extra whitespace removal
    6. Repeated character removal
    7. Tokenization using NLTK
    8. Spell correction using SymSpell
    9. POS tagging
    10. Lemmatization with POS information
    11. Stopword removal (with optional named entity preservation)

    Attributes:
        keep_named_entities (bool): Whether to preserve named entities (NNP/NNPS)
        normalize_unicode (bool): Whether to normalize unicode
        expand_contractions (bool): Whether to expand contractions
        stop_words (set): Set of stopwords
        lemmatizer: WordNetLemmatizer instance
        sym_spell: SymSpell spell checker instance
    """

    def __init__(
        self,
        language: str = "english",
        keep_named_entities: bool = True,
        normalize_unicode: bool = True,
        expand_contractions: bool = True,
    ):
        """
        Initialize text preprocessor

        Args:
            language: Language for stopwords/lemmatization (default: 'english')
            keep_named_entities: Keep NNP/NNPS tags (default: True)
            normalize_unicode: Normalize unicode characters (default: True)
            expand_contractions: Expand contractions (default: True)
        """
        self.keep_named_entities = keep_named_entities
        self.normalize_unicode = normalize_unicode
        self.expand_contractions = expand_contractions

        # Initialize NLTK components
        self.stop_words = set(stopwords.words(language))
        self.lemmatizer = WordNetLemmatizer()
        self.sym_spell = self._initialize_symspell()

        # Custom stopwords for web/technical text
        self.custom_stopwords = {"http", "https", "www", "com", "org", "net", "html", "htm"}
        self.stop_words.update(self.custom_stopwords)

    def _initialize_symspell(self) -> SymSpell:
        """
        Initialize SymSpell spell checker

        Returns:
            SymSpell instance with loaded dictionary
        """
        sym_spell = SymSpell(max_dictionary_edit_distance=2, prefix_length=7)
        dictionary_path = pkg_resources.resource_filename("symspellpy", "frequency_dictionary_en_82_765.txt")
        sym_spell.load_dictionary(dictionary_path, term_index=0, count_index=1)
        return sym_spell

    @staticmethod
    def get_wordnet_pos(treebank_tag: str):
        """
        Convert treebank POS tags to WordNet POS tags for better lemmatization

        Args:
            treebank_tag: POS tag from NLTK pos_tag

        Returns:
            WordNet POS constant (ADJ, VERB, NOUN, ADV, or NOUN as default)
        """
        if treebank_tag.startswith("J"):
            return wordnet.ADJ
        elif treebank_tag.startswith("V"):
            return wordnet.VERB
        elif treebank_tag.startswith("N"):
            return wordnet.NOUN
        elif treebank_tag.startswith("R"):
            return wordnet.ADV
        else:
            return wordnet.NOUN

    def normalize_text(self, text: str) -> str:
        """
        Normalize unicode characters

        Args:
            text: Input text

        Returns:
            Unicode-normalized text
        """
        if self.normalize_unicode:
            text = unicodedata.normalize("NFKD", text)
            text = text.encode("ascii", "ignore").decode("ascii")
        return text

    def expand_contractions_text(self, text: str) -> str:
        """
        Expand contractions in text

        Args:
            text: Input text

        Returns:
            Text with contractions expanded
        """
        if self.expand_contractions:
            text = contractions.fix(text)
        return text

    def clean_text(self, text: str) -> str:
        """
        Clean text by removing URLs, emails, etc.

        Args:
            text: Input text

        Returns:
            Cleaned text
        """
        # Remove URLs
        text = re.sub(r"https?://(?:[a-zA-Z\d$\-_@.&+!*\\(),]|%[\da-fA-F]{2})+", "", text)

        # Remove email addresses
        text = re.sub(r"\S+@\S+", "", text)

        # Remove extra whitespace
        text = re.sub(r"\s+", " ", text)

        # Remove repeated characters (e.g., "sooooo" -> "so")
        text = re.sub(r"(.)\1{2,}", r"\1\1", text)

        return text.strip()

    @staticmethod
    def is_valid_token(token: str) -> bool:
        """
        Check if token meets validity criteria

        Args:
            token: Input token

        Returns:
            True if valid, False otherwise
        """
        # Skip all digits or all punctuation
        if token.isdigit() or all(c in string.punctuation for c in token):
            return False

        # Skip repeated characters
        if len(set(token)) == 1:
            return False

        return True

    def _correct_spelling(self, tokens: List[str]) -> List[str]:
        """
        Apply spell correction to tokens

        Args:
            tokens: List of tokens

        Returns:
            List of corrected tokens
        """
        corrected_tokens = []
        for token in tokens:
            if len(token) > 1:
                suggestions = self.sym_spell.lookup(token, Verbosity.CLOSEST, max_edit_distance=2)
                corrected_tokens.append(suggestions[0].term if suggestions else token)
            else:
                corrected_tokens.append(token)
        return corrected_tokens

    def _should_keep_token(self, token: str, pos: str) -> bool:
        """
        Determine if a token should be kept based on stopwords and named entities

        Args:
            token: The token to check
            pos: POS tag

        Returns:
            True if token should be kept, False otherwise
        """
        if token in self.stop_words:
            return self.keep_named_entities and pos in ["NNP", "NNPS"]
        return True

    def _lemmatize_and_filter(self, pos_tags: List[tuple]) -> List[str]:
        """
        Lemmatize tokens and filter invalid ones

        Args:
            pos_tags: List of (token, pos) tuples

        Returns:
            List of processed tokens
        """
        processed_tokens = []
        for token, pos in pos_tags:
            if not self.is_valid_token(token):
                continue

            if not self._should_keep_token(token, pos):
                continue

            wordnet_pos = self.get_wordnet_pos(pos)
            lemmatized = self.lemmatizer.lemmatize(token, pos=wordnet_pos)

            if self.is_valid_token(lemmatized):
                processed_tokens.append(lemmatized)

        return processed_tokens

    def preprocess_text(self, text: str) -> List[str]:
        """
        Preprocess single text through complete pipeline

        Args:
            text: Input text

        Returns:
            List of processed tokens
        """
        if not isinstance(text, str) or not text.strip():
            return []

        # Step 1-4: Normalize, expand, lowercase, clean
        text = self.normalize_text(text)
        text = self.expand_contractions_text(text)
        text = text.lower()
        text = self.clean_text(text)

        # Step 5: Remove punctuation (except periods)
        text = re.sub(r"[^\w\s\.]", " ", text)
        text = re.sub(r"\.{2,}", ".", text)

        # Step 6: Tokenize
        tokens = word_tokenize(text)

        # Step 7: Spell correction
        corrected_tokens = self._correct_spelling(tokens)

        # Step 8: POS tagging
        pos_tags = pos_tag(corrected_tokens)

        # Step 9: Lemmatization and filtering
        return self._lemmatize_and_filter(pos_tags)

    def preprocess_dataset(self, df: DataFrame) -> DataFrame:
        """
        Preprocess all texts in a Spark DataFrame

        Args:
            df: PySpark DataFrame with 'text' column

        Returns:
            DataFrame with added columns:
            - processed_tokens: Array<String> of cleaned tokens
            - processed_text: String (space-joined tokens)
        """
        # Define UDF for preprocessing
        preprocess_udf = F.udf(self.preprocess_text, ArrayType(StringType()))

        # Apply preprocessing
        result = df.withColumn("processed_tokens", preprocess_udf(F.col("text"))).withColumn(
            "processed_text", F.concat_ws(" ", F.col("processed_tokens"))
        )

        return result


# ============================================================================
# PART 4: VALIDATION FUNCTIONS
# ============================================================================


def validate_preprocessed_data(df: DataFrame, text_type: str) -> Dict[str, Any]:
    """
    Validate preprocessed data quality

    Args:
        df: PySpark DataFrame with preprocessed data
        text_type: Type of text ('claims', 'abs_title', 'std_text')

    Returns:
        Dictionary with validation metrics:
        - total_records: Total number of records
        - null_tokens: Count of null token arrays
        - empty_tokens: Count of empty token arrays
        - avg_tokens_per_record: Average tokens per record
    """
    print(f"\nValidating {text_type} data...")

    metrics = {
        "total_records": df.count(),
        "null_tokens": df.filter(F.col("processed_tokens").isNull()).count(),
        "empty_tokens": df.filter(F.size(F.col("processed_tokens")) == 0).count(),
        "avg_tokens_per_record": df.select(F.avg(F.size(F.col("processed_tokens")))).collect()[0][0],
    }

    print(f"  Total records: {metrics['total_records']:,}")
    print(f"  Null tokens: {metrics['null_tokens']}")
    print(f"  Empty tokens: {metrics['empty_tokens']}")
    print(f"  Avg tokens per record: {metrics['avg_tokens_per_record']:.2f}")

    return metrics


def get_data_summary(
    claims_df: DataFrame, abs_title_df: DataFrame, std_text_df: DataFrame
) -> Dict[str, Dict[str, int]]:
    """
    Get summary statistics for all preprocessed data

    Args:
        claims_df: Claims dataframe
        abs_title_df: Abstract/title dataframe
        std_text_df: Standards dataframe

    Returns:
        Dictionary with summary by text type:
        {
            'claims': {'total': int, 'techs': int},
            'abstracts': {'total': int, 'techs': int},
            'standards': {'total': int, 'techs': int}
        }
    """
    summary = {
        "claims": {"total": claims_df.count(), "techs": claims_df.select("tech").distinct().count()},
        "abstracts": {"total": abs_title_df.count(), "techs": abs_title_df.select("tech").distinct().count()},
        "standards": {"total": std_text_df.count(), "techs": std_text_df.select("tech").distinct().count()},
    }

    return summary


# ============================================================================
# INITIALIZATION MESSAGE
# ============================================================================

print("✓ Essentiality utilities module loaded successfully")
