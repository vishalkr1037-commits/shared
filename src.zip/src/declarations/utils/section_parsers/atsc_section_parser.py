import re
from collections import OrderedDict
from typing import Dict, List


class AtscEncodingSectionParser:
    """Parser for extracting sections from ATSC standards documents."""

    # Special ATSC standards with predefined indexes
    ATSC_A324_SIGNATURE = "ATSC A/324:2022-06"
    ATSC_A331_SIGNATURE = "ATSC A/331:2022-03"

    @staticmethod
    def parse_index(full_text: str) -> OrderedDict[str, str]:
        """
        Parse the index from ATSC standard text.

        Handles special cases for A/324 and A/331 standards,
        otherwise extracts index dynamically from the text.

        Args:
            full_text: Complete standard document text

        Returns:
            OrderedDict mapping section number -> section title
        """
        if AtscEncodingSectionParser.ATSC_A324_SIGNATURE in full_text:
            return AtscEncodingSectionParser._get_predefined_index("ATSC_A324")
        elif AtscEncodingSectionParser.ATSC_A331_SIGNATURE in full_text:
            return AtscEncodingSectionParser._get_predefined_index("ATSC_A331")

        # Dynamic index extraction from content
        return AtscEncodingSectionParser._extract_index_from_content(full_text)

    @staticmethod
    def _get_predefined_index(standard_id: str) -> OrderedDict[str, str]:
        """Get predefined index for known standards (placeholder for CSV loading)."""
        # In production, load from CSV file
        # For now, return empty dict - would be loaded from resources
        return OrderedDict()

    @staticmethod
    def _extract_index_from_content(full_text: str) -> OrderedDict[str, str]:
        """Extract index dynamically from standard text content."""
        index_content_list = AtscEncodingSectionParser._get_index_content_stream(full_text)
        result = OrderedDict()

        for line in index_content_list:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                section_num = parts[0].strip()
                section_title = parts[1].strip()
                result[section_num] = section_title

        return result

    @staticmethod
    def _get_index_content_stream(full_text: str) -> List[str]:
        """Extract index content as list of strings."""
        header_footer_free = AtscEncodingSectionParser.clean_header_footer(full_text)
        index_list = AtscEncodingSectionParser._extract_index(header_footer_free)
        return [line.strip() for line in index_list]

    @staticmethod
    def _extract_index(full_text: str) -> List[str]:
        """Extract index sections from text."""
        # Split by 10+ dots (standard index delimiter)
        parts = re.split(r"\.{10,}", full_text)

        # Process all parts except the last
        result = []
        for part in parts[:-1]:
            sub_indices = AtscEncodingSectionParser._split_sub_index(part)
            result.extend(sub_indices)

        return result

    @staticmethod
    def _split_sub_index(full_text: str) -> List[str]:
        """Split sub-indices and filter valid index lines."""
        # Regex: split on section number pattern (e.g., "2.3.4A")
        pattern = r"(?=(\s(((?!0\\b)\d{1,3}\\.)+((?!0\\b)\d{1,3})?)(\s)))"
        parts = re.split(pattern, full_text)

        result = []
        for part in parts:
            part = part.strip()
            if not part:
                continue

            # Filter valid index lines
            if not AtscEncodingSectionParser._is_index_line(part):
                continue

            # Clean up the line
            part = AtscEncodingSectionParser._remove_repetitive_words(part)
            part = AtscEncodingSectionParser._drop_leading_number(part)

            if part:
                result.append(part)

        return result

    @staticmethod
    def _is_index_line(line: str) -> bool:
        """Check if line matches index pattern."""
        pattern = r"^(((?!0\b)\d{1,3}\.)+(?!0\b)\d{1,3}?)(\s)[\s\S]{1,200}"
        return bool(re.match(pattern, line))

    @staticmethod
    def _remove_repetitive_words(line: str) -> str:
        """Remove repetitive index words like Figure, Table, ANNEX."""
        # Remove "Index of Figures and Tables"
        line = re.sub(r"Index of Figures and Tables [\s\S]+", "", line)

        # Remove Figure, Table, ANNEX entries
        for word in ["Figure", "Table", "ANNEX"]:
            line = re.sub(rf"{word}\s[\w:]\s[\s\S]+", "", line)

        return line.strip()

    @staticmethod
    def _drop_leading_number(line: str) -> str:
        """Remove trailing page numbers from index lines."""
        parts = line.rsplit(" ", 1)
        if len(parts) == 2 and parts[1].isdigit():
            return parts[0].strip()
        return line

    @staticmethod
    def clean_header_footer(full_text: str) -> str:
        """Remove header/footer patterns from standard document."""
        pattern = r"ATSC(\s)A(\/)(\\d{3})(-\\d{1})?[\s\S]{1,150}(\s)(vii|vi|v|iv|iii|ii|i)(\s)"
        match = re.search(pattern, full_text)

        if match:
            header_footer = match.group()
            # Remove page number suffix
            header_footer_no_page = header_footer[:-3]
            # Remove from text
            full_text = re.sub(re.escape(header_footer_no_page) + r"\s[\s\S]{1,3}\s", "", full_text)

        return full_text

    @staticmethod
    def parse_section_content(full_text: str, index: Dict[str, str], section_reference: str) -> str:
        """
        Extract content for a specific section.

        Args:
            full_text: Complete document text
            index: Map of section numbers to titles
            section_reference: Section number to extract (e.g., "2.3.4")

        Returns:
            Section content as string
        """
        if section_reference not in index:
            return ""

        lower_boundary = AtscEncodingSectionParser._get_section_lower_boundary(index, section_reference)
        upper_boundary = AtscEncodingSectionParser._get_section_upper_boundary_same_level(index, section_reference)

        text_without_index = AtscEncodingSectionParser._skip_index(full_text)
        return AtscEncodingSectionParser._extract_section_content(text_without_index, lower_boundary, upper_boundary)

    @staticmethod
    def _get_section_lower_boundary(index: Dict[str, str], section_ref: str) -> str:
        """Get the starting boundary for a section."""
        return f"{section_ref} {index[section_ref]}"

    @staticmethod
    def _get_section_upper_boundary_same_level(index: Dict[str, str], section_ref: str) -> str:
        """Get the ending boundary for a section (next same or higher level)."""
        next_sections = AtscEncodingSectionParser._build_next_sections_above_level(section_ref)

        for next_section in next_sections:
            if next_section in index:
                return f"{next_section} {index[next_section]}"

        return "Annex"

    @staticmethod
    def _extract_section_content(full_text: str, lower_boundary: str, upper_boundary: str) -> str:
        """Extract text between two boundaries."""
        if lower_boundary not in full_text:
            return ""

        if full_text.endswith(lower_boundary):
            return ""

        if upper_boundary not in full_text:
            return ""

        try:
            # Extract between boundaries
            start_idx = full_text.find(lower_boundary) + len(lower_boundary)
            end_idx = full_text.find(upper_boundary, start_idx)

            if end_idx <= start_idx:
                return ""

            return full_text[start_idx:end_idx].strip()
        except Exception:
            return ""

    @staticmethod
    def _skip_index(full_text: str) -> str:
        """Skip to the main content (after index)."""
        parts = re.split(r"\.{10,}", full_text)
        return parts[-1] if parts else ""

    @staticmethod
    def _build_next_sections_above_level(reference_section: str) -> List[str]:
        """Build list of potential next sections at same or higher level."""
        result = []
        lowest_next = AtscEncodingSectionParser._build_next_section_same_level(reference_section)
        result.append(lowest_next)

        if "." in reference_section:
            parts = lowest_next.split(".")
            for i in range(len(parts) - 2, -1, -1):
                if parts[i].isdigit():
                    next_level = int(parts[i]) + 1
                    current = ".".join(parts[:i] + [str(next_level)])
                    result.append(current)

        return result

    @staticmethod
    def _build_next_section_same_level(reference_section: str) -> str:
        """Build the next section at the same level."""
        if "." not in reference_section:
            if reference_section.isdigit():
                return str(int(reference_section) + 1)
            return ""

        parts = reference_section.split(".")
        last_part = parts[-1]

        # Handle numeric last part
        if re.match(r"^\d+$", last_part):
            next_num = str(int(last_part) + 1)
            return ".".join(parts[:-1] + [next_num])

        # Handle alphanumeric (e.g., "3A")
        match = re.match(r"^(\d+)", last_part)
        if match:
            num = int(match.group(1))
            suffix = last_part[len(match.group(1)) :]
            next_num = str(num + 1) + suffix
            return ".".join(parts[:-1] + [next_num])

        return ""
