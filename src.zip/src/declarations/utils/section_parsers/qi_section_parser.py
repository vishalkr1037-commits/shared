import re
from collections import OrderedDict
from typing import Dict, List


class QiSectionParser:
    """Parser for extracting sections from Qi standards documents."""

    @staticmethod
    def parse_index(full_text: str) -> OrderedDict[str, str]:
        """
        Parse the index from Qi standard text.

        Args:
            full_text: Complete standard document text

        Returns:
            OrderedDict mapping section number -> section title
        """
        index_content_list = QiSectionParser._get_index_content_stream(full_text)
        result = OrderedDict()

        for line in index_content_list:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                section_num = parts[0].strip()
                section_title = parts[1].strip()
                result[section_num] = section_title

        return result

    @staticmethod
    def _get_index_content_stream(full_text: str) -> List[str]:
        """Extract index content as list of strings."""
        header_footer_free = QiSectionParser.clean_header_footer(full_text)

        # Split by 10+ dots or ". " repeated 10+ times
        parts = re.split(r"\.{10,}|(?:\.\s){10,}", header_footer_free)

        result = []
        for part in parts:
            part = part.strip()
            if not part:
                continue

            # Normalize whitespace: replace newlines with space and collapse multiple spaces
            part = part.replace("\n", " ")
            part = re.sub(r"\s+", " ", part)

            # Filter valid index lines
            if not QiSectionParser._is_index_line(part):
                continue

            # Drop leading number
            part = QiSectionParser._drop_leading_number(part)

            if part:
                result.append(part)

        return result

    @staticmethod
    def clean_header_footer(full_text: str) -> str:
        """Remove header/footer patterns from Qi standard document."""
        pattern = r"\bWireless Power Consortium Inc\. \d+ Version 1\.3 . WIRELESS POWER CONSORTIUM"
        match = re.search(pattern, full_text)

        if match:
            header_footer = match.group()
            # Remove header/footer with page numbers
            full_text = re.sub(r"\s+\d+\s+" + re.escape(header_footer), "", full_text)

        return full_text

    @staticmethod
    def _is_index_line(line: str) -> bool:
        """Check if line matches Qi index pattern (starts with number space number)."""
        pattern = r"^\d+ \d.*"
        return bool(re.match(pattern, line))

    @staticmethod
    def _drop_leading_number(line: str) -> str:
        """Remove leading number and space from index lines."""
        return re.sub(r"^\d+ ", "", line)

    @staticmethod
    def parse_section_content(full_text: str, index: Dict[str, str], section_reference: str) -> str:
        """
        Extract content for a specific section.

        Args:
            full_text: Complete document text
            index: Map of section numbers to titles
            section_reference: Section number to extract (e.g., "2.3.4")

        Returns:
            Section content as string
        """
        if section_reference not in index:
            return ""

        lower_boundary = QiSectionParser._get_section_lower_boundary(index, section_reference)
        upper_boundary = QiSectionParser._get_section_upper_boundary_same_level(index, section_reference)

        text_without_index = QiSectionParser._skip_index(full_text)
        return QiSectionParser._extract_section_content(text_without_index, lower_boundary, upper_boundary)

    @staticmethod
    def _get_section_lower_boundary(index: Dict[str, str], section_ref: str) -> str:
        """Get the starting boundary for a section."""
        return f"{section_ref} {index[section_ref]}"

    @staticmethod
    def _get_section_upper_boundary_same_level(index: Dict[str, str], section_ref: str) -> str:
        """Get the ending boundary for a section (next same or higher level)."""
        next_sections = QiSectionParser._build_next_sections_above_level(section_ref)

        for next_section in next_sections:
            if next_section in index:
                return f"{next_section} {index[next_section]}"

        return "Annex"

    @staticmethod
    def _extract_section_content(full_text: str, lower_boundary: str, upper_boundary: str) -> str:
        """Extract text between two boundaries."""
        if lower_boundary not in full_text:
            return ""

        if full_text.endswith(lower_boundary):
            return ""

        if upper_boundary not in full_text:
            return ""

        try:
            # Extract between boundaries
            start_idx = full_text.find(lower_boundary) + len(lower_boundary)
            end_idx = full_text.find(upper_boundary, start_idx)

            if end_idx <= start_idx:
                return ""

            return full_text[start_idx:end_idx].strip()
        except Exception:
            return ""

    @staticmethod
    def _skip_index(full_text: str) -> str:
        """Skip to the main content (after index)."""
        # Use 13+ dots or ". " repeated 10+ times
        parts = re.split(r"\.{13,}|(?:\.\s){10,}", full_text)
        return parts[-1] if parts else ""

    @staticmethod
    def _build_next_sections_above_level(reference_section: str) -> List[str]:
        """Build list of potential next sections at same or higher level."""
        result = []
        lowest_next = QiSectionParser._build_next_section_same_level(reference_section)
        result.append(lowest_next)

        if "." in reference_section:
            parts = lowest_next.split(".")
            for i in range(len(parts) - 2, -1, -1):
                if parts[i].isdigit():
                    next_level = int(parts[i]) + 1
                    current = ".".join(parts[:i] + [str(next_level)])
                    result.append(current)

        return result

    @staticmethod
    def _build_next_section_same_level(reference_section: str) -> str:
        """Build the next section at the same level."""
        if "." not in reference_section:
            if reference_section.isdigit():
                return str(int(reference_section) + 1)
            return ""

        parts = reference_section.split(".")
        last_part = parts[-1]

        # Handle numeric last part
        if re.match(r"^\d+$", last_part):
            next_num = str(int(last_part) + 1)
            return ".".join(parts[:-1] + [next_num])

        # Handle alphanumeric (e.g., "3A")
        match = re.match(r"^(\d+)", last_part)
        if match:
            num = int(match.group(1))
            suffix = last_part[len(match.group(1)) :]
            next_num = str(num + 1) + suffix
            return ".".join(parts[:-1] + [next_num])

        return ""
