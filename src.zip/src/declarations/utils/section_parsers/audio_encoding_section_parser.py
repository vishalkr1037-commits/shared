import logging
import re
from collections import OrderedDict
from typing import List


class AudioEncodingSectionParser:
    """Parser for extracting sections from audio encoding standards."""

    # Header detection patterns for specific audio standards
    HEADER_1 = "Internet Engineering Task Force (IETF) JM. Valin Request for Comments: 8251 Mozilla Corporation Updates: 6716 K. Vos Category: Standards Track vocTone ISSN: 2070-1721 October 2017"
    HEADER_2 = "Information technology — High efficiency coding and media delivery in heterogeneous environments — Part 9: 3D Audio conformance testing Technologies de l'information — Codage à haut rendement et fourniture de supports dans les environnements hétérogènes — Partie 9: Essais de conformité 3D Audio INTERNATIONAL STANDARD ISO/IEC 23008-9 Third edition 2023-05"
    HEADER_3 = "Internet Engineering Task Force (IETF) JM. Valin Request for Comments: 6716 Mozilla Corporation Category: Standards Track K. Vos ISSN: 2070-1721 Skype Technologies S.A. T. Terriberry Mozilla Corporation September 2012"
    HEADER_4 = "Reference number ISO/IEC 13818-7:2006(E) © ISO/IEC 2006 INTERNATIONAL STANDARD ISO/IEC 13818-7 Fourth edition 2006-01-15"
    HEADER_5 = "Information technology — Coding of audio-visual objects — Part 3: Audio Technologies de l'information — Codage des objets audiovisuels — Partie 3: Codage audio INTERNATIONAL STANDARD ISO/IEC 14496-3 Reference number ISO/IEC 14496-3:2019(E)"
    HEADER_6 = "Internet Engineering Task Force (IETF) J. Skoglund Request for Comments: 8486 Google LLC Updates: 7845 M. Graczyk Category: Standards Track October 2018 ISSN: 2070-1721"
    HEADER_7 = "Information technology — High efficiency coding and media delivery in heterogeneous environments — Part 3: 3D audio Technologies de l'information — Codage à haute efficacité et livraison des medias dans des environnements hétérogènes — Partie 3: Audio 3D INTERNATIONAL STANDARD ISO/IEC 23008-3 Third edition 2022-08 Reference number ISO/IEC 23008-3:2022(E)"

    @staticmethod
    def parse_index(full_text: str) -> OrderedDict[str, str]:
        """
        Parse the index from audio encoding standard text.
        Detects specific standards and loads from CSV or falls back to text parsing.

        Args:
            full_text: Complete standard document text

        Returns:
            OrderedDict mapping section number -> section title
        """
        full_text = AudioEncodingSectionParser.clean_header_footer(full_text)

        # Check for specific audio standard headers
        if full_text.startswith(AudioEncodingSectionParser.HEADER_1):
            return AudioEncodingSectionParser._get_index_from_csv("1_IETF_2017.csv")
        elif full_text.startswith(AudioEncodingSectionParser.HEADER_2):
            return AudioEncodingSectionParser._get_index_from_csv("2_ISO_IEC_2023.csv")
        elif full_text.startswith(AudioEncodingSectionParser.HEADER_3):
            return AudioEncodingSectionParser._get_index_from_csv("3_IETF_2012.csv")
        elif full_text.startswith(AudioEncodingSectionParser.HEADER_4):
            return AudioEncodingSectionParser._get_index_from_csv("4_AAC_2006.csv")
        elif full_text.startswith(AudioEncodingSectionParser.HEADER_5):
            return AudioEncodingSectionParser._get_index_from_csv("5_ISO_IEC_2019.csv")
        elif full_text.startswith(AudioEncodingSectionParser.HEADER_6):
            return AudioEncodingSectionParser._get_index_from_csv("6_IETF_2018.csv")
        elif full_text.startswith(AudioEncodingSectionParser.HEADER_7):
            return AudioEncodingSectionParser._get_index_from_csv("7_ISO_IEC_2022.csv")

        # Fallback to text parsing
        index_content_list = AudioEncodingSectionParser._get_index_content_stream(full_text)
        result = OrderedDict()

        for line in index_content_list:
            parts = line.split(" ", 1)
            if len(parts) == 2:
                section_num = parts[0].strip()
                section_title = parts[1].strip()
                result[section_num] = section_title

        return result

    @staticmethod
    def _get_index_from_csv(csv_file: str) -> OrderedDict[str, str]:
        """Load index from CSV file in AE_standards directory with '#' delimiter."""
        result = OrderedDict()

        try:
            import csv
            import os

            # Try to find the CSV file in resources
            resource_path = os.path.join(
                os.path.dirname(__file__), "..", "..", "..", "..", "resources", "AE_standards", csv_file
            )

            if os.path.exists(resource_path):
                with open(resource_path, "r", encoding="utf-8") as f:
                    reader = csv.DictReader(f, delimiter="#")
                    for row in reader:
                        values = list(row.values())
                        if len(values) >= 2:
                            section_num = values[0].strip()
                            section_title = values[1].strip()
                            result[section_num] = section_title
            else:
                logging.debug(f"CSV file not found: {resource_path}, falling back to text parsing")
        except Exception as e:
            logging.warning(f"Failed to load CSV index from {csv_file}: {e}")

        return result

    @staticmethod
    def _get_index_content_stream(full_text: str) -> List[str]:
        """Extract index content as list of strings."""
        header_footer_free = AudioEncodingSectionParser.clean_header_footer(full_text)

        # Split by 5+ dots or ". " repeated 5+ times
        parts = re.split(r"\.{5,}|(?:\.\s){5,}", header_footer_free)

        result = []
        for part in parts:
            part = part.strip()
            if not part:
                continue

            # Filter valid index lines
            if not AudioEncodingSectionParser._is_index_line(part):
                continue

            # Drop leading number/roman numeral
            part = AudioEncodingSectionParser._drop_leading_number(part)

            if part:
                result.append(part)

        return result

    @staticmethod
    def clean_header_footer(full_text: str) -> str:
        """Remove header/footer patterns from audio encoding standard documents."""
        # Typo fix
        full_text = full_text.replace(
            "4.2.7.5. Normalized Line Spectral Frequency (LSF) and Linear Predictive Coding (LPC) Coeffieients",
            "4.2.7.5. Normalized Line Spectral Frequency (LSF) and Linear Predictive Coding (LPC) Coefficients",
        )

        # ISO/IEC copyright patterns
        full_text = re.sub(
            r"^© ISO/IEC \d{4} – All rights reserved Licensed to .+? \(.+?@.+?\) ISO Store Order: OP-\d+ license #\d+/ Downloaded: \d{4}-\d{2}-\d{2} Single user licence only, copying and networking prohibited\. ISO/IEC \d{5}-\d:\d+\(\w+\)$",
            "",
            full_text,
            flags=re.MULTILINE,
        )

        full_text = re.sub(
            r"© ISO/IEC 2023 – All rights reserved \d* Licensed to IPlytics GmbH / Tim Pohlmann \(pohlmann@iplytics\.com\) ISO Store Order: OP-842610 license #1/ Downloaded: 2024-11-14 Single user licence only, copying and networking prohibited\. ISO/IEC 23008-9:2023\(E\)",
            "",
            full_text,
        )

        full_text = re.sub(
            r"© ISO/IEC 2023 – All rights reserved \d* Licensed to IPlytics GmbH / Tim Pohlmann \(pohlmann@iplytics\.com\) ISO Store Order: OP-842610 license #1/ Downloaded: 2024-11-14 Single user licence only, copying and networking prohibited\. https://standards\.iso\.org/iso-iec/23008/-9/ed-3/en https://standards\.iso\.org/iso-iec/23008/-9/ed-3/en ISO/IEC 23008-9:2023\(E\)",
            "",
            full_text,
        )

        full_text = full_text.replace(
            "© ISO/IEC 2023 – All rights reserved Licensed to IPlytics GmbH / Tim Pohlmann (pohlmann@iplytics.com) ISO Store Order: OP-842610 license #1/ Downloaded: 2024-11-14 Single user licence only, copying and networking prohibited. https://www.iso.org ISO/IEC 23008-9:2023(E)",
            "",
        )

        full_text = full_text.replace(
            "© ISO/IEC 2023 – All rights reserved Licensed to IPlytics GmbH / Tim Pohlmann (pohlmann@iplytics.com)\nISO Store Order: OP-842610 license #1/ Downloaded: 2024-11-14\nSingle user licence only, copying and networking prohibited. ISO/IEC 23008-9:2023(E)",
            "",
        )

        full_text = full_text.replace(
            "© ISO/IEC 2023 – All rights reserved Licensed to IPlytics GmbH / Tim Pohlmann (pohlmann@iplytics.com) ISO Store Order: OP-842610 license #1/ Downloaded: 2024-11-14 Single user licence only, copying and networking prohibited. ISO/IEC 23008-9:2023(E)",
            "",
        )

        full_text = full_text.replace(
            "© ISO/IEC 2023 – All rights reserved Contents Page Licensed to IPlytics GmbH / Tim Pohlmann (pohlmann@iplytics.com) ISO Store Order: OP-842610 license #1/ Downloaded: 2024-11-14 Single user licence only, copying and networking prohibited. ISO/IEC 23008-9:2023(E)",
            "",
        )

        full_text = full_text.replace(
            "Licensed to IPlytics GmbH / Tim Pohlmann (pohlmann@iplytics.com) ISO Store Order: OP-842610 license #1/ Downloaded: 2024-11-14 Single user licence only, copying and networking prohibited.",
            "",
        )

        return full_text

    @staticmethod
    def _is_index_line(line: str) -> bool:
        """
        Check if line matches audio encoding standard index pattern.
        Pattern: roman/arabic numeral, space, digits with dots, optional dot, text with letter.
        """
        pattern = r"^(?:[1-9]\d*|[ivxlcdmIVXLCDM]+) \d+(?:\.\d+)*\.?.* [A-Za-z].*$"
        return bool(re.match(pattern, line))

    @staticmethod
    def _drop_leading_number(line: str) -> str:
        """Remove leading number or roman numeral and space from index lines."""
        return re.sub(r"^(?:[1-9]\d*|[ivxlcdmIVXLCDM]+) ", "", line)

    @staticmethod
    def extract_section_content(full_text: str, lower_boundary: str, upper_boundary: str) -> str:
        """
        Extract content for a specific section using word boundaries.

        Args:
            full_text: Full document text
            lower_boundary: Starting boundary (section number + title)
            upper_boundary: Ending boundary (next section or "Annex")

        Returns:
            Section content as string
        """
        # Quick checks for missing boundaries
        if lower_boundary not in full_text:
            return ""

        if full_text.endswith(lower_boundary):
            return ""

        if upper_boundary not in full_text:
            return ""

        try:
            # Escape regex special characters
            lower_escaped = AudioEncodingSectionParser._escape_regex_special_chars(lower_boundary)
            upper_escaped = AudioEncodingSectionParser._escape_regex_special_chars(upper_boundary)

            # Use word boundaries for splitting
            text_parts = re.split(r"\b" + lower_escaped + r"\s\b", full_text)

            if len(text_parts) < 2:
                correct_part = text_parts[0]
            else:
                correct_part = text_parts[1]

            # Extract between boundaries
            content = re.split(r"\b" + upper_escaped + r"\s\b", correct_part)[0].strip()
            return content
        except Exception as e:
            logging.warning(f"Failed to extract section content: {e}")
            return ""

    @staticmethod
    def _escape_regex_special_chars(text: str) -> str:
        """Escape special regex characters in a string."""
        special_chars = r"[]\()|*+.?"
        escaped = text
        for char in special_chars:
            escaped = escaped.replace(char, "\\" + char)
        return escaped
