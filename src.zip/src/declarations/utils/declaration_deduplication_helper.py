import csv
from collections import defaultdict
from pathlib import Path

import pandas as pd
from pyspark.broadcast import Broadcast
from pyspark.sql import SparkSession
from pyspark.sql.functions import pandas_udf, udf
from pyspark.sql.types import BooleanType


def is_applicant_assignee_first_word_contained_in_declaring_company(
    concatenated_assignees_applicants: list[str], harmonized_company_name: list[str]
) -> bool:
    if not (concatenated_assignees_applicants and harmonized_company_name):
        return False

    declaring_companies = {company.lower() for company in harmonized_company_name if company}
    if not declaring_companies:
        return False

    for entry in concatenated_assignees_applicants:
        if entry:
            first_word = entry.strip().split(" ")[0].lower()
            if len(first_word) >= 2 and any(first_word in company for company in declaring_companies):
                return True

    return False


@udf(returnType=BooleanType())
def is_applicant_assignee_first_word_contained_in_declaring_company_udf(
    concatenated_assignees_applicants, harmonized_company_name
):
    return is_applicant_assignee_first_word_contained_in_declaring_company(
        concatenated_assignees_applicants, harmonized_company_name
    )


def is_declaring_company_first_word_contained_in_applicant_assignee(
    concatenated_assignees_applicants: list[str], harmonized_company_name: list[str], seps_data: dict[str, set[str]]
) -> bool:
    """
    Check if the first word of any harmonized company name is contained in any of the
    concatenated assignees/applicants strings or in the company aliases.
    """
    if not concatenated_assignees_applicants or not harmonized_company_name:
        return False

    # Clean up the first words of harmonized company names
    cleaned_first_words = get_cleaned_first_words(harmonized_company_name)

    # Check if any first word is in applicants or aliases
    return any(
        is_first_word_in_applicant(first_word, concatenated_assignees_applicants, seps_data)
        for first_word in cleaned_first_words
    )


def get_cleaned_first_words(harmonized_company_name: list[str]) -> list[str]:
    """
    Returns a list of the first words of the harmonized company names, cleaned and lowercased.
    """
    return [company.strip().split(" ")[0].lower().replace(",", "") for company in harmonized_company_name if company]


def is_first_word_in_applicant(first_word: str, applicants: list[str], seps_data: dict[str, set[str]]) -> bool:
    """
    Checks if the first word is contained in any of the applicant/assignee strings or their aliases.
    """
    for applicant in applicants:
        if applicant and first_word in applicant.lower():
            return True
        if is_applicant_assignee_contained_in_company_aliases(applicant, first_word, seps_data):
            return True
    return False


def is_applicant_assignee_contained_in_company_aliases(
    applicant_assignee: str, declaring_company: str, company_aliases: dict[str, set[str]]
) -> bool:
    """
    Checks if the applicant/assignee is contained in the company aliases of the declaring company.

    :param applicant_assignee: The applicant/assignee string.
    :param declaring_company: The declaring company string.
    :param company_aliases: A dictionary where keys are group names and values are sets of aliases.
    :return: True if the applicant/assignee is contained in the company aliases of the declaring company, False otherwise.
    """
    if not applicant_assignee or not declaring_company or not company_aliases:
        return False
    applicant_assignee = applicant_assignee.lower()
    declaring_company = declaring_company.lower()

    group_name_applicants = set()
    group_name_declaring_company = set()

    for group_name, aliases in company_aliases.items():
        aliases = [entry.lower() for entry in aliases]
        if any(alias in applicant_assignee for alias in aliases):
            group_name_applicants.add(group_name)
        if any(declaring_company in alias for alias in aliases):
            group_name_declaring_company.add(group_name)
    return bool(group_name_applicants & group_name_declaring_company)


@udf(returnType=BooleanType())
def is_applicant_assignee_contained_in_company_aliases_udf(applicant_assignee, declaring_company, company_aliases):
    return is_applicant_assignee_contained_in_company_aliases(applicant_assignee, declaring_company, company_aliases)


def init_company_aliases_csv_for_matching():
    """
    Reads a CSV file and extracts a dictionary where keys are group_name and values are sets of aliases.

    :return: A dictionary with group_name as keys and sets of aliases as values.
    """
    resource_path = Path(__file__).resolve().parent.parent / "resources"
    resource_name = "sep_demo_groups_data_improved_only_seps.csv"
    file_path = resource_path / resource_name

    company_aliases = defaultdict(set)

    with open(file_path, mode="r", encoding="utf-8") as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            group_name = row["group_name"].strip().lower()
            company_aliases[group_name].add(group_name)
            group_entries = row["group_entries"].split("|")
            for entry in group_entries:
                company_aliases[group_name].add(entry.strip().lower())

    return company_aliases


broadcast_aliases: Broadcast = None
company_aliases_dict = None


def init(spark: SparkSession):
    """
    Initializes the broadcast variable for company aliases.

    :param sprk: The Spark session.
    """
    global broadcast_aliases
    global company_aliases_dict

    # Initialize the company aliases dictionary and broadcast it
    company_aliases_dict = init_company_aliases_csv_for_matching()
    broadcast_aliases = spark.sparkContext.broadcast(company_aliases_dict)


@pandas_udf(BooleanType())
def is_declaring_company_first_word_contained_in_applicant_assignee_udf_pandas(applicants, companies):
    global broadcast_aliases
    seps_data = broadcast_aliases.value

    results = []
    for applicants_list, company_list in zip(applicants, companies):
        try:
            results.append(
                is_declaring_company_first_word_contained_in_applicant_assignee(
                    applicants_list, company_list, seps_data
                )
            )
        except Exception:
            results.append(False)
    return pd.Series(results)


@udf(returnType=BooleanType())
def is_declaring_company_first_word_contained_in_applicant_assignee_udf(
    concatenated_assignees_applicants, harmonized_company_name
):
    global company_aliases_dict
    if company_aliases_dict is None:
        company_aliases_dict = init_company_aliases_csv_for_matching()

    return is_declaring_company_first_word_contained_in_applicant_assignee(
        concatenated_assignees_applicants, harmonized_company_name, company_aliases_dict
    )
