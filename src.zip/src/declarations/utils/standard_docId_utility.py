import re
from typing import Optional, Tuple

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

# Patterns
number_pattern = re.compile(r"1?\d{2}[.\s]?\d{3}(-\d{1})?")
number_pattern_etsi_style = re.compile(r"1\d{2}\s\d{3}(-\d{1})?")
version_pattern = re.compile(r"\d+(\.\d+)*(-\d{1})?")
prefixes = ["TS", "TR", "CR"]


def etsi_standard_docid_to_str(docid: dict) -> str:
    return f"[{docid.get('prefix')}] [{docid.get('number')}] [{docid.get('version')}]"


def etsi_standard_docid_is_empty(docid: dict) -> bool:
    return not docid.get("prefix") and not docid.get("number") and not docid.get("version")


def parse_ignore_version(std_doc_id: str) -> dict:
    etsi_standard_doc_id = parse(std_doc_id)
    return {"prefix": etsi_standard_doc_id.get("prefix"), "number": etsi_standard_doc_id.get("number")}


def separate_inside_parenthesis_from_outside(s: str) -> Tuple[str, str]:
    if not s:
        return ("", "NOT_FOUND")

    start = s.find("(")
    if start == -1:
        return (s, "NOT_FOUND")

    end = s.find(")", start)
    if end == -1:
        return (s, "NOT_FOUND")

    inside = s[start + 1 : end]
    return (s, inside)


prefixes = ["TS", "TR", "EN", "ISO", "IEC"]  # Add all relevant prefixes here


def parse(std_doc_id: str) -> dict:
    if not std_doc_id:
        return {"prefix": None, "number": None, "version": None}

    std_doc_id_lower = std_doc_id.lower()
    cleaned = remove_parentheses(std_doc_id_lower)

    result = {
        "version": extract_version(std_doc_id),
        "prefix": extract_prefix(cleaned),
        "number": extract_number(cleaned, std_doc_id_lower),
    }

    return result


def remove_parentheses(text: str) -> str:
    while True:
        new_text = re.sub(r"\([^()]*\)", " ", text)
        if new_text == text:
            break
        text = new_text
    return " ".join(text.replace("(", " ").replace(")", " ").split())


def extract_version(original: str) -> Optional[str]:
    match = re.search(r"\bv(\d+\.\d+\.\d+)\b", original)
    if match:
        return match.group(0)
    if re.search(r"\bv\s*$", original):
        return None
    return None


def extract_prefix(cleaned: str) -> Optional[str]:
    for prefix in prefixes:
        if cleaned.startswith(prefix.lower()):
            return prefix
    return None


def extract_number(cleaned: str, original: str) -> Optional[str]:
    # Remove the prefix part before matching
    for prefix in prefixes:
        if cleaned.startswith(prefix.lower()):
            cleaned = cleaned[len(prefix) :].strip()
            break

    number_match = re.search(r"\b(\d{2}\.\d{3}(?:-\d+)?)\b", cleaned)
    if number_match:
        return number_match.group(1)

    etsi_match = re.search(r"\b1(\d{2})\s(\d{3})(?:-\d+)?\b", cleaned)
    if etsi_match:
        return f"{etsi_match.group(1)}.{etsi_match.group(2)}"

    etsi_fallback_match = re.search(r"\b1(\d{2})\s(\d{3})(?:-\d+)?\b", original)
    if etsi_fallback_match:
        return f"{etsi_fallback_match.group(1)}.{etsi_fallback_match.group(2)}"

    return None


def format_number(input_str: str) -> str:
    if number_pattern_etsi_style.match(input_str):
        return re.sub(r"^1", "", input_str, count=1).replace(" ", ".", 1)
    return input_str


def is_more_recent(ref_version: Optional[str], other_version: Optional[str]) -> bool:
    if (
        not other_version
        or not other_version.startswith("v")
        or not version_pattern.fullmatch(other_version.lstrip("v"))
    ):
        return False
    if not ref_version or not ref_version.startswith("v") or not version_pattern.fullmatch(ref_version.lstrip("v")):
        return True
    ref_versions = ref_version.lstrip("v").split(".")
    other_versions = other_version.lstrip("v").split(".")
    min_number_level = min(len(ref_versions), len(other_versions))
    for i in range(min_number_level):
        if ref_versions[i].isdigit() and other_versions[i].isdigit():
            if int(ref_versions[i]) != int(other_versions[i]):
                return int(ref_versions[i]) < int(other_versions[i])
    return len(ref_versions) < len(other_versions)


parse_standard_doc_id_udf = udf(
    lambda std_doc_id: parse(std_doc_id).get("number"),
    StringType(),
)
