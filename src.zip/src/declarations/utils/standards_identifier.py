from typing import List, Optional, Set

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType

from .standard_docId_utility import is_more_recent, parse, parse_ignore_version


def get_most_meaningful_standard_document_id(
    identified_standard_document_ids: List[str], standard_document_id: str
) -> Optional[str]:
    valid_standards = get_valid_standard_document_ids(identified_standard_document_ids, standard_document_id)
    latest_standard_document_id = most_meaningful_standard_document_id(valid_standards, standard_document_id)
    return latest_standard_document_id


def get_valid_standard_document_ids(identified_standard_document_ids: List[str], standard_document_id: str) -> Set[str]:
    unwrapped = identified_standard_document_ids or []
    reference_std_doc_id = parse(standard_document_id)
    valid_standard_document_ids = filter_standards_by_etsi_standard_doc_id(unwrapped, reference_std_doc_id)
    if not valid_standard_document_ids:
        reference_std_doc_id = parse_ignore_version(standard_document_id)
        valid_standard_document_ids = filter_standards_by_etsi_standard_doc_id(unwrapped, reference_std_doc_id)
    return valid_standard_document_ids


def filter_standards_by_etsi_standard_doc_id(
    identified_standard_document_ids: List[str], reference_std_doc_id: dict
) -> Set[str]:
    return {
        std_id
        for std_id in identified_standard_document_ids
        if standard_agrees_with_std_doc_id(std_id, reference_std_doc_id)
    }


def standard_agrees_with_std_doc_id(standard_document_id: str, reference_std_doc_id: dict) -> bool:
    if not reference_std_doc_id:
        return False

    prefix = reference_std_doc_id.get("prefix")
    number = reference_std_doc_id.get("number")
    version = reference_std_doc_id.get("version")
    suffix = reference_std_doc_id.get("suffix")

    if not prefix and not number and not version:
        return False

    parsed = parse(standard_document_id)
    if not parsed:
        return False

    if prefix != parsed.get("prefix") or not number or not parsed.get("number"):
        return False

    if suffix:
        return number == parsed.get("number") and suffix == parsed.get("suffix") and version == parsed.get("version")

    std_number = parsed.get("number")
    if not (std_number == number or std_number.startswith(number + "-")):
        return False

    std_version = parsed.get("version")
    if version and std_version != version:
        return False

    return not (version and std_version is None)


def most_meaningful_standard_document_id(
    all_identified_standard_document_ids: Set[str], declared_std_doc_id_or_str
) -> Optional[str]:

    declared_std_doc_id = (
        parse(declared_std_doc_id_or_str) if isinstance(declared_std_doc_id_or_str, str) else declared_std_doc_id_or_str
    )

    if declared_std_doc_id_or_str in all_identified_standard_document_ids:
        return declared_std_doc_id_or_str

    if not declared_std_doc_id:
        return latest_meaningful_standard_document_id(all_identified_standard_document_ids)

    def filter_by_key(key: str) -> Set[str]:
        expected_value = safe_lower(declared_std_doc_id.get(key, ""))
        return {
            std_id
            for std_id in all_identified_standard_document_ids
            if safe_lower(parse(std_id).get(key, "")) == expected_value
        }

    for key in ["prefix", "version"]:
        filtered = filter_by_key(key)
        if filtered:
            return latest_meaningful_standard_document_id(filtered)

    prefix_version_match = {
        std_id
        for std_id in all_identified_standard_document_ids
        if safe_lower(parse(std_id).get("prefix", "")) == safe_lower(declared_std_doc_id.get("prefix", ""))
        and safe_lower(parse(std_id).get("version", "")) == safe_lower(declared_std_doc_id.get("version", ""))
    }

    if prefix_version_match:
        return latest_meaningful_standard_document_id(prefix_version_match)

    return latest_meaningful_standard_document_id(all_identified_standard_document_ids)


def latest_meaningful_standard_document_id(standard_document_ids: Set[str]) -> Optional[str]:
    result = None
    latest_version = None
    for standard_document_id in standard_document_ids:
        current_std_doc_id = parse(standard_document_id)
        if is_more_recent(latest_version, current_std_doc_id.get("version")):
            result = standard_document_id
            latest_version = current_std_doc_id.get("version")
    return result


# PySpark UDF
get_most_meaningful_standard_document_id_udf = udf(
    get_most_meaningful_standard_document_id,
    StringType(),
)


def safe_lower(value: Optional[str]) -> str:
    return value.lower() if isinstance(value, str) else ""
