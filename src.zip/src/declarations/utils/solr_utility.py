import re

from pyspark.sql.functions import udf
from pyspark.sql.types import StringType


# Clean text: trim, strip spaces and hyphens from ends
def clean_text(text):
    return text.strip().strip(" ").strip("-") if text else ""


# Add "Bridging (...)" if there's a comma
def add_bridging_text(text):
    if text and "," in text:
        return f"Bridging ({text})"
    return text


# Check for valid names (i.e., not empty or known invalid terms)
def is_valid_name(name):
    if name:
        lowered = name.strip().lower()
        return lowered not in {"na", "n.a", "n.a.", "not available"}
    return False


# The full logic to split, process, and join
def split_by_asterisk_pipe_and_join_by_pipe(original):
    if not original:
        return ""

    # Split on '*', '?', or '|'
    parts = re.split(r"[\*\?\|]", original)

    # Process parts
    authors = []
    for part in parts:
        trimmed = clean_text(part)
        bridged = add_bridging_text(trimmed)
        if is_valid_name(bridged):
            authors.append(bridged)

    return " | ".join(authors)


# Register UDF
split_by_asterisk_pipe_udf = udf(split_by_asterisk_pipe_and_join_by_pipe, StringType())
