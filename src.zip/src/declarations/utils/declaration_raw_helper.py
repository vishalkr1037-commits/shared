from pyspark.sql.functions import (
    col,
    concat,
    lit,
    regexp_extract,
    regexp_replace,
    split,
    substring,
    trim,
    when,
)


class DeclarationRawHelperClass:
    @staticmethod
    def get_standard_project_rename(sso, csv_file_name):
        cleaned_standard_project = trim(regexp_replace(col("Standard Project"), "(?i)Pool\\s*Program+\\s*:\\s*", ""))

        return when(
            sso == "Blu-ray Disc™ Association", DeclarationRawHelperClass.get_one_blue_standard_project(csv_file_name)
        ).otherwise(cleaned_standard_project)

    @staticmethod
    def get_one_blue_standard_project(csv_file_name):
        standard_project_for_one_blue = regexp_replace(
            regexp_extract(csv_file_name, "[^/]*$", 0), "_\\d\\w*\\b" + ".csv", ""
        )
        return standard_project_for_one_blue

    @staticmethod
    def get_patent_pool_rename(pool_name):
        return (
            when(pool_name.isin("HEVC Advance", "VVC Advance"), lit("Access Advance"))
            .when(pool_name.isin("MPEG LA", "Via Licensing"), lit("Via LA"))
            .when(pool_name == "OPUS", lit("Vectis IP"))
            .when(pool_name == "JPEG XS", lit("Vectis IP"))
            .otherwise(pool_name)
        )

    @staticmethod
    def get_patent_pool_rename_with_standard_doc_id(pool_name, standard_document_d):
        return (
            when(pool_name.isin("HEVC Advance", "VVC Advance"), lit("Access Advance"))
            .when(pool_name.isin("MPEG LA", "Via Licensing"), lit("Via LA"))
            .when((pool_name == "SISVEL") & (standard_document_d == "AV1"), lit("AV1"))
            .when((pool_name == "SISVEL") & (standard_document_d == "VP9"), lit("VP9"))
            .when((pool_name == "OPUS") & (standard_document_d == "RFC_6716"), lit("OPUS"))
            .when((pool_name == "JPEG XS") & (standard_document_d == "ISO/IEC 21122-1:2022"), lit("JPEG XS"))
            .otherwise(pool_name)
        )

    @staticmethod
    def get_data_provider_based_on_sso_pool_name(sso, pool_name):
        return (
            when(pool_name == "MPEG LA", lit("MPEG LA"))
            .when(pool_name == "Access Advance", lit("Access Advance"))
            .when(pool_name == "ONE-BLUE", lit("ONE-BLUE"))
            .when(pool_name == "ONE-RED - Philips", lit("ONE-RED - Philips"))
            .when(pool_name == "Premier BD", lit("Premier BD"))
            .when(pool_name == "Via Licensing", lit("Via Licensing"))
            .when(pool_name.isin("SISVEL", "AV1", "VP9"), lit("SISVEL"))
            .when(pool_name == "ONE-RED", lit("ONE-RED"))
            .when(pool_name == "Velos Media", lit("Velos Media"))
            .when(pool_name == "Uldage Pool", lit("Uldage Pool"))
            .when(pool_name == "Via LA", "Via LA")
            .when(pool_name == "Yes", lit("Velos Media"))
            .otherwise(sso)
        )

    @staticmethod
    def get_data_provider_based_on_sso_pool_name_csv_file(sso, pool_name, csv_file_name):
        return (
            when(pool_name == "MPEG LA", lit("MPEG LA"))
            .when(pool_name == "Access Advance", lit("Access Advance"))
            .when(pool_name == "ONE-BLUE", lit("ONE-BLUE"))
            .when(pool_name == "ONE-RED - Philips", lit("ONE-RED - Philips"))
            .when(pool_name == "Premier BD", lit("Premier BD"))
            .when(pool_name == "Via Licensing", lit("Via Licensing"))
            .when(pool_name.isin("SISVEL", "AV1", "VP9"), lit("SISVEL"))
            .when(pool_name == "ONE-RED", lit("ONE-RED"))
            .when(pool_name == "Velos Media", lit("Velos Media"))
            .when(pool_name == "Uldage Pool", lit("Uldage Pool"))
            .when(pool_name == "Via LA", "Via LA")
            .when(pool_name == "OPUS", "Vectis IP")
            .when(pool_name == "JPEG XS", "Vectis IP")
            .when(sso == "VESA", "Via LA")
            .when(pool_name == "Yes", lit("Velos Media"))
            .when(csv_file_name.contains("mpeg_la"), "Via LA")
            .otherwise(sso)
        )

    @staticmethod
    def get_harmonize_pool_name(is_pool, standard_project):
        return when(
            is_pool.contains("Yes"), DeclarationRawHelperClass.get_clean_standard_project(standard_project)
        ).otherwise(None)

    @staticmethod
    def get_clean_standard_project(standard_project):
        return when(standard_project.contains(":"), trim(split(standard_project, ":").getItem(1))).otherwise(
            standard_project
        )

    @staticmethod
    def parse_pool_name(pool_name):
        return when(
            pool_name.contains("Yes"), regexp_replace(regexp_replace(pool_name, ".*\\(", ""), "\\)", "")
        ).otherwise(None)

    @staticmethod
    def get_type(
        application_as_to_declaration,
        publication_as_to_declaration,
        application_as_to_declaration_other,
        publication_as_to_declaration_other,
    ):
        def is_null_or_empty(column):
            return col(column).isNull() | (col(column) == "")

        conditions = (
            is_null_or_empty(application_as_to_declaration)
            & is_null_or_empty(application_as_to_declaration_other)
            & is_null_or_empty(publication_as_to_declaration)
            & is_null_or_empty(publication_as_to_declaration_other)
        )

        return when(conditions, lit("BLANKET_DECLARATION")).otherwise(lit("DECLARATION"))

    @staticmethod
    def map_atis_standard_document_id(standard_document_id):
        return (
            when(
                standard_document_id.contains("V"),
                DeclarationRawHelperClass.transform_atis_document_id(standard_document_id),
            )
            .when(standard_document_id.contains("TS"), concat(lit("TS "), split(standard_document_id, "TS")[1]))
            .otherwise(standard_document_id)
        )

    @staticmethod
    def transform_atis_document_id(standard_document_id):
        ts_part = split(split(standard_document_id, "3GPP.")[1], "V")[0]
        version_part = split(split(standard_document_id, "V")[1], "-")[0]

        ts_formatted = concat(lit("TS "), ts_part)

        version_formatted = concat(
            lit("v"),
            substring(version_part, 1, 2),
            lit("."),
            substring(version_part, 3, 1),
            lit("."),
            substring(version_part, 4, 1),
        )

        return concat(ts_formatted, lit(" "), version_formatted)

    @staticmethod
    def get_contact_person_info(pool_provider):
        return when(pool_provider == "Via LA", lit("Contact Via LA directly")).otherwise(
            col("Contact Person for License")
        )

    @staticmethod
    def get_contact_email(pool_provider):
        return when(pool_provider == "Via LA", lit("info@via-la.com")).otherwise(col("Contact Email for License"))

    @staticmethod
    def get_info_for_licensing(pool_provider):
        return when(pool_provider == "Via LA", lit("https://www.via-la.com/licensing/")).otherwise(
            col("Contact Address for License")
        )
