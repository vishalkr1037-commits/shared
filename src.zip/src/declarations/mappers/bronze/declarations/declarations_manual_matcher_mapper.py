from pyspark.sql.functions import col

import src.declarations.models.bronze.declarations.declarations_manual_matching as DeclarationsManualMatching
import src.declarations.models.landing.declarations_manual_matching_csv as DeclarationsManualMatchedCsv


class DeclarationsManualMatchingMapper:
    @staticmethod
    def apply(df):
        return df.withColumns(
            {
                DeclarationsManualMatching.WORKING_NUMBER: col(DeclarationsManualMatchedCsv.WORKING_NUMBER),
                DeclarationsManualMatching.PUBLICATION_NUMBER: col(DeclarationsManualMatchedCsv.PUBLICATION_NUMBER),
                DeclarationsManualMatching.SOURCE: col(DeclarationsManualMatchedCsv.SOURCE),
            }
        )
