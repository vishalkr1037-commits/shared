from pyspark.sql.functions import array, col, date_format, lit, substring, trim, when

from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.landing.declarations_others_raw_csv import (
    DeclarationsOthersRawCsv,
)
from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declaration_raw_helper import DeclarationRawHelperClass
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)
from src.declarations.utils.licensing_info_helper_task import LicensingInfoHelper


class DeclarationsOthersRawMapper:
    @staticmethod
    def apply(df):
        return (
            df.withColumns(
                {
                    DeclarationRaw.ISLD: col(DeclarationsOthersRawCsv.ISLD),
                    DeclarationRaw.SECTION: trim(col(DeclarationsOthersRawCsv.SECTION)),
                    DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER: lit(None).cast("string"),
                    DeclarationRaw.STANDARD_DOCUMENT_TITLE: lit(None).cast("string"),
                    DeclarationRaw.STANDARD_PROJECT: DeclarationsOthersRawMapper._get_standard_project(),
                    DeclarationRaw.STANDARD_DOCUMENT_ID: col(DeclarationsOthersRawCsv.STANDARD_DOCUMENT_ID),
                    DeclarationRaw.DECLARING_COMPANY: col(DeclarationsOthersRawCsv.DECLARING_COMPANY),
                    DeclarationRaw.APPLICATION_AS_TO_DECLARATION: col(
                        DeclarationsOthersRawCsv.APPLICATION_AS_TO_DECLARATION
                    ),
                    DeclarationRaw.PUBLICATION_AS_TO_DECLARATION: col(
                        DeclarationsOthersRawCsv.PUBLICATION_AS_TO_DECLARATION
                    ),
                    DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER: col(
                        DeclarationsOthersRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER
                    ),
                    DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER: col(
                        DeclarationsOthersRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER
                    ),
                }
            )
            .withColumns(
                {
                    DeclarationRaw.DECLARATION_DATE: DeclarationsOthersRawMapper._get_declaration_date(),
                    DeclarationRaw.POOL_PROVIDER: DeclarationsOthersRawMapper._get_pool_provider(),
                    DeclarationRaw.PATENT_POOL_NAME: DeclarationsOthersRawMapper._get_patent_pool_name(),
                    DeclarationRaw.POOL_NAME_HARMONIZED: DeclarationsOthersRawMapper._get_pool_name_harmonized(),
                    DeclarationRaw.STANDARD_MATCH_ID: col(DeclarationsOthersRawCsv.STANDARD_MATCH_ID),
                    DeclarationRaw.LICENSING_TERMS: DeclarationsOthersRawMapper._get_licensing_terms(),
                    DeclarationRaw.SPECIFIC_LICENSING_CONDITIONS: DeclarationsOthersRawMapper._get_specific_licensing_terms(),
                    DeclarationRaw.RECIPROCITY_STATEMENT: col(DeclarationsOthersRawCsv.RECIPROCITY_STATEMENT),
                    DeclarationRaw.LICENSING_COMMENT: col(DeclarationsOthersRawCsv.LICENSING_COMMENT),
                    DeclarationRaw.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES: col(
                        DeclarationsOthersRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES
                    ),
                    DeclarationRaw.CONTACT_PERSON_FOR_LICENSE: col(DeclarationsOthersRawCsv.CONTACT_PERSON_FOR_LICENSE),
                    DeclarationRaw.CONTACT_PERSON_POSITION: col(DeclarationsOthersRawCsv.CONTACT_PERSON_POSITION),
                    DeclarationRaw.CONTACT_ADDRESS_FOR_LICENSE: col(
                        DeclarationsOthersRawCsv.CONTACT_ADDRESS_FOR_LICENSE
                    ),
                    DeclarationRaw.CONTACT_PHONE_FOR_LICENSE: col(
                        DeclarationsOthersRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE
                    ),
                    DeclarationRaw.CONTACT_EMAIL_FOR_LICENSE: col(DeclarationsOthersRawCsv.CONTACT_EMAIL_FOR_LICENSE),
                    DeclarationRaw.COUNTRY_OF_REGISTRATION: trim(col(DeclarationsOthersRawCsv.COUNTRY_OF_REGISTRATION)),
                    DeclarationRaw.PATENT_PROPRIETORS: trim(col(DeclarationsOthersRawCsv.PATENT_PROPRIETORS)),
                    DeclarationRaw.PROPRIETORS_OTHER_MEMBERS: trim(
                        col(DeclarationsOthersRawCsv.PROPRIETORS_OTHER_MEMBERS)
                    ),
                    DeclarationRaw.PATENT_TITLE: trim(col(DeclarationsOthersRawCsv.PATENT_TITLE)),
                    DeclarationRaw.DECLARANT_IS_PROPRIETOR: trim(col(DeclarationsOthersRawCsv.DECLARANT_IS_PROPRIETOR)),
                    DeclarationRaw.DATA_PROVIDER: DeclarationsOthersRawMapper._get_data_provider(),
                    DeclarationRaw.ESSENTIAL_CLAIM_NO: lit(None).cast("string"),
                    DeclarationRaw.ISLD_AGGREGATED: DeclarationsOthersRawMapper._get_aggregated_column(
                        DeclarationRaw.ISLD
                    ),
                    DeclarationRaw.DISCLOSURE_NUMBER_AGGREGATED: DeclarationsOthersRawMapper._get_aggregated_column_int(
                        DeclarationsOthersRawCsv.DISCLOSURE_NUMBER
                    ),
                    DeclarationRaw.SECTION_AGGREGATED: DeclarationsOthersRawMapper._get_aggregated_column(
                        DeclarationRaw.SECTION
                    ),
                    DeclarationRaw.TYPE: DeclarationsOthersRawMapper._get_type(),
                    DeclarationRaw.SSO: DeclarationsOthersRawMapper._get_sso(),
                }
            )
            .withColumns(
                {
                    DeclarationRaw.STANDARD_DOCUMENT_ID: DeclarationsOthersRawMapper._get_standard_document_id(),
                }
            )
            .withColumns(
                {
                    DeclarationRaw.ID: DeclarationsOthersRawMapper._get_id(),
                }
            )
            .withColumns(
                {
                    DeclarationRaw.ID_FIRST_CHAR: substring(col(DeclarationRaw.ID), 1, 1),
                }
            )
            .dropDuplicates([DeclarationRaw.ID])
            .drop(
                DeclarationsOthersRawCsv.STANDARD_PROJECT,
                DeclarationsOthersRawCsv.STANDARD_DOCUMENT_ID,
                DeclarationsOthersRawCsv.DECLARING_COMPANY,
                DeclarationsOthersRawCsv.APPLICATION_AS_TO_DECLARATION,
                DeclarationsOthersRawCsv.PUBLICATION_AS_TO_DECLARATION,
                DeclarationsOthersRawCsv.DECLARATION_DATE,
                DeclarationsOthersRawCsv.PATENT_POOLED,
                DeclarationsOthersRawCsv.STANDARD_MATCH_ID,
                DeclarationsOthersRawCsv.LICENSING_TERMS,
                DeclarationsOthersRawCsv.SPECIFIC_LICENSING_CONDITIONS,
                DeclarationsOthersRawCsv.RECIPROCITY_STATEMENT,
                DeclarationsOthersRawCsv.LICENSING_COMMENT,
                DeclarationsOthersRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES,
                DeclarationsOthersRawCsv.CONTACT_PERSON_FOR_LICENSE,
                DeclarationsOthersRawCsv.CONTACT_PERSON_POSITION,
                DeclarationsOthersRawCsv.CONTACT_ADDRESS_FOR_LICENSE,
                DeclarationsOthersRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE,
                DeclarationsOthersRawCsv.CONTACT_EMAIL_FOR_LICENSE,
                DeclarationsOthersRawCsv.DISCLOSURE_NUMBER,
                DeclarationsOthersRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER,
                DeclarationsOthersRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER,
                DeclarationsOthersRawCsv.COUNTRY_OF_REGISTRATION,
                DeclarationsOthersRawCsv.PATENT_PROPRIETORS,
                DeclarationsOthersRawCsv.PROPRIETORS_OTHER_MEMBERS,
                DeclarationsOthersRawCsv.PATENT_TITLE,
                DeclarationsOthersRawCsv.DECLARANT_IS_PROPRIETOR,
                DeclarationsOthersRawCsv.DECLARING_COMPANY_HARMONIZED,
                DeclarationsOthersRawCsv.PUBLICATION_NUMBER,
                DeclarationsOthersRawCsv.INPADOC_FAMILY_ID,
                DeclarationsOthersRawCsv.INPADOC_FAMILY_EXTENSIONS,
                DeclarationsOthersRawCsv.SINGLE_FAMILY_EXTENSIONS,
            )
        )

    @staticmethod
    def _get_standard_project():
        return DeclarationRawHelperClass.get_standard_project_rename(
            col(DeclarationsOthersRawCsv.SSO), col(DeclarationRaw.CSV_FILE_NAME)
        )

    @staticmethod
    def _get_declaration_date():
        return date_format(
            HelperFunctionForParseDate.parse_date(col(DeclarationsOthersRawCsv.DECLARATION_DATE)), "yyyy-MM-dd"
        )

    @staticmethod
    def _get_pool_provider():
        return DeclarationRawHelperClass.get_patent_pool_rename(
            DeclarationRawHelperClass.parse_pool_name(col(DeclarationsOthersRawCsv.PATENT_POOLED))
        )

    @staticmethod
    def _get_patent_pool_name():
        return DeclarationRawHelperClass.get_patent_pool_rename_with_standard_doc_id(
            DeclarationRawHelperClass.parse_pool_name(col(DeclarationsOthersRawCsv.PATENT_POOLED)),
            col(DeclarationRaw.STANDARD_DOCUMENT_ID),
        )

    @staticmethod
    def _get_pool_name_harmonized():
        return DeclarationRawHelperClass.get_harmonize_pool_name(
            col(DeclarationsOthersRawCsv.PATENT_POOLED), col(DeclarationRaw.STANDARD_PROJECT)
        )

    @staticmethod
    def _get_licensing_terms():
        return LicensingInfoHelper.get_licensing_terms(
            col(DeclarationRaw.PATENT_POOL_NAME), col(DeclarationsOthersRawCsv.LICENSING_TERMS)
        )

    @staticmethod
    def _get_specific_licensing_terms():
        return LicensingInfoHelper.get_specific_licensing_terms(
            col(DeclarationRaw.PATENT_POOL_NAME),
            col(DeclarationRaw.STANDARD_PROJECT),
            col(DeclarationsOthersRawCsv.SPECIFIC_LICENSING_CONDITIONS),
        )

    @staticmethod
    def _get_data_provider():
        return DeclarationRawHelperClass.get_data_provider_based_on_sso_pool_name(
            col(DeclarationsOthersRawCsv.SSO), col(DeclarationRaw.PATENT_POOL_NAME)
        )

    @staticmethod
    def _get_aggregated_column(column):
        return when(col(column).isNotNull(), array(col(column))).otherwise(None)

    @staticmethod
    def _get_aggregated_column_int(column):
        return when(col(column).cast("int").isNotNull(), array(col(column).cast("int"))).otherwise(None)

    @staticmethod
    def _get_type():
        return DeclarationRawHelperClass.get_type(
            DeclarationRaw.APPLICATION_AS_TO_DECLARATION,
            DeclarationRaw.PUBLICATION_AS_TO_DECLARATION,
            DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER,
        )

    @staticmethod
    def _get_sso():
        return when(col(DeclarationsOthersRawCsv.SSO) == "Via LA", None).otherwise(col(DeclarationsOthersRawCsv.SSO))

    @staticmethod
    def _get_standard_document_id():
        return when(
            col(DeclarationRaw.SSO) == "ATIS",
            DeclarationRawHelperClass.map_atis_standard_document_id(col(DeclarationRaw.STANDARD_DOCUMENT_ID)),
        ).otherwise(col(DeclarationRaw.STANDARD_DOCUMENT_ID))

    @staticmethod
    def _get_id():
        return DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
            col(DeclarationRaw.STANDARD_PROJECT),
            col(DeclarationRaw.STANDARD_DOCUMENT_ID),
            col(DeclarationRaw.DECLARING_COMPANY),
            col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION),
            col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION),
            col(DeclarationRaw.DECLARATION_DATE),
        )
