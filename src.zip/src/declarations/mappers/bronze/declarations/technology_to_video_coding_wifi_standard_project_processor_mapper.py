from pyspark.sql.functions import col, regexp_replace, trim

import src.declarations.models.bronze.declarations.technology_to_video_coding_wifi_standard_project as TechnologyToVideoCodingWifiStandardProject
from src.declarations.models.landing.technology_to_video_coding_wifi_standard_project_csv import (
    TechnologyToVideoCodingWifiStandardProjectCsv,
)


class TechnologyToVideoCodingWifiStandardProjectMapper:
    @staticmethod
    def apply(df):
        return df.withColumns(
            {
                TechnologyToVideoCodingWifiStandardProject.TECHNOLOGY_GENERATION: col(
                    TechnologyToVideoCodingWifiStandardProjectCsv.TECHNOLOGY_GENERATION
                ),
                TechnologyToVideoCodingWifiStandardProject.STANDARD_PROJECTS: trim(
                    regexp_replace(
                        col(TechnologyToVideoCodingWifiStandardProjectCsv.STANDARD_PROJECTS), "Pool Program:\\s*", ""
                    )
                ),
            }
        )
