from pyspark.sql import Column
from pyspark.sql import functions as F

import src.declarations.models.bronze.declarations.three_gpp_specification as three_gpp_spec
import src.declarations.models.landing.three_gpp_specification_csv as three_gpp_spec_csv


def apply(df):
    return (
        df.withColumns(
            {
                three_gpp_spec.ID: _combine_std_doc_id_freeze_date(
                    F.col(three_gpp_spec_csv.STANDARD_DOC_ID), F.col(three_gpp_spec_csv.FREEZE_DATE)
                ),
                three_gpp_spec.RELEASE: _replace_hyphen_and_num_with_correct_rel_format(
                    F.col(three_gpp_spec_csv.RELEASE), F.col(three_gpp_spec_csv.CSV_FILE_NAME)
                ),
                three_gpp_spec.TECHNOLOGY_GENERATION: F.col(three_gpp_spec_csv.TECHNOLOGY),
                three_gpp_spec.TITLE: F.col(three_gpp_spec_csv.TITLE),
                three_gpp_spec.GROUP: F.col(three_gpp_spec_csv.GROUP),
                three_gpp_spec.FOR_PUBLICATION: F.col(three_gpp_spec_csv.FOR_PUBLICATION),
                three_gpp_spec.FREEZE_DATE: F.col(three_gpp_spec_csv.FREEZE_DATE),
                three_gpp_spec.FROZEN: F.col(three_gpp_spec_csv.FROZEN),
            }
        )
        .drop(
            three_gpp_spec_csv.FREEZE_DATE,
            three_gpp_spec_csv.STANDARD_DOC_ID,
            three_gpp_spec_csv.FOR_PUBLICATION,
            three_gpp_spec_csv.TECHNOLOGY,
            three_gpp_spec_csv.CSV_FILE_NAME,
        )
        .select(
            three_gpp_spec.RELEASE,
            three_gpp_spec.TITLE,
            three_gpp_spec.GROUP,
            three_gpp_spec.FROZEN,
            three_gpp_spec.ID,
            three_gpp_spec.TECHNOLOGY_GENERATION,
            three_gpp_spec.FOR_PUBLICATION,
            three_gpp_spec.FREEZE_DATE,
        )
    )


def _combine_std_doc_id_freeze_date(std_doc_id: Column, freeze_date: Column) -> Column:
    return F.when(
        freeze_date.isNotNull() & (freeze_date != ""), F.concat(std_doc_id, F.lit("_"), freeze_date)
    ).otherwise(std_doc_id)


def _replace_hyphen_and_num_with_correct_rel_format(release: Column, file_name: Column) -> Column:
    return F.when(
        file_name.contains("3gpp_set_page") & release.contains("Rel-"),
        F.concat(F.lit("Release "), F.expr("substring_index(release, '-', -1)")),
    ).otherwise(release)
