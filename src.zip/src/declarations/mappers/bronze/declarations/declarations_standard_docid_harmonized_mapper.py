import pyspark.sql.functions as F

import src.declarations.models.bronze.declarations.declarations_standard_docid_harmonized as DeclarationsStandardDocIdHarmonized
import src.declarations.models.landing.declarations_standard_docid_harmonized_csv as DeclarationsStandardDocIdHarmonizedCsv


def apply(df):
    return df.withColumns(
        {
            DeclarationsStandardDocIdHarmonized.TECHNOLOGY_GENERATION: F.col(
                DeclarationsStandardDocIdHarmonizedCsv.TECHNOLOGY_GENERATION
            ),
            DeclarationsStandardDocIdHarmonized.SSO: F.col(DeclarationsStandardDocIdHarmonizedCsv.SSO),
            DeclarationsStandardDocIdHarmonized.STANDARD_DOCUMENT_ID_HARMONIZED_VAL: F.col(
                DeclarationsStandardDocIdHarmonizedCsv.STANDARD_DOCUMENT_ID_HARMONIZED
            ),
        }
    )
