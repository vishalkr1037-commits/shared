from pyspark.sql.functions import array, col, date_format, lit, substring, trim, when

from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.landing.declarations_raw_csv import DeclarationsRawCsv
from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declaration_raw_helper import DeclarationRawHelperClass
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)
from src.declarations.utils.licensing_info_helper_task import LicensingInfoHelper


class DeclarationsRawMapper:
    @staticmethod
    def apply(df):
        return (
            df.withColumns(
                {
                    DeclarationRaw.ISLD: col(DeclarationsRawCsv.ISLD),
                    DeclarationRaw.SECTION: trim(col(DeclarationsRawCsv.SECTION)),
                    DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER: lit(None).cast("string"),
                    DeclarationRaw.STANDARD_DOCUMENT_TITLE: lit(None).cast("string"),
                    DeclarationRaw.STANDARD_PROJECT: DeclarationsRawMapper._get_standard_project(),
                    DeclarationRaw.STANDARD_DOCUMENT_ID: col(DeclarationsRawCsv.STANDARD_DOCUMENT_ID),
                    DeclarationRaw.DECLARING_COMPANY: col(DeclarationsRawCsv.DECLARING_COMPANY),
                    DeclarationRaw.APPLICATION_AS_TO_DECLARATION: col(DeclarationsRawCsv.APPLICATION_AS_TO_DECLARATION),
                    DeclarationRaw.PUBLICATION_AS_TO_DECLARATION: col(DeclarationsRawCsv.PUBLICATION_AS_TO_DECLARATION),
                    DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER: col(
                        DeclarationsRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER
                    ),
                    DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER: col(
                        DeclarationsRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER
                    ),
                    DeclarationRaw.DECLARATION_DATE: DeclarationsRawMapper._get_declaration_date(),
                    DeclarationRaw.POOL_PROVIDER: DeclarationsRawMapper._get_pool_provider(),
                    DeclarationRaw.PATENT_POOL_NAME: DeclarationsRawMapper._get_patent_pool_name(),
                    DeclarationRaw.POOL_NAME_HARMONIZED: DeclarationsRawMapper._get_pool_name_harmonized(),
                    DeclarationRaw.STANDARD_MATCH_ID: col(DeclarationsRawCsv.STANDARD_MATCH_ID),
                    DeclarationRaw.LICENSING_TERMS: DeclarationsRawMapper._get_licensing_terms(),
                    DeclarationRaw.SPECIFIC_LICENSING_CONDITIONS: DeclarationsRawMapper._get_specific_licensing_terms(),
                    DeclarationRaw.RECIPROCITY_STATEMENT: col(DeclarationsRawCsv.RECIPROCITY_STATEMENT),
                    DeclarationRaw.LICENSING_COMMENT: col(DeclarationsRawCsv.LICENSING_COMMENT),
                    DeclarationRaw.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES: col(
                        DeclarationsRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES
                    ),
                    DeclarationRaw.CONTACT_PERSON_FOR_LICENSE: trim(col(DeclarationsRawCsv.CONTACT_PERSON_FOR_LICENSE)),
                    DeclarationRaw.CONTACT_PERSON_POSITION: trim(col(DeclarationsRawCsv.CONTACT_PERSON_POSITION)),
                    DeclarationRaw.CONTACT_ADDRESS_FOR_LICENSE: trim(
                        col(DeclarationsRawCsv.CONTACT_ADDRESS_FOR_LICENSE)
                    ),
                    DeclarationRaw.CONTACT_PHONE_FOR_LICENSE: trim(
                        col(DeclarationsRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE)
                    ),
                    DeclarationRaw.CONTACT_EMAIL_FOR_LICENSE: trim(col(DeclarationsRawCsv.CONTACT_EMAIL_FOR_LICENSE)),
                    DeclarationRaw.COUNTRY_OF_REGISTRATION: trim(col(DeclarationsRawCsv.COUNTRY_OF_REGISTRATION)),
                    DeclarationRaw.PATENT_PROPRIETORS: trim(col(DeclarationsRawCsv.PATENT_PROPRIETORS)),
                    DeclarationRaw.PROPRIETORS_OTHER_MEMBERS: trim(col(DeclarationsRawCsv.PROPRIETORS_OTHER_MEMBERS)),
                    DeclarationRaw.PATENT_TITLE: trim(col(DeclarationsRawCsv.PATENT_TITLE)),
                    DeclarationRaw.DECLARANT_IS_PROPRIETOR: trim(col(DeclarationsRawCsv.DECLARANT_IS_PROPRIETOR)),
                    DeclarationRaw.DATA_PROVIDER: DeclarationsRawMapper._get_data_provider(),
                    DeclarationRaw.ESSENTIAL_CLAIM_NO: lit(None).cast("string"),
                    DeclarationRaw.ISLD_AGGREGATED: DeclarationsRawMapper._get_aggregated_column(DeclarationRaw.ISLD),
                    DeclarationRaw.DISCLOSURE_NUMBER_AGGREGATED: DeclarationsRawMapper._get_aggregated_column_int(
                        DeclarationsRawCsv.DISCLOSURE_NUMBER
                    ),
                    DeclarationRaw.SECTION_AGGREGATED: DeclarationsRawMapper._get_aggregated_column(
                        DeclarationRaw.SECTION
                    ),
                    DeclarationRaw.TYPE: DeclarationsRawMapper._get_type(),
                    DeclarationRaw.SSO: DeclarationsRawMapper._get_sso(),
                    DeclarationRaw.ID: DeclarationsRawMapper._get_id(),
                    DeclarationRaw.ID_FIRST_CHAR: substring(col(DeclarationRaw.ID), 1, 1),
                }
            )
            .dropDuplicates([DeclarationRaw.ID])
            .drop(
                DeclarationsRawCsv.STANDARD_PROJECT,
                DeclarationsRawCsv.STANDARD_DOCUMENT_ID,
                DeclarationsRawCsv.DECLARING_COMPANY,
                DeclarationsRawCsv.APPLICATION_AS_TO_DECLARATION,
                DeclarationsRawCsv.PUBLICATION_AS_TO_DECLARATION,
                DeclarationsRawCsv.DECLARATION_DATE,
                DeclarationsRawCsv.PATENT_POOLED,
                DeclarationsRawCsv.STANDARD_MATCH_ID,
                DeclarationsRawCsv.LICENSING_TERMS,
                DeclarationsRawCsv.SPECIFIC_LICENSING_CONDITIONS,
                DeclarationsRawCsv.RECIPROCITY_STATEMENT,
                DeclarationsRawCsv.LICENSING_COMMENT,
                DeclarationsRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES,
                DeclarationsRawCsv.CONTACT_PERSON_FOR_LICENSE,
                DeclarationsRawCsv.CONTACT_PERSON_POSITION,
                DeclarationsRawCsv.CONTACT_ADDRESS_FOR_LICENSE,
                DeclarationsRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE,
                DeclarationsRawCsv.CONTACT_EMAIL_FOR_LICENSE,
                DeclarationsRawCsv.DISCLOSURE_NUMBER,
                DeclarationsRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER,
                DeclarationsRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER,
                DeclarationsRawCsv.COUNTRY_OF_REGISTRATION,
                DeclarationsRawCsv.PATENT_PROPRIETORS,
                DeclarationsRawCsv.PROPRIETORS_OTHER_MEMBERS,
                DeclarationsRawCsv.PATENT_TITLE,
                DeclarationsRawCsv.DECLARANT_IS_PROPRIETOR,
                DeclarationsRawCsv.DECLARING_COMPANY_HARMONIZED,
                DeclarationsRawCsv.PUBLICATION_NUMBER,
                DeclarationsRawCsv.INPADOC_FAMILY_ID,
                DeclarationsRawCsv.INPADOC_FAMILY_EXTENSIONS,
                DeclarationsRawCsv.SINGLE_FAMILY_EXTENSIONS,
            )
        )

    @staticmethod
    def _get_standard_project():
        return DeclarationRawHelperClass.get_standard_project_rename(
            col(DeclarationsRawCsv.SSO), col(DeclarationRaw.CSV_FILE_NAME)
        )

    @staticmethod
    def _get_declaration_date():
        return date_format(
            HelperFunctionForParseDate.parse_date(col(DeclarationsRawCsv.DECLARATION_DATE)), "yyyy-MM-dd"
        )

    @staticmethod
    def _get_pool_provider():
        return DeclarationRawHelperClass.get_patent_pool_rename(
            DeclarationRawHelperClass.parse_pool_name(col(DeclarationsRawCsv.PATENT_POOLED))
        )

    @staticmethod
    def _get_patent_pool_name():
        return DeclarationRawHelperClass.get_patent_pool_rename_with_standard_doc_id(
            DeclarationRawHelperClass.parse_pool_name(col(DeclarationsRawCsv.PATENT_POOLED)),
            col(DeclarationRaw.STANDARD_DOCUMENT_ID),
        )

    @staticmethod
    def _get_pool_name_harmonized():
        return DeclarationRawHelperClass.get_harmonize_pool_name(
            col(DeclarationsRawCsv.PATENT_POOLED), col(DeclarationRaw.STANDARD_PROJECT)
        )

    @staticmethod
    def _get_licensing_terms():
        return LicensingInfoHelper.get_licensing_terms(
            col(DeclarationRaw.PATENT_POOL_NAME), col(DeclarationsRawCsv.LICENSING_TERMS)
        )

    @staticmethod
    def _get_specific_licensing_terms():
        return LicensingInfoHelper.get_specific_licensing_terms(
            col(DeclarationRaw.PATENT_POOL_NAME),
            col(DeclarationRaw.STANDARD_PROJECT),
            col(DeclarationsRawCsv.SPECIFIC_LICENSING_CONDITIONS),
        )

    @staticmethod
    def _get_data_provider():
        return DeclarationRawHelperClass.get_data_provider_based_on_sso_pool_name(
            col(DeclarationsRawCsv.SSO), col(DeclarationRaw.PATENT_POOL_NAME)
        )

    @staticmethod
    def _get_aggregated_column(column):
        return when(col(column).isNotNull(), array(col(column))).otherwise(None)

    @staticmethod
    def _get_aggregated_column_int(column):
        return when(col(column).cast("int").isNotNull(), array(col(column).cast("int"))).otherwise(None)

    @staticmethod
    def _get_type():
        return DeclarationRawHelperClass.get_type(
            DeclarationRaw.APPLICATION_AS_TO_DECLARATION,
            DeclarationRaw.PUBLICATION_AS_TO_DECLARATION,
            DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER,
        )

    @staticmethod
    def _get_sso():
        return when(col(DeclarationsRawCsv.SSO) == "Via LA", None).otherwise(col(DeclarationsRawCsv.SSO))

    @staticmethod
    def _get_id():
        return DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
            col(DeclarationRaw.STANDARD_PROJECT),
            col(DeclarationRaw.STANDARD_DOCUMENT_ID),
            col(DeclarationRaw.DECLARING_COMPANY),
            col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION),
            col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION),
            col(DeclarationRaw.DECLARATION_DATE),
        )
