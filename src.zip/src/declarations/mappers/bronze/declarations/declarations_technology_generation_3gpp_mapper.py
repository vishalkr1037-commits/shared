from pyspark.sql.functions import col, regexp_replace, when

import src.declarations.models.bronze.declarations.technology_generation_3gpp as TechnologyGeneration3gpp
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched

specialCaseOfNumberWithExtraZeros = "29."
regexForRemovingAnythingThatIsNotDotNumberOrHyphen = "[^\\d.-]"


def _get_standard_id(id_col):
    return (
        when(
            id_col.isNotNull() & id_col.contains(specialCaseOfNumberWithExtraZeros),
            regexp_replace(regexp_replace(id_col, regexForRemovingAnythingThatIsNotDotNumberOrHyphen, ""), "-0", "-"),
        )
        .when(id_col.isNotNull(), regexp_replace(id_col, regexForRemovingAnythingThatIsNotDotNumberOrHyphen, ""))
        .otherwise(when(id_col.isNull(), None))
    )


def apply(df):
    return (
        df.withColumns(
            {
                DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID: _get_standard_id(col(TechnologyGeneration3gpp.ID)),
                "technology_generation_ss": col(TechnologyGeneration3gpp.TECHNOLOGY_GENERATION),
            }
        )
        .filter(
            col(DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID).isNotNull()
            & (col(DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID) != "")
        )
        .drop(TechnologyGeneration3gpp.ID, TechnologyGeneration3gpp.TECHNOLOGY_GENERATION)
    )
