from pandas import DataFrame
from pyspark.sql.functions import col

import src.declarations.models.bronze.declarations.industry_class_sector as IndustryClassSector
import src.declarations.models.landing.industry_class_sector_csv as IndustryClassSectorCsv


def apply(df: DataFrame):

    return df.withColumns(
        {
            IndustryClassSector.INDUSTRY_CLASS: col(IndustryClassSectorCsv.INDUSTRY_CLASS),
            IndustryClassSector.FIELD_ENGLISH: col(IndustryClassSectorCsv.FIELD_ENGLISH),
            IndustryClassSector.FIELD_NUMBER: col(IndustryClassSectorCsv.FIELD_NUMBER),
            IndustryClassSector.SECTOR_ENGLISH: col(IndustryClassSectorCsv.SECTOR_ENGLISH),
        }
    )
