from pyspark.sql.functions import col, explode, regexp_replace, split, transform

import src.declarations.models.bronze.declarations.technology_generation_to_video_coding_wifi as TechnologyGenerationToVideoCodingWifi
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched


def split_and_clean_standard_doc_ids(standard_doc_ids):
    standard_doc_id_array = split(standard_doc_ids, " \\| ")
    standard_doc_id_without_quotes = transform(standard_doc_id_array, lambda x: regexp_replace(x, "“", ""))
    standard_doc_id_without_double_quotes = transform(
        standard_doc_id_without_quotes, lambda x: regexp_replace(x, "”", "")
    )
    final_cleaned = transform(standard_doc_id_without_double_quotes, lambda x: regexp_replace(x, "=\\|=", " | "))

    return final_cleaned


def apply(df):
    return df.withColumns(
        {
            "enriched_technology_generation": col(TechnologyGenerationToVideoCodingWifi.TECHNOLOGY_GENERATION),
            DeclarationRawEnriched.STANDARD_DOCUMENT_ID: explode(
                split_and_clean_standard_doc_ids(col(TechnologyGenerationToVideoCodingWifi.STANDARD_DOCUMENT_IDS))
            ),
        }
    ).drop(
        TechnologyGenerationToVideoCodingWifi.STANDARD_DOCUMENT_IDS,
        TechnologyGenerationToVideoCodingWifi.TECHNOLOGY_GENERATION,
    )
