from pyspark.sql.functions import col

from src.declarations.models.bronze.declarations.declaring_company_lookup import (
    DeclaringCompanyLookup,
)
from src.declarations.models.landing.declaring_company_lookup_csv import (
    DeclaringCompanyLookupCsv,
)


class DeclaringCompanyLookupMapper:
    @staticmethod
    def apply(df):
        return df.withColumns(
            {
                DeclaringCompanyLookup.DECLARING_COMPANY: col(DeclaringCompanyLookupCsv.ORIGINAL_NAME),
                DeclaringCompanyLookup.DECLARING_COMPANY_HARMONIZED: col(DeclaringCompanyLookupCsv.HARMONIZED_NAME),
            }
        ).drop(DeclaringCompanyLookupCsv.ORIGINAL_NAME, DeclaringCompanyLookupCsv.HARMONIZED_NAME)
