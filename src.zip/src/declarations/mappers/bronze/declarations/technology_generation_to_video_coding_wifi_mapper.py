from pyspark.sql.functions import col

import src.declarations.models.bronze.declarations.technology_generation_to_video_coding_wifi as TechnologyGenerationToVideoCodingWifi
from src.declarations.models.landing.technology_generation_to_video_coding_wifi_csv import (
    TechnologyGenerationToVideoCodingWifiCsv,
)


class TechnologyGenerationToVideoCodingWifiMapper:
    @staticmethod
    def apply(df):
        return df.withColumns(
            {
                TechnologyGenerationToVideoCodingWifi.TECHNOLOGY_GENERATION: col(
                    TechnologyGenerationToVideoCodingWifiCsv.TECHNOLOGY_GENERATION
                ),
                TechnologyGenerationToVideoCodingWifi.STANDARD_DOCUMENT_IDS: col(
                    TechnologyGenerationToVideoCodingWifiCsv.STANDARD_DOCUMENT_IDS
                ),
            }
        )
