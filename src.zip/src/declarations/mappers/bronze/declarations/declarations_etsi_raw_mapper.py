from pyspark.sql.functions import col, date_format, lit, substring, trim, when

import src.declarations.models.landing.declarations_etsi_raw_csv as DeclarationsEtsiRawCsv
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declaration_raw_helper import DeclarationRawHelperClass
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)
from src.declarations.utils.licensing_info_helper_task import LicensingInfoHelper


def apply(df):
    return (
        df.withColumns(
            {
                DeclarationRaw.ISLD: col(DeclarationsEtsiRawCsv.ISLD),
                DeclarationRaw.SECTION: trim(col(DeclarationsEtsiRawCsv.SECTION)),
                DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER: col(DeclarationsEtsiRawCsv.COUNTRY_OF_REGISTRATION_OTHER),
                DeclarationRaw.STANDARD_DOCUMENT_TITLE: trim(col(DeclarationsEtsiRawCsv.STANDARD_DOCUMENT_TITLE)),
                DeclarationRaw.STANDARD_PROJECT: _get_standard_project(),
                DeclarationRaw.STANDARD_DOCUMENT_ID: col(DeclarationsEtsiRawCsv.STANDARD_DOCUMENT_ID),
                DeclarationRaw.DECLARING_COMPANY: col(DeclarationsEtsiRawCsv.DECLARING_COMPANY),
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION: col(DeclarationsEtsiRawCsv.APPLICATION_AS_TO_DECLARATION),
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION: col(DeclarationsEtsiRawCsv.PUBLICATION_AS_TO_DECLARATION),
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER: col(
                    DeclarationsEtsiRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER
                ),
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER: col(
                    DeclarationsEtsiRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER
                ),
                DeclarationRaw.DECLARATION_DATE: _get_declaration_date(),
                DeclarationRaw.POOL_PROVIDER: _get_pool_provider(),
                DeclarationRaw.PATENT_POOL_NAME: _get_patent_pool_name(),
                DeclarationRaw.POOL_NAME_HARMONIZED: _get_pool_name_harmonized(),
                DeclarationRaw.STANDARD_MATCH_ID: col(DeclarationsEtsiRawCsv.STANDARD_MATCH_ID),
                DeclarationRaw.LICENSING_TERMS: _get_licensing_terms(),
                DeclarationRaw.SPECIFIC_LICENSING_CONDITIONS: _get_specific_licensing_terms(),
                DeclarationRaw.RECIPROCITY_STATEMENT: col(DeclarationsEtsiRawCsv.RECIPROCITY_STATEMENT),
                DeclarationRaw.LICENSING_COMMENT: col(DeclarationsEtsiRawCsv.LICENSING_COMMENT),
                DeclarationRaw.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES: col(
                    DeclarationsEtsiRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES
                ),
                DeclarationRaw.CONTACT_PERSON_FOR_LICENSE: trim(col(DeclarationsEtsiRawCsv.CONTACT_PERSON_FOR_LICENSE)),
                DeclarationRaw.CONTACT_PERSON_POSITION: trim(col(DeclarationsEtsiRawCsv.CONTACT_PERSON_POSITION)),
                DeclarationRaw.CONTACT_ADDRESS_FOR_LICENSE: trim(
                    col(DeclarationsEtsiRawCsv.CONTACT_ADDRESS_FOR_LICENSE)
                ),
                DeclarationRaw.CONTACT_PHONE_FOR_LICENSE: trim(
                    col(DeclarationsEtsiRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE)
                ),
                DeclarationRaw.CONTACT_EMAIL_FOR_LICENSE: trim(col(DeclarationsEtsiRawCsv.CONTACT_EMAIL_FOR_LICENSE)),
                DeclarationRaw.COUNTRY_OF_REGISTRATION: trim(col(DeclarationsEtsiRawCsv.COUNTRY_OF_REGISTRATION)),
                DeclarationRaw.PATENT_PROPRIETORS: trim(col(DeclarationsEtsiRawCsv.PATENT_PROPRIETORS)),
                DeclarationRaw.PROPRIETORS_OTHER_MEMBERS: trim(col(DeclarationsEtsiRawCsv.PROPRIETORS_OTHER_MEMBERS)),
                DeclarationRaw.PATENT_TITLE: trim(col(DeclarationsEtsiRawCsv.PATENT_TITLE)),
                DeclarationRaw.DECLARANT_IS_PROPRIETOR: trim(col(DeclarationsEtsiRawCsv.DECLARANT_IS_PROPRIETOR)),
                DeclarationRaw.DATA_PROVIDER: _get_data_provider(),
                DeclarationRaw.ESSENTIAL_CLAIM_NO: lit(None).cast("string"),
                DeclarationRaw.TYPE: _get_type(),
                DeclarationRaw.SSO: _get_sso(),
                DeclarationRaw.ID: _get_id(),
                DeclarationRaw.ID_FIRST_CHAR: substring(col(DeclarationRaw.ID), 1, 1),
            }
        )
        .dropDuplicates([DeclarationRaw.ID])
        .drop(
            DeclarationsEtsiRawCsv.STANDARD_PROJECT,
            DeclarationsEtsiRawCsv.STANDARD_DOCUMENT_ID,
            DeclarationsEtsiRawCsv.DECLARING_COMPANY,
            DeclarationsEtsiRawCsv.APPLICATION_AS_TO_DECLARATION,
            DeclarationsEtsiRawCsv.PUBLICATION_AS_TO_DECLARATION,
            DeclarationsEtsiRawCsv.DECLARATION_DATE,
            DeclarationsEtsiRawCsv.PATENT_POOLED,
            DeclarationsEtsiRawCsv.STANDARD_MATCH_ID,
            DeclarationsEtsiRawCsv.LICENSING_TERMS,
            DeclarationsEtsiRawCsv.SPECIFIC_LICENSING_CONDITIONS,
            DeclarationsEtsiRawCsv.RECIPROCITY_STATEMENT,
            DeclarationsEtsiRawCsv.LICENSING_COMMENT,
            DeclarationsEtsiRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES,
            DeclarationsEtsiRawCsv.CONTACT_PERSON_FOR_LICENSE,
            DeclarationsEtsiRawCsv.CONTACT_PERSON_POSITION,
            DeclarationsEtsiRawCsv.CONTACT_ADDRESS_FOR_LICENSE,
            DeclarationsEtsiRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE,
            DeclarationsEtsiRawCsv.CONTACT_EMAIL_FOR_LICENSE,
            DeclarationsEtsiRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationsEtsiRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationsEtsiRawCsv.COUNTRY_OF_REGISTRATION,
            DeclarationsEtsiRawCsv.PATENT_PROPRIETORS,
            DeclarationsEtsiRawCsv.PROPRIETORS_OTHER_MEMBERS,
            DeclarationsEtsiRawCsv.PATENT_TITLE,
            DeclarationsEtsiRawCsv.DECLARANT_IS_PROPRIETOR,
            DeclarationsEtsiRawCsv.DECLARING_COMPANY_HARMONIZED,
            DeclarationsEtsiRawCsv.PUBLICATION_NUMBER,
            DeclarationsEtsiRawCsv.INPADOC_FAMILY_ID,
            DeclarationsEtsiRawCsv.INPADOC_FAMILY_EXTENSIONS,
            DeclarationsEtsiRawCsv.SINGLE_FAMILY_EXTENSIONS,
            DeclarationsEtsiRawCsv.COUNTRY_OF_REGISTRATION_OTHER,
            DeclarationsEtsiRawCsv.STANDARD_DOCUMENT_TITLE,
        )
    )


def _get_standard_project():
    return DeclarationRawHelperClass.get_standard_project_rename(
        col(DeclarationsEtsiRawCsv.SSO), col(DeclarationRaw.CSV_FILE_NAME)
    )


def _get_declaration_date():
    return date_format(
        HelperFunctionForParseDate.parse_date(col(DeclarationsEtsiRawCsv.DECLARATION_DATE)), "yyyy-MM-dd"
    )


def _get_pool_provider():
    return DeclarationRawHelperClass.get_patent_pool_rename(
        DeclarationRawHelperClass.parse_pool_name(col(DeclarationsEtsiRawCsv.PATENT_POOLED))
    )


def _get_patent_pool_name():
    return DeclarationRawHelperClass.get_patent_pool_rename_with_standard_doc_id(
        DeclarationRawHelperClass.parse_pool_name(col(DeclarationsEtsiRawCsv.PATENT_POOLED)),
        col(DeclarationRaw.STANDARD_DOCUMENT_ID),
    )


def _get_pool_name_harmonized():
    return DeclarationRawHelperClass.get_harmonize_pool_name(
        col(DeclarationsEtsiRawCsv.PATENT_POOLED), col(DeclarationRaw.STANDARD_PROJECT)
    )


def _get_licensing_terms():
    return LicensingInfoHelper.get_licensing_terms(
        col(DeclarationRaw.PATENT_POOL_NAME), col(DeclarationsEtsiRawCsv.LICENSING_TERMS)
    )


def _get_specific_licensing_terms():
    return LicensingInfoHelper.get_specific_licensing_terms(
        col(DeclarationRaw.PATENT_POOL_NAME),
        col(DeclarationRaw.STANDARD_PROJECT),
        col(DeclarationsEtsiRawCsv.SPECIFIC_LICENSING_CONDITIONS),
    )


def _get_data_provider():
    return DeclarationRawHelperClass.get_data_provider_based_on_sso_pool_name(
        col(DeclarationsEtsiRawCsv.SSO), col(DeclarationRaw.PATENT_POOL_NAME)
    )


def _get_type():
    return DeclarationRawHelperClass.get_type(
        DeclarationRaw.APPLICATION_AS_TO_DECLARATION,
        DeclarationRaw.PUBLICATION_AS_TO_DECLARATION,
        DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER,
        DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER,
    )


def _get_sso():
    return when(col(DeclarationsEtsiRawCsv.SSO) == "Via LA", None).otherwise(col(DeclarationsEtsiRawCsv.SSO))


def _get_id():
    return DeclarationsIdGeneratorHelper.make_id_for_declaration_etsi_raw_udf(
        col(DeclarationRaw.STANDARD_PROJECT),
        col(DeclarationRaw.STANDARD_DOCUMENT_ID),
        col(DeclarationRaw.DECLARING_COMPANY),
        col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION),
        col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION),
        col(DeclarationRaw.DECLARATION_DATE),
        col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER),
        col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER),
    )
