from pyspark.sql.functions import col, collect_set, explode, split

import src.declarations.models.bronze.declarations.technology_to_video_coding_wifi_standard_project as TechnologyToVideoCodingWifiStandardProject
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched


def _split_and_clean_standard_doc_ids(standard_projects):
    return split(standard_projects, " \\| ")


def apply(df):
    return (
        df.withColumn(
            DeclarationRawEnriched.STANDARD_PROJECT,
            explode(
                _split_and_clean_standard_doc_ids(col(TechnologyToVideoCodingWifiStandardProject.STANDARD_PROJECTS))
            ),
        )
        .groupBy(DeclarationRawEnriched.STANDARD_PROJECT)
        .agg(
            collect_set(col(TechnologyToVideoCodingWifiStandardProject.TECHNOLOGY_GENERATION)).alias(
                "enriched_technology_generation_by_standard_project"
            )
        )
        .drop(
            TechnologyToVideoCodingWifiStandardProject.TECHNOLOGY_GENERATION,
            TechnologyToVideoCodingWifiStandardProject.STANDARD_PROJECTS,
        )
    )
