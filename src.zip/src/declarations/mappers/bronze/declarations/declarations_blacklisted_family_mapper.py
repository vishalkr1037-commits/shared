from pandas import DataFrame
from pyspark.sql.functions import col

from src.declarations.models.bronze.declarations.declarations_blacklisted_family import (
    DeclarationsBlackListedFamily,
)
from src.declarations.models.landing.declarations_blacklisted_family_csv import (
    DeclarationsBlackListedFamilyCsv,
)


class DeclarationsBlackListedFamilyMapper:
    @staticmethod
    def apply(df: DataFrame):

        return df.withColumns(
            {
                DeclarationsBlackListedFamily.SIMPLE_FAMILY_ID: col(DeclarationsBlackListedFamilyCsv.SIMPLE_FAMILY_ID),
                DeclarationsBlackListedFamily.BLACKLISTED_PUBLICATION_ID_FAMILY: col(
                    DeclarationsBlackListedFamilyCsv.BLACKLISTED_PUBLICATION_ID_FAMILY
                ),
            }
        )
