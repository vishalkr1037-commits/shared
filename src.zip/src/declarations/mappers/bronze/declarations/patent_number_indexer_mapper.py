from pyspark.sql.functions import col, concat_ws, date_format

import src.declarations.models.bronze.patents.patent_family as PatentFamily
import src.declarations.models.bronze.patents.patent_status as PatentStatus
import src.declarations.models.bronze.patents.patents_index as PatentsIndex
import src.declarations.models.silver.patents.patent_number_index as PatentNumberIndex


def apply(df):
    return df.withColumns(
        {
            PatentNumberIndex.PUBLICATION_NUMBER_SEARCH: col(PatentsIndex.PUBLICATION_NUMBER),
            PatentNumberIndex.APPLICATION_NUMBER_SEARCH: col(PatentsIndex.APPLICATION_NUMBER),
            PatentNumberIndex.PUBLICATION_DATE: date_format(col(PatentsIndex.PUBLICATION_DATE), "yyyy-MM-dd"),
            PatentNumberIndex.GRANTED: col(PatentStatus.GRANTED),
            PatentNumberIndex.ALL_PRIORITY_NUMBERS_SEARCH: concat_ws("|", col(PatentFamily.ALL_PRIORITY_NUMBERS)),
        }
    ).drop(
        PatentsIndex.PUBLICATION_NUMBER,
        PatentsIndex.PUBLICATION_ID,
        PatentsIndex.APPLICATION_NUMBER,
        PatentFamily.ALL_PRIORITY_NUMBERS,
    )
