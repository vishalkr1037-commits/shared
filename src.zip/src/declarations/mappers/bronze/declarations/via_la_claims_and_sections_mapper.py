from pyspark.sql.functions import col, lit, regexp_replace, trim, when

import src.declarations.models.bronze.declarations.via_la_claims_and_sections as ViaLAClaimsAndSections
from src.declarations.models.landing.via_la_claims_and_sections_csv import (
    ViaLAClaimsAndSectionsCsv,
)


class ViaLaClaimsAndSectionsMapper:
    @staticmethod
    def apply(df):
        return df.withColumns(
            {
                ViaLAClaimsAndSections.STANDARD_PROJECT: ViaLaClaimsAndSectionsMapper.__get_standard_project(
                    col(ViaLAClaimsAndSectionsCsv.STANDARD_PROJECT)
                ),
                ViaLAClaimsAndSections.PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE: col(
                    ViaLAClaimsAndSectionsCsv.PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE
                ),
                ViaLAClaimsAndSections.PUBLICATION_AS_TO_DECLARATION: col(ViaLAClaimsAndSectionsCsv.PATENT_NUMBER),
                ViaLAClaimsAndSections.ESSENTIAL_CLAIMS: col(ViaLAClaimsAndSectionsCsv.ESSENTIAL_CLAIMS),
                ViaLAClaimsAndSections.SECTION: col(ViaLAClaimsAndSectionsCsv.SECTION),
            }
        ).drop(
            ViaLAClaimsAndSectionsCsv.STANDARD_PROJECT,
            ViaLAClaimsAndSectionsCsv.PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE,
            ViaLAClaimsAndSectionsCsv.PATENT_NUMBER,
            ViaLAClaimsAndSectionsCsv.ESSENTIAL_CLAIMS,
            ViaLAClaimsAndSectionsCsv.SECTION,
        )

    @staticmethod
    def __get_standard_project(standard_project):
        standard_project = trim(regexp_replace(standard_project, "Pool Program:", ""))

        return (
            when(standard_project == "HEVC", lit("HEVC (H.265)"))
            .when(standard_project == "VVC", lit("VVC (H.266)"))
            .when(standard_project == "AVC", lit("AVC/H.264"))
            .when(standard_project == "EV Charging", lit("EV, Charging"))
            .when(standard_project == "ATSC 3.0", lit("ATSC, 3.0"))
            .when(standard_project == "MPEG-2 Systems", lit("MPEG-2"))
            .otherwise(standard_project)
        )
