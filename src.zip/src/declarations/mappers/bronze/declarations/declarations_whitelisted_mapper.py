from pandas import DataFrame
from pyspark.sql.functions import col

from src.declarations.models.bronze.declarations.declarations_whitelisted import (
    DeclarationsWhiteListed,
)
from src.declarations.models.landing.declarations_whitelisted_csv import (
    DeclarationsWhiteListedCsv,
)


class DeclarationsWhiteListedMapper:
    @staticmethod
    def apply(df: DataFrame):

        return df.withColumns(
            {
                DeclarationsWhiteListed.WHITELISTED_WORKING_NUMBER: col(
                    DeclarationsWhiteListedCsv.WHITELISTED_WORKING_NUMBER
                ),
                DeclarationsWhiteListed.WHITELISTED_PUBLICATION_NUMBER: col(
                    DeclarationsWhiteListedCsv.WHITELISTED_PUBLICATION_NUMBER
                ),
            }
        )
