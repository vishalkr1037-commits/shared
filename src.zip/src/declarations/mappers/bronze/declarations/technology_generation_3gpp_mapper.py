from pyspark.sql import functions as F

import src.declarations.models.bronze.declarations.technology_generation_3gpp as TechnologyGeneration3gpp
from src.declarations.models.landing.technology_generation_3gpp_csv import (
    TechnologyGeneration3GPPCsv,
)


class TechnologyGeneration3GPPMapper:

    @staticmethod
    def apply(df):
        return df.withColumns(
            {
                TechnologyGeneration3gpp.ID: F.col(TechnologyGeneration3GPPCsv.ID),
                TechnologyGeneration3gpp.SPEC_NO: F.col(TechnologyGeneration3GPPCsv.SPECNO),
                TechnologyGeneration3gpp.TYPE: F.col(TechnologyGeneration3GPPCsv.TYPE),
                TechnologyGeneration3gpp.TITLE: F.col(TechnologyGeneration3GPPCsv.TITLE),
                TechnologyGeneration3gpp.STATUS: F.col(TechnologyGeneration3GPPCsv.STATUS),
                TechnologyGeneration3gpp.PRIMARY_RESP_GRP: F.col(TechnologyGeneration3GPPCsv.PRIMARY_RESP_GRP),
                TechnologyGeneration3gpp.AUTHOR: F.col(TechnologyGeneration3GPPCsv.AUTHOR),
                TechnologyGeneration3gpp.INITIAL_PLANNED_RELEASE: F.col(
                    TechnologyGeneration3GPPCsv.INITIAL_PLANNED_RELEASE
                ),
                TechnologyGeneration3gpp.PUBLICATION: F.col(TechnologyGeneration3GPPCsv.PUBLICATION),
                TechnologyGeneration3gpp.COMMON_IMS: F.col(TechnologyGeneration3GPPCsv.COMMON_IMS),
                TechnologyGeneration3gpp.TECHNOLOGY_GENERATION: F.regexp_replace(
                    F.col(TechnologyGeneration3GPPCsv.TECHNOLOGY_GENERATION), "LTE", "4G"
                ),
            }
        ).select(
            TechnologyGeneration3gpp.ID,
            TechnologyGeneration3gpp.TITLE,
            TechnologyGeneration3gpp.STATUS,
            TechnologyGeneration3gpp.PRIMARY_RESP_GRP,
            TechnologyGeneration3gpp.AUTHOR,
            TechnologyGeneration3gpp.INITIAL_PLANNED_RELEASE,
            TechnologyGeneration3gpp.PUBLICATION,
            TechnologyGeneration3gpp.COMMON_IMS,
            TechnologyGeneration3gpp.TECHNOLOGY_GENERATION,
        )
