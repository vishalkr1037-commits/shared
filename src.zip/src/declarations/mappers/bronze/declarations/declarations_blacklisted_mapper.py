from pandas import DataFrame
from pyspark.sql.functions import col

from src.declarations.models.bronze.declarations.declarations_blacklisted import (
    DeclarationsBlackListed,
)
from src.declarations.models.landing.declarations_blacklisted_csv import (
    DeclarationsBlackListedCsv,
)


class DeclarationsBlackListedMapper:
    @staticmethod
    def apply(df: DataFrame):

        return df.withColumns(
            {
                DeclarationsBlackListed.BLACKLISTED_WORKING_NUMBER: col(
                    DeclarationsBlackListedCsv.BLACKLISTED_WORKING_NUMBER
                ),
                DeclarationsBlackListed.BLACKLISTED_PUBLICATION_NUMBER: col(
                    DeclarationsBlackListedCsv.BLACKLISTED_PUBLICATION_NUMBER
                ),
            }
        )
