from pyspark.sql.functions import col

import src.declarations.models.bronze.declarations.technology_generation_classification as TechnologyGenerationClassification
from src.declarations.models.landing.technology_generation_classification_csv import (
    TechnologyGenerationClassificationCsv,
)


class TechnologyGenerationClassificationMapper:
    @staticmethod
    def apply(df):
        return df.withColumns(
            {
                TechnologyGenerationClassification.STANDARD_DOC_ID: col(
                    TechnologyGenerationClassificationCsv.STANDARD_DOC_ID
                ),
                TechnologyGenerationClassification.TECHNOLOGY_CLASSIFICATION: col(
                    TechnologyGenerationClassificationCsv.TECHNOLOGY_CLASSIFICATION
                ),
            }
        )
