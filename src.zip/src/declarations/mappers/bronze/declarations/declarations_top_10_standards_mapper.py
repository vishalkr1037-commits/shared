from pyspark.sql import functions as F

import src.declarations.models.bronze.undeclared_declarations.top_10_standards_per_committee as top_10_standards
import src.declarations.models.landing.declarations_top_10_standards_csv as top_10_standards_csv


def apply(df):
    return df.withColumns(
        {
            top_10_standards.TECHNOLOGY_GENERATION: F.col(top_10_standards_csv.TECHNOLOGY_GENERATION),
            top_10_standards.GROUP: F.col(top_10_standards_csv.GROUP),
            top_10_standards.STANDARD_DOCUMENT_ID: F.col(top_10_standards_csv.STANDARD_DOCUMENT_ID),
        }
    )
