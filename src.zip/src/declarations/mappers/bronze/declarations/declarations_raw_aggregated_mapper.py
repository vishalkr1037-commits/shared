from pyspark.sql.functions import col, collect_set, explode, split, when

from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.landing.declarations_pooled_raw_csv import (
    DeclarationsPooledRawCsv,
)


def apply(df):
    return (
        df.withColumns(
            {
                DeclarationRaw.ISLD: explode(split(DeclarationRaw.ISLD, " \\| ")),
                DeclarationsPooledRawCsv.DISCLOSURE_NUMBER: _validate_integer_column(),
            }
        )
        .groupBy(DeclarationRaw.ID)
        .agg(
            collect_set(DeclarationRaw.ISLD).alias(DeclarationRaw.ISLD_AGGREGATED),
            collect_set(DeclarationsPooledRawCsv.DISCLOSURE_NUMBER).alias(DeclarationRaw.DISCLOSURE_NUMBER_AGGREGATED),
            collect_set(DeclarationRaw.SECTION).alias(DeclarationRaw.SECTION_AGGREGATED),
        )
        .orderBy(DeclarationRaw.ID)
    )


def _validate_integer_column():
    return when(
        col(DeclarationsPooledRawCsv.DISCLOSURE_NUMBER).cast("int").isNotNull(),
        col(DeclarationsPooledRawCsv.DISCLOSURE_NUMBER).cast("int"),
    ).otherwise(None)
