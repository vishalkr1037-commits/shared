from pyspark.sql.functions import (
    array_distinct,
    col,
    collect_set,
    first,
    flatten,
    split,
    substring_index,
    trim,
    when,
)

import src.declarations.models.bronze.declarations.three_gpp_specification as ThreeGppSpecificationSet
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched


def get_non_empty_clean_standard_id(id_col):
    return when(id_col.isNotNull() & (id_col != ""), id_col).otherwise(None)


def apply(df):
    return (
        df.withColumn(
            DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID,
            get_non_empty_clean_standard_id(substring_index(col(ThreeGppSpecificationSet.ID), "_", 1)),
        )
        .filter(
            col(DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID).isNotNull()
            & (col(DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID) != "")
        )
        .groupBy(DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID)
        .agg(
            flatten(collect_set(split(col(ThreeGppSpecificationSet.RELEASE), "\\|"))).alias(
                ThreeGppSpecificationSet.RELEASE
            ),
            flatten(collect_set(split(col(ThreeGppSpecificationSet.TECHNOLOGY_GENERATION), "\\|"))).alias(
                "technology_generation_ss3"
            ),
            first(col(ThreeGppSpecificationSet.GROUP), True).alias(ThreeGppSpecificationSet.GROUP),
            first(trim(col(ThreeGppSpecificationSet.TITLE)), True).alias(ThreeGppSpecificationSet.TITLE),
        )
        .withColumns(
            {
                ThreeGppSpecificationSet.RELEASE: array_distinct(col(ThreeGppSpecificationSet.RELEASE)),
                "technology_generation_ss3": array_distinct(col("technology_generation_ss3")),
            }
        )
        .drop(ThreeGppSpecificationSet.ID)
    )
