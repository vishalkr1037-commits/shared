from pyspark.sql.functions import (
    array,
    coalesce,
    col,
    date_format,
    lit,
    regexp_extract,
    row_number,
    substring,
    to_date,
    trim,
    when,
)
from pyspark.sql.window import Window

from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.landing.declarations_pooled_raw_csv import (
    DeclarationsPooledRawCsv,
)
from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declaration_raw_helper import DeclarationRawHelperClass
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)
from src.declarations.utils.licensing_info_helper_task import LicensingInfoHelper


class DeclarationsPooledRawMapper:
    @staticmethod
    def apply(df):
        # Parse ingest date from path/filename BEFORE mapping so dedup can use it
        dir_date = regexp_extract(col("csv_file_name"), r"/(\d{8})/", 1)
        file_date = regexp_extract(col("csv_file_name"), r"_(\d{8})_postprocessed\.csv$", 1)
        df = df.withColumn("_ingest_date", to_date(coalesce(dir_date, file_date), "yyyyMMdd"))

        mapped = df.withColumns(
            {
                DeclarationRaw.ISLD: col(DeclarationsPooledRawCsv.ISLD),
                DeclarationRaw.SECTION: trim(col(DeclarationsPooledRawCsv.SECTION)),
                DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER: lit(None).cast("string"),
                DeclarationRaw.STANDARD_DOCUMENT_TITLE: lit(None).cast("string"),
                DeclarationRaw.STANDARD_PROJECT: DeclarationsPooledRawMapper._get_standard_project(),
                DeclarationRaw.STANDARD_DOCUMENT_ID: col(DeclarationsPooledRawCsv.STANDARD_DOCUMENT_ID),
                DeclarationRaw.DECLARING_COMPANY: col(DeclarationsPooledRawCsv.DECLARING_COMPANY),
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION: col(
                    DeclarationsPooledRawCsv.APPLICATION_AS_TO_DECLARATION
                ),
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION: col(
                    DeclarationsPooledRawCsv.PUBLICATION_AS_TO_DECLARATION
                ),
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER: col(
                    DeclarationsPooledRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER
                ),
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER: col(
                    DeclarationsPooledRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER
                ),
                DeclarationRaw.DECLARATION_DATE: DeclarationsPooledRawMapper._get_declaration_date(),
                DeclarationRaw.POOL_PROVIDER: DeclarationsPooledRawMapper._get_pool_provider(),
                DeclarationRaw.PATENT_POOL_NAME: DeclarationsPooledRawMapper._get_patent_pool_name(),
                DeclarationRaw.POOL_NAME_HARMONIZED: DeclarationsPooledRawMapper._get_pool_name_harmonized(),
                DeclarationRaw.STANDARD_MATCH_ID: col(DeclarationsPooledRawCsv.STANDARD_MATCH_ID),
                DeclarationRaw.LICENSING_TERMS: DeclarationsPooledRawMapper._get_licensing_terms(),
                DeclarationRaw.SPECIFIC_LICENSING_CONDITIONS: DeclarationsPooledRawMapper._get_specific_licensing_terms(),
                DeclarationRaw.RECIPROCITY_STATEMENT: col(DeclarationsPooledRawCsv.RECIPROCITY_STATEMENT),
                DeclarationRaw.LICENSING_COMMENT: col(DeclarationsPooledRawCsv.LICENSING_COMMENT),
                DeclarationRaw.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES: col(
                    DeclarationsPooledRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES
                ),
                DeclarationRaw.CONTACT_PERSON_FOR_LICENSE: DeclarationsPooledRawMapper._get_contact_person_info(),
                DeclarationRaw.CONTACT_PERSON_POSITION: col(DeclarationsPooledRawCsv.CONTACT_PERSON_POSITION),
                DeclarationRaw.CONTACT_ADDRESS_FOR_LICENSE: DeclarationsPooledRawMapper._get_into_for_licensing(),
                DeclarationRaw.CONTACT_PHONE_FOR_LICENSE: col(
                    DeclarationsPooledRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE
                ),
                DeclarationRaw.CONTACT_EMAIL_FOR_LICENSE: DeclarationsPooledRawMapper._get_contact_email(),
                DeclarationRaw.COUNTRY_OF_REGISTRATION: trim(col(DeclarationsPooledRawCsv.COUNTRY_OF_REGISTRATION)),
                DeclarationRaw.PATENT_PROPRIETORS: trim(col(DeclarationsPooledRawCsv.PATENT_PROPRIETORS)),
                DeclarationRaw.PROPRIETORS_OTHER_MEMBERS: trim(col(DeclarationsPooledRawCsv.PROPRIETORS_OTHER_MEMBERS)),
                DeclarationRaw.PATENT_TITLE: trim(col(DeclarationsPooledRawCsv.PATENT_TITLE)),
                DeclarationRaw.DECLARANT_IS_PROPRIETOR: trim(col(DeclarationsPooledRawCsv.DECLARANT_IS_PROPRIETOR)),
                DeclarationRaw.DATA_PROVIDER: DeclarationsPooledRawMapper._get_data_provider(),
                DeclarationRaw.ESSENTIAL_CLAIM_NO: trim(col(DeclarationsPooledRawCsv.ESSENTIAL_CLAIMS)),
                DeclarationRaw.TYPE: DeclarationsPooledRawMapper._get_type(),
                DeclarationRaw.SSO: DeclarationsPooledRawMapper._get_sso(),
                DeclarationRaw.ID: DeclarationsPooledRawMapper._get_id(),
                DeclarationRaw.ID_FIRST_CHAR: substring(col(DeclarationRaw.ID), 1, 1),
            }
        ).drop(
            DeclarationsPooledRawCsv.STANDARD_PROJECT,
            DeclarationsPooledRawCsv.STANDARD_DOCUMENT_ID,
            DeclarationsPooledRawCsv.DECLARING_COMPANY,
            DeclarationsPooledRawCsv.APPLICATION_AS_TO_DECLARATION,
            DeclarationsPooledRawCsv.PUBLICATION_AS_TO_DECLARATION,
            DeclarationsPooledRawCsv.DECLARATION_DATE,
            DeclarationsPooledRawCsv.PATENT_POOLED,
            DeclarationsPooledRawCsv.STANDARD_MATCH_ID,
            DeclarationsPooledRawCsv.LICENSING_TERMS,
            DeclarationsPooledRawCsv.SPECIFIC_LICENSING_CONDITIONS,
            DeclarationsPooledRawCsv.RECIPROCITY_STATEMENT,
            DeclarationsPooledRawCsv.LICENSING_COMMENT,
            DeclarationsPooledRawCsv.DECLARANT_AFFILIATES_GRANT_LICENSES,
            DeclarationsPooledRawCsv.CONTACT_PERSON_FOR_LICENSE,
            DeclarationsPooledRawCsv.CONTACT_PERSON_POSITION,
            DeclarationsPooledRawCsv.CONTACT_ADDRESS_FOR_LICENSE,
            DeclarationsPooledRawCsv.CONTACT_PHONE_NUMBER_FOR_LICENSE,
            DeclarationsPooledRawCsv.CONTACT_EMAIL_FOR_LICENSE,
            DeclarationsPooledRawCsv.APPLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationsPooledRawCsv.PUBLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationsPooledRawCsv.COUNTRY_OF_REGISTRATION,
            DeclarationsPooledRawCsv.PATENT_PROPRIETORS,
            DeclarationsPooledRawCsv.PROPRIETORS_OTHER_MEMBERS,
            DeclarationsPooledRawCsv.PATENT_TITLE,
            DeclarationsPooledRawCsv.DECLARANT_IS_PROPRIETOR,
            DeclarationsPooledRawCsv.DECLARING_COMPANY_HARMONIZED,
            DeclarationsPooledRawCsv.PUBLICATION_NUMBER,
            DeclarationsPooledRawCsv.INPADOC_FAMILY_ID,
            DeclarationsPooledRawCsv.INPADOC_FAMILY_EXTENSIONS,
            DeclarationsPooledRawCsv.SINGLE_FAMILY_EXTENSIONS,
            DeclarationsPooledRawCsv.ESSENTIAL_CLAIMS,
        )

        # Deduplicate inside mapper using finalized ID (hash) and latest ingest date
        # Only apply dedup where _ingest_date is present; otherwise keep rows unchanged
        has_date = mapped["_ingest_date"].isNotNull()
        mapped_dated = mapped.filter(has_date)
        mapped_undated = mapped.filter(~has_date).drop("_ingest_date")

        w_latest = Window.partitionBy(col(DeclarationRaw.ID)).orderBy(
            col("_ingest_date").desc(), col(DeclarationRaw.CSV_FILE_NAME).desc()
        )
        mapped_dated_latest = (
            mapped_dated.withColumn("_rn", row_number().over(w_latest))
            .filter(col("_rn") == 1)
            .drop("_rn", "_ingest_date")
        )

        # Align columns and union back undated rows
        common_cols = mapped_dated_latest.columns
        mapped_undated_aligned = mapped_undated.select(*[col(c) for c in common_cols])
        return mapped_dated_latest.unionByName(mapped_undated_aligned)

    @staticmethod
    def _get_standard_project():
        return DeclarationRawHelperClass.get_standard_project_rename(
            col(DeclarationsPooledRawCsv.SSO), col(DeclarationRaw.CSV_FILE_NAME)
        )

    @staticmethod
    def _get_declaration_date():
        return date_format(
            HelperFunctionForParseDate.parse_date(col(DeclarationsPooledRawCsv.DECLARATION_DATE)), "yyyy-MM-dd"
        )

    @staticmethod
    def _get_pool_provider():
        return DeclarationRawHelperClass.get_patent_pool_rename(
            DeclarationRawHelperClass.parse_pool_name(col(DeclarationsPooledRawCsv.PATENT_POOLED))
        )

    @staticmethod
    def _get_patent_pool_name():
        return DeclarationRawHelperClass.get_patent_pool_rename_with_standard_doc_id(
            DeclarationRawHelperClass.parse_pool_name(col(DeclarationsPooledRawCsv.PATENT_POOLED)),
            col(DeclarationRaw.STANDARD_DOCUMENT_ID),
        )

    @staticmethod
    def _get_pool_name_harmonized():
        return DeclarationRawHelperClass.get_harmonize_pool_name(
            col(DeclarationsPooledRawCsv.PATENT_POOLED), col(DeclarationRaw.STANDARD_PROJECT)
        )

    @staticmethod
    def _get_licensing_terms():
        return LicensingInfoHelper.get_licensing_terms(
            col(DeclarationRaw.PATENT_POOL_NAME), col(DeclarationsPooledRawCsv.LICENSING_TERMS)
        )

    @staticmethod
    def _get_specific_licensing_terms():
        return LicensingInfoHelper.get_specific_licensing_terms(
            col(DeclarationRaw.PATENT_POOL_NAME),
            col(DeclarationRaw.STANDARD_PROJECT),
            col(DeclarationsPooledRawCsv.SPECIFIC_LICENSING_CONDITIONS),
        )

    @staticmethod
    def _get_contact_person_info():
        return DeclarationRawHelperClass.get_contact_person_info(col(DeclarationRaw.POOL_PROVIDER))

    @staticmethod
    def _get_contact_email():
        return DeclarationRawHelperClass.get_contact_email(col(DeclarationRaw.POOL_PROVIDER))

    @staticmethod
    def _get_into_for_licensing():
        return DeclarationRawHelperClass.get_info_for_licensing(col(DeclarationRaw.POOL_PROVIDER))

    @staticmethod
    def _get_data_provider():
        return DeclarationRawHelperClass.get_data_provider_based_on_sso_pool_name_csv_file(
            col(DeclarationsPooledRawCsv.SSO), col(DeclarationRaw.PATENT_POOL_NAME), col(DeclarationRaw.CSV_FILE_NAME)
        )

    @staticmethod
    def _get_aggregated_column(column):
        return when(col(column).isNotNull(), array(col(column))).otherwise(None)

    @staticmethod
    def _get_type():
        return lit("POOLED")

    @staticmethod
    def _get_sso():
        return when(col(DeclarationsPooledRawCsv.SSO) == "Via LA", None).otherwise(col(DeclarationsPooledRawCsv.SSO))

    @staticmethod
    def _get_id():
        return DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
            col(DeclarationRaw.STANDARD_PROJECT),
            col(DeclarationRaw.STANDARD_DOCUMENT_ID),
            col(DeclarationRaw.DECLARING_COMPANY),
            col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION),
            col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION),
            col(DeclarationRaw.DECLARATION_DATE),
        )
