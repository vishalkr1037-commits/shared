from pyspark.sql import functions as F
from pyspark.sql.functions import col, when

import src.declarations.models.bronze.undeclared_declarations.undeclared_simple_families as UndeclaredSimpleFamiles
import src.declarations.models.landing.undeclared_simple_family_id_csv as UndeclaredSimpleFamilyIdCsv


def apply(df):
    df = df.withColumns(
        {
            UndeclaredSimpleFamiles.SIMPLE_FAMILY_ID: col(UndeclaredSimpleFamilyIdCsv.SIMPLE_FAMILY_ID),
            UndeclaredSimpleFamiles.CSV_FILE_NAME: col("_metadata.file_path"),
            "tech_prefix": F.regexp_extract(
                col(UndeclaredSimpleFamiles.CSV_FILE_NAME),
                r"/([^/]+)_undeclared_families/",
                1,
            ),
            UndeclaredSimpleFamiles.TECHNOLOGY: when(col("tech_prefix") == "vvc", "VVC (H.266)")
            .when((col("tech_prefix") == "qi1") | (col("tech_prefix") == "qi"), "Qi1")
            .when((col("tech_prefix") == "qi2"), "Qi2")
            .when(col("tech_prefix") == "wifi1", "WIFI1")
            .when(col("tech_prefix") == "wifi2", "WIFI2")
            .when(col("tech_prefix") == "wifi3", "WIFI3")
            .when(col("tech_prefix") == "wifi4", "WIFI4")
            .when(col("tech_prefix") == "wifi5", "WIFI5")
            .when(col("tech_prefix") == "wifi6", "WIFI6")
            .when(col("tech_prefix") == "wifi7", "WIFI7")
            .when(col("tech_prefix") == "hevc", "HEVC (H.265)")
            .when(col("tech_prefix") == "avc", "AVC (H.264)")
            .otherwise(col("tech_prefix")),
        }
    ).drop("_metadata.file_path", "tech_prefix")
    return df
