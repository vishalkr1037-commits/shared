from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.models.silver.undeclared_declarations.undeclared_declarations_family_technology_generation as UndeclaredDeclarationsFamilyTechnologyGeneration
import src.declarations.models.silver.undeclared_declarations.undeclared_declarations_patent_index_preparation_model as UndeclaredDeclarationsPatentIndexPreparationModel
import src.declarations.utils.string_utility as utils


def apply(df: DataFrame) -> DataFrame:
    df = df.withColumn(
        UndeclaredDeclarationsPatentIndexPreparationModel.FAMILY_TECHNOLOGY_GENERATION_ARRAY,
        F.col(UndeclaredDeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION),
    )

    return df.withColumns(
        {
            UndeclaredDeclarationsPatentIndexPreparationModel.TECHNOLOGY_GENERATION: utils.get_set_to_string(
                F.col("technology_generation_array")
            ),
            UndeclaredDeclarationsPatentIndexPreparationModel.GROUP: utils.join_set(F.col("group_array")),
            UndeclaredDeclarationsPatentIndexPreparationModel.RELEASE_ARRAY: utils.split_string_to_set_array(
                F.col("release")
            ),
            UndeclaredDeclarationsPatentIndexPreparationModel.FAMILY_TECHNOLOGY_GENERATION: utils.join_set(
                F.col(UndeclaredDeclarationsPatentIndexPreparationModel.FAMILY_TECHNOLOGY_GENERATION_ARRAY)
            ),
            "title": F.lit(None),
        }
    )
