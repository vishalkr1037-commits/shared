from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def clean_column(col_or_name):

    if isinstance(col_or_name, str):
        col = F.col(col_or_name)
    else:
        # Accept both classic and connect Column types
        col = col_or_name
    return F.regexp_replace(col, "[\\r\\n]", "")


def clean_and_format_date(col_name: str):
    return F.date_format(HelperFunctionForParseDate.parse_date(clean_column(col_name)), "yyyy-MM-dd")


def build_id_column():
    return DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
        clean_column("standard_document_id"),
        clean_column("standard_project"),
        F.initcap(clean_column("declaring_company")),
        clean_and_format_date("declaration_date"),
        clean_column("publication_number"),
        clean_column(F.concat_ws(" | ", F.col("isld"))),
    )


def apply(result: DataFrame) -> DataFrame:
    return result.withColumn("id", build_id_column())
