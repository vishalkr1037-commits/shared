import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from pyspark.sql.types import StringType

import src.declarations.models.bronze.patents.patents_index as PatentIndex

# Assuming these imports exist in your codebase
import src.declarations.models.silver.undeclared_declarations.undeclared_patent_expansion as UndeclaredPatentExpansion
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def apply(df: DataFrame) -> DataFrame:
    return (
        df.withColumns(
            {
                UndeclaredPatentExpansion.PUBLICATION_NUMBER: F.col(PatentIndex.PUBLICATION_NUMBER),
                UndeclaredPatentExpansion.PUBLICATION_ID: F.col(PatentIndex.PUBLICATION_ID),
                UndeclaredPatentExpansion.STANDARD_DOCUMENT_ID: (
                    F.when(F.col("technology") == "WIFI4", F.lit("IEEE 802.11n"))
                    .when(F.col("technology") == "WIFI5", F.lit("IEEE 802.11ac"))
                    .when(F.col("technology") == "WIFI6", F.lit("IEEE 802.11ax"))
                    .when(F.col("technology") == "WIFI7", F.lit("IEEE 802.11be"))
                    .when(F.col("technology") == "AVC", F.lit("ISO/IEC 14496-10:2020"))
                    .when(F.col("technology") == "HEVC", F.lit("CAN/CSA-ISO/IEC 23008-2:21"))
                    .when(F.col("technology") == "VVC", F.lit("ISO/IEC 23090-3:2021"))
                    .when(F.col("technology") == "Qi", F.lit("QI Standard"))
                    .when(F.col("technology") == "AAC", F.lit("ISO/IEC_13818-7"))
                    .when(F.col("technology") == "OPUS", F.lit("RFC_6716"))
                    .when(F.col("technology") == "MPEG", F.lit("ISO/IEC_23008-3"))
                    .when(F.col("technology") == "AV1", F.lit("AV1"))
                    .when(F.col("technology") == "VP9", F.lit("VP9"))
                ),
                UndeclaredPatentExpansion.STANDARD_PROJECT: (
                    F.when(F.col("technology") == "AVC", F.lit("AVC (Advanced Video Coding)"))
                    .when(F.col("technology") == "HEVC", F.lit("HEVC (Hight Efficiency Video Coding)"))
                    .when(F.col("technology") == "VVC", F.lit("VVC (Versatile Video Coding)"))
                    .when(F.col("technology") == "WIFI4", F.lit("IEEE 802.11™ and amendments"))
                    .when(F.col("technology") == "WIFI5", F.lit("IEEE 802.11™ and amendments"))
                    .when(F.col("technology") == "WIFI6", F.lit("IEEE 802.11™ and amendments"))
                    .when(F.col("technology") == "WIFI7", F.lit("IEEE 802.11™ and amendments"))
                    .when(F.col("technology") == "Qi", F.lit("QI Standard"))
                    .when(F.col("technology") == "AAC", F.lit("AAC"))
                    .when(F.col("technology") == "OPUS", F.lit("OPUS"))
                    .when(F.col("technology") == "MPEG", F.lit("MPEG_H 3D"))
                    .when(F.col("technology") == "AV1", F.lit("AV1"))
                    .when(F.col("technology") == "VP9", F.lit("VP9"))
                ),
                UndeclaredPatentExpansion.DECLARING_COMPANY: F.lit("not available (undeclared patent)"),
                UndeclaredPatentExpansion.DECLARATION_DATE: F.lit(None),
                UndeclaredPatentExpansion.ISLD: F.lit("not available (undeclared patent)"),
                UndeclaredPatentExpansion.SECTION: F.lit(None),
                UndeclaredPatentExpansion.ID: DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
                    F.col(UndeclaredPatentExpansion.STANDARD_DOCUMENT_ID),
                    F.col(UndeclaredPatentExpansion.STANDARD_PROJECT),
                    F.col(UndeclaredPatentExpansion.DECLARING_COMPANY),
                    F.col(UndeclaredPatentExpansion.DECLARATION_DATE),
                    F.col(PatentIndex.PUBLICATION_NUMBER),
                    F.col(UndeclaredPatentExpansion.ISLD),
                ),
                UndeclaredPatentExpansion.ID_FIRST_CHAR: F.substring(F.col("id"), 1, 1),
                UndeclaredPatentExpansion.SSO: F.lit(None),
                UndeclaredPatentExpansion.APPLICATION_AS_TO_DECLARATION: F.lit(None),
                UndeclaredPatentExpansion.PUBLICATION_AS_TO_DECLARATION: F.lit(None),
                UndeclaredPatentExpansion.PATENT_POOL_NAME: F.lit(None).cast(StringType()),
                UndeclaredPatentExpansion.LICENSING_TERMS: F.lit(None),
                UndeclaredPatentExpansion.SPECIFIC_LICENSING_CONDITIONS: F.lit(None),
                UndeclaredPatentExpansion.RECIPOCITY_STATEMENT: F.lit(None),
                UndeclaredPatentExpansion.LICENSING_COMMENT: F.lit(None),
                UndeclaredPatentExpansion.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES: F.lit(None),
                UndeclaredPatentExpansion.CONTACT_PERSON_FOR_LICENSE: F.lit(None),
                UndeclaredPatentExpansion.CONTACT_PERSON_POSITION: F.lit(None),
                UndeclaredPatentExpansion.CONTACT_ADDRESS_FOR_LICENSE: F.lit(None),
                UndeclaredPatentExpansion.CONTACT_PHONE_FOR_LICENSE: F.lit(None),
                UndeclaredPatentExpansion.CONTACT_EMAIL_FOR_LICENSE: F.lit(None),
                UndeclaredPatentExpansion.DISCLOSURE_NUMBER: F.lit(None),
                UndeclaredPatentExpansion.SELECTED_PUBLICATION_NUMBER: F.lit(None),
                UndeclaredPatentExpansion.DECLARARION_ID: F.lit(None),
                UndeclaredPatentExpansion.APPLICATION_AS_TO_DECLARATION_OTHER: F.lit(None),
                UndeclaredPatentExpansion.PUBLICATION_AS_TO_DECLARATION_OTHER: F.lit(None),
                UndeclaredPatentExpansion.PUBLICATION_NUMBER_SOURCE: F.lit(None),
                "technology_generation": (
                    F.when(F.col("technology") == "WIFI4", F.lit("Wi-Fi 4 (IEEE 802.11n)"))
                    .when(F.col("technology") == "WIFI5", F.lit("Wi-Fi 5 (IEEE 802.11ac)"))
                    .when(F.col("technology") == "WIFI6", F.lit("Wi-Fi 6 (IEEE 802.11ax)"))
                    .when(F.col("technology") == "WIFI7", F.lit("Wi-Fi 7 (IEEE 802.11be)"))
                    .when(F.col("technology") == "AVC", F.lit("AVC (H.264)"))
                    .when(F.col("technology") == "HEVC", F.lit("HEVC (H.265)"))
                    .when(F.col("technology") == "VVC", F.lit("VVC (H.266)"))
                    .when(F.col("technology") == "Qi", F.lit("Qi1"))
                    .when(F.col("technology") == "AAC", F.lit("AAC"))
                    .when(F.col("technology") == "OPUS", F.lit("OPUS"))
                    .when(F.col("technology") == "MPEG", F.lit("MPEG_H 3D"))
                    .when(F.col("technology") == "AV1", F.lit("AV1"))
                    .when(F.col("technology") == "VP9", F.lit("VP9"))
                ),
                UndeclaredPatentExpansion.TECHNOLOGY_GENERATION_ARRAY: F.array(F.col("technology_generation")),
                UndeclaredPatentExpansion.RELEASE: F.lit(None),
                UndeclaredPatentExpansion.GROUP_ARRAY: F.array().cast("array<string>"),
                UndeclaredPatentExpansion.TYPE: F.lit("UNDECLARED_PATENT"),
                UndeclaredPatentExpansion.POOL_PROVIDER: F.lit(None).cast(StringType()),
                UndeclaredPatentExpansion.POOL_NAME_HARMONIZED: F.lit(None).cast(StringType()),
                UndeclaredPatentExpansion.ESSENTIAL_CLAIM_NUMBER: F.lit(None),
                UndeclaredPatentExpansion.EXPANDED: F.lit("Undeclared patent"),
            }
        )
        .drop(F.col("technology_generation"))
        .drop(F.col("active"))
        .drop(F.col("technology"))
        .drop(F.col("status"))
    )
