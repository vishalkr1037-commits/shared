from pyspark.sql import Window
from pyspark.sql import functions as F


def apply(df):
    window = Window.partitionBy(
        F.col("publication_number"), F.col("harmonized_standard_doc_id"), F.col("publication_date_flag")
    ).orderBy(F.col("publication_date").desc(), F.col("standard_document_id").desc())

    window_final = Window.partitionBy(F.col("publication_number"), F.col("harmonized_standard_doc_id"))

    return (
        df.drop("standard_document_ref")
        .withColumns({"rank": F.rank().over(window)})
        .filter(F.col("rank") == 1)
        .drop(F.col("rank"))
        .withColumns({"count": F.count("publication_date_flag").over(window_final)})
        .filter((F.col("count") == 1) | ((F.col("count") == 2) & (F.col("publication_date_flag") == F.lit(True))))
        .drop("rank", "publication_date_flag", "count", "patent_publication_date", "publication_date")
    )
