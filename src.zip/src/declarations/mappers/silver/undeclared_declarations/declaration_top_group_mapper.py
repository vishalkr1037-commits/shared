from pyspark.sql import functions as F


def pick_top_group():
    return (
        F.when(F.col("group").contains("CT"), F.lit("CT"))
        .when(F.col("group").contains("RAN"), F.lit("RAN"))
        .when(F.col("group").contains("SA"), F.lit("SA"))
        .otherwise(F.lit(""))
    )


def filter_etsi(df):
    return df.filter(F.col("SSO") == "ETSI") if "SSO" in df.columns else df


def add_harmonized_group(df):
    if "group" not in df.columns:
        return df
    return df.filter((F.col("group").isNotNull()) & (F.col("group") != "")).withColumns(
        {
            "harmonized_group": pick_top_group(),
        }
    )


def apply(df):
    return add_harmonized_group(filter_etsi(df))
