from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit, regexp_extract, regexp_replace, trim, when

import src.declarations.models.bronze.declarations.declarations_standard_docid_harmonized as DeclarationsStandardDocidHarmonized
import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFilteredModel
import src.declarations.models.silver.undeclared_declarations.undeclared_declarations_patent_index_preparation_model as UndeclaredDeclarationsPatentIndexPreparationModel
import src.declarations.three_gpp_specifications_helper.standard_doc_helpers as helper
import src.declarations.three_gpp_specifications_helper.standard_doc_udfs as wrapper_udf

get_harmonized_standard_doc_id_udf = wrapper_udf.create_pandas_udf(helper.get_harmonized_standard_doc_id_number)
get_joined_standard_document_id_and_title_udf = wrapper_udf.create_pandas_udf(
    helper.get_joined_standard_document_id_and_title, is_multi_column=True
)

get_release_mapped_on_version_udf = wrapper_udf.create_pandas_udf(
    helper.get_release_mapped_on_version_declarations, is_multi_column=True
)


def apply(df: DataFrame) -> DataFrame:
    df = df.withColumn(
        "harmonized_standard_doc_id",
        get_specifications_based_on_sso(
            get_harmonized_standard_doc_id_udf(
                get_pre_clean_standard_document_id(
                    col(UndeclaredDeclarationsPatentIndexPreparationModel.STANDARD_DOCUMENT_ID)
                )
            ),
            col(DeclarationsStandardDocidHarmonized.STANDARD_DOCUMENT_ID_HARMONIZED_VAL),
        ),
    )

    df = df.withColumn(
        "harmonized_standard_doc_id",
        get_harmonized_id_for_special_cases(
            col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_TITLE),
            col(UndeclaredDeclarationsPatentIndexPreparationModel.SSO),
        ),
    )

    df = df.withColumns(
        {
            UndeclaredDeclarationsPatentIndexPreparationModel.STANDARD_DOCUMENT_ID_HARMONIZED: get_specifications_based_on_sso(
                get_joined_standard_document_id_and_title_udf(
                    col("harmonized_standard_doc_id"),
                    col(DeclarationCompanyFilteredModel.TITLE),
                ),
                col(DeclarationsStandardDocidHarmonized.STANDARD_DOCUMENT_ID_HARMONIZED_VAL),
            ),
            UndeclaredDeclarationsPatentIndexPreparationModel.STANDARD_DOCUMENT_ID_HARMONIZED_SEARCH: col(
                UndeclaredDeclarationsPatentIndexPreparationModel.STANDARD_DOCUMENT_ID_HARMONIZED
            ),
        }
    )

    return df.drop(
        DeclarationsStandardDocidHarmonized.STANDARD_DOCUMENT_ID_HARMONIZED_VAL,
        DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_TITLE,
        DeclarationCompanyFilteredModel.TITLE,
    )


def get_specifications_based_on_sso(col_, std_doc_id_harmonized_val):
    return when(
        (col(UndeclaredDeclarationsPatentIndexPreparationModel.SSO) == "ETSI")
        | (col(UndeclaredDeclarationsPatentIndexPreparationModel.SSO) == "ARIB")
        | is_ccsa()
        | is_atis(),
        col_,
    ).otherwise(std_doc_id_harmonized_val)


def is_3gpp_special_case():
    return (
        col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_ID).rlike(r"[A-Za-z]{2}\s*10\d+\s*\d+")
        & (col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_TITLE) != "")
        & col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_TITLE).isNotNull()
        & col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_TITLE).contains("3GPP TS")
    )


def get_harmonized_id_for_special_cases(standard_document_title, sso):
    three_gpp_part = regexp_extract(standard_document_title, r"TS \d\d\.\d\d", 0)
    std_document_id_harmonized = regexp_replace(three_gpp_part, "version ", "v")
    return when(is_3gpp_special_case() & (sso == "ETSI"), std_document_id_harmonized).otherwise(
        col("harmonized_standard_doc_id")
    )


def is_atis():
    return col(UndeclaredDeclarationsPatentIndexPreparationModel.SSO) == "ATIS"


def is_ccsa():
    return col(UndeclaredDeclarationsPatentIndexPreparationModel.SSO) == "CCSA"


def get_pre_clean_standard_document_id(standard_doc_id):
    return when(is_ccsa(), trim(regexp_replace(standard_doc_id, "3GPP", ""))).otherwise(standard_doc_id)


def get_specifications_based_on_sso_string(col_):
    return when(
        (col(UndeclaredDeclarationsPatentIndexPreparationModel.DATA_PROVIDER) == "ETSI")
        | (col(UndeclaredDeclarationsPatentIndexPreparationModel.DATA_PROVIDER) == "ARIB"),
        col_,
    ).otherwise(lit(""))
