from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from src.declarations.models.silver.essentiality import (
    semantic_similarity_scores_with_text as SemanticSimilarityScoresWithTextModel,
)


def apply(df: DataFrame) -> DataFrame:
    """
    Aggregates claim chart data by ID, collecting top-scored items.
    Equivalent to TopThreeClaimChartMapper in Java.

    Orders by ID and score (descending) before aggregation to ensure
    top items are collected first in the lists.

    Returns:
        DataFrame with arrays of top claim numbers, texts, section numbers, texts, and scores per ID
    """
    return (
        df
        # Order by ID and score descending (ensures top scores come first in aggregated lists)
        .orderBy(
            F.col(SemanticSimilarityScoresWithTextModel.ID), F.col(SemanticSimilarityScoresWithTextModel.SCORE).desc()
        )
        # Group by ID
        .groupBy(SemanticSimilarityScoresWithTextModel.ID)
        # Aggregate into lists (collect_list maintains order from orderBy)
        .agg(
            F.collect_list(SemanticSimilarityScoresWithTextModel.CLAIM_NUMBER).alias(
                SemanticSimilarityScoresWithTextModel.TOP_CLAIM_NUMBERS
            ),
            F.collect_list(SemanticSimilarityScoresWithTextModel.CLAIM_TEXT).alias(
                SemanticSimilarityScoresWithTextModel.TOP_CLAIM_TEXTS
            ),
            F.collect_list(SemanticSimilarityScoresWithTextModel.SECTION_NUMBER).alias(
                SemanticSimilarityScoresWithTextModel.TOP_SECTION_NUMBERS
            ),
            F.collect_list(SemanticSimilarityScoresWithTextModel.SECTION_TEXT).alias(
                SemanticSimilarityScoresWithTextModel.TOP_SECTION_TEXTS
            ),
            F.collect_list(SemanticSimilarityScoresWithTextModel.SCORE).alias(
                SemanticSimilarityScoresWithTextModel.TOP_SCORES
            ),
        )
    )
