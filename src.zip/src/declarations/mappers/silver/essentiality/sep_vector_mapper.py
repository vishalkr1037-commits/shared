"""
Mapper for SEP Scoring vectors (Notebook 05)
Contains functions to transform tokenized data into vectorized format
"""

import logging
from typing import Dict

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, FloatType, StringType, StructField, StructType

from src.declarations.models.silver.essentiality import sep_vector

logger = logging.getLogger("SEPScoringMapper")


def get_models_directory(tech: str, catalog: str, schema: str) -> str:
    """
    Construct standardized model directory path for a given technology.

    Args:
        tech: Technology identifier (wifi, audio, video, qi, atsc, etsi)
        catalog: Databricks catalog name (default: personal_dev)
        schema: Databricks schema/database name (default: shankarg)

    Returns:
        Full path to models directory for the technology

    Example:
        >>> get_models_directory("atsc")
        '/Volumes/personal_dev/shankarg/models/word2vec/atsc'
    """
    return f"/Volumes/{catalog}/{schema}/models/word2vec/{tech}"


def add_tech_column(df: DataFrame, tech: str) -> DataFrame:
    """
    Add technology column to vectorized dataframe

    Args:
        df: Input DataFrame with vectors
        tech: Technology identifier (e.g., 'wifi', 'etsi', 'atsc')

    Returns:
        DataFrame with tech column added
    """
    return df.withColumn(sep_vector.VECTORS_TECH, F.lit(tech))


def _combine_token_arrays(abs_col: str, claims_col: str) -> F.Column:
    """
    Combine abstract and claims token arrays with null handling.

    Args:
        abs_col: Column name for abstract tokens
        claims_col: Column name for claims tokens

    Returns:
        PySpark column with concatenated tokens
    """
    return F.concat(
        F.coalesce(F.col(abs_col), F.array()),
        F.coalesce(F.col(claims_col), F.array()),
    )


def _add_document_id(df: DataFrame, id_col1: str, id_col2: str, separator: str = "|") -> DataFrame:
    """
    Add document_id by concatenating two columns with a separator.

    Args:
        df: Input DataFrame
        id_col1: First column to concatenate
        id_col2: Second column to concatenate
        separator: Separator between columns (default: "|")

    Returns:
        DataFrame with added document_id column
    """
    return df.withColumn("document_id", F.concat(F.col(id_col1), F.lit(separator), F.col(id_col2)))


def prepare_token_sets(claims_df: DataFrame, abstract_df: DataFrame, standards_df: DataFrame) -> Dict[str, DataFrame]:
    """Build token sets for claims-only, claims+abstract, and standards.

    Returns a dict with two DataFrames ready for vectorization: claims_only_std and
    claims_and_abstract_std (both unioned with standards).
    """
    logger.info("Preparing uniquely identified token sets...")

    claims_only_df = (
        _add_document_id(claims_df, "publication_number", "claim_id")
        .select("document_id", "processed_tokens")
        .distinct()
    )
    logger.info(f"Created claims-only token set with {claims_only_df.count()} claims.")

    claims_abs_df = (
        claims_df.withColumnRenamed("processed_tokens", "claims_processed_tokens")
        .join(
            abstract_df.withColumnRenamed("processed_tokens", "abs_processed_tokens"),
            on="publication_number",
            how="left",
        )
        .withColumn(
            "claims_abs_processed_tokens",
            _combine_token_arrays("abs_processed_tokens", "claims_processed_tokens"),
        )
        .transform(lambda df: _add_document_id(df, "publication_number", "claim_id"))
        .withColumnRenamed("claims_abs_processed_tokens", "processed_tokens")
        .select("document_id", "processed_tokens")
        .distinct()
    )
    logger.info(f"Created claims+abstract token set with {claims_abs_df.count()} documents.")

    std_df = (
        _add_document_id(standards_df, "most_meaningful_standard_document_id", "section_number")
        .select("document_id", "processed_tokens")
        .distinct()
    )
    logger.info(f"Created standards token set with {std_df.count()} sections.")

    return {
        "claims_only_std": claims_only_df.unionByName(std_df),
        "claims_and_abstract_std": claims_abs_df.unionByName(std_df),
    }


def prepare_vector_schema(model_names: list) -> StructType:
    """
    Prepare schema for vectorized output dataframe

    Args:
        model_names: List of model names (e.g., ['Word2Vec_Claims', 'Word2Vec_Claims_Abs'])

    Returns:
        StructType schema for output
    """
    fields = [StructField("tech", StringType(), False), StructField("document_id", StringType(), False)]

    for model_name in model_names:
        fields.append(StructField(model_name, ArrayType(FloatType()), True))

    return StructType(fields)


def apply_svd_enhancement(df: DataFrame, model_name: str, svd_component) -> DataFrame:
    """
    Apply SVD enhancement to remove common principal components from vectors

    Args:
        df: Input DataFrame with vector column
        model_name: Name of the model column to enhance
        svd_component: SVD component vector to remove

    Returns:
        DataFrame with enhanced vectors
    """
    import numpy as np

    def remove_component_udf(v):
        if v is None:
            return None
        vec = np.array(v)
        # Remove the projection of common component
        transformed_vec = vec - vec.dot(svd_component.T) * svd_component
        return transformed_vec.flatten().tolist()

    from pyspark.sql.functions import udf
    from pyspark.sql.types import ArrayType, FloatType

    svd_udf = udf(remove_component_udf, ArrayType(FloatType()))
    return df.withColumn(model_name, svd_udf(F.col(model_name)))


def apply_multiple_svd_enhancements(df: DataFrame, model_cols: list, models_dir: str) -> DataFrame:
    """
    Apply SVD enhancements to all model vector columns

    Args:
        df: Input DataFrame with vector columns
        model_cols: List of model column names to enhance
        models_dir: Directory path where SVD components are stored (supports Databricks Volumes)

    Returns:
        DataFrame with all SVD enhancements applied
    """
    import os

    import joblib

    logger.info(f"Applying SVD enhancement to {len(model_cols)} models...")

    for model_name in model_cols:
        try:
            # Direct path to model directory for SVD components
            base_dir = models_dir.rstrip("/")
            if models_dir.startswith("/Volumes/"):
                candidate_svd_paths = [
                    f"{base_dir}/{model_name}/svd_component.joblib",
                    f"{base_dir}/{model_name}/{model_name}/svd_component.joblib",
                ]
            else:
                candidate_svd_paths = [
                    os.path.join(base_dir, model_name, "svd_component.joblib"),
                    os.path.join(base_dir, model_name, model_name, "svd_component.joblib"),
                ]

            svd_path = next((p for p in candidate_svd_paths if os.path.isfile(p)), None)
            if not svd_path:
                raise FileNotFoundError(f"svd_component.joblib not found in {candidate_svd_paths}")

            logger.info(f"  Loading SVD component from: {svd_path}")
            common_component = joblib.load(svd_path)
            df = apply_svd_enhancement(df, model_name, common_component)
            logger.info(f"  ✓ Applied SVD transformation for {model_name}")
        except Exception as e:
            logger.warning(f"  ⚠ Could not apply SVD for {model_name}. Skipping. Error: {e}")

    return df


def reorder_columns(df: DataFrame, model_cols: list) -> DataFrame:
    """
    Reorder columns to match model schema (tech, document_id, then model vectors)

    Args:
        df: Input DataFrame with all columns
        model_cols: List of model column names in desired order

    Returns:
        DataFrame with reordered columns
    """
    col_order = [sep_vector.VECTORS_TECH, sep_vector.VECTORS_DOCUMENT_ID] + model_cols
    return df.select(col_order)
