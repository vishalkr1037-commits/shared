# src/declarations/mappers/silver/essentiality/semantic_similarity_scores_with_text_mapper.py

from dataclasses import dataclass
from typing import Dict, List

from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.column import Column


@dataclass
class PredictionConfig:
    """Configuration for prediction thresholds by technology."""

    high_bound_declared: float
    mid_bound_declared: float
    high_bound_undeclared: float
    mid_bound_undeclared: float
    doc_origin: List[str] = None

    def __post_init__(self):
        if self.doc_origin is None:
            self.doc_origin = ["declared", "testing"]


# Technology-specific configurations for prediction thresholds: must be updated after ses prediction re run
TECH_CONFIGS: Dict[str, PredictionConfig] = {
    "WIFI": PredictionConfig(
        high_bound_declared=0.8896, mid_bound_declared=0.816, high_bound_undeclared=0.85, mid_bound_undeclared=0.776
    ),
    "ETSI": PredictionConfig(
        high_bound_declared=0.937, mid_bound_declared=0.874, high_bound_undeclared=0.95, mid_bound_undeclared=0.901
    ),
    "ATSC": PredictionConfig(
        high_bound_declared=0.909, mid_bound_declared=0.855, high_bound_undeclared=0.86, mid_bound_undeclared=0.78
    ),
    "AE": PredictionConfig(
        high_bound_declared=0.856, mid_bound_declared=0.816, high_bound_undeclared=0.876, mid_bound_undeclared=0.827
    ),
    "VE": PredictionConfig(
        high_bound_declared=0.806, mid_bound_declared=0.724, high_bound_undeclared=0.798, mid_bound_undeclared=0.72
    ),
    "QI": PredictionConfig(
        high_bound_declared=0.941, mid_bound_declared=0.878, high_bound_undeclared=0.903, mid_bound_undeclared=0.854
    ),
}


def apply(df: DataFrame, technology: str) -> DataFrame:
    """
    Mapper to transform semantic similarity scores with text data.
    Uses technology-specific prediction thresholds.

    Args:
        df: Input DataFrame
        technology: Technology name (WIFI, ETS, ATSC, etc.)

    Returns:
        Transformed DataFrame with parsed claims, sections, and predictions
    """
    # Get technology-specific config
    config = TECH_CONFIGS.get(technology.upper())
    if not config:
        raise ValueError(f"Unknown technology: {technology}. Available technologies: {list(TECH_CONFIGS.keys())}")

    return (
        df.withColumn("claim_number", F.regexp_extract(F.col("claim_id"), r"(0|[1-9]+[0-9]*)$", 0))
        .withColumn("section_number", F.col("section_reference"))
        .withColumn("section_text", get_section_text(F.col("most_meaningful_section_array"), F.col("section_number")))
        .withColumn("claim_text", get_claims_text())
        .withColumn("semantic_prediction", get_prediction(config))
        .drop(
            "section_reference",
            "claim_id",
            "section",
            "claims",
            "most_meaningful_section_array",
            "flattenedSectionData",
        )
    )


def get_prediction(config: PredictionConfig) -> F.Column:
    """
    Generates semantic prediction based on document origin and score thresholds.

    Args:
        config: PredictionConfig with technology-specific thresholds

    Returns:
        Column with prediction values: 'high', 'mid', or 'low'
    """
    return (
        F.when(
            (F.col("document_origin").isin(config.doc_origin) & (F.col("score") >= config.high_bound_declared))
            | ((F.col("document_origin") == "undeclared") & (F.col("score") >= config.high_bound_undeclared)),
            F.lit("high"),
        )
        .when(
            # Mid prediction
            (F.col("document_origin").isin(config.doc_origin) & (F.col("score") >= config.mid_bound_declared))
            | ((F.col("document_origin") == "undeclared") & (F.col("score") >= config.mid_bound_undeclared)),
            F.lit("mid"),
        )
        .otherwise(F.lit("low"))
    )


def get_claims_text() -> F.Column:
    """
    Parses claims JSON to extract claim text for the specific claim_id.

    JSON structure: [{"claim_id": "0001", "claim_content": "text..."}, ...]

    Returns:
        Column with parsed claim text or NULL if not found
    """
    return F.expr(
        """
        CASE
            WHEN claims IS NOT NULL AND claims != '' THEN
                COALESCE(
                    filter(
                        from_json(claims, 'array<struct<claim_id:string,claim_content:string>>'),
                        x -> x.claim_id = claim_id
                    )[0].claim_content,
                    NULL
                )
            ELSE NULL
        END
    """
    )


def get_section_text(sections_col: Column, section_ref_col: Column) -> Column:
    """
    Extract section text from an unflattened array of [section_number, section_text]
    """
    return F.when(sections_col.isNull() | section_ref_col.isNull(), F.lit("")).otherwise(
        F.element_at(F.element_at(F.filter(sections_col, lambda x: x[0] == section_ref_col), 1), 2)
    )
