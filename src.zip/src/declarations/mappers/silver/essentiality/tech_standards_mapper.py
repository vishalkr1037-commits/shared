from pyspark.sql import DataFrame
from pyspark.sql.functions import col, when

import src.declarations.models.silver.standards.standards as StandardsModel
from src.declarations.models.silver.essentiality.ses_standards_model import (
    EssentialityStandardsModel,
)
from src.declarations.utils.standards_parser import StandardsParser


# Note: Called by EssentialitySectionExtractionProcessor which is not in use
# So purposely not adding unit tests for this mapper at the moment, as it is not being used in any active pipeline
class TechStandardsMapper:
    @staticmethod
    def apply(df: DataFrame, technology: str) -> DataFrame:
        """
        Map and transform tech standards data with description and sections extraction.

        Args:
            df: DataFrame containing standards with AC_CODE, STANDARD_DOCUMENT_ID,
                PUBLICATION_DATE, standardsDescription, and normalDescription columns

        Returns:
            Transformed DataFrame with extracted sections and cleaned descriptions
        """
        return df.withColumns(
            {
                EssentialityStandardsModel.AC_CODE: col(StandardsModel.AC_CODE),
                EssentialityStandardsModel.STANDARD_DOCUMENT_ID: col(StandardsModel.STANDARD_DOCUMENT_ID),
                EssentialityStandardsModel.DESCRIPTION: TechStandardsMapper._get_description(),
                EssentialityStandardsModel.PUBLICATION_DATE: col(StandardsModel.PUBLICATION_DATE),
                EssentialityStandardsModel.SECTION_ZIP: TechStandardsMapper._get_sections(technology),
            }
        ).drop("standardsDescription", "normalDescription")

    @staticmethod
    def _get_description():
        """
        Get description from standardsDescription if available and not empty,
        otherwise fall back to normalDescription. Apply cleanDescription UDF.
        """
        # Select the right description column first, then apply UDF
        description_col = when(
            col("standardsDescription").isNotNull() & (col("standardsDescription") != ""), col("standardsDescription")
        ).otherwise(col("normalDescription"))

        return StandardsParser.clean_description_udf(description_col)

    @staticmethod
    def _get_sections(technology: str):
        """
        Extract all sections from description column using extractAllSections UDF.
        """
        if technology == "atsc":
            return StandardsParser.extract_atsc_sections_udf(col(EssentialityStandardsModel.DESCRIPTION))
        elif technology == "qi":
            return StandardsParser.extract_qi_sections_udf(col(EssentialityStandardsModel.DESCRIPTION))
        elif technology == "audio":
            return StandardsParser.extract_audio_sections_udf(col(EssentialityStandardsModel.DESCRIPTION))
        elif technology == "video":
            return StandardsParser.extract_video_sections_udf(col(EssentialityStandardsModel.DESCRIPTION))
        elif technology == "wifi":
            return StandardsParser.extract_video_sections_udf(col(EssentialityStandardsModel.DESCRIPTION))
        else:
            return StandardsParser.extract_etsi_sections_udf(col(EssentialityStandardsModel.DESCRIPTION))
