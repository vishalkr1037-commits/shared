import pyspark.sql.functions as F
from pyspark.sql import DataFrame

from src.declarations.models.silver.essentiality import semsim as SemsimModel
from src.declarations.models.silver.essentiality import ses_scoring_model as ses_score


# Simplified functional version (like your mapper pattern)
def apply_ses_transformation(df: DataFrame) -> DataFrame:
    """
    Apply SES transformation to a DataFrame.
    Use this if you're reading/writing separately.
    """
    pub_split_col = (
        F.when(
            F.col(ses_score.SES_PUBLICATION_CLAIM_ID).contains("|"),
            F.split(F.col(ses_score.SES_PUBLICATION_CLAIM_ID), "\\|"),
        )
        .when(
            F.col(ses_score.SES_PUBLICATION_CLAIM_ID).contains("_"),
            F.split(F.col(ses_score.SES_PUBLICATION_CLAIM_ID), "_"),
        )
        .otherwise(F.array(F.col(ses_score.SES_PUBLICATION_CLAIM_ID), F.lit(None)))
    )
    std_split_col = (
        F.when(
            F.col(ses_score.SES_STANDARD_SECTION_NUMBER).contains("|"),
            F.split(F.col(ses_score.SES_STANDARD_SECTION_NUMBER), "\\|"),
        )
        .when(
            F.col(ses_score.SES_STANDARD_SECTION_NUMBER).contains("_"),
            F.split(F.col(ses_score.SES_STANDARD_SECTION_NUMBER), "_"),
        )
        .otherwise(F.array(F.col(ses_score.SES_STANDARD_SECTION_NUMBER), F.lit(None)))
    )

    return (
        df.na.fill("")
        .withColumnRenamed(ses_score.SES_SIMILARITY_SCORE, "score")
        .withColumnRenamed(ses_score.SES_ID, "id")
        .withColumn("publ_splitted", pub_split_col)
        .withColumn(SemsimModel.PUBLICATION_NUMBER, F.col("publ_splitted").getItem(0))
        .withColumn(SemsimModel.CLAIM_ID, F.col("publ_splitted").getItem(1))
        .withColumn("std_splitted", std_split_col)
        .withColumn(SemsimModel.MOST_MEANINGFUL_STANDARD_DOCUMENT_ID, F.col("std_splitted").getItem(0))
        .withColumn(SemsimModel.SECTION_REFERENCE, F.col("std_splitted").getItem(1))
        .drop("publ_splitted", "publication_claim_id", "std_splitted", "standard_section_number")
    )
