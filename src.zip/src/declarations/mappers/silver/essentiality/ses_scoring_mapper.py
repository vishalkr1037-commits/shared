"""
SES Scoring Mapper
Transformation functions for SES similarity scoring pipeline
"""

import logging

import numpy as np
import pyspark.sql.functions as F
from pyspark.sql import DataFrame
from pyspark.sql.functions import col, row_number, udf
from pyspark.sql.types import FloatType
from pyspark.sql.window import Window
from sklearn.metrics.pairwise import cosine_similarity

logger = logging.getLogger("SESMapper")


def get_most_meaningful_standard_document_id(declarations_df: DataFrame, std_df: DataFrame) -> DataFrame:
    """
    Returns a DataFrame with the most meaningful standard document ID for each declaration.

    Args:
        declarations_df: DataFrame containing declaration details, including
                         'publication_number' and 'standard_document_id'.
        std_df: DataFrame containing standard document details with
                'standard_document_id' and 'most_meaningful_standard_document_id'.
    Returns:
        A new DataFrame with the most meaningful standard document ID for each declaration.
    """
    # Join the declarations DataFrame with the standards DataFrame
    if "standard_document_id" in declarations_df.columns and "standard_document_id" in std_df.columns:
        joined_df = declarations_df.withColumn("standard_document_id", F.upper("standard_document_id")).join(
            std_df.withColumn("standard_document_id", F.upper("standard_document_id"))
            .select("standard_document_id", "most_meaningful_standard_document_id")
            .distinct(),
            on="standard_document_id",
            how="inner",
        )
    else:
        # If the standard_document_id column is absent, assume declarations already contain most_meaningful_standard_document_id
        joined_df = declarations_df
    logger.info("Joined declarations with standards")
    return joined_df


def pair_declarations_with_vectors(declarations_df: DataFrame, vectors_df: DataFrame, model_name: str) -> DataFrame:
    """
    Pairs declaration data with its corresponding claim and section vectors.

    This function performs two inner joins:
    1. Joins declarations with vectors to link a publication to its claim vector.
    2. Joins the result again with vectors to link the most meaningful standard document to its section vector.

    Args:
        declarations_df: DataFrame containing declaration details, including
                         'publication_number' and 'most_meaningful_standard_document_id'.
        vectors_df: DataFrame containing document vectors, including
                    'document_id' and model_name column for vectors.
        model_name: Name of the vector column to use

    Returns:
        A new DataFrame with declarations paired with their respective vectors.
        Output columns include: publication_claim_id, standard_section_number, claims_vectors, sections_vectors.
    """
    # Alias the vectors DataFrame for the first join to get claim vectors
    vectors_claims_alias = vectors_df.alias("v").withColumnRenamed(model_name, "claims_vectors")

    # Alias the vectors DataFrame for the second join to get section vectors
    vectors_sections_alias = vectors_df.alias("v2").withColumnRenamed(model_name, "sections_vectors")

    # Join 1 (base logic): publication_number -> v.main_id, select explicit columns to avoid duplicates
    paired_df = (
        declarations_df.alias("d")
        .join(vectors_claims_alias, F.col("d.publication_number") == F.col("v.main_id"), how="inner")
        .select(
            F.col("d.*"),
            F.col("claims_vectors"),
            F.col("v.document_id").alias("publication_claim_id"),
        )
    )

    # Join 2 (base logic): d.most_meaningful_standard_document_id -> v2.main_id, rename v2.document_id -> standard_section_number
    final_paired_df = (
        paired_df.alias("d")
        .join(
            vectors_sections_alias,
            F.col("d.most_meaningful_standard_document_id") == F.col("v2.main_id"),
            how="inner",
        )
        .select(
            F.col("d.*"),
            F.col("sections_vectors"),
            F.col("v2.document_id").alias("standard_section_number"),
            F.col("v2.sub_id"),
        )
        .withColumnRenamed("sub_id", "sub_id")
    )

    logger.info("Pairing complete: claims and sections joins applied")
    return final_paired_df


def add_hierarchical_match_flag(input_df: DataFrame) -> DataFrame:
    """
    Cleans section data and adds a boolean flag for hierarchical matches.

    This function first cleans the 'section' array by extracting only numerical patterns.
    Then, it applies a complex set of rules to determine if a 'sub_id' matches any
    of the cleaned section numbers based on their hierarchy.

    Matching Rules:
    1. Exact Match: '2.1' and '2.1'
    2. Child Match: 'sub_id' is a parent of a 'section' element (e.g., '1' and '1.2')
    3. Parent Match: 'sub_id' is a child of a 'section' element (e.g., '1.1' and '1')
    4. Sibling Match: They share the same immediate parent (e.g., '10.1.5' and '10.1.2')

    Args:
        input_df: A DataFrame that includes 'id', 'sub_id', and a 'section' array column.

    Returns:
        The input DataFrame with an added boolean column 'has_match'.
    """
    # Step 1: Create a temporary column with a cleaned version of the 'section' array.
    # This expression handles strings with text, multiple numbers, and extra spaces.
    df_with_clean_section = input_df.withColumn(
        "section_clean",
        F.expr(
            """
            transform(
                flatten(transform(section, s -> split(s, ' '))),
                s -> regexp_extract(s, '\\\\d+(\\\\.\\d+)*', 0)
            )
        """
        ),
    )

    # Step 2: Apply the matching logic to the cleaned array to create the 'has_match' flag.
    df_with_match_flag = df_with_clean_section.withColumn(
        "has_match",
        F.expr(
            """
            size(
                filter(section_clean, s ->
                    s IS NOT NULL AND s != '' AND (
                        s = sub_id OR                          -- 1. Exact Match: '2.1' and '2.1'
                        startswith(s, sub_id || '.') OR        -- 2. Sub-match: section element '1.2' starts with sub_id '1.'
                        startswith(sub_id, s || '.') OR        -- 3. Parent-match: sub_id '1.1' starts with section element '1.'
                        (                      -- 4. Sibling Match: Checks if they have the same immediate parent. 10.1 and 10.2
                            size(split(s, '\\\\.')) > 1 AND
                            size(split(sub_id, '\\\\.')) > 1 AND
                            substring_index(s, '.', size(split(s, '\\\\.')) - 1) =
                            substring_index(sub_id, '.', size(split(sub_id, '\\\\.')) - 1)
                        )
                    )
                )
            ) > 0
        """
        ),
    ).drop("section_clean")

    return df_with_match_flag


def filter_by_matched_sections(input_df: DataFrame) -> DataFrame:
    """
    Conditionally filters records based on matched sections within each ID group.

    - For IDs with at least one match, it retains ONLY the matched rows.
    - For IDs with NO matches, it retains ALL of their original rows.

    Args:
        input_df: DataFrame with 'id' and list of provided 'section' and all sections available in the Standard documents

    Returns:
        A DataFrame containing the conditionally filtered results.
    """
    # Create the section matching flag
    matched_df = add_hierarchical_match_flag(input_df)
    # Filter for IDs with at least one matched section
    matched_id_df = matched_df.filter(col("has_match") == True).select("id").distinct()

    # Filter for IDs with no matched sections
    non_matched_id_df = matched_df.select("id").distinct().join(matched_id_df, "id", "leftanti")

    # Join everything back to get the final results
    result_df = (
        matched_df.join(matched_id_df, on="id", how="inner")
        .filter(col("has_match") == True)
        .unionByName(matched_df.join(non_matched_id_df, on="id", how="inner"))
    ).drop("sub_id", "section_clean", "has_match")

    logger.info("Filtered by matched sections")
    return result_df


def calculate_cosine_similarity(v1, v2):
    """Calculates cosine similarity between two vectors passed as lists."""
    if v1 is None or v2 is None:
        return 0.0
    # Reshape for sklearn's function and compute similarity
    similarity = cosine_similarity(np.array(v1).reshape(1, -1), np.array(v2).reshape(1, -1))
    return float(similarity[0][0])


# Register the UDF with Spark
cosine_similarity_udf = udf(calculate_cosine_similarity, FloatType())


def find_top_k_similarities(main_df: DataFrame, k: int = 3) -> DataFrame:
    """
    Calculates top-k similarities.

    This function combines similarity calculation with top-k selection in a single step,
    matching the original notebook behavior.

    Parameters:
    -----------
    main_df : pyspark.sql.DataFrame
        DataFrame with ID mappings (id, publication_claim_id, standard_section_number, claims_vectors, sections_vectors).
    k : int
        Number of top results to return.

    Returns:
    --------
    pyspark.sql.DataFrame
        A DataFrame with the top-k similarity results for each ID.
    """
    # 1. Calculate similarity for each pair using the distributed UDF
    logger.info("Calculating cosine similarity for all pairs...")
    similarity_df = main_df.withColumn(
        "similarity_score", cosine_similarity_udf(col("claims_vectors"), col("sections_vectors"))
    )

    # 2. Use a Window Function to find the Top-K results for each 'id'
    logger.info(f"Finding top {k} results per ID using a Window function...")
    window_spec = Window.partitionBy("id").orderBy(col("similarity_score").desc())

    top_k_df = (
        similarity_df.withColumn("rank", row_number().over(window_spec))
        .filter(col("rank") <= k)
        .select("id", "publication_claim_id", "standard_section_number", "similarity_score")
    )

    logger.info(f"Selected top-{k} results")
    return top_k_df
