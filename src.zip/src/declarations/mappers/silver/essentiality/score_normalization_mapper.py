from pyspark.sql import functions as F
from pyspark.sql.window import Window

from src.declarations.models.silver.essentiality import semsim as SemsemModel

LAMBDA = 0.6284808032170515
LOW_RANGE = 0.4
HIGH_RANGE = 1.0


def apply(df):
    """
    Normalizes and scales semantic similarity scores to a fixed range using global statistics.
    """
    FULL_DATASET_WINDOW = Window.orderBy(F.lit(1))
    return (
        df.withColumn(
            "min_positive_score",
            F.min(F.when(F.col(SemsemModel.SCORE) > 0, F.col(SemsemModel.SCORE))).over(FULL_DATASET_WINDOW),
        )
        .withColumn(
            "normalized_score",
            normalize(
                F.when(
                    F.col(SemsemModel.SCORE) < 0,
                    F.exp(F.col(SemsemModel.SCORE)) * F.col("min_positive_score"),
                ).otherwise(F.col(SemsemModel.SCORE))
            ),
        )
        .withColumn("min_normalized_score", F.min("normalized_score").over(FULL_DATASET_WINDOW))
        .withColumn("max_normalized_score", F.max("normalized_score").over(FULL_DATASET_WINDOW))
        .withColumn(
            "final_score",
            scale(
                F.col("normalized_score"),
                F.col("min_normalized_score"),
                F.col("max_normalized_score"),
            ),
        )
        .drop(
            "score",
            "min_positive_score",
            "normalized_score",
            "min_normalized_score",
            "max_normalized_score",
        )
        .withColumnRenamed("final_score", "score")
    )


def normalize(score_col):
    if LAMBDA != 0:
        return (F.pow(score_col, LAMBDA) - F.lit(-1.0)) / F.lit(LAMBDA)
    else:
        return F.log(score_col)


def scale(score_col, min_col, max_col):
    range_diff = F.lit(HIGH_RANGE - LOW_RANGE)
    max_minus_min = max_col - min_col

    return F.when(
        max_minus_min == 0,
        F.lit(LOW_RANGE),
    ).otherwise((score_col - min_col) * range_diff / max_minus_min + F.lit(LOW_RANGE))
