from pyspark.sql import DataFrame
from pyspark.sql.functions import col, when

import src.declarations.models.silver.standards.standards as StandardsModel
from src.declarations.models.silver.essentiality.ses_etsi_standards_model import (
    EssentialityEtsiStandardsModel,
)
from src.declarations.utils.standards_parser import StandardsParser


# Note: Called by EssentialitySectionExtractionProcessor which is not in use
# So purposely not adding unit tests for this mapper at the moment, as it is not being used in any active pipeline
class EtsiStandardsMapper:
    """Mapper for transforming ETSI standards data."""

    @staticmethod
    def apply(df: DataFrame) -> DataFrame:
        """
        Map and transform ETSI standards data with description and sections extraction.

        Args:
            df: DataFrame containing standards with AC_CODE, STANDARD_DOCUMENT_ID,
                PUBLICATION_DATE, standardsDescription, and normalDescription columns

        Returns:
            Transformed DataFrame with extracted sections, cleaned descriptions,
            and parsed standard document numbers
        """
        return df.withColumns(
            {
                EssentialityEtsiStandardsModel.AC_CODE: col(StandardsModel.AC_CODE),
                EssentialityEtsiStandardsModel.ID: col(StandardsModel.ID),
                EssentialityEtsiStandardsModel.STANDARD_DOCUMENT_NUMBER: EtsiStandardsMapper._get_standard_document_number(),
                EssentialityEtsiStandardsModel.STANDARD_DOCUMENT_ID: col(StandardsModel.STANDARD_DOCUMENT_ID),
                EssentialityEtsiStandardsModel.DESCRIPTION: EtsiStandardsMapper._get_description(),
                EssentialityEtsiStandardsModel.PUBLICATION_DATE: col(StandardsModel.PUBLICATION_DATE),
                EssentialityEtsiStandardsModel.SECTION_ZIP: EtsiStandardsMapper._get_sections(),
            }
        ).drop("standardsDescription", "normalDescription")

    @staticmethod
    def _get_description() -> any:
        """
        Get description from standardsDescription if available and not empty,
        otherwise fall back to normalDescription. Apply cleanDescription UDF.
        """
        # Select the right description column first, then apply UDF
        description_col = when(
            col("standardsDescription").isNotNull() & (col("standardsDescription") != ""), col("standardsDescription")
        ).otherwise(col("normalDescription"))

        return StandardsParser.clean_description_udf(description_col)

    @staticmethod
    def _get_sections() -> any:
        """
        Extract all sections from description column using extractAllSections UDF.
        Uses ETSI-specific section extraction.
        """
        return StandardsParser.extract_etsi_sections_udf(col(EssentialityEtsiStandardsModel.DESCRIPTION))

    @staticmethod
    def _get_standard_document_number():
        return StandardsParser.parse_etsi_standard_document_number_udf(
            col(EssentialityEtsiStandardsModel.STANDARD_DOCUMENT_NUMBER)
        )
