"""
Mapper for consolidating preprocessed text data into 3 global tables
Handles transformation to add tech column and consolidate across technologies
"""

from typing import List

import pyspark.sql.functions as F
from pyspark.sql import DataFrame

from src.declarations.models.silver.essentiality import essentiality_consolidated


def add_tech_column(df: DataFrame, tech: str) -> DataFrame:
    """
    Add technology column to dataframe

    Args:
        df: Input dataframe
        tech: Technology identifier (wifi, audio, video, qi, atsc, etsi, true_negative)

    Returns:
        DataFrame with tech column added
    """
    return df.withColumn("tech", F.lit(tech))


def consolidate_claims_data(claims_dfs_with_tech: List[DataFrame]) -> DataFrame:
    """
    Consolidate claims data from all technologies into single dataframe

    Args:
        claims_dfs_with_tech: List of claims dataframes (each with tech column added)

    Returns:
        Consolidated dataframe with all technologies
    """
    if not claims_dfs_with_tech:
        raise ValueError("No claims dataframes provided for consolidation")

    # Start with first dataframe
    consolidated = claims_dfs_with_tech[0]

    # Union with remaining dataframes
    for df in claims_dfs_with_tech[1:]:
        consolidated = consolidated.unionByName(df, allowMissingColumns=True)

    return consolidated


def consolidate_abs_title_data(abs_title_dfs_with_tech: List[DataFrame]) -> DataFrame:
    """
    Consolidate abstract/title data from all technologies into single dataframe

    Args:
        abs_title_dfs_with_tech: List of abstract/title dataframes (each with tech column added)

    Returns:
        Consolidated dataframe with all technologies
    """
    if not abs_title_dfs_with_tech:
        raise ValueError("No abstract/title dataframes provided for consolidation")

    # Start with first dataframe
    consolidated = abs_title_dfs_with_tech[0]

    # Union with remaining dataframes
    for df in abs_title_dfs_with_tech[1:]:
        consolidated = consolidated.unionByName(df, allowMissingColumns=True)

    return consolidated


def consolidate_std_text_data(std_text_dfs_with_tech: List[DataFrame]) -> DataFrame:
    """
    Consolidate standards text data from all technologies into single dataframe

    Args:
        std_text_dfs_with_tech: List of standards text dataframes (each with tech column added)

    Returns:
        Consolidated dataframe with all technologies
    """
    if not std_text_dfs_with_tech:
        raise ValueError("No standards text dataframes provided for consolidation")

    # Start with first dataframe
    consolidated = std_text_dfs_with_tech[0]

    # Union with remaining dataframes
    for df in std_text_dfs_with_tech[1:]:
        consolidated = consolidated.unionByName(df, allowMissingColumns=True)

    return consolidated


def reorder_columns_claims(df: DataFrame) -> DataFrame:
    """
    Reorder columns to match DDL for claims table

    Args:
        df: Input dataframe

    Returns:
        DataFrame with columns in correct order
    """
    column_order = [
        essentiality_consolidated.CLAIMS_TECH,
        essentiality_consolidated.CLAIMS_PUBLICATION_NUMBER,
        essentiality_consolidated.CLAIMS_CLAIM_ID,
        essentiality_consolidated.CLAIMS_TEXT,
        essentiality_consolidated.CLAIMS_PROCESSED_TOKENS,
        essentiality_consolidated.CLAIMS_PROCESSED_TEXT,
    ]

    # Only select columns that exist in the dataframe
    existing_columns = [col for col in column_order if col in df.columns]
    return df.select(existing_columns)


def reorder_columns_abs_title(df: DataFrame) -> DataFrame:
    """
    Reorder columns to match DDL for abstract/title table

    Args:
        df: Input dataframe

    Returns:
        DataFrame with columns in correct order
    """
    column_order = [
        essentiality_consolidated.ABS_TITLE_TECH,
        essentiality_consolidated.ABS_TITLE_PUBLICATION_NUMBER,
        essentiality_consolidated.ABS_TITLE_ABSTRACT,
        essentiality_consolidated.ABS_TITLE_TITLE,
        essentiality_consolidated.ABS_TITLE_TEXT,
        essentiality_consolidated.ABS_TITLE_PROCESSED_TOKENS,
        essentiality_consolidated.ABS_TITLE_PROCESSED_TEXT,
    ]

    # Only select columns that exist in the dataframe
    existing_columns = [col for col in column_order if col in df.columns]
    return df.select(existing_columns)


def reorder_columns_std_text(df: DataFrame) -> DataFrame:
    """
    Reorder columns to match DDL for standards text table

    Args:
        df: Input dataframe

    Returns:
        DataFrame with columns in correct order
    """
    column_order = [
        essentiality_consolidated.STD_TEXT_TECH,
        essentiality_consolidated.STD_TEXT_MOST_MEANINGFUL_STANDARD_DOCUMENT_ID,
        essentiality_consolidated.STD_TEXT_SECTION_NUMBER,
        essentiality_consolidated.STD_TEXT_TEXT,
        essentiality_consolidated.STD_TEXT_PROCESSED_TOKENS,
        essentiality_consolidated.STD_TEXT_PROCESSED_TEXT,
    ]

    # Only select columns that exist in the dataframe
    existing_columns = [col for col in column_order if col in df.columns]
    return df.select(existing_columns)
