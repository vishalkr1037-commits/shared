from pyspark.sql import DataFrame
from pyspark.sql import functions as F


def apply(joined_data: DataFrame) -> DataFrame:
    return (
        joined_data.withColumn("publication_id", F.explode(F.col("publication_id")))
        .withColumn("id", F.explode(F.col("id")))
        .cache()
    )
