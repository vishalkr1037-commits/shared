from pyspark.sql.functions import col, when

import src.declarations.models.bronze.declarations.via_la_claims_and_sections as ViaLaClaimsAndSections
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched


def apply(df):
    return df.withColumns(
        {
            DeclarationRawEnriched.SECTION: when(
                col(DeclarationRawEnriched.DATA_PROVIDER) == "Via LA", col(ViaLaClaimsAndSections.SECTION)
            ).otherwise(col(DeclarationRawEnriched.SECTION)),
            DeclarationRawEnriched.ESSENTIAL_CLAIM_NO: when(
                col(DeclarationRawEnriched.DATA_PROVIDER) == "Via LA", col(ViaLaClaimsAndSections.ESSENTIAL_CLAIMS)
            ).otherwise(col(DeclarationRawEnriched.ESSENTIAL_CLAIM_NO)),
        }
    ).drop(ViaLaClaimsAndSections.SECTION, ViaLaClaimsAndSections.ESSENTIAL_CLAIMS)
