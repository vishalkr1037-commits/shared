from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.utils.string_utility as string_util
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.silver.declarations import (
    declaration_deduplicated_intermediate,
    declaration_raw_aggregated,
)


def apply(df: DataFrame) -> DataFrame:
    """
    Applies the transformation logic to the input DataFrame.

    Args:
        df (DataFrame): Input DataFrame.

    Returns:
        DataFrame: Transformed DataFrame.
    """
    # Add columns from DeclarationRaw
    transformed_df = df.withColumns(
        {
            declaration_deduplicated_intermediate.SSO: F.col(DeclarationRaw.SSO),
            declaration_deduplicated_intermediate.DATA_PROVIDER: F.col(DeclarationRaw.DATA_PROVIDER),
            declaration_deduplicated_intermediate.STANDARD_PROJECT: F.col(DeclarationRaw.STANDARD_PROJECT),
            declaration_deduplicated_intermediate.STANDARD_DOCUMENT_ID: F.col(DeclarationRaw.STANDARD_DOCUMENT_ID),
            declaration_deduplicated_intermediate.DECLARING_COMPANY: F.col(DeclarationRaw.DECLARING_COMPANY),
            declaration_deduplicated_intermediate.APPLICATION_AS_TO_DECLARATION: F.col(
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION
            ),
            declaration_deduplicated_intermediate.PUBLICATION_AS_TO_DECLARATION: F.col(
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION
            ),
            declaration_deduplicated_intermediate.DECLARATION_DATE: F.col(DeclarationRaw.DECLARATION_DATE),
            declaration_deduplicated_intermediate.PATENT_POOL_NAME: F.col(DeclarationRaw.PATENT_POOL_NAME),
            declaration_deduplicated_intermediate.STANDARD_MATCH_ID: F.col(DeclarationRaw.STANDARD_MATCH_ID),
            declaration_deduplicated_intermediate.LICENSING_TERMS: F.col(DeclarationRaw.LICENSING_TERMS),
            declaration_deduplicated_intermediate.SPECIFIC_LICENSING_CONDITIONS: F.col(
                DeclarationRaw.SPECIFIC_LICENSING_CONDITIONS
            ),
            declaration_deduplicated_intermediate.RECIPOCITY_STATEMENT: F.col(
                declaration_deduplicated_intermediate.RECIPOCITY_STATEMENT
            ),
            declaration_deduplicated_intermediate.LICENSING_COMMENT: F.col(DeclarationRaw.LICENSING_COMMENT),
            declaration_deduplicated_intermediate.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES: F.col(
                DeclarationRaw.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES
            ),
            declaration_deduplicated_intermediate.CONTACT_PERSON_FOR_LICENSE: F.col(
                DeclarationRaw.CONTACT_PERSON_FOR_LICENSE
            ),
            declaration_deduplicated_intermediate.CONTACT_PERSON_POSITION: F.col(
                DeclarationRaw.CONTACT_PERSON_POSITION
            ),
            declaration_deduplicated_intermediate.CONTACT_ADDRESS_FOR_LICENSE: F.col(
                DeclarationRaw.CONTACT_ADDRESS_FOR_LICENSE
            ),
            declaration_deduplicated_intermediate.CONTACT_PHONE_FOR_LICENSE: F.col(
                DeclarationRaw.CONTACT_PHONE_FOR_LICENSE
            ),
            declaration_deduplicated_intermediate.CONTACT_EMAIL_FOR_LICENSE: F.col(
                DeclarationRaw.CONTACT_EMAIL_FOR_LICENSE
            ),
            declaration_deduplicated_intermediate.SECTION: F.col(DeclarationRaw.SECTION),
            declaration_deduplicated_intermediate.ESSENTIAL_CLAIM_NUMBER: F.col(DeclarationRaw.ESSENTIAL_CLAIM_NUMBER),
            declaration_deduplicated_intermediate.APPLICATION_AS_TO_DECLARATION_OTHER: F.col(
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER
            ),
            declaration_deduplicated_intermediate.PUBLICATION_AS_TO_DECLARATION_OTHER: F.col(
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER
            ),
        }
    )

    # Add aggregated columns with joined values
    transformed_df = transformed_df.withColumns(
        {
            declaration_deduplicated_intermediate.ISLD: string_util.join_set(
                F.col(declaration_raw_aggregated.ISLD_AGGREGATED)
            ),
            declaration_deduplicated_intermediate.DISCLOSURE_NUMBER: string_util.join_set(
                F.col(declaration_raw_aggregated.DISCLOSURE_NUMBER_AGGREGATED)
            ),
        }
    )

    # Drop intermediate aggregated columns
    transformed_df = transformed_df.drop(
        declaration_raw_aggregated.DISCLOSURE_NUMBER_AGGREGATED, declaration_raw_aggregated.ISLD_AGGREGATED
    )

    return transformed_df
