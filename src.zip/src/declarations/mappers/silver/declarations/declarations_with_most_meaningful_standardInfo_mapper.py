from pyspark.sql.functions import col, when

from src.declarations.models.silver.declarations.declaration_most_meaningful_standard_info import (
    AC_CODE,
    DECLARATION_ID,
    ORIGINAL_STANDARD_DOCUMENT_URL,
    STANDARD_DOCUMENT_REF,
    STANDARD_ID,
)


def get_non_empty_document_url(document_url, enriched_document_url, sso):
    return when(
        (sso != "ETSI") & (enriched_document_url.isNotNull()) & (enriched_document_url != ""), enriched_document_url
    ).otherwise(document_url)


def apply(df):
    return df.withColumns(
        {
            DECLARATION_ID: col("id"),
            STANDARD_DOCUMENT_REF: col("most_meaningful_standard_document_id"),
            ORIGINAL_STANDARD_DOCUMENT_URL: get_non_empty_document_url(
                col("document_url"), col("enriched_document_url"), col("sso")
            ),
            AC_CODE: col("ac_code"),
            STANDARD_ID: col("standard_id"),
        }
    )
