from pyspark.sql.functions import (
    array,
    array_distinct,
    col,
    explode_outer,
    lit,
    size,
    substring,
    when,
)

import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched
import src.declarations.utils.string_utility as string_util
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def _get_real_array_size(tech_gen_array):
    return when((size(tech_gen_array) == 1) & (tech_gen_array.getItem(0) == ""), lit(0)).otherwise(size(tech_gen_array))


def _get_non_empty_technology_generation(
    enriched_technology_generation, enriched_technology_generation_by_standard_project
):
    return when(
        _get_real_array_size(col(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY)) == 0,
        _get_concatenated_wifi_tech_gen(
            enriched_technology_generation, enriched_technology_generation_by_standard_project
        ),
    ).otherwise(col(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY))


def _get_concatenated_wifi_tech_gen(tech_gen_standard_doc_id, tech_gen_standard_project):
    return when(
        tech_gen_standard_doc_id.isNotNull() & (tech_gen_standard_doc_id != ""),
        string_util.split_string_to_set_array(tech_gen_standard_doc_id),
    ).otherwise(array_distinct(tech_gen_standard_project))


def _get_standard_document_id():
    return (
        when(col("technology_generation") == "AVC (H.264)", lit("ISO/IEC 14496-10:2020"))
        .when(col("technology_generation") == "HEVC (H.265)", lit("CAN/CSA-ISO/IEC 23008-2:21"))
        .when(col("technology_generation") == "VVC (H.266)", lit("ISO/IEC 23090-3:2021"))
        .when(col("technology_generation") == "Wi-Fi 1 (IEEE 802.11b)", lit("IEEE 802.11b"))
        .when(col("technology_generation") == "Wi-Fi 2 (IEEE 802.11a)", lit("IEEE 802.11a"))
        .when(col("technology_generation") == "Wi-Fi 3 (IEEE 802.11g)", lit("IEEE 802.11g"))
        .when(col("technology_generation") == "Wi-Fi 4 (IEEE 802.11n)", lit("IEEE 802.11n"))
        .when(col("technology_generation") == "Wi-Fi 5 (IEEE 802.11ac)", lit("IEEE 802.11ac-2013"))
        .when(col("technology_generation") == "Wi-Fi 6 (IEEE 802.11ax)", lit("IEEE 802.11ax-2021"))
        .otherwise(col("standard_document_id"))
    )


def _get_standardized_standard_project():
    return when(
        col(DeclarationRawEnriched.STANDARD_PROJECT).contains("AVC/H.264"),
        lit("AVC (H.264)"),
    ).otherwise(col(DeclarationRawEnriched.STANDARD_PROJECT))


def _get_new_id():
    return DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
        col(DeclarationRawEnriched.STANDARD_PROJECT),
        col(DeclarationRawEnriched.STANDARD_DOCUMENT_ID),
        col(DeclarationRawEnriched.DECLARING_COMPANY),
        col(DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION),
        col(DeclarationRawEnriched.PUBLICATION_AS_TO_DECLARATION),
        col(DeclarationRawEnriched.DECLARATION_DATE),
    )


def _is_etsi_or_pooled():
    return when(
        (col(DeclarationRawEnriched.DATA_PROVIDER) == "ETSI") | (col(DeclarationRawEnriched.TYPE) == "POOLED"),
        col(DeclarationRawEnriched.ID),
    ).otherwise(_get_new_id())


def apply(df):
    return (
        df.withColumns(
            {
                DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY: _get_non_empty_technology_generation(
                    col("enriched_technology_generation"), col("enriched_technology_generation_by_standard_project")
                ),
            }
        )
        .withColumns(
            {
                "technology_generation": explode_outer(col(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY)),
            }
        )
        .withColumns(
            {
                DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY: when(
                    col("technology_generation").isNotNull(), array(col("technology_generation"))
                ).otherwise(array()),
                DeclarationRawEnriched.STANDARD_DOCUMENT_ID: _get_standard_document_id(),
                DeclarationRawEnriched.ID: _is_etsi_or_pooled(),
                DeclarationRawEnriched.STANDARD_PROJECT: _get_standardized_standard_project(),
            }
        )
        .withColumns(
            {
                DeclarationRawEnriched.ID_FIRST_CHAR: substring(col(DeclarationRawEnriched.ID), 1, 1),
            }
        )
        .dropDuplicates([DeclarationRawEnriched.ID])
        .drop(
            "technology_generation",
            "enriched_technology_generation",
            "enriched_technology_generation_by_standard_project",
        )
    )
