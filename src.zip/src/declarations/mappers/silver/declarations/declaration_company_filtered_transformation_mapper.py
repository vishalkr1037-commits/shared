from pyspark.sql.functions import (
    array,
    array_distinct,
    col,
    date_format,
    expr,
    flatten,
    initcap,
    lit,
    size,
    substring,
    when,
)

import src.declarations.utils.declaration_deduplication_helper as declaration_deduplication_helper
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def get_real_array_size(arr_col):
    return (
        when((size(arr_col) == 1) & (arr_col[0] == ""), 0)
        .when((size(arr_col) == 2) & (arr_col[0].isNull()) & (arr_col[1] == ""), 0)
        .when((size(arr_col) == 2) & (arr_col[0] == "") & (arr_col[1].isNull()), 0)
        .otherwise(size(arr_col))
    )


def apply(
    df,
    black_listed_pub_numbers,
    black_listed_working_numbers,
    white_listed_pub_numbers,
    white_listed_working_numbers,
    patent_assignee_applicant_df,
    patent_kind_type_df,
    patent_family_assignees_df,
    patent_family_applicants_df,
    harmonized_declaring_companies_df,
    aggregated_declarations_df,
):
    # Use the correct case-sensitive column names
    join_cond_decl_raw_and_harmonized = (
        col("declaration_id") == harmonized_declaring_companies_df["declaration_id_harmonized"]
    )

    result_before_join = (
        df.join(patent_assignee_applicant_df, on="publication_id", how="left")
        .join(patent_kind_type_df, on="publication_id", how="left")
        .repartition("inpadoc_family_id")
        .join(patent_family_assignees_df, on="inpadoc_family_id", how="left")
        .join(patent_family_applicants_df, on="inpadoc_family_id", how="left")
    )

    result = (
        result_before_join.join(harmonized_declaring_companies_df, join_cond_decl_raw_and_harmonized, "left")
        .withColumn(
            "harmonized_patent_family_applicants_name",
            when(
                col("harmonized_patent_family_applicants_name").isNotNull(),
                col("harmonized_patent_family_applicants_name"),
            ).otherwise(array()),
        )
        .withColumn(
            "harmonized_patent_family_assignees_name",
            when(
                col("harmonized_patent_family_assignees_name").isNotNull(),
                col("harmonized_patent_family_assignees_name"),
            ).otherwise(array()),
        )
        .withColumn(
            "assignee_name_array",
            when(col("assignee_name_array").isNotNull(), col("assignee_name_array")).otherwise(array()),
        )
        .withColumn(
            "applicant_name_array",
            when(col("applicant_name_array").isNotNull(), col("applicant_name_array")).otherwise(array()),
        )
        .withColumn(
            "concatenated_assignees_applicants",
            array_distinct(
                flatten(
                    array(
                        col("harmonized_patent_family_applicants_name"),
                        col("harmonized_patent_family_assignees_name"),
                        col("assignee_name_array"),
                        col("applicant_name_array"),
                    )
                )
            ),
        )
    )

    result = result.withColumn(
        "real_array_size",
        when(
            (size(col("concatenated_assignees_applicants")) == 1)
            & (expr("get(concatenated_assignees_applicants, 0)") == ""),
            lit(0),
        )
        .when(
            (size(col("concatenated_assignees_applicants")) == 2)
            & (expr("get(concatenated_assignees_applicants, 0)").isNull())
            & (expr("get(concatenated_assignees_applicants, 1)") == ""),
            lit(0),
        )
        .when(
            (size(col("concatenated_assignees_applicants")) == 2)
            & (expr("get(concatenated_assignees_applicants, 0)") == "")
            & (expr("get(concatenated_assignees_applicants, 1)").isNull()),
            lit(0),
        )
        .otherwise(size(col("concatenated_assignees_applicants"))),
    )

    result = (
        result.withColumn(
            "is_company_valid",
            is_company_valid(
                col("applied_rules"),
                col("harmonized_company_name"),
                col("concatenated_assignees_applicants"),
                col("publication_number"),
                col("matched"),
                col("kind_type_short"),
                col("working_number"),
                col("real_array_size"),
                white_listed_pub_numbers,
                white_listed_working_numbers,
                black_listed_pub_numbers,
                black_listed_working_numbers,
            ),
        )
        .withColumn(
            "declaration_date",
            when((col("declaration_date") == "") | col("declaration_date").isNull(), None).otherwise(
                col("declaration_date")
            ),
        )
        .withColumn(
            "id",
            DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
                col("standard_document_id"),
                col("standard_project"),
                initcap(col("declaring_company")),
                date_format(col("declaration_date"), "yyyy-MM-dd"),
                col("publication_number"),
                col("isld"),
            ),
        )
        .drop("id_first_char", "id_first_char_harmonized_declaring_companies")
        .join(aggregated_declarations_df, on="id", how="left")
        .orderBy(col("declaration_date").desc())
        .dropDuplicates(
            [
                "standard_document_id",
                "standard_project",
                "declaring_company",
                "publication_number",
                "isld",
                "is_company_valid",
            ]
        )
        .withColumn("id_first_char", substring(col("id"), 1, 1))
    )

    return result


def is_company_valid(
    applied_rules,
    harmonized_company_name,
    concatenated_assignees_applicants,
    publication_number,
    matched,
    patent_kind_type,
    working_number,
    real_array_size,
    white_listed_pub_numbers,
    white_listed_working_numbers,
    black_listed_pub_numbers,
    black_listed_working_numbers,
):
    return (
        when(matched == False, lit(True))
        .when(
            (publication_number.isin(white_listed_pub_numbers)) & (working_number.isin(white_listed_working_numbers)),
            lit(True),
        )
        .when(
            (publication_number.isin(black_listed_pub_numbers)) & (working_number.isin(black_listed_working_numbers)),
            lit(False),
        )
        .when(applied_rules == lit(True), lit(True))
        .when(harmonized_company_name.contains("N.a.") | (harmonized_company_name == ""), lit(False))
        .when((real_array_size == 0) & (patent_kind_type == "Utility Model"), lit(False))
        .when(
            (real_array_size == 0)
            & (~publication_number.isin(black_listed_pub_numbers))
            & (~working_number.isin(black_listed_working_numbers)),
            lit(True),
        )
        .when(
            declaration_deduplication_helper.is_applicant_assignee_first_word_contained_in_declaring_company_udf(
                concatenated_assignees_applicants, array(harmonized_company_name)
            ),
            lit(True),
        )
        .when(
            declaration_deduplication_helper.is_declaring_company_first_word_contained_in_applicant_assignee_udf(
                concatenated_assignees_applicants, array(harmonized_company_name)
            ),
            lit(True),
        )
        .otherwise(lit(False))
    )
