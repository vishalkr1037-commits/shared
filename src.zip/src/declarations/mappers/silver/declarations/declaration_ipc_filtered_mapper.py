from pyspark.sql import functions as F
from pyspark.sql.functions import col

import src.declarations.models.silver.declarations.declaration_ipc_filtered as DeclarationIPCFiltered
from src.declarations.models.silver.declarations import (
    declaration_deduplicated_intermediate as DeclarationDeduplicatedIntermediate,
)


class DeclarationIpcFilteredMapper:
    @staticmethod
    def apply(df):
        return df.withColumn(
            DeclarationIPCFiltered.IS_INDUSTRY_SECTOR_VALID,
            DeclarationIpcFilteredMapper.build_is_industry_sector_valid_column(),
        ).withColumnRenamed(DeclarationDeduplicatedIntermediate.ID, "declaration_id")

    @staticmethod
    def build_is_industry_sector_valid_column():
        return DeclarationIpcFilteredMapper.is_industry_sector_valid(
            col(DeclarationDeduplicatedIntermediate.APPLIED_RULES),
            col(DeclarationDeduplicatedIntermediate.DATA_PROVIDER),
            col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR),
            col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_IPC),
            col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_CPC),
            col(DeclarationDeduplicatedIntermediate.MATCHED),
            col(DeclarationDeduplicatedIntermediate.STANDARD_PROJECT),
            white_listed_data_providers=["ProviderA", "ProviderB"],
            black_listed_industry_sectors=["SectorX", "SectorY"],
        )

    @staticmethod
    def is_industry_sector_valid(
        applied_rules,
        data_provider,
        industry_sector,
        ipc_industry_sector,
        cpc_industry_sector,
        matched,
        standard_project,
        white_listed_data_providers,
        black_listed_industry_sectors,
    ):
        matched_clean = F.coalesce(matched.cast("boolean"), F.lit(False))
        applied_rules_clean = F.coalesce(applied_rules.cast("boolean"), F.lit(False))
        blacklist_cond = DeclarationIpcFilteredMapper.is_blacklisted_industry_sectors_combinations(
            ipc_industry_sector, cpc_industry_sector, data_provider, standard_project
        )
        return (
            F.when(~matched_clean, F.lit(True))
            .when(blacklist_cond, F.lit(False))
            .when(applied_rules_clean, F.lit(True))
            .when(data_provider.isin(white_listed_data_providers), F.lit(True))
            .when(industry_sector.isin(black_listed_industry_sectors), F.lit(False))
            .otherwise(F.lit(True))
        )

    @staticmethod
    def is_blacklisted_industry_sectors_combinations(
        ipc_industry_sector, cpc_industry_sector, data_provider, standard_project
    ):
        return (
            F.when(
                ((ipc_industry_sector == "Chemistry") | (cpc_industry_sector == "Chemistry"))
                & (ipc_industry_sector != "Electrical engineering")
                & (cpc_industry_sector != "Electrical engineering"),
                F.lit(True),
            )
            .when(
                ((ipc_industry_sector == "Mechanical engineering") | (cpc_industry_sector == "Mechanical engineering"))
                & (data_provider != "SAE")
                & (standard_project != "EV, Charging")
                & (ipc_industry_sector != "Electrical engineering")
                & (cpc_industry_sector != "Electrical engineering"),
                F.lit(True),
            )
            .when(
                ((ipc_industry_sector == "Other fields") | (cpc_industry_sector == "Other fields"))
                & (ipc_industry_sector != "Electrical engineering")
                & (cpc_industry_sector != "Electrical engineering"),
                F.lit(True),
            )
            .when(
                (
                    ((ipc_industry_sector == "") | ipc_industry_sector.isNull())
                    & ((cpc_industry_sector == "") | cpc_industry_sector.isNull())
                ),
                F.lit(True),
            )
            .otherwise(F.lit(False))
        )
