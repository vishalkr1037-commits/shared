from pandas import DataFrame
from pyspark.sql.functions import col

from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.bronze.declarations.declaring_company_lookup import (
    DeclaringCompanyLookup,
)
from src.declarations.models.silver.declarations.raw_declaration_companies_harmonization import (
    RawDeclarationCompaniesHarmonizations,
)


class RawDeclarationCompaniesHarmonizationMapper:
    @staticmethod
    def apply(df: DataFrame):

        return df.withColumns(
            {
                RawDeclarationCompaniesHarmonizations.DECLARING_ID: col(DeclarationRaw.ID),
                RawDeclarationCompaniesHarmonizations.HARMONIZED_NAME: col(
                    DeclaringCompanyLookup.DECLARING_COMPANY_HARMONIZED
                ),
                RawDeclarationCompaniesHarmonizations.ORIGINAL_NAME: col(DeclarationRaw.DECLARING_COMPANY),
            }
        ).drop(DeclaringCompanyLookup.DECLARING_COMPANY_HARMONIZED, DeclarationRaw.ID, DeclarationRaw.DECLARING_COMPANY)
