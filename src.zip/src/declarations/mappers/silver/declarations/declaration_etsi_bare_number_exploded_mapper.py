from pyspark.sql.functions import (
    array_remove,
    col,
    collect_set,
    concat,
    concat_ws,
    length,
    substring,
    trim,
    when,
)

from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw


def _get_complete_app_patent(app_num, patent_office, data_provider):
    return when(
        _verify_bare_number_or_pi(app_num)
        & patent_office.isNotNull()
        & (patent_office != "")
        & (data_provider == "ETSI"),
        _add_patent_office_in_patent(app_num, patent_office),
    ).otherwise(app_num)


def _get_complete_pub_patent(pub, patent_office, data_provider):
    return when(
        _verify_bare_number_or_pi(pub) & patent_office.isNotNull() & (patent_office != "") & (data_provider == "ETSI"),
        _add_patent_office_in_patent(pub, patent_office),
    ).otherwise(pub)


def _add_patent_office_in_patent(num, patent_office):
    return concat(_get_country_code(patent_office), num)


def _verify_bare_number_or_pi(num):
    return (
        (num.isNotNull() & (num != "") & num.rlike("^[0-9]*$"))
        | (num.isNotNull() & (num != "") & num.rlike("^PI[0-9]*$"))
        | (num.isNotNull() & (num != "") & num.rlike("^[0-9]*.[0-9]$"))
        | (num.isNotNull() & (num != "") & num.rlike("^\\d{2}\\/\\d{4,}$"))
        | (num.isNotNull() & (num != "") & num.rlike("^\\d{4}\\-\\d{4,}$"))
        | (num.isNotNull() & (num != "") & num.rlike("^[0-9]*.X$"))
        | (num.isNotNull() & (num != "") & num.rlike("^[0-9]*.[0-9]*[A-Z]$"))
        | (num.isNotNull() & (num != "") & num.rlike("^\\d{1,}[\\/]?([a-zA-Z]{3,5})[\\/]?\\d{1,}$"))
    )


def _get_country_code(patent_office):
    return when(
        (length(substring(patent_office, 1, 2)) == 2) & substring(patent_office, 1, 2).rlike("^[A-Z]"),
        substring(patent_office, 1, 2),
    ).otherwise(patent_office)


def apply(df):
    return (
        df.withColumns(
            {
                "application_numbers_others": _get_complete_app_patent(
                    col("application_as_to_declaration_other_exploded"),
                    col("country_of_registration_other_exploded"),
                    col(DeclarationRaw.DATA_PROVIDER),
                ),
                "publication_numbers_others": _get_complete_pub_patent(
                    col("publication_as_to_declaration_other_exploded"),
                    col("country_of_registration_other_exploded"),
                    col(DeclarationRaw.DATA_PROVIDER),
                ),
            }
        )
        .orderBy(DeclarationRaw.ID)
        .groupBy(DeclarationRaw.ID)
        .agg(
            collect_set(trim(col("publication_numbers_others"))).alias(
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER
            ),
            collect_set(trim(col("application_numbers_others"))).alias(
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER
            ),
            collect_set(trim(col("country_of_registration_other_exploded"))).alias(
                DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER
            ),
        )
        .withColumns(
            {
                DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER: concat_ws(
                    "|", array_remove(col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER), "")
                ),
                DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER: concat_ws(
                    "|", array_remove(col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER), "")
                ),
                DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER: concat_ws(
                    "|", array_remove(col(DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER), "")
                ),
            }
        )
    )
