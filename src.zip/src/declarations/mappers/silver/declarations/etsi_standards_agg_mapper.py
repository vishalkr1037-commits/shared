from pyspark.sql import DataFrame
from pyspark.sql.functions import col, collect_set

import src.declarations.models.silver.declarations.declarations as Declarations


def apply(df: DataFrame) -> DataFrame:
    """
    Aggregates ETSI standards by grouping and collecting standard_doc_id into an array.
    Args:
        df (DataFrame): Input DataFrame.
    Returns:
        DataFrame: Aggregated DataFrame with standard_document_id_array.
    """
    return (
        df.select(
            col("standard_document_number"),
            col(Declarations.ID_FIRST_CHAR),
            col("id").alias(Declarations.ID),
            col(Declarations.STANDARD_DOCUMENT_ID),
            col("technology_generation"),
            col("sso"),
            col("standard_doc_id"),
        )
        .groupBy(
            col("standard_document_number"),
            col(Declarations.ID_FIRST_CHAR),
            col(Declarations.ID),
            col(Declarations.STANDARD_DOCUMENT_ID),
            col("technology_generation"),
            col("sso"),
        )
        .agg(collect_set(col("standard_doc_id")).alias("standard_document_id_array"))
    )
