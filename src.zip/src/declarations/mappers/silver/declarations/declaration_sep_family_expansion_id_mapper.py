from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.models.silver.declarations.declaration_sep_family_expansion as DeclarationSepFamilyExpansion
from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def apply(result: DataFrame) -> DataFrame:

    standard_document_id = F.regexp_replace(F.col("standard_document_id"), "[\\r\\n]", "")
    standard_project = F.regexp_replace(F.col("standard_project"), "[\\r\\n]", "")
    declaring_company = F.initcap(F.regexp_replace(F.col("declaring_company"), "[\\r\\n]", ""))
    declaration_date = F.date_format(
        HelperFunctionForParseDate.parse_date(F.regexp_replace(F.col("declaration_date"), "[\\r\\n]", "")),
        "yyyy-MM-dd",
    )
    publication_number = F.regexp_replace(F.col("publication_number"), "[\\r\\n]", "")
    isld = F.concat_ws(" | ", F.regexp_replace(F.col("isld"), "[\\r\\n]", ""))

    return (
        result.withColumnRenamed("id", DeclarationSepFamilyExpansion.TAKE_DECLARATION_DATA_FROM)
        .withColumn(
            "id",
            DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
                standard_document_id,
                standard_project,
                declaring_company,
                declaration_date,
                publication_number,
                isld,
            ),
        )
        .select(
            DeclarationSepFamilyExpansion.PUBLICATION_ID,
            "id",
            DeclarationSepFamilyExpansion.STANDARD_DOCUMENT_ID,
            F.col(DeclarationSepFamilyExpansion.TAKE_DECLARATION_DATA_FROM).cast("string"),
        )
    )
