from pyspark.sql import DataFrame
from pyspark.sql.functions import col, concat_ws, current_timestamp, lit

import src.declarations.models.silver.declarations.declaration_diff_ids as DeclarationDiffIds


def apply(df: DataFrame, type: str) -> DataFrame:
    return (
        df.withColumn(DeclarationDiffIds.STATUS, lit(type))
        .withColumn(DeclarationDiffIds.TIMESTAMP, current_timestamp().cast("string"))
        .withColumn(
            DeclarationDiffIds.ID,
            concat_ws(
                "_",
                col(DeclarationDiffIds.DECLARATION_ID),
                col(DeclarationDiffIds.STATUS),
                col(DeclarationDiffIds.TIMESTAMP),
            ),
        )
        .select(
            DeclarationDiffIds.DECLARATION_ID,
            DeclarationDiffIds.ID,
            DeclarationDiffIds.STATUS,
            DeclarationDiffIds.TIMESTAMP,
        )
    )
