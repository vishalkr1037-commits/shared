from pyspark.sql.functions import (
    array,
    array_join,
    array_union,
    col,
    concat_ws,
    filter,
    lit,
    size,
    sort_array,
    split,
    when,
)

import src.declarations.models.bronze.declarations.three_gpp_specification as ThreeGppSpecificationSet
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched
import src.declarations.three_gpp_specifications_helper.standard_doc_helpers as helper
import src.declarations.three_gpp_specifications_helper.standard_doc_udfs as wrapper_udf

get_release_mapped_on_version_udf = wrapper_udf.create_pandas_udf(
    helper.get_release_mapped_on_version, is_multi_column=True
)


def _get_set_to_string(set_col):
    return array_join(filter(set_col, lambda x: x.isNotNull() & (x != "")), ", ")


def join_set(set_col):
    return array_join(set_col, " | ")


def _split_string_to_set_array(set_col):
    return split(set_col, " \\| ")


def _technology_set():
    return sort_array(
        array_union(split(col("technology_generation_ss"), "\\|"), col("technology_generation_ss3")), asc=False
    )


def _get_specifications_based_on_sso(specifications):
    return when(col(DeclarationRawEnriched.SSO).isin("ETSI", "ARIB", "ATIS", "CCSA"), specifications).otherwise(array())


def _get_specifications_based_on_sso_string(specifications):
    return when(col(DeclarationRawEnriched.SSO).isin("ETSI", "ARIB", "ATIS", "CCSA"), specifications).otherwise("")


# def _get_5g_bridging_technology():
#     return when(
#         concat_ws(",", col(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY)).contains("5G"),
#         lit("5G and bridging technologies"),
#     ).otherwise(lit(""))


def _get_concatenated_tech_classification(tech_classification, tech_classification_5g):
    return (
        when(
            tech_classification.isNotNull()
            & (tech_classification != "")
            & tech_classification_5g.isNotNull()
            & (tech_classification_5g != ""),
            concat_ws(" | ", tech_classification, tech_classification_5g),
        )
        .when(tech_classification_5g.isNull() | (tech_classification_5g == ""), tech_classification)
        .otherwise(tech_classification_5g)
    )


def _get_real_array_size(tech_gen_array):
    return when((size(tech_gen_array) == 1) & (tech_gen_array.getItem(0) == ""), lit(0)).otherwise(size(tech_gen_array))


def _get_non_empty_technology_generation():
    return when(
        _get_real_array_size(col(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY)) == 0,
        _get_technology_generation_based_on_standard(),
    ).otherwise(col(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY))


def _get_technology_generation_based_on_standard():
    return (
        when(_is_vvc_from_standard_doc_id(), _split_string_to_set_array(lit("VVC (H.266)")))
        .when(_is_vvc_from_standard_project(), _split_string_to_set_array(lit("VVC (H.266)")))
        .when(_is_av1_from_standard_doc_id(), _split_string_to_set_array(lit("AV1")))
        .when(_is_vp9_from_standard_doc_id(), _split_string_to_set_array(lit("VP9")))
        .when(_is_qi_standard_doc_id(), _split_string_to_set_array(lit("Qi1")))
        .when(_is_atsc_from_standard_project(), _split_string_to_set_array(lit("ATSC 3.0")))
        .when(_is_opus_from_standard_project(), _split_string_to_set_array(lit("OPUS")))
        .otherwise(col(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY))
    )


def _is_vp9_from_standard_doc_id():
    return col(DeclarationRawEnriched.STANDARD_DOCUMENT_ID).contains("VP9")


def _is_vvc_from_standard_doc_id():
    return col(DeclarationRawEnriched.STANDARD_DOCUMENT_ID).contains("H.266") | col(
        DeclarationRawEnriched.STANDARD_DOCUMENT_ID
    ).contains("ISO/IEC 23090-3")


def _is_av1_from_standard_doc_id():
    return col(DeclarationRawEnriched.STANDARD_DOCUMENT_ID).contains("AV1")


def _is_vvc_from_standard_project():
    return (
        col(DeclarationRawEnriched.STANDARD_PROJECT).contains("H.266")
        | col(DeclarationRawEnriched.STANDARD_PROJECT).contains("H266")
        | col(DeclarationRawEnriched.STANDARD_PROJECT).contains("ISO/IEC 23090-3")
        | col(DeclarationRawEnriched.STANDARD_PROJECT).contains("VVC")
        | col(DeclarationRawEnriched.STANDARD_PROJECT).contains("HVVC")
    )


def _is_atsc_from_standard_project():
    return col(DeclarationRawEnriched.STANDARD_PROJECT).contains("ATSC 3.0") | col(
        DeclarationRawEnriched.STANDARD_PROJECT
    ).contains("ATSC, 3.0")


def _is_opus_from_standard_project():
    return col(DeclarationRawEnriched.STANDARD_PROJECT).contains("OPUS")


def _is_qi_standard_doc_id():
    return col(DeclarationRawEnriched.STANDARD_DOCUMENT_ID).contains("QI Standard")


def _is_sisvel_from_standard_project():
    return _is_sisvel_lte() | _is_sisvel_nbiot()


def _is_sisvel_lte():
    return col(DeclarationRawEnriched.STANDARD_PROJECT).eqNullSafe("Cellular IoT") & col(
        DeclarationRawEnriched.STANDARD_DOCUMENT_ID
    ).eqNullSafe("LTE-M")


def _is_sisvel_nbiot():
    return col(DeclarationRawEnriched.STANDARD_PROJECT).eqNullSafe("Cellular IoT") & col(
        DeclarationRawEnriched.STANDARD_DOCUMENT_ID
    ).eqNullSafe("NB-IoT")


def _get_enriched_technology_classification(tech_classification):
    return when(_is_sisvel_lte(), lit("LTE-M")).when(_is_sisvel_nbiot(), lit("NB-IoT")).otherwise(tech_classification)


def _get_cleared_standard_document_id():
    return when(_is_sisvel_from_standard_project(), lit("")).otherwise(col("STANDARD_DOCUMENT_ID"))


def _get_cleared_technology_generation():
    array_with_empty_string = array(lit(""))
    return when(_is_sisvel_from_standard_project(), array_with_empty_string).otherwise(
        col("TECHNOLOGY_GENERATION_ARRAY")
    )


def apply(df):
    return (
        df.withColumns(
            {
                ThreeGppSpecificationSet.RELEASE: when(
                    col(ThreeGppSpecificationSet.RELEASE).isNull(), array()
                ).otherwise(col(ThreeGppSpecificationSet.RELEASE)),
                "technology_generation_ss3": when(col("technology_generation_ss3").isNull(), array()).otherwise(
                    col("technology_generation_ss3")
                ),
            }
        )
        .withColumns(
            {
                DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY: array(
                    _get_set_to_string(_get_specifications_based_on_sso(_technology_set()))
                ),
                DeclarationRawEnriched.GROUP_ARRAY: _get_specifications_based_on_sso(
                    _split_string_to_set_array(col(ThreeGppSpecificationSet.GROUP))
                ),
            }
        )
        .withColumn(
            DeclarationRawEnriched.RELEASE,
            _get_specifications_based_on_sso_string(
                get_release_mapped_on_version_udf(
                    col(DeclarationRawEnriched.STANDARD_DOCUMENT_ID), join_set(col(ThreeGppSpecificationSet.RELEASE))
                )
            ),
        )
        .withColumns(
            {
                DeclarationRawEnriched.TECHNOLOGY_CLASSIFICATION: _get_enriched_technology_classification(
                    col("technology_classification"),  # Fixed the column reference here
                ),
                DeclarationRawEnriched.STANDARD_DOCUMENT_ID: _get_cleared_standard_document_id(),
                DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY: _get_cleared_technology_generation(),
            }
        )
        .drop(
            "technology_generation_ss",
            ThreeGppSpecificationSet.GROUP,
            "technology_generation_ss3",
            "prefix_clean_standard_doc_id",
            "technology_classification_5g",
        )
        .withColumn(DeclarationRawEnriched.TECHNOLOGY_GENERATION_ARRAY, _get_non_empty_technology_generation())
    )
