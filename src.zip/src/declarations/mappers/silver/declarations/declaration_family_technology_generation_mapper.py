from pyspark.sql import functions as F

import src.declarations.models.silver.declarations.declarations_family_technology_generation as DeclarationsFamilyTechnologyGeneration


def apply(all_declarations_df, all_involved_family_members_df):
    result_df = all_declarations_df.join(
        all_involved_family_members_df, DeclarationsFamilyTechnologyGeneration.PUBLICATION_ID, "left"
    )

    family_tech_gen_df = (
        result_df.groupBy(DeclarationsFamilyTechnologyGeneration.INPADOC_FAMILY_ID)
        .agg(
            F.array_distinct(
                F.flatten(F.collect_set(DeclarationsFamilyTechnologyGeneration.TECHNOLOGY_GENERATION_ARRAY))
            ).alias(DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION)
        )
        .filter(
            F.col(DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION).isNotNull()
            & (F.size(F.col(DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION)) > 0)
        )
    )

    result_df = (
        result_df.join(family_tech_gen_df, DeclarationsFamilyTechnologyGeneration.INPADOC_FAMILY_ID, "left")
        .select(
            DeclarationsFamilyTechnologyGeneration.ID,
            DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION,
        )
        .withColumn(
            DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION,
            F.expr(
                f"filter({DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION}, x -> x IS NOT NULL AND x != '')"
            ),
        )
        .filter(
            F.col(DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION).isNotNull()
            & (F.size(F.col(DeclarationsFamilyTechnologyGeneration.FAMILY_TECHNOLOGY_GENERATION)) > 0)
        )
    )
    return result_df
