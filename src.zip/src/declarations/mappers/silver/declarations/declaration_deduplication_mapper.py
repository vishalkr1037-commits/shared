from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from src.declarations.models.silver.declarations import (
    declaration_deduplicated_intermediate as declaration_deduplicated_intermediate,
)
from src.declarations.models.silver.declarations import (
    declaration_patent_number_matching_candidates as declaration_matching_candidates,
)


def apply(df: DataFrame) -> DataFrame:
    """
    Applies the transformation logic to the input DataFrame.

    Args:
        df (DataFrame): Input DataFrame.

    Returns:
        DataFrame: Transformed DataFrame.
    """
    # Group by DECLARATION_ID and aggregate into a zipped array
    grouped_df = df.groupBy(declaration_matching_candidates.DECLARATION_ID).agg(
        F.collect_list(
            F.struct(
                declaration_matching_candidates.SELECTED_PUBLICATION_NUMBER,
                declaration_matching_candidates.APPLIED_RULES,
                declaration_matching_candidates.SOURCE,
                declaration_matching_candidates.MATCHED,
                declaration_matching_candidates.WORKING_NUMBER,
            )
        ).alias("zipped_array")
    )

    # Add DECLARATION_ID column
    grouped_df = grouped_df.withColumn(
        declaration_matching_candidates.DECLARATION_ID, F.col(declaration_matching_candidates.DECLARATION_ID)
    )

    # Explode the zipped array
    exploded_df = grouped_df.withColumn("exploded_zipped_array", F.explode(F.col("zipped_array")))

    # Extract fields from the exploded array
    transformed_df = exploded_df.withColumns(
        {
            declaration_deduplicated_intermediate.SELECTED_PUBLICATION_NUMBER: F.col("exploded_zipped_array").getField(
                declaration_deduplicated_intermediate.SELECTED_PUBLICATION_NUMBER
            ),
            declaration_deduplicated_intermediate.APPLIED_RULES: F.col("exploded_zipped_array").getField(
                declaration_deduplicated_intermediate.APPLIED_RULES
            ),
            declaration_deduplicated_intermediate.PUBLICATION_NUMBER_SOURCE: F.col("exploded_zipped_array").getField(
                declaration_matching_candidates.SOURCE
            ),
            declaration_deduplicated_intermediate.MATCHED: F.col("exploded_zipped_array").getField(
                declaration_deduplicated_intermediate.MATCHED
            ),
            declaration_deduplicated_intermediate.WORKING_NUMBER: F.col("exploded_zipped_array").getField(
                declaration_deduplicated_intermediate.WORKING_NUMBER
            ),
        }
    )

    # Drop intermediate columns
    transformed_df = transformed_df.drop(
        "zipped_array", "exploded_zipped_array", declaration_matching_candidates.SOURCE
    )

    return transformed_df
