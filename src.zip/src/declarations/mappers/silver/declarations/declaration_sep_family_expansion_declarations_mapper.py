from pyspark.sql import DataFrame
from pyspark.sql import functions as F


def apply(all_declarations: DataFrame) -> DataFrame:
    return all_declarations.groupBy("simple_family_id").agg(F.collect_set("id").alias("id"))
