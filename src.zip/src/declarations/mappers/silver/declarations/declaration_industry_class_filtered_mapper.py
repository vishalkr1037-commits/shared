from typing import Optional

from pyspark.sql.functions import col, lit, udf, when
from pyspark.sql.types import BooleanType

import src.declarations.models.silver.declarations.declaration_industry_class_filtered as DeclarationIndustryClassFiltered

blackListedIPCCPC = [
    "A61K39",
    "A61P13",
    "A61P31",
    "B24B3",
    "B81B1",
    "B82Y40",
    "C01B2",
    "C01G4",
    "C03C1",
    "C07F",
    "C07H21",
    "C08J9",
    "C08K5",
    "C09J",
    "C09K1",
    "C12N2",
    "C12N5",
    "C12P21",
    "C12Q",
    "C23C14/08",
    "C23C16",
    "C40B40",
    "E02F",
    "F25D29",
    "G01N2333",
]

_BLACKLISTED_DATA_PROVIDERS = {"ATSC", "ONE-BLUE"}


def get_list_of_all_classes(ipc_current: Optional[str], cpc_current: Optional[str]) -> list[str]:
    elements = []

    for codes in (ipc_current, cpc_current):
        if codes:
            for code in codes.split("|"):
                code = code.strip()
                if len(code) >= 4:
                    elements.append(code)

    return elements


@udf(returnType=BooleanType())
def is_ipc_cpc_blacklisted(ipc_current, cpc_current, data_provider):
    if data_provider in _BLACKLISTED_DATA_PROVIDERS:
        return True

    classes = get_list_of_all_classes(ipc_current, cpc_current)

    return not any(any(blacklist in element for blacklist in blackListedIPCCPC) for element in classes)


def add_is_ipc_cpc_blacklisted(df):
    return df.withColumn(
        "isIPCCPCBlackListed",
        is_ipc_cpc_blacklisted(
            col(DeclarationIndustryClassFiltered.IPC_CURRENT),
            col(DeclarationIndustryClassFiltered.CPC_CURRENT),
            col(DeclarationIndustryClassFiltered.DATA_PROVIDER),
        ),
    )


@udf(returnType=BooleanType())
def is_industry_class_valid(ipc_current, cpc_current):
    return any(s[0].upper() in {"H", "G", "Y", "F"} for s in get_list_of_all_classes(ipc_current, cpc_current))


def get_is_industry_class_valid():
    return when(col(DeclarationIndustryClassFiltered.MATCHED) == False, lit(True)).otherwise(
        is_industry_class_valid(
            col(DeclarationIndustryClassFiltered.IPC_CURRENT), col(DeclarationIndustryClassFiltered.CPC_CURRENT)
        )
    )


def get_is_ipc_cpc_valid():
    return when(
        col(DeclarationIndustryClassFiltered.IS_INDUSTRY_CLASS_VALID) == True,
        is_ipc_cpc_blacklisted(
            col(DeclarationIndustryClassFiltered.IPC_CURRENT),
            col(DeclarationIndustryClassFiltered.CPC_CURRENT),
            col(DeclarationIndustryClassFiltered.DATA_PROVIDER),
        ),
    ).otherwise(lit(False))


def apply(df):
    return df.withColumns(
        {
            DeclarationIndustryClassFiltered.IS_INDUSTRY_CLASS_VALID: get_is_industry_class_valid(),
            DeclarationIndustryClassFiltered.IS_IPC_CPC_VALID: get_is_ipc_cpc_valid(),
        }
    )
