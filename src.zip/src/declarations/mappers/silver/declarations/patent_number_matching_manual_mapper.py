from pyspark.sql.functions import array, col, lit, when

import src.declarations.models.silver.declarations.declaration_patent_number_matching_candidates as DeclarationPatentNumberMatchingCandidates


def get_manual_matched_pub_num_if_exists():
    """
    Get the manually matched publication number if it exists.

    :return: A PySpark Column with the manually matched publication number or the default value.
    """
    return when(
        col("publication_number").isNotNull() & (col("publication_number") != ""), col("publication_number")
    ).otherwise(col(DeclarationPatentNumberMatchingCandidates.SELECTED_PUBLICATION_NUMBER))


def get_manual_matched_if_exists():
    """
    Get the manually matched flag if the publication number exists.

    :return: A PySpark Column with a boolean indicating if the publication number is manually matched.
    """
    return when(col("publication_number").isNotNull() & (col("publication_number") != ""), lit(True)).otherwise(
        col(DeclarationPatentNumberMatchingCandidates.MATCHED)
    )


def get_manual_matched_applied_rules_if_exists():
    """
    Get the manually matched applied rules if the publication number exists.

    :return: A PySpark Column with the applied rules or the default value.
    """
    return when(
        col("publication_number").isNotNull() & (col("publication_number") != ""), array(lit("perfect_match"))
    ).otherwise(col(DeclarationPatentNumberMatchingCandidates.APPLIED_RULES))


def apply(df):
    """
    Apply manual matching transformations to the DataFrame.

    :param df: Input PySpark DataFrame.
    :return: Transformed PySpark DataFrame.
    """
    return df.withColumns(
        {
            DeclarationPatentNumberMatchingCandidates.SELECTED_PUBLICATION_NUMBER: get_manual_matched_pub_num_if_exists(),
            DeclarationPatentNumberMatchingCandidates.MATCHED: get_manual_matched_if_exists(),
            DeclarationPatentNumberMatchingCandidates.APPLIED_RULES: get_manual_matched_applied_rules_if_exists(),
        }
    ).drop("publication_number", "manual_matched_working_number", "manual_matched_source")
