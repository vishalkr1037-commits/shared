from pyspark.sql.functions import arrays_zip, col, explode_outer, split

from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw


def apply(df):
    return (
        df.filter(col(DeclarationRaw.DATA_PROVIDER) == "ETSI")
        .select(
            col(DeclarationRaw.ID),
            col(DeclarationRaw.DATA_PROVIDER),
            col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER),
            col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER),
            col(DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER),
        )
        .na.fill("")
        .withColumns(
            {
                "publication_as_to_declaration_other_split": split(
                    col(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER), "\\|"
                ),
                "application_as_to_declaration_other_split": split(
                    col(DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER), "\\|"
                ),
                "country_of_registration_other_split": split(col(DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER), "\\|"),
            }
        )
        .withColumn(
            "zipped",
            arrays_zip(
                col("publication_as_to_declaration_other_split"),
                col("application_as_to_declaration_other_split"),
                col("country_of_registration_other_split"),
            ),
        )
        .withColumn("exploded", explode_outer(col("zipped")))
        .withColumns(
            {
                "publication_as_to_declaration_other_exploded": col("exploded").getItem(
                    "publication_as_to_declaration_other_split"
                ),
                "application_as_to_declaration_other_exploded": col("exploded").getItem(
                    "application_as_to_declaration_other_split"
                ),
                "country_of_registration_other_exploded": col("exploded").getItem(
                    "country_of_registration_other_split"
                ),
            }
        )
        .na.fill("")
        .drop(
            "publication_as_to_declaration_other_split",
            "application_as_to_declaration_other_split",
            "country_of_registration_other_split",
            "zipped",
            "exploded",
            DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER,
        )
    )
