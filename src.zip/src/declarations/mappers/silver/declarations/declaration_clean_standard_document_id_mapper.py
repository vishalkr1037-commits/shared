from pyspark.sql.functions import col, regexp_extract, regexp_replace, trim, when

import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched
import src.declarations.three_gpp_specifications_helper.standard_doc_helpers as helper
import src.declarations.three_gpp_specifications_helper.standard_doc_udfs as wrapper_udf
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw

get_cleaned_standard_doc_id_udf = wrapper_udf.create_pandas_udf(helper.get_cleaned_standard_doc_id_number)
get_prefix_cleaned_standard_doc_id_udf = wrapper_udf.create_pandas_udf(
    helper.get_standard_doc_id_with_prefix_and_number
)


def _is_3gpp_special_case(standard_doc_id, standard_document_title):
    return (
        standard_doc_id.rlike("[A-Za-z]\\s*10\\d+\\s*\\d+")
        & (standard_document_title != "")
        & standard_document_title.isNotNull()
        & standard_document_title.contains("3GPP")
    )


def _is_ccsa(sso, standard_doc_id):
    return (sso == "CCSA") & standard_doc_id.startswith("3GPP")


def _get_pre_clean_standard_document_id(standard_doc_id, standard_document_title, sso):
    three_gpp_part = regexp_extract(standard_document_title, "TS \\d\\d\\.\\d\\d version \\d+(\\.\\d+)+", 0)
    std_document_id = regexp_replace(three_gpp_part, "version ", "v")
    return (
        when(_is_3gpp_special_case(standard_doc_id, standard_document_title) & (sso == "ETSI"), std_document_id)
        .when(_is_ccsa(sso, standard_doc_id), trim(regexp_replace(standard_doc_id, "3GPP", "")))
        .otherwise(standard_doc_id)
    )


def apply(df):
    # First, add the pre_clean_st_doc_id column
    df_with_pre_clean = df.withColumn(
        "pre_clean_st_doc_id",
        _get_pre_clean_standard_document_id(
            col(DeclarationRaw.STANDARD_DOCUMENT_ID),
            col(DeclarationRaw.STANDARD_DOCUMENT_TITLE),
            col(DeclarationRaw.SSO),
        ),
    )

    # Now we can reference pre_clean_st_doc_id in subsequent operations
    df_with_clean_ids = df_with_pre_clean.withColumns(
        {
            DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID: get_cleaned_standard_doc_id_udf(col("pre_clean_st_doc_id")),
            "prefix_clean_standard_doc_id": get_prefix_cleaned_standard_doc_id_udf(col("pre_clean_st_doc_id")),
        }
    )

    # Finally drop the temporary column
    return df_with_clean_ids.drop("pre_clean_st_doc_id")
