from pyspark.sql.functions import (
    array,
    array_union,
    col,
    concat_ws,
    explode_outer,
    lit,
    udf,
    when,
)
from pyspark.sql.types import ArrayType, StringType

import src.declarations.models.silver.declarations.declaration_patent_number_matching_candidates as DeclarationPatentNumberMatchingCandidates
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched
import src.declarations.patent_matching.cleaners.cleaner_service as cleaner
import src.declarations.patent_matching.declaration_number_matcher as matcher


def apply(df):
    return (
        df.withColumns(
            {
                DeclarationPatentNumberMatchingCandidates.DECLARATION_ID: col(DeclarationRawEnriched.ID),
                DeclarationPatentNumberMatchingCandidates.ID_FIRST_CHAR: col(DeclarationRawEnriched.ID_FIRST_CHAR),
                DeclarationPatentNumberMatchingCandidates.SSO: col(DeclarationRawEnriched.SSO),
                DeclarationPatentNumberMatchingCandidates.DATA_PROVIDER: col(DeclarationRawEnriched.DATA_PROVIDER),
                "cleaned_publication_number_array": _get_cleaned_publication_numbers(),
                "cleaned_application_number_array": _get_cleaned_application_numbers(),
                "cleaned_publication_number_other_array": _get_cleaned_publication_numbers_other(),
                "cleaned_application_number_other_array": _get_cleaned_application_numbers_other(),
            }
        )
        .drop(
            DeclarationRawEnriched.PUBLICATION_AS_TO_DECLARATION,
            DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION,
            DeclarationRawEnriched.PUBLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION_OTHER,
        )
        .withColumns(
            {
                "publication_working_number_array": _get_publication_working_number_array(),
                "application_working_number_array": _get_application_working_number_array(),
                "publication_working_number_other_array": _get_publication_other_working_number_array(),
                "application_working_number_other_array": _get_application_other_working_number_array(),
                "publication_matches_array": _get_publication_matches_array(),
                "application_matches_array": _get_application_matches_array(),
                "publication_matches_other_array": _get_publication_matches_other_array(),
                "application_matches_other_array": _get_application_matches_other_array(),
                "publication_matches_struct": _get_publication_matches_struct(),
                "application_matches_struct": _get_application_matches_struct(),
                "publication_matches_other_struct": _get_publication_matches_other_struct(),
                "application_matches_other_struct": _get_application_matches_other_struct(),
                "all_matches_struct": _get_all_matches_struct(),
            }
        )
        .drop(
            DeclarationRawEnriched.COUNTRY_OF_REGISTRATION,
            "cleaned_publication_number_array",
            "cleaned_application_number_array",
            "cleaned_publication_number_other_array",
            "cleaned_application_number_other_array",
            "publication_working_number_array",
            "application_working_number_array",
            "publication_working_number_other_array",
            "application_working_number_other_array",
            "publication_matches_array",
            "application_matches_array",
            "publication_matches_other_array",
            "application_matches_other_array",
            "publication_matches_struct",
            "application_matches_struct",
            "publication_matches_other_struct",
            "application_matches_other_struct",
        )
        .withColumn("all_matches_struct", explode_outer(col("all_matches_struct")))
        .withColumns(
            {
                DeclarationPatentNumberMatchingCandidates.SOURCE: col("all_matches_struct.source"),
                DeclarationPatentNumberMatchingCandidates.COUNTRY_OF_REGISTRATION: col(
                    "all_matches_struct.country_of_registration"
                ),
                DeclarationPatentNumberMatchingCandidates.ORIGINAL_CLEAN_NUMBER: col(
                    "all_matches_struct.original_clean_number"
                ),
                DeclarationPatentNumberMatchingCandidates.WORKING_NUMBER: col("all_matches_struct.working_number"),
            }
        )
        .withColumn("number_and_rules", col("all_matches_struct.number_and_rules"))
        .drop("all_matches_struct")
        .withColumn("number_and_rules", explode_outer(col("number_and_rules")))
        .withColumn(
            DeclarationPatentNumberMatchingCandidates.SELECTED_PUBLICATION_NUMBER,
            when(
                col("number_and_rules").isNotNull(),
                col("number_and_rules").getItem(0),
            ).otherwise(lit(None)),
        )
        .withColumns(
            {
                DeclarationPatentNumberMatchingCandidates.APPLIED_RULES: when(
                    col("number_and_rules").isNotNull(),
                    array(col("number_and_rules").getItem(1)),
                ).otherwise(lit(None)),
                DeclarationPatentNumberMatchingCandidates.ID: concat_ws(
                    "_",
                    col(DeclarationRawEnriched.ID),
                    col(DeclarationPatentNumberMatchingCandidates.SELECTED_PUBLICATION_NUMBER),
                    col(DeclarationPatentNumberMatchingCandidates.SOURCE),
                ),
                DeclarationPatentNumberMatchingCandidates.MATCHED: col(
                    DeclarationPatentNumberMatchingCandidates.SELECTED_PUBLICATION_NUMBER
                ).isNotNull()
                & (col(DeclarationPatentNumberMatchingCandidates.SELECTED_PUBLICATION_NUMBER) != ""),
            }
        )
        .drop("number_and_rules")
    )


def _get_cleaned_publication_numbers():
    return cleaner.publication_as_to_declaration_cleaner_udf(
        col(DeclarationPatentNumberMatchingCandidates.DATA_PROVIDER),
        col(DeclarationRawEnriched.PUBLICATION_AS_TO_DECLARATION),
    )


def _get_cleaned_application_numbers():
    return cleaner.application_as_to_declaration_cleaner_udf(
        col(DeclarationPatentNumberMatchingCandidates.DATA_PROVIDER),
        col(DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION),
    )


def _get_cleaned_publication_numbers_other():
    return cleaner.publication_as_to_declaration_cleaner_udf(
        col(DeclarationPatentNumberMatchingCandidates.DATA_PROVIDER),
        col(DeclarationRawEnriched.PUBLICATION_AS_TO_DECLARATION_OTHER),
    )


def _get_cleaned_application_numbers_other():
    return cleaner.application_as_to_declaration_cleaner_udf(
        col(DeclarationPatentNumberMatchingCandidates.DATA_PROVIDER),
        col(DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION_OTHER),
    )


@udf(returnType=ArrayType(StringType()))
def get_working_number_array(cleaned_number_array, country_of_registration):
    return [matcher.get_preprocessed_number(number, country_of_registration) for number in cleaned_number_array]


def _get_publication_working_number_array():
    return get_working_number_array(
        col("cleaned_publication_number_array"), col(DeclarationRawEnriched.COUNTRY_OF_REGISTRATION)
    )


def _get_application_working_number_array():
    return get_working_number_array(
        col("cleaned_application_number_array"), col(DeclarationRawEnriched.COUNTRY_OF_REGISTRATION)
    )


def _get_publication_other_working_number_array():
    return get_working_number_array(col("cleaned_publication_number_other_array"), lit(""))


def _get_application_other_working_number_array():
    return get_working_number_array(col("cleaned_application_number_other_array"), lit(""))


@udf(returnType=ArrayType(ArrayType(ArrayType(StringType()))))
def find_all_publication_numbers_spark_udf(work_number_array, country_of_registration):
    return [matcher.find_all_publication_numbers_udf(number, country_of_registration) for number in work_number_array]


@udf(returnType=ArrayType(ArrayType(ArrayType(StringType()))))
def find_all_application_numbers_spark_udf(work_number_array, country_of_registration):
    return [matcher.find_all_application_numbers_udf(number, country_of_registration) for number in work_number_array]


def _get_publication_matches_array():
    return find_all_publication_numbers_spark_udf(
        col("publication_working_number_array"), col(DeclarationRawEnriched.COUNTRY_OF_REGISTRATION)
    )


def _get_application_matches_array():
    return find_all_application_numbers_spark_udf(
        col("application_working_number_array"), col(DeclarationRawEnriched.COUNTRY_OF_REGISTRATION)
    )


def _get_publication_matches_other_array():
    return find_all_publication_numbers_spark_udf(col("publication_working_number_other_array"), lit(""))


def _get_application_matches_other_array():
    return find_all_application_numbers_spark_udf(col("application_working_number_other_array"), lit(""))


def _get_publication_matches_struct():
    return matcher.get_matches_struct(
        "cleaned_publication_number_array",
        "publication_working_number_array",
        "publication_matches_array",
        lit("PUBLICATION_AS_TO_DECLARATION"),
        col(DeclarationRawEnriched.COUNTRY_OF_REGISTRATION),
    )


def _get_application_matches_struct():
    return matcher.get_matches_struct(
        "cleaned_application_number_array",
        "application_working_number_array",
        "application_matches_array",
        lit("APPLICATION_AS_TO_DECLARATION"),
        col(DeclarationRawEnriched.COUNTRY_OF_REGISTRATION),
    )


def _get_publication_matches_other_struct():
    return matcher.get_matches_struct(
        "cleaned_publication_number_other_array",
        "publication_working_number_other_array",
        "publication_matches_other_array",
        lit("PUBLICATION_AS_TO_DECLARATION_OTHER"),
        lit(""),
    )


def _get_application_matches_other_struct():
    return matcher.get_matches_struct(
        "cleaned_application_number_other_array",
        "application_working_number_other_array",
        "application_matches_other_array",
        lit("APPLICATION_AS_TO_DECLARATION_OTHER"),
        lit(""),
    )


def _get_all_matches_struct():
    return array_union(
        col("publication_matches_struct"),
        array_union(
            col("application_matches_struct"),
            array_union(col("publication_matches_other_struct"), col("application_matches_other_struct")),
        ),
    )
