from pyspark.sql import DataFrame
from pyspark.sql.functions import col, lit, to_date, when, year

# Constants for column names
EARLIEST_PRIORITY_DATE = "earliest_priority_date"
IS_PRIORITY_DATE_VALID = "is_priority_date_valid"
MATCHED = "matched"
APPLIED_RULES = "applied_rules"
PUBLICATION_NUMBER = "publication_number"

# Whitelisted publication numbers
WHITELISTED_PUB_NUMS = [
    "JPS63502867A",
    "JPS62291280A",
    "JPS642435A",
    "JPS61501125A",
    "JPS61502720A",
    "JPS63500543A",
    "JPS59501527A",
    "JPS59501524A",
    "JPS59501525A",
    "JPS63310294A",
    "JPS6431285A",
    "JPS63126084A",
    "JPS6383892A",
    "JPS63133723A",
    "JPS6335026A",
    "JPS59116794A",
    "JPS59116795A",
    "JPS59116793A",
    "JPS59139736A",
    "JPS59139735A",
    "JPS59171338A",
    "JPS59139738A",
    "JPS5684045A",
]


def initialize_whitelisted_pub_nums_broadcast(spark):
    return spark.sparkContext.broadcast(set(WHITELISTED_PUB_NUMS))


def is_priority_date_earlier_than_1977_or_jps_not_perfect_match(
    priority_date_col, applied_rules_col, pub_number_col, whitelisted_pub_nums_broadcast
):
    return (
        when(year(priority_date_col) < 1977, lit(False))
        .when(
            pub_number_col.startswith("JPS")
            & (~applied_rules_col)
            & (~pub_number_col.isin(*whitelisted_pub_nums_broadcast.value)),
            lit(False),
        )
        .otherwise(lit(True))
    )


def normalize_earliest_priority_date(df: DataFrame):
    return df.withColumn(EARLIEST_PRIORITY_DATE, to_date(col(EARLIEST_PRIORITY_DATE), "yyyyMMdd"))


def is_unmatched_record():
    return col(MATCHED) == lit(False)


def priority_date_validity_condition(whitelisted_pub_nums_broadcast):
    return when(is_unmatched_record(), lit(True)).otherwise(
        is_priority_date_earlier_than_1977_or_jps_not_perfect_match(
            col(EARLIEST_PRIORITY_DATE),
            col(APPLIED_RULES),
            col(PUBLICATION_NUMBER),
            whitelisted_pub_nums_broadcast,
        )
    )


def add_priority_date_valid_flag(df: DataFrame, whitelisted_pub_nums_broadcast):
    return df.withColumn(IS_PRIORITY_DATE_VALID, priority_date_validity_condition(whitelisted_pub_nums_broadcast))


def apply_mapper(df: DataFrame, whitelisted_pub_nums_broadcast):
    df = normalize_earliest_priority_date(df)
    df = add_priority_date_valid_flag(df, whitelisted_pub_nums_broadcast)
    return df
