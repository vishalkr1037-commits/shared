from pyspark.sql import Column, DataFrame
from pyspark.sql.functions import col, lit, when

import src.declarations.utils.standards_identifier as standards_identifier


def is_video_encoding_declarations() -> Column:
    return (
        (col("technology_generation") == "AVC (H.264)")
        | (col("technology_generation") == "HEVC (H.265)")
        | (col("technology_generation") == "VVC (H.266)")
        | (col("technology_generation") == "AV1")
        | (col("technology_generation") == "VP9")
    )


def is_wifi_declarations() -> Column:
    return (
        (col("technology_generation") == "Wi-Fi 1 (IEEE 802.11b)")
        | (col("technology_generation") == "Wi-Fi 2 (IEEE 802.11a)")
        | (col("technology_generation") == "Wi-Fi 3 (IEEE 802.11g)")
        | (col("technology_generation") == "Wi-Fi 4 (IEEE 802.11n)")
        | (col("technology_generation") == "Wi-Fi 5 (IEEE 802.11ac)")
        | (col("technology_generation") == "Wi-Fi 6 (IEEE 802.11ax)")
        | (col("technology_generation") == "Wi-Fi 7 (IEEE 802.11be)")
    )


def is_qi_declarations() -> Column:
    return col("standard_document_id") == "QI Standard"


def is_etsi_declarations() -> Column:
    return col("sso") == "ETSI"


def get_most_meaningful_standard_document_id_for_video_encoding() -> Column:
    return (
        when(col("technology_generation") == "AVC (H.264)", lit("ISO/IEC 14496-10:2020"))
        .when(col("technology_generation") == "HEVC (H.265)", lit("CAN/CSA-ISO/IEC 23008-2:21"))
        .when(col("technology_generation") == "VVC (H.266)", lit("ISO/IEC 23090-3:2021"))
        .when(col("technology_generation") == "AV1", lit("AV1 v.1.0.0"))
        .when(col("technology_generation") == "VP9", lit("VP9 v0.6"))
    )


def get_most_meaningful_standard_document_id_for_wifi() -> Column:
    return (
        when(col("technology_generation") == "Wi-Fi 1 (IEEE 802.11b)", lit("IEEE 802.11b"))
        .when(col("technology_generation") == "Wi-Fi 2 (IEEE 802.11a)", lit("IEEE 802.11a"))
        .when(col("technology_generation") == "Wi-Fi 3 (IEEE 802.11g)", lit("IEEE 802.11g"))
        .when(col("technology_generation") == "Wi-Fi 4 (IEEE 802.11n)", lit("IEEE 802.11n"))
        .when(col("technology_generation") == "Wi-Fi 5 (IEEE 802.11ac)", lit("IEEE 802.11ac-2013"))
        .when(col("technology_generation") == "Wi-Fi 6 (IEEE 802.11ax)", lit("IEEE 802.11ax-2021"))
        .when(col("technology_generation") == "Wi-Fi 7 (IEEE 802.11be)", lit("IEEE 802.11be"))
    )


def get_most_meaningful_standard_document_id_for_etsi() -> Column:
    return standards_identifier.get_most_meaningful_standard_document_id_udf(
        col("standard_document_id_array"),
        col("standard_document_id"),
    )


def get_most_meaningful_standard_document_id_qi() -> Column:
    return lit("Qi Standard")


def get_most_meaningful_standard_document_id() -> Column:
    return (
        when(is_video_encoding_declarations(), get_most_meaningful_standard_document_id_for_video_encoding())
        .when(is_qi_declarations(), get_most_meaningful_standard_document_id_qi())
        .when(is_wifi_declarations(), get_most_meaningful_standard_document_id_for_wifi())
        .when(is_etsi_declarations(), get_most_meaningful_standard_document_id_for_etsi())
        .otherwise(col("standard_document_id"))
    )


def apply(df: DataFrame) -> DataFrame:
    """
    Adds the most_meaningful_standard_document_id column to the DataFrame.
    Args:
        df (DataFrame): Input DataFrame.
    Returns:
        DataFrame: DataFrame with the new column.
    """
    return df.withColumn("most_meaningful_standard_document_id", get_most_meaningful_standard_document_id())
