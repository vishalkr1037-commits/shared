from pyspark.sql import functions as F

import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFilteredModel


def apply(df):
    tech_classification_col = F.when(
        F.col("technology_classification_cellular").isNull(),
        F.col(DeclarationCompanyFilteredModel.TECHNOLOGY_CLASSIFICATION),
    ).otherwise(F.col("technology_classification_cellular"))

    aggregated_tech_classification_df = (
        df.select("publication_number", "standard_project", tech_classification_col.alias("tech_classification"))
        .repartition("publication_number")  # schuffling optimization
        .groupBy("publication_number", "standard_project")
        .agg(F.array_join(F.collect_set("tech_classification"), " | ").alias("aggregated_tech_classification"))
    )

    result_df = (
        df.drop("technology_classification_cellular")
        .join(aggregated_tech_classification_df, on=["publication_number", "standard_project"], how="left")
        .withColumns(
            {
                "technology_classification": F.coalesce(
                    F.col("aggregated_tech_classification"), F.col("technology_classification")
                )
            }
        )
        .drop("aggregated_tech_classification")
    )
    return result_df
