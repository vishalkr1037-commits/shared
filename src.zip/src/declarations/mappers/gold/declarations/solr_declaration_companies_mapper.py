from pyspark.sql import DataFrame
from pyspark.sql import functions as F

from src.declarations.models.silver.declarations.raw_declaration_companies_harmonization import (
    RawDeclarationCompaniesHarmonizations,
)


def apply(df: DataFrame) -> DataFrame:
    return df.withColumns(
        {
            "id": F.col(RawDeclarationCompaniesHarmonizations.DECLARING_ID),
            "declaring_company": F.concat_ws(" | ", F.col(RawDeclarationCompaniesHarmonizations.HARMONIZED_NAME)),
            "declaring_company_search": F.concat_ws(
                " | ", F.col(RawDeclarationCompaniesHarmonizations.HARMONIZED_NAME)
            ),
            "declaring_company_array": F.col(RawDeclarationCompaniesHarmonizations.HARMONIZED_NAME),
        }
    ).drop(
        F.col(RawDeclarationCompaniesHarmonizations.HARMONIZED_NAME),
        F.col(RawDeclarationCompaniesHarmonizations.DECLARING_ID),
    )
