from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFilteredModel
import src.declarations.utils.string_utility as utils
from src.declarations.utils.solr_utility import split_by_asterisk_pipe_udf

MULTI_MODE_REGEX = "(?i),"
FIVE_G_REGEX = "(?i)(^|,)5G(,|$)"
FOUR_G_REGEX = "(?i)(^|,)4G(,|$)"
THREE_G_REGEX = "(?i)(^|,)3G(,|$)"


def apply(df: DataFrame) -> DataFrame:
    return df.withColumns(
        {
            DeclarationGoldModel.TECHNOLOGY_GENERATION: add_multi_mode_string(
                utils.get_set_to_string(F.col(DeclarationCompanyFilteredModel.TECHNOLOGY_GENERATION_ARRAY))
            ),
            DeclarationGoldModel.TECHNOLOGY_GENERATION_ARRAY: utils.split_string_to_set_array(
                add_multi_mode_string(
                    utils.get_set_to_string(F.col(DeclarationCompanyFilteredModel.TECHNOLOGY_GENERATION_ARRAY))
                )
            ),
            DeclarationGoldModel.GROUP: utils.join_set(F.col(DeclarationCompanyFilteredModel.GROUP_ARRAY)),
            DeclarationGoldModel.FAMILY_TECHNOLOGY_GENERATION: split_by_asterisk_pipe_udf(
                utils.join_set(F.col(DeclarationGoldModel.FAMILY_TECHNOLOGY_GENERATION))
            ),
            DeclarationGoldModel.FAMILY_TECHNOLOGY_GENERATION_ARRAY: utils.split_string_to_set_array(
                split_by_asterisk_pipe_udf(utils.join_set(F.col(DeclarationGoldModel.FAMILY_TECHNOLOGY_GENERATION)))
            ),
        }
    ).drop(DeclarationCompanyFilteredModel.GROUP_ARRAY)


def add_multi_mode_string(set_col):
    return (
        F.when(set_col.rlike(FIVE_G_REGEX) & set_col.rlike(MULTI_MODE_REGEX), F.lit("5G and bridging technologies"))
        .when(
            ~set_col.rlike(FIVE_G_REGEX) & set_col.rlike(FOUR_G_REGEX) & set_col.rlike(MULTI_MODE_REGEX),
            F.lit("4G and bridging technologies"),
        )
        .when(
            ~set_col.rlike(f"{FIVE_G_REGEX}|{FOUR_G_REGEX}")
            & set_col.rlike(THREE_G_REGEX)
            & set_col.rlike(MULTI_MODE_REGEX),
            F.lit("3G and bridging technologies"),
        )
        .otherwise(set_col)
    )
