from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFilteredModel


def apply(df: DataFrame) -> DataFrame:
    return (
        df.withColumns(
            {
                DeclarationGoldModel.ID: F.col(DeclarationCompanyFilteredModel.ID),
                DeclarationGoldModel.SSO: F.col(DeclarationCompanyFilteredModel.SSO),
            }
        )
        .withColumns(
            {
                DeclarationGoldModel.SSO_SEARCH: F.col(DeclarationCompanyFilteredModel.SSO),
                DeclarationGoldModel.DATA_PROVIDER: F.col(DeclarationCompanyFilteredModel.DATA_PROVIDER),
                DeclarationGoldModel.STANDARD_PROJECT: F.col(DeclarationCompanyFilteredModel.STANDARD_PROJECT),
            }
        )
        .withColumns(
            {
                DeclarationGoldModel.STANDARD_PROJECT_SEARCH: F.col(DeclarationCompanyFilteredModel.STANDARD_PROJECT),
                DeclarationGoldModel.STANDARD_DOCUMENT_ID: get_standard_document_id(
                    F.col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_ID)
                ),
                DeclarationGoldModel.DECLARATION_DATE: F.to_date(
                    F.col(DeclarationCompanyFilteredModel.DECLARATION_DATE)
                ),
            }
        )
        .withColumns(
            {
                DeclarationGoldModel.STANDARD_DOCUMENT_ID_SEARCH: F.col(DeclarationGoldModel.STANDARD_DOCUMENT_ID),
                DeclarationGoldModel.DECLARATION_YEAR: F.year(F.col(DeclarationGoldModel.DECLARATION_DATE)),
                DeclarationGoldModel.POOLED: is_pooled(),
                DeclarationGoldModel.POOL_NAME: F.col(DeclarationCompanyFilteredModel.PATENT_POOL_NAME),
                DeclarationGoldModel.POOL_NAME_SEARCH: F.col(DeclarationCompanyFilteredModel.PATENT_POOL_NAME),
                DeclarationGoldModel.BASIS_PATENT: is_basis_patent(),
                DeclarationGoldModel.APPLICATION_AS_TO_DECLARATION: F.col(
                    DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION
                ),
                DeclarationGoldModel.APPLICATION_AS_TO_DECLARATION_SEARCH: F.split(
                    F.col(DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION), r" \| "
                ),
                DeclarationGoldModel.APPLICATION_AS_TO_DECLARATION_ARRAY: F.split(
                    F.col(DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION), r" \| "
                ),
                DeclarationGoldModel.PUBLICATION_AS_TO_DECLARATION: F.col(
                    DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION
                ),
                DeclarationGoldModel.PUBLICATION_AS_TO_DECLARATION_SEARCH: F.split(
                    F.col(DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION), r" \| "
                ),
                DeclarationGoldModel.PUBLICATION_AS_TO_DECLARATION_ARRAY: F.split(
                    F.col(DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION), r" \| "
                ),
                DeclarationGoldModel.APPLICATION_AS_TO_DECLARATION_OTHER: F.col(
                    DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION_OTHER
                ),
                DeclarationGoldModel.APPLICATION_AS_TO_DECLARATION_OTHER_SEARCH: F.split(
                    F.col(DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION_OTHER), r" \| "
                ),
                DeclarationGoldModel.APPLICATION_AS_TO_DECLARATION_OTHER_ARRAY: F.split(
                    F.col(DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION_OTHER), r" \| "
                ),
                DeclarationGoldModel.PUBLICATION_AS_TO_DECLARATION_OTHER: F.col(
                    DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION_OTHER
                ),
                DeclarationGoldModel.PUBLICATION_AS_TO_DECLARATION_OTHER_SEARCH: F.split(
                    F.col(DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION_OTHER), r" \| "
                ),
                DeclarationGoldModel.PUBLICATION_AS_TO_DECLARATION_OTHER_ARRAY: F.split(
                    F.col(DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION_OTHER), r" \| "
                ),
                DeclarationGoldModel.LICENSING_TERMS: F.col(DeclarationCompanyFilteredModel.LICENSING_TERMS),
                DeclarationGoldModel.SPECIFIC_LICENSING_CONDITIONS: F.col(
                    DeclarationCompanyFilteredModel.SPECIFIC_LICENSING_CONDITIONS
                ),
                DeclarationGoldModel.RECIPROCITY_STATEMENT: F.col(DeclarationCompanyFilteredModel.RECIPOCITY_STATEMENT),
                DeclarationGoldModel.LICENSING_COMMENT: F.col(DeclarationCompanyFilteredModel.LICENSING_COMMENT),
                DeclarationGoldModel.PREPARED_TO_GRANT_LICENSES: F.col(
                    DeclarationCompanyFilteredModel.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES
                ),
                DeclarationGoldModel.CONTACT_PERSON_FOR_LICENSE: F.col(
                    DeclarationCompanyFilteredModel.CONTACT_PERSON_FOR_LICENSE
                ),
                DeclarationGoldModel.CONTACT_PERSON_POSITION: F.col(
                    DeclarationCompanyFilteredModel.CONTACT_PERSON_POSITION
                ),
                DeclarationGoldModel.CONTACT_ADDRESS_FOR_LICENSE: F.col(
                    DeclarationCompanyFilteredModel.CONTACT_ADDRESS_FOR_LICENSE
                ),
                DeclarationGoldModel.CONTACT_PHONE_FOR_LICENSE: F.col(
                    DeclarationCompanyFilteredModel.CONTACT_PHONE_FOR_LICENSE
                ),
                DeclarationGoldModel.CONTACT_EMAIL_FOR_LICENSE: F.col(
                    DeclarationCompanyFilteredModel.CONTACT_EMAIL_FOR_LICENSE
                ),
                DeclarationGoldModel.ISLD: F.split(F.col(DeclarationCompanyFilteredModel.ISLD), r" \| "),
            }
        )
        .withColumns(
            {
                DeclarationGoldModel.ISLD_SEARCH: F.col(DeclarationGoldModel.ISLD),
                DeclarationGoldModel.DISCLOSURE_NUMBER: get_disclosure_number(),
                DeclarationGoldModel.SECTION: get_section(),
                DeclarationGoldModel.TYPE: F.col(DeclarationCompanyFilteredModel.TYPE),
                DeclarationGoldModel.POOL_PROVIDER: F.col(DeclarationCompanyFilteredModel.POOL_PROVIDER),
                DeclarationGoldModel.POOL_NAME_HARMONIZED: F.col(DeclarationCompanyFilteredModel.POOL_NAME_HARMONIZED),
                DeclarationGoldModel.ESSENTIAL_CLAIM_NO: F.col(DeclarationCompanyFilteredModel.ESSENTIAL_CLAIM_NUMBER),
                DeclarationGoldModel.TECHNOLOGY_CLASSIFICATION: F.col(
                    DeclarationCompanyFilteredModel.TECHNOLOGY_CLASSIFICATION
                ),
            }
        )
        .withColumn(
            DeclarationGoldModel.TECHNOLOGY_CLASSIFICATION_ARRAY,
            F.split(F.col(DeclarationGoldModel.TECHNOLOGY_CLASSIFICATION), r" \| "),
        )
        .drop(
            DeclarationCompanyFilteredModel.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES,
            DeclarationCompanyFilteredModel.PATENT_POOL_NAME,
            DeclarationCompanyFilteredModel.RECIPOCITY_STATEMENT,
            DeclarationCompanyFilteredModel.PUBLICATION_NUMBER_SOURCE,
        )
    )


def is_pooled():
    return (F.col(DeclarationCompanyFilteredModel.PATENT_POOL_NAME).isNotNull()) & (
        F.col(DeclarationCompanyFilteredModel.PATENT_POOL_NAME) != ""
    )


def is_basis_patent():
    return (
        F.col(DeclarationCompanyFilteredModel.PUBLICATION_NUMBER_SOURCE)
        == F.col(DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION).cast("string")
    ) | (
        F.col(DeclarationCompanyFilteredModel.PUBLICATION_NUMBER_SOURCE)
        == F.col(DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION).cast("string")
    )


def get_section():
    sections_col = F.split(F.col(DeclarationCompanyFilteredModel.SECTION), r"\|")
    return F.filter(sections_col, lambda x: (x.isNotNull()) & (x != ""))


def get_disclosure_number():
    # Step 1: Split the DISCLOSURE_NUMBER column on ' | ' (space-pipe-space)
    disclosure_numbers = F.split(F.col(DeclarationCompanyFilteredModel.DISCLOSURE_NUMBER), r" \| ")

    # Step 2: Filter only elements that match digits using rlike
    valid_numbers = F.filter(disclosure_numbers, lambda x: x.rlike(r"\d+"))

    # Step 3: Convert each element to integer
    return F.transform(valid_numbers, lambda x: x.cast("int"))


def get_standard_document_id(std_doc_id_col):
    trimmed_std_doc_id = F.when(std_doc_id_col.endswith(","), F.translate(std_doc_id_col, ",", "")).otherwise(
        F.trim(std_doc_id_col)
    )

    cleaned = F.trim(
        F.regexp_replace(F.regexp_replace(trimmed_std_doc_id, r"(.*),\.(.*)", r"\1.\2"), r"(.*),(.*)", r"\1.\2")
    )

    return cleaned
