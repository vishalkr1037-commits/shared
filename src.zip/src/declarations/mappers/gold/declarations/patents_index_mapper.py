from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.models.bronze.patents.patents_index as patents_index_model


def apply(df: DataFrame) -> DataFrame:
    """
    Maps the patent document values DataFrame to the required format.

    Args:
        df (DataFrame): Input DataFrame containing patent document values.

    Returns:
        DataFrame: Transformed DataFrame with selected columns and renamed columns.
    """
    return df.withColumns(
        {
            patents_index_model.PUBLICATION_NUMBER: F.col("publication_number"),
            patents_index_model.PUBLICATION_DATE: F.col("publication_date"),
            patents_index_model.PUBLICATION_YEAR: F.col("publication_year"),
            "country": F.col("country"),
        }
    ).select(F.col(patents_index_model.PUBLICATION_NUMBER), F.col(patents_index_model.PUBLICATION_YEAR))
