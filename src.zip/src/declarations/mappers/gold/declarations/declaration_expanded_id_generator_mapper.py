from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.models.gold.declarations.declaration_gold as declaration_gold
from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def apply(df: DataFrame) -> DataFrame:
    """
    Maps the patent document values DataFrame to the required format.

    Args:
        df (DataFrame): Input DataFrame containing patent document values.

    Returns:
        DataFrame: cleaned isld and generated id.
    """
    # Step 1: create temp column
    df = df.withColumns(
        {
            declaration_gold.ISLD + "_ID_GENERATOR": F.expr("transform(isld, x -> regexp_replace(x, '\\r', ''))"),
        }
    )

    # Step 2: create ID using the temp column
    return df.withColumns(
        {
            declaration_gold.ID: DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
                F.col(declaration_gold.STANDARD_DOCUMENT_ID),
                F.col(declaration_gold.STANDARD_PROJECT),
                F.initcap(F.col(declaration_gold.DECLARING_COMPANY)),
                F.date_format(
                    HelperFunctionForParseDate.parse_date(F.col(declaration_gold.DECLARATION_DATE)),
                    "yyyy-MM-dd",
                ),
                F.col(declaration_gold.PUBLICATION_NUMBER),
                F.concat_ws(" | ", F.col(declaration_gold.ISLD + "_ID_GENERATOR")),
            ),
        }
    ).drop(declaration_gold.ISLD + "_ID_GENERATOR")
