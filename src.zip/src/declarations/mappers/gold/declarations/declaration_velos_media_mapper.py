from pyspark.sql import DataFrame
from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, BooleanType, IntegerType, StringType

import src.declarations.models.bronze.patents.patents_index as PatentsIndexModel
import src.declarations.models.gold.declarations.declaration_gold as DeclarationsGoldModel
import src.declarations.models.gold.declarations.declarations_gold_velos_media_index_preparation as DeclarationsVelosMediaGoldModel
import src.declarations.models.silver.patents.patent_transferred_flag_current_assignee as PatentsAssigneesModel
from src.declarations.utils.declaration_date_parser_helper import (
    HelperFunctionForParseDate,
)
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def apply(df: DataFrame) -> DataFrame:
    return df.withColumns(
        {
            DeclarationsVelosMediaGoldModel.STANDARD_DOCUMENT_ID: F.lit("CAN/CSA-ISO/IEC 23008-2:21"),
            DeclarationsVelosMediaGoldModel.STANDARD_DOCUMENT_ID_SEARCH: F.lit("CAN/CSA-ISO/IEC 23008-2:21"),
            DeclarationsVelosMediaGoldModel.STANDARD_DOCUMENT_ID_HARMONIZED: F.lit(
                "H.265 / ISO/IEC 23008-2 - High Efficiency Video Coding (HEVC)"
            ),
            DeclarationsVelosMediaGoldModel.STANDARD_DOCUMENT_ID_HARMONIZED_SEARCH: F.lit(
                "H.265 / ISO/IEC 23008-2 - High Efficiency Video Coding (HEVC)"
            ),
            DeclarationsVelosMediaGoldModel.STANDARD_PROJECT: F.lit("HEVC (H.265)"),
            DeclarationsVelosMediaGoldModel.STANDARD_PROJECT_SEARCH: F.lit("HEVC (H.265)"),
            DeclarationsVelosMediaGoldModel.SSO: F.lit("ITUT"),
            DeclarationsVelosMediaGoldModel.SSO_SEARCH: F.lit("ITUT"),
            DeclarationsVelosMediaGoldModel.TECHNOLOGY_GENERATION: F.lit("HEVC (H.265)"),
            DeclarationsVelosMediaGoldModel.RELEASE: F.lit(""),
            DeclarationsVelosMediaGoldModel.RELEASE_ARRAY: F.array(F.col(DeclarationsVelosMediaGoldModel.RELEASE)),
            DeclarationsVelosMediaGoldModel.GROUP: F.lit(""),
            DeclarationsVelosMediaGoldModel.GROUP_ARRAY: F.array(F.col("group")),
            DeclarationsVelosMediaGoldModel.TECHNOLOGY_GENERATION_ARRAY: split_string_to_set_array(
                F.col(DeclarationsVelosMediaGoldModel.TECHNOLOGY_GENERATION)
            ),
            DeclarationsVelosMediaGoldModel.FAMILY_TECHNOLOGY_GENERATION_ARRAY: F.col(
                DeclarationsVelosMediaGoldModel.TECHNOLOGY_GENERATION_ARRAY
            ),
            DeclarationsVelosMediaGoldModel.FAMILY_TECHNOLOGY_GENERATION: F.col(
                DeclarationsVelosMediaGoldModel.TECHNOLOGY_GENERATION
            ),
            DeclarationsVelosMediaGoldModel.POOL_NAME: F.lit("Velos Media"),
            DeclarationsVelosMediaGoldModel.POOL_NAME_SEARCH: F.lit("Velos Media"),
            DeclarationsVelosMediaGoldModel.POOL_PROVIDER: F.lit("Velos Media"),
            DeclarationsVelosMediaGoldModel.POOL_NAME_HARMONIZED: F.lit("HEVC (H.265)"),
            DeclarationsVelosMediaGoldModel.POOLED: is_pooled(),
            DeclarationsVelosMediaGoldModel.LICENSING_TERMS: F.lit("https://velosmedia.com/"),
            DeclarationsVelosMediaGoldModel.SPECIFIC_LICENSING_CONDITIONS: F.lit(
                "http://velosmedia.com/technology/why-hevc/"
            ),
            DeclarationsVelosMediaGoldModel.PREPARED_TO_GRANT_LICENSES: F.lit("Yes"),
            DeclarationsGoldModel.DECLARING_COMPANY: F.array_join(
                fallback_on_initial_name_if_empty(
                    F.col(PatentsAssigneesModel.ASSIGNEE_HARMONIZED_NAME_ARRAY),
                    F.col(PatentsAssigneesModel.ASSIGNEE_NAME_ARRAY),
                ),
                " | ",
            ),
            DeclarationsGoldModel.DECLARATION_DATE: HelperFunctionForParseDate.parse_date(
                F.col(PatentsIndexModel.PUBLICATION_DATE)
            ),
            DeclarationsVelosMediaGoldModel.PUBLICATION_NUMBER: F.col(PatentsIndexModel.PUBLICATION_NUMBER),
            DeclarationsVelosMediaGoldModel.SECTION: F.lit(None).cast(ArrayType(StringType())),
            DeclarationsVelosMediaGoldModel.TYPE: F.lit("POOLED"),
            DeclarationsGoldModel.ISLD: F.lit(None).cast(ArrayType(StringType())),
            DeclarationsVelosMediaGoldModel.ID: DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
                F.col(DeclarationsVelosMediaGoldModel.STANDARD_DOCUMENT_ID),
                F.col(DeclarationsVelosMediaGoldModel.STANDARD_PROJECT),
                F.col(DeclarationsGoldModel.DECLARING_COMPANY),
                F.date_format(
                    HelperFunctionForParseDate.parse_date(F.col(DeclarationsGoldModel.DECLARATION_DATE)), "yyyy-MM-dd"
                ),
                F.col(DeclarationsVelosMediaGoldModel.PUBLICATION_NUMBER),
                F.concat_ws(" | ", F.col(DeclarationsGoldModel.ISLD)),
            ),
            DeclarationsVelosMediaGoldModel.ID_FIRST_CHAR: F.substring("id", 1, 1),
            "application_as_to_declaration": F.lit(None).cast(StringType()),
            "application_as_to_declaration_array": F.lit(None).cast(ArrayType(StringType())),
            "application_as_to_declaration_other": F.lit(None).cast(StringType()),
            "application_as_to_declaration_other_array": F.lit(None).cast(ArrayType(StringType())),
            "application_as_to_declaration_other_search": F.lit(None).cast(ArrayType(StringType())),
            "application_as_to_declaration_search": F.lit(None).cast(ArrayType(StringType())),
            "basis_patent": F.lit(None).cast(BooleanType()),
            "contact_address_for_license": F.lit(None).cast(StringType()),
            "contact_email_for_license": F.lit(None).cast(StringType()),
            "contact_person_for_license": F.lit(None).cast(StringType()),
            "contact_person_position": F.lit(None).cast(StringType()),
            "contact_phone_for_license": F.lit(None).cast(StringType()),
            "data_provider": F.lit(None).cast(StringType()),
            "declaration_id": F.lit(None).cast(StringType()),
            "declaration_year": F.lit(None).cast(IntegerType()),
            "declaring_company_array": F.lit(None).cast(ArrayType(StringType())),
            "declaring_company_search": F.lit(None).cast(StringType()),
            "disclosure_number": F.lit(None).cast(ArrayType(IntegerType())),
            "essential_claim_no": F.lit(None).cast(StringType()),
            "expanded": F.lit("Original declaration"),
            "harmonized_standard_doc_id": F.lit(None).cast(StringType()),
            "isld_search": F.lit(None).cast(ArrayType(StringType())),
            "licensing_comment": F.lit(None).cast(StringType()),
            "publication_as_to_declaration": F.lit(None).cast(StringType()),
            "publication_as_to_declaration_array": F.lit(None).cast(ArrayType(StringType())),
            "publication_as_to_declaration_other": F.lit(None).cast(StringType()),
            "publication_as_to_declaration_other_array": F.lit(None).cast(ArrayType(StringType())),
            "publication_as_to_declaration_other_search": F.lit(None).cast(ArrayType(StringType())),
            "publication_as_to_declaration_search": F.lit(None).cast(ArrayType(StringType())),
            "publication_year": F.lit(None).cast(IntegerType()),
            "reciprocity_statement": F.lit(None).cast(StringType()),
            "technology_classification": F.lit(None).cast(StringType()),
            "technology_classification_array": F.lit(None).cast(ArrayType(StringType())),
        }
    ).drop(
        PatentsIndexModel.PUBLICATION_DATE,
        PatentsAssigneesModel.ASSIGNEE_HARMONIZED_NAME_ARRAY,
        PatentsAssigneesModel.ASSIGNEE_NAME_ARRAY,
    )


def split_string_to_set_array(col):
    return F.split(col, r" \| ")


def is_pooled():
    return (F.col(DeclarationsVelosMediaGoldModel.POOL_NAME).isNotNull()) & (
        F.col(DeclarationsVelosMediaGoldModel.POOL_NAME) != ""
    )


def fallback_on_initial_name_if_empty(aimed_col, fallback_col):
    zipped = F.arrays_zip(aimed_col, fallback_col)
    return F.transform(
        zipped,
        lambda x: F.when(F.length(x[aimed_col._jc.toString()]) > 0, x[aimed_col._jc.toString()]).otherwise(
            x[fallback_col._jc.toString()]
        ),
    )
