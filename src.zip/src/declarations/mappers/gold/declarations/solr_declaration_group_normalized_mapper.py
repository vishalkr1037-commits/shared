from pyspark.sql import DataFrame
from pyspark.sql.functions import col, when

import src.declarations.models.bronze.declarations.declarations_groups_normalizer as DeclarationsGroupsNormalizerModel
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.utils.string_utility as utils


def apply(df: DataFrame) -> DataFrame:
    return (
        df.withColumns(
            {
                DeclarationGoldModel.GROUP: get_normalised_group(),
            }
        )
        .withColumns(
            {
                DeclarationGoldModel.GROUP_ARRAY: utils.split_string_to_set_array(DeclarationGoldModel.GROUP),
            }
        )
        .drop(DeclarationsGroupsNormalizerModel.GROUP_NORMALIZED)
        .dropDuplicates([DeclarationGoldModel.ID])
    )


def get_normalised_group():
    return when(
        (col(DeclarationsGroupsNormalizerModel.GROUP_NORMALIZED).isNotNull())
        & (col(DeclarationsGroupsNormalizerModel.GROUP_NORMALIZED) != ""),
        col(DeclarationsGroupsNormalizerModel.GROUP_NORMALIZED),
    ).otherwise(col(DeclarationsGroupsNormalizerModel.GROUP))
