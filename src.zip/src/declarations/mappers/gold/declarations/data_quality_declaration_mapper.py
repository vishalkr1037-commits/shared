from pyspark.sql import DataFrame
from pyspark.sql import functions as F

import src.declarations.models.gold.declarations.data_quality_tracker as DataQualityModel


def transpose_df(df: DataFrame) -> DataFrame:
    rule_names = [c for c in df.columns if c not in ("data_provider", "total_count")]

    if not rule_names:
        return df

    stack_expr = ", ".join([f"'{c}', {c}" for c in rule_names])
    stacked_df = df.withColumn("Rule_id", F.lit("valid_row_count")).selectExpr(
        "Rule_id", "data_provider", "total_count", f"stack({len(rule_names)}, {stack_expr}) as (col0, col1)"
    )

    # groupBy col0 + data_provider + total_count, pivot on Rule_id, aggregate
    transposed_df = (
        stacked_df.groupBy("col0", "data_provider", "total_count")
        .pivot("Rule_id")
        .agg(F.concat_ws("", F.collect_list(F.col("col1"))))
        .withColumnRenamed("col0", "Rule_id")
    )

    return transposed_df


def apply(df: DataFrame) -> DataFrame:
    df = transpose_df(df)

    df = df.withColumns(
        {
            DataQualityModel.RULE_ID: F.col(DataQualityModel.RULE_ID),
            DataQualityModel.DATA_PROVIDER: F.col(DataQualityModel.DATA_PROVIDER),
            DataQualityModel.VALID_ROW_COUNT: F.col(DataQualityModel.VALID_ROW_COUNT),
        }
    )
    df2 = df.withColumns(
        {
            DataQualityModel.INVALID_ROW_COUNT: F.col("total_count") - F.col(DataQualityModel.VALID_ROW_COUNT),
            DataQualityModel.RUNNING_TIMESTAMP: F.current_timestamp(),
            DataQualityModel.TOTAL_ROW_COUNT: F.col("total_count"),
            DataQualityModel.ID: F.concat_ws(
                "_",
                F.col(DataQualityModel.RULE_ID),
                F.regexp_replace(F.col(DataQualityModel.DATA_PROVIDER), " ", "_"),
                F.col(DataQualityModel.RUNNING_TIMESTAMP),
            ),
        }
    ).drop("total_count")

    return df2
