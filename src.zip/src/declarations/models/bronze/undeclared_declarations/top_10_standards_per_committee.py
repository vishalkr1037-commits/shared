from src.declarations.common.declarations_table_config import table_config

TECHNOLOGY_GENERATION = "technology_generation"
GROUP = "group"
STANDARD_DOCUMENT_ID = "standard_document_id"

PATH = table_config.BRONZE_DECLARATIONS_TOP_10_STANDARDS
