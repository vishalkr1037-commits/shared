from src.declarations.common.declarations_table_config import table_config

SIMPLE_FAMILY_ID = "simple_family_id"
TECHNOLOGY = "technology"
CSV_FILE_NAME = "csv_file_name"
PATH = table_config.BRONZE_UNDECLARED_SIMPLE_FAMILIES
