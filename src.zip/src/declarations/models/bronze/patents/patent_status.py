from src.declarations.common.declarations_table_config import table_config

PUBLICATION_ID = "publication_id"
PUBLICATION_YEAR = "publication_year"
APPLICATION_NUMBER = "application_number"
PUBLICATION_TYPE = "publication_type"
PUBLICATION_MONTH = "publication_month"
COUNTRY_CODE = "country_code"
EXPIRATION_DATE = "expiration_date"
EXPIRATION_DATE_SOURCE = "expiration_date_source"
STATUS = "status"
GRANTED = "granted"
ACTIVE = "active"

PATH = table_config.BRONZE_PATENT_STATUS
