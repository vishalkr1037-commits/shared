from src.declarations.common.declarations_table_config import table_config

PUBLICATION_ID = "publication_id"
PUBLICATION_YEAR = "publication_year"
ALL_PRIORITY_NUMBERS = "all_priority_numbers"
ALL_PRIORITY_DATES = "all_priority_dates"
EARLIEST_PRIORITY_NUMBER = "earliest_priority_number"
EARLIEST_PRIORITY_DATE = "earliest_priority_date"
APPLICATION_NUMBER = "application_number"
PUBLICATION_MONTH = "publication_month"
COUNTRY_CODE = "country_code"
INPADOC_FAMILY_ID = "inpadoc_family_id"
PRIORITY_PATENT = "priority_patent"

PATH = table_config.BRONZE_PATENT_FAMILY
