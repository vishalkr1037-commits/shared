from src.declarations.common.declarations_table_config import table_config

PUBLICATION_ID = "publication_id"
PUBLICATION_DATE = "publication_date"
PUBLICATION_YEAR = "publication_year"
PUBLICATION_MONTH = "publication_month"
PUBLICATION_NUMBER = "publication_number"
APPLICATION_NUMBER = "application_number"
CPC_CURRENT = "cpc_current"
IPC_CURRENT = "ipc_current"
INPADOC_FAMILY_ID = "inpadoc_family_id"
APPLICATION_NUMBER_ORIGINAL_FORMAT = "application_number_original_format"
APPLICATION_NUMBER_EPO_FORMAT = "application_number_epo_format"
APPLICATION_DATE = "application_date"
SIMPLE_FAMILY_ID = "simple_family_id"

PATH = table_config.BRONZE_PATENTS_INDEX
