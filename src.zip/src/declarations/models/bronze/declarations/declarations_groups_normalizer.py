from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config.table_config import (
    BRONZE_DECLARATIONS_GROUPS_NORMALIZED,
)

GROUP = "group"
GROUP_NORMALIZED = "group_normalized"

SCHEMA = table_schema("declarations_groups_normalized")

PATH = BRONZE_DECLARATIONS_GROUPS_NORMALIZED
