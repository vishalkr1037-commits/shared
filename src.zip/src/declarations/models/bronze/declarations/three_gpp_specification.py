from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config.table_config import (
    BRONZE_THREE_GPP_SPECIFICATIONS_SET,
)

RELEASE = "release"
TITLE = "title"
GROUP = "group"
FROZEN = "frozen"
ID = "id"
TECHNOLOGY_GENERATION = "technology_generation"
FOR_PUBLICATION = "for_publication"
FREEZE_DATE = "freeze_date"

SCHEMA = table_schema("three_gpp_specifications_set")

PATH = BRONZE_THREE_GPP_SPECIFICATIONS_SET
