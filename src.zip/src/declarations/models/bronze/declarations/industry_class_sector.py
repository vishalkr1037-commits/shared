from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config

INDUSTRY_CLASS = " industry_class"
FIELD_ENGLISH = "field_english"
FIELD_NUMBER = "field_number"
SECTOR_ENGLISH = "sector_english"

SCHEMA = table_schema("industry_class_sector")

PATH = table_config.BRONZE_INDUSTRY_CLASS_SECTOR
