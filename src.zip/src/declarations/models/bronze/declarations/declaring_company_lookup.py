from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config


class DeclaringCompanyLookup:
    DECLARING_COMPANY = "declaring_company"
    DECLARING_COMPANY_HARMONIZED = "declaring_company_harmonized"

    SCHEMA = table_schema("declaring_company_lookup")

    PATH = table_config.BRONZE_DECLARATIONS_COMPANY_LOOKUP
