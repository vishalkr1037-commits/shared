from src.declarations.common.declarations_table_config import table_config

SIMPLE_FAMILY_ID = "simple_family_id"
TECHNOLOGY_CLASSIFICATION = "technology_classification"

PATH = table_config.CELLULAR_IOT_DATA
