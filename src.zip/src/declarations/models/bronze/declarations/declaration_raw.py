from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config


class DeclarationRaw:
    ID = "id"
    SSO = "sso"
    ISLD = "isld"
    SECTION = "section"
    CSV_FILE_NAME = "csv_file_name"
    COUNTRY_OF_REGISTRATION_OTHER = "country_of_registration_other"
    STANDARD_DOCUMENT_TITLE = "standard_document_title"
    STANDARD_PROJECT = "standard_project"
    STANDARD_DOCUMENT_ID = "standard_document_id"
    DECLARING_COMPANY = "declaring_company"
    APPLICATION_AS_TO_DECLARATION = "application_as_to_declaration"
    PUBLICATION_AS_TO_DECLARATION = "publication_as_to_declaration"
    APPLICATION_AS_TO_DECLARATION_OTHER = "application_as_to_declaration_other"
    PUBLICATION_AS_TO_DECLARATION_OTHER = "publication_as_to_declaration_other"
    DECLARATION_DATE = "declaration_date"
    POOL_PROVIDER = "pool_provider"
    PATENT_POOL_NAME = "patent_pool_name"
    POOL_NAME_HARMONIZED = "pool_name_harmonized"
    STANDARD_MATCH_ID = "standard_match_id"
    LICENSING_TERMS = "licensing_terms"
    SPECIFIC_LICENSING_CONDITIONS = "specific_licensing_conditions"
    RECIPROCITY_STATEMENT = "reciprocity_statement"
    LICENSING_COMMENT = "licensing_comment"
    DECLARANT_IS_PREPARED_TO_GRANT_LICENSES = "declarant_is_prepared_to_grant_licenses"
    CONTACT_PERSON_FOR_LICENSE = "contact_person_for_license"
    CONTACT_PERSON_POSITION = "contact_person_position"
    CONTACT_ADDRESS_FOR_LICENSE = "contact_address_for_license"
    CONTACT_PHONE_FOR_LICENSE = "contact_phone_for_license"
    CONTACT_EMAIL_FOR_LICENSE = "contact_email_for_license"
    COUNTRY_OF_REGISTRATION = "country_of_registration"
    PATENT_PROPRIETORS = "patent_proprietors"
    PROPRIETORS_OTHER_MEMBERS = "proprietors_other_members"
    PATENT_TITLE = "patent_title"
    DECLARANT_IS_PROPRIETOR = "declarant_is_proprietor"
    DATA_PROVIDER = "data_provider"
    ESSENTIAL_CLAIM_NO = "essential_claim_no"
    ISLD_AGGREGATED = "isld_aggregated"
    DISCLOSURE_NUMBER_AGGREGATED = "disclosure_number_aggregated"
    SECTION_AGGREGATED = "section_aggregated"
    ID_FIRST_CHAR = "id_first_char"
    TYPE = "type"
    RECIPOCITY_STATEMENT = "reciprocity_statement"
    ESSENTIAL_CLAIM_NUMBER = "essential_claim_no"

    SCHEMA = table_schema("declaration_raw")

    PATH = table_config.BRONZE_DECLARATIONS_RAW
