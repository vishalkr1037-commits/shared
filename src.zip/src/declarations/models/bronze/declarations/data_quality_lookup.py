from src.declarations.common.declarations_table_config import table_config

RULE_ID = "rule_id"
RULE_DESC = "rule_desc"
DIMENSION = "dimension"
SOURCE_NAME = "source_name"
COLUMN_NAME = "column_name"
RULE_CATEGORY = "rule_category"


PATH = table_config.DATA_QUALITY_LOOKUP
