from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config.table_config import (
    BRONZE_DECLARATIONS_MANUAL_MATCHING,
)

WORKING_NUMBER = "working_number"
PUBLICATION_NUMBER = "publication_number"
SOURCE = "source"

SCHEMA = table_schema("manual_matched_publication_numbers")

PATH = BRONZE_DECLARATIONS_MANUAL_MATCHING
