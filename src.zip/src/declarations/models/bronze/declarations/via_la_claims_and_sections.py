from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config

STANDARD_PROJECT = "standard_project"
PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE = "application_as_to_declaration"
PUBLICATION_AS_TO_DECLARATION = "via_la_publication_as_to_declaration"
ESSENTIAL_CLAIMS = "via_la_essential_claim_no"
SECTION = "via_la_section"

SCHEMA = table_schema("declaration_via_la_claims_and_sections")

PATH = table_config.BRONZE_DECLARATIONS_VIA_LA_CLAIMS_SECTION
