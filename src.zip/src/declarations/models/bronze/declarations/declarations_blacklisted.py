from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config


class DeclarationsBlackListed:
    BLACKLISTED_WORKING_NUMBER = "blacklisted_working_number"
    BLACKLISTED_PUBLICATION_NUMBER = "blacklisted_publication_number"

    SCHEMA = table_schema("blacklisted_publication_numbers")

    PATH = table_config.BRONZE_DECLARATIONS_BLACKLISTED
