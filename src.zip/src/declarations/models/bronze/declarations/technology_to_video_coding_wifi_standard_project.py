from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config

TECHNOLOGY_GENERATION = "technology_generation"
STANDARD_PROJECTS = "standard_projects"

SCHEMA = table_schema("technology_generation_to_video_coding_wifi_standard_projects")

PATH = table_config.TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI_STANDARD_PROJECTS
