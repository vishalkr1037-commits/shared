from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config.table_config import (
    TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI,
)

TECHNOLOGY_GENERATION = "technology_generation"
STANDARD_DOCUMENT_IDS = "standard_document_ids"

SCHEMA = table_schema("technology_generation_to_video_coding_wifi")

PATH = TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI
