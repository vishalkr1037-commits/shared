from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config.table_config import (
    TECHNOLOGY_GENERATION_CLASSIFICATION,
)

STANDARD_DOC_ID = "standard_doc_id"
TECHNOLOGY_CLASSIFICATION = "technology_classification"

SCHEMA = table_schema("technology_generation_classification")

PATH = TECHNOLOGY_GENERATION_CLASSIFICATION
