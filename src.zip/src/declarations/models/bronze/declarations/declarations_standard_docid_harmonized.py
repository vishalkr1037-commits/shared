from src.declarations.common.declarations_table_config import table_config

TECHNOLOGY_GENERATION = "technology_generation"
SSO = "sso"
STANDARD_DOCUMENT_ID_HARMONIZED_VAL = "standard_document_id_harmonized_val"
PATH = table_config.BRONZE_STANDARD_DOCID_HARMONIZED
