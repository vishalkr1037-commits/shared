from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config


class DeclarationsWhiteListed:
    WHITELISTED_WORKING_NUMBER = "whitelisted_working_number"
    WHITELISTED_PUBLICATION_NUMBER = "whitelisted_publication_number"

    SCHEMA = table_schema("whitelisted_publication_numbers")

    PATH = table_config.BRONZE_DECLARATIONS_WHITELISTED
