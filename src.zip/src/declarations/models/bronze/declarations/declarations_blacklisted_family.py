from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config


class DeclarationsBlackListedFamily:
    SIMPLE_FAMILY_ID = "simple_family_id"
    BLACKLISTED_PUBLICATION_ID_FAMILY = "blacklisted_publication_id_family"

    SCHEMA = table_schema("blacklisted_family_publication_numbers")

    PATH = table_config.BRONZE_DECLARATIONS_BLACKLISTED_FAMILY
