from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config.table_config import (
    TECHNOLOGY_GENERATION_3GPP,
)

ID = "id"
TITLE = "title"
STATUS = "status"
SPEC_NO = "spec_no"
TYPE = "type"
PRIMARY_RESP_GRP = "primary_resp_grp"
AUTHOR = "author"
INITIAL_PLANNED_RELEASE = "initial_planned_release"
PUBLICATION = "PUBLICATION"
COMMON_IMS = "common_ims"
TECHNOLOGY_GENERATION = "technology_generation"

SCHEMA = table_schema("technology_generation_3gpp")

PATH = TECHNOLOGY_GENERATION_3GPP
