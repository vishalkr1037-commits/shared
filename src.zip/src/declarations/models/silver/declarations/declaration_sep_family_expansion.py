from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config

PUBLICATION_ID = "publication_id"
TAKE_DECLARATION_DATA_FROM = "take_declaration_data_from"
STANDARD_DOCUMENT_ID = "standard_document_id"

SCHEMA = table_schema("declarations_sep_family_expansion")

PATH = table_config.SILVER_DECLARATION_SEP_FAMILY_EXPANSION
