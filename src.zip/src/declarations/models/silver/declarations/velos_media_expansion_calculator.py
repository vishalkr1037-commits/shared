from src.declarations.common.declarations_table_config import table_config

PUBLICATION_ID = "publication_id"
ASSIGNEE_HARMONIZED_NAME_ARRAY = "assignee_harmonized_name_array"
PATH = table_config.SILVER_VELOS_MEDIA_CALCULATOR
