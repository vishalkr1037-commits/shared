from src.declarations.common.declarations_table_config import table_config

DECLARATION_ID = "declaration_id"
ID = "id"
STATUS = "status"
TIMESTAMP = "timestamp"

PATH = table_config.SILVER_DECLARATION_DIFF_IDS
