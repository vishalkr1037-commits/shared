from src.declarations.common.declarations_table_config import table_config

PUBLICATION_NUMBER = "publication_number"
SIMPLE_FAMILY_ID = "simple_family_id"
TECHNOLOGY_CLASSIFICATION = "technology_classification"
PATH = table_config.SILVER_CELLULAR_TECHNOLOGY_CLASSIFICATION
