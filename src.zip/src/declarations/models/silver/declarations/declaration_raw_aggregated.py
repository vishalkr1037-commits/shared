ISLD_AGGREGATED = "isld_aggregated"
DISCLOSURE_NUMBER_AGGREGATED = "disclosure_number_aggregated"
