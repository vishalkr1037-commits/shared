from src.declarations.common.declarations_table_config import table_config

ID = "id"
FAMILY_TECHNOLOGY_GENERATION = "family_technology_generation"
PUBLICATION_ID = "publication_id"
IS_COMPANY_VALID = "is_company_valid"
TECHNOLOGY_GENERATION_ARRAY = "technology_generation_array"
INPADOC_FAMILY_ID = "inpadoc_family_id"

PATH = table_config.SILVER_DECLARATION_FAMILY_TECHNOLOGY_GENERATION
