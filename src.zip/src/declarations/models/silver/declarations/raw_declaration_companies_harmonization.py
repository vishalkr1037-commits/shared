from lnip_data_platform_shared_libs.config.table_config.table_config_interface import (
    table_schema,
)

from src.declarations.common.declarations_table_config import table_config


class RawDeclarationCompaniesHarmonizations:
    DECLARING_ID = "declaration_id"
    HARMONIZED_NAME = "harmonized_name"
    ORIGINAL_NAME = "original_name"

    SCHEMA = table_schema("harmonized_raw_declaring_companies")

    PATH = table_config.SILVER_HARMONIZED_RAW_DECLARING_COMPANIES
