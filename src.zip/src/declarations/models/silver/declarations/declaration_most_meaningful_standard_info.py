from src.declarations.common.declarations_table_config import table_config

DECLARATION_ID = "declaration_id"
ID_FIRST_CHAR = "id_first_char"
STANDARD_DOCUMENT_REF = "standard_document_ref"
AC_CODE = "ac_code"
ORIGINAL_STANDARD_DOCUMENT_URL = "original_standard_document_url"
STANDARD_ID = "standard_id"
PATH = table_config.SILVER_DECLARATION_WITH_MOST_MEANINGFUL_STANDARD_INFO
