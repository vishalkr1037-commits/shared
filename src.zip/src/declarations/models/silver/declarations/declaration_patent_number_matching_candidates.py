from src.declarations.common.declarations_table_config import table_config

ID = "id"
ID_FIRST_CHAR = "id_first_char"
DECLARATION_ID = "declaration_id"
SSO = "sso"
DATA_PROVIDER = "data_provider"
COUNTRY_OF_REGISTRATION = "country_of_registration"
ORIGINAL_CLEAN_NUMBER = "original_clean_number"
WORKING_NUMBER = "working_number"
SOURCE = "source"
SELECTED_PUBLICATION_NUMBER = "selected_publication_number"
MATCHED = "matched"
APPLIED_RULES = "applied_rules"

PATH = table_config.SILVER_DECLARATION_PATENT_NUMBER_MATCHING_CANDIDATES
