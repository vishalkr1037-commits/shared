INPADOC_FAMILY_ID = "inpadoc_family_id"  # INPADOC family ID
HARMONIZED_NAME = "harmonized_name"  # Harmonized name of the applicant
