from src.declarations.common.declarations_table_config import table_config

PUBLICATION_ID = "publication_id"
ASSIGNEE_NAME_ARRAY = "assignee_name_array"
APPLICANT_NAME_ARRAY = "applicant_name_array"
ASSIGNEE_HARMONIZED_NAME_ARRAY = "assignee_harmonized_name_array"

PATH = table_config.BRONZE_PATENT_ASSIGNEES
