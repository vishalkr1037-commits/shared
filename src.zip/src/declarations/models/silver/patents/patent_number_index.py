from src.declarations.common.declarations_table_config import table_config

PUBLICATION_NUMBER_SEARCH = "publication_number_search"
APPLICATION_NUMBER_SEARCH = "application_number_search"
PUBLICATION_DATE = "publication_date"
GRANTED = "granted"
ALL_PRIORITY_NUMBERS_SEARCH = "all_priority_numbers_search"

PATH = table_config.SILVER_PATENT_NUMBER_INDEX
