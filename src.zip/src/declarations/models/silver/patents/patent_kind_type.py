# Variables used in processor
PUBLICATION_ID = "publication_id"  # Publication ID
KIND_TYPE_SHORT = "kind_type_short"  # Short form of kind type
