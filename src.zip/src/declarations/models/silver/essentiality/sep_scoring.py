from src.declarations.common.declarations_table_config import table_config

PATH = table_config.SILVER_SEP_SCORING_VECTORS

# Column constants for SEP scoring vectors table
SEP_TECH = "tech"
SEP_DOCUMENT_ID = "document_id"
SEP_WORD2VEC_CLAIMS = "Word2Vec_Claims"
SEP_WORD2VEC_CLAIMS_ABS = "Word2Vec_Claims_Abs"
