from src.declarations.common.declarations_table_config import table_config

SES_SCORING_SIMILARITIES_TABLE = table_config.SILVER_SES_SCORING_SIMILARITIES

# Column constants for SES scoring similarities table
SES_ID = "id"
SES_PUBLICATION_CLAIM_ID = "publication_claim_id"
SES_STANDARD_SECTION_NUMBER = "standard_section_number"
SES_SIMILARITY_SCORE = "similarity_score"
TECH = "tech"
