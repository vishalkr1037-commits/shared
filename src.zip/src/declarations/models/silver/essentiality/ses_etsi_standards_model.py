from src.declarations.common.declarations_table_config import table_config


class EssentialityEtsiStandardsModel:
    AC_CODE = "ac_code"
    STANDARD_DOCUMENT_ID = "standard_document_id"
    DESCRIPTION = "description"
    SECTION_ZIP = "sections_zip"
    PUBLICATION_DATE = "publication_date"
    STANDARD_DOCUMENT_NUMBER = "standard_document_number"
    ID = "id"

    SILVER_ETSI_STANDARDS = table_config.SILVER_ETSI_STANDARDS
