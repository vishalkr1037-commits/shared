from src.declarations.common.declarations_table_config import table_config

PATH = table_config.SILVER_SEP_SCORING_VECTORS

# Column constants for SEP scoring vectors table
VECTORS_TECH = "tech"
VECTORS_DOCUMENT_ID = "document_id"
VECTORS_WORD2VEC_CLAIMS = "Word2Vec_Claims"
VECTORS_WORD2VEC_CLAIMS_ABS = "Word2Vec_Claims_Abs"
