from src.declarations.common.declarations_table_config import table_config

# Column constants for SES scoring similarities table
ID = "id"
PUBLICATION_NUMBER = "publication_number"
CLAIM_ID = "claim_id"
MOST_MEANINGFUL_STANDARD_DOCUMENT_ID = "most_meaningful_standard_document_id"
SECTION_REFERENCE = "section_reference"
SCORE = "score"


SILVER_ETSI_NORMALIZED_SEMSIM = table_config.SILVER_ETSI_NORMALIZED_SEMSIM
SILVER_ATSC_NORMALIZED_SEMSIM = table_config.SILVER_ATSC_NORMALIZED_SEMSIM
SILVER_VIDEO_NORMALIZED_SEMSIM = table_config.SILVER_VIDEO_NORMALIZED_SEMSIM
SILVER_QI_NORMALIZED_SEMSIM = table_config.SILVER_QI_NORMALIZED_SEMSIM
SILVER_WIFI_NORMALIZED_SEMSIM = table_config.SILVER_WIFI_NORMALIZED_SEMSIM
SILVER_AUDIO_NORMALIZED_SEMSIM = table_config.SILVER_AUDIO_NORMALIZED_SEMSIM
