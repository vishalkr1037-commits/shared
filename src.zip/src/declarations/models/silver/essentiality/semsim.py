from src.declarations.common.declarations_table_config import table_config

# Column constants for SEMSIM table
ID = "id"
PUBLICATION_NUMBER = "publication_number"
CLAIM_ID = "claim_id"
SCORE = "score"
MOST_MEANINGFUL_STANDARD_DOCUMENT_ID = "most_meaningful_standard_document_id"
SECTION_REFERENCE = "section_reference"


SILVER_ETSI_SEMSIM = table_config.SILVER_ETSI_SEMSIM
SILVER_ATSC_SEMSIM = table_config.SILVER_ATSC_SEMSIM
SILVER_VIDEO_SEMSIM = table_config.SILVER_VIDEO_SEMSIM
SILVER_QI_SEMSIM = table_config.SILVER_QI_SEMSIM
SILVER_WIFI_SEMSIM = table_config.SILVER_WIFI_SEMSIM
SILVER_AUDIO_SEMSIM = table_config.SILVER_AUDIO_SEMSIM
