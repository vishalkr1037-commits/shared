from src.declarations.common.declarations_table_config import table_config

PREPROCESSED_CLAIMS_TABLE = table_config.SILVER_PREPROCESSED_CLAIMS


# Column constants for CLAIMS table
CLAIMS_TECH = "tech"
CLAIMS_PUBLICATION_NUMBER = "publication_number"
CLAIMS_CLAIM_ID = "claim_id"
CLAIMS_TEXT = "text"
CLAIMS_PROCESSED_TOKENS = "processed_tokens"
CLAIMS_PROCESSED_TEXT = "processed_text"


PREPROCESSED_ABS_TITLE_TABLE = table_config.SILVER_PREPROCESSED_ABS_TITLE

# Column constants for ABS_TITLE table
ABS_TITLE_TECH = "tech"
ABS_TITLE_PUBLICATION_NUMBER = "publication_number"
ABS_TITLE_ABSTRACT = "abstract"
ABS_TITLE_TITLE = "title"
ABS_TITLE_TEXT = "text"
ABS_TITLE_PROCESSED_TOKENS = "processed_tokens"
ABS_TITLE_PROCESSED_TEXT = "processed_text"

# ============================================================================
# CONSOLIDATED STD_TEXT TABLE (all techs)
# ============================================================================
PREPROCESSED_STD_TEXT_TABLE = table_config.SILVER_PREPROCESSED_STD_TEXT

# Column constants for STD_TEXT table
STD_TEXT_TECH = "tech"
STD_TEXT_MOST_MEANINGFUL_STANDARD_DOCUMENT_ID = "most_meaningful_standard_document_id"
STD_TEXT_SECTION_NUMBER = "section_number"
STD_TEXT_TEXT = "text"
STD_TEXT_PROCESSED_TOKENS = "processed_tokens"
STD_TEXT_PROCESSED_TEXT = "processed_text"
