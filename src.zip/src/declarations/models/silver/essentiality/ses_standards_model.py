from src.declarations.common.declarations_table_config import table_config


class EssentialityStandardsModel:
    AC_CODE = "ac_code"
    STANDARD_DOCUMENT_ID = "standard_document_id"
    DESCRIPTION = "description"
    SECTION_ZIP = "sections_zip"
    PUBLICATION_DATE = "publication_date"

    SILVER_ATSC_STANDARDS = table_config.SILVER_ATSC_STANDARDS
    SILVER_QI_STANDARDS = table_config.SILVER_QI_STANDARDS
    SILVER_WIFI_STANDARDS = table_config.SILVER_WIFI_STANDARDS
    SILVER_AE_STANDARDS = table_config.SILVER_AE_STANDARDS
    SILVER_VE_STANDARDS = table_config.SILVER_VE_STANDARDS
