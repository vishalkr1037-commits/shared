from src.declarations.common.declarations_table_config import table_config

ID = "id"
FAMILY_TECHNOLOGY_GENERATION = "family_technology_generation"

PATH = table_config.SILVER_UNDECLARED_DECLARATIONS_FAMILY_TECHNOLOGY_GENERATION
