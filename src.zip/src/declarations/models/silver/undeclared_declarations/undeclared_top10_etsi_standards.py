from src.declarations.common.declarations_table_config import table_config

PUBLICATION_NUMBER = "publication_number"
TECHNOLOGY_GENERATION = "technology_generation"
GROUP = "group"
HARMONIZED_STANDARD_DOC_ID = "harmonized_standard_doc_id"
STANDARD_DOCUMENT_ID = "standard_document_id"
PATH = table_config.SILVER_UNDECLARED_TOP10_ETSI_STANDARDS
