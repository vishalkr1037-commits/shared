from src.declarations.common.declarations_table_config import table_config


class StandardsDescription:
    AC_CODE = "ac_code"
    ID = "id"
    ID_FIRST_CHAR = "id_first_char"
    DESCRIPTION = "description"

    PATH = table_config.STANDARD_DESCRIPTION_CURATED_PATH
