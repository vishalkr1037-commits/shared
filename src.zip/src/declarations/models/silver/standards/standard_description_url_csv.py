from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

AC_CODE = "AC_code"
FILE_URL = "File URL"
FILE_TEXT = "File Text"

SCHEMA = StructType(
    [
        StructField(AC_CODE, StringType(), True),
        StructField(FILE_URL, StringType(), True),
        StructField(FILE_TEXT, StringType(), True),
    ]
)

PATH = table_config.STANDARD_DESCRIPTION
