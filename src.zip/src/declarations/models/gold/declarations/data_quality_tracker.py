from src.declarations.common.declarations_table_config import table_config

ID = "id"
RULE_ID = "rule_id"
DATA_PROVIDER = "data_provider"
TOTAL_ROW_COUNT = "total_row_count"
VALID_ROW_COUNT = "valid_row_count"
INVALID_ROW_COUNT = "invalid_row_count"
RUNNING_TIMESTAMP = "running_timestamp"

PATH = table_config.GOLD_DECLARATION_DATA_QUALITY
