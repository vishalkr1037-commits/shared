from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config.table_config import (
    LANDING_CSV_TECHNOLOGY_CLASSIFICATION,
)


class TechnologyGenerationClassificationCsv:
    STANDARD_DOC_ID = "standard_doc_id"
    TECHNOLOGY_CLASSIFICATION = "technology_classification"

    SCHEMA = StructType(
        [StructField(STANDARD_DOC_ID, StringType(), True), StructField(TECHNOLOGY_CLASSIFICATION, StringType(), True)]
    )

    PATH = LANDING_CSV_TECHNOLOGY_CLASSIFICATION
