from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config.table_config import (
    LANDING_CSV_BLACKLISTED_FAMILY,
)


class DeclarationsBlackListedFamilyCsv:
    SIMPLE_FAMILY_ID = "simple_family_id"
    BLACKLISTED_PUBLICATION_ID_FAMILY = "blacklisted_publication_id_family"

    SCHEMA = StructType(
        [
            StructField(SIMPLE_FAMILY_ID, StringType(), True),
            StructField(BLACKLISTED_PUBLICATION_ID_FAMILY, StringType(), True),
        ]
    )

    PATH = LANDING_CSV_BLACKLISTED_FAMILY
