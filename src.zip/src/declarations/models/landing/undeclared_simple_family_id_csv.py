from pyspark.sql.types import IntegerType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

SIMPLE_FAMILY_ID = "simple_family_id"

SCHEMA = StructType(
    [
        StructField(SIMPLE_FAMILY_ID, IntegerType(), True),
    ]
)

PATH = table_config.LANDING_UNDECLARED_SIMPLE_FAMILY_ID
