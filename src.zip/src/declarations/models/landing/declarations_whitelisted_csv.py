from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config


class DeclarationsWhiteListedCsv:
    WHITELISTED_WORKING_NUMBER = "whitelisted_working_number"
    WHITELISTED_PUBLICATION_NUMBER = "whitelisted_publication_number"

    SCHEMA = StructType(
        [
            StructField(WHITELISTED_WORKING_NUMBER, StringType(), True),
            StructField(WHITELISTED_PUBLICATION_NUMBER, StringType(), True),
        ]
    )

    PATH = table_config.LANDING_CSV_WHITELISTED
