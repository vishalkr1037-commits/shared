from pyspark.sql.types import IntegerType, StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

SIMPLE_FAMILY_ID = "simple_family_id"
TECHNOLOGY_CLASSIFICATION = "technology_classification"

SCHEMA = StructType(
    [
        StructField(SIMPLE_FAMILY_ID, IntegerType(), True),
        StructField(TECHNOLOGY_CLASSIFICATION, StringType(), True),
    ]
)

PATH = table_config.LANDING_CSV_CELLULAR_IOT_DATA
