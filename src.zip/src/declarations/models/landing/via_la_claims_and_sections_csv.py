from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config


class ViaLAClaimsAndSectionsCsv:
    STANDARD_PROJECT = "Standard Project"
    PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE = "Patent Number With Original Country Code"
    PATENT_NUMBER = "Patent Number"
    ESSENTIAL_CLAIMS = "Essential Claims"
    SECTION = "Section"

    SCHEMA = StructType(
        [
            StructField(STANDARD_PROJECT, StringType(), True),
            StructField(PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE, StringType(), True),
            StructField(PATENT_NUMBER, StringType(), True),
            StructField(ESSENTIAL_CLAIMS, StringType(), True),
            StructField(SECTION, StringType(), True),
        ]
    )

    PATH = table_config.LANDING_CSV_LOCATION_VIA_LA_CLAIMS_SECTION
