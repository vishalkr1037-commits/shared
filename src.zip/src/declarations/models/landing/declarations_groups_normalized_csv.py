from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

GROUPS = "groups"
GROUPS_NORMALIZED = "groups_normalized"

SCHEMA = StructType(
    [
        StructField(GROUPS, StringType(), True),
        StructField(GROUPS_NORMALIZED, StringType(), True),
    ]
)

PATH = table_config.DECLARATIONS_GROUPS_NORMALIZED_CSV
