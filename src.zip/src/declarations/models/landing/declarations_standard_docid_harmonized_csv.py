from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

TECHNOLOGY_GENERATION = "technology_generation"
SSO = "sso"
STANDARD_DOCUMENT_ID_HARMONIZED = "standard_document_id_harmonized"

SCHEMA = StructType(
    [
        StructField(TECHNOLOGY_GENERATION, StringType(), True),
        StructField(SSO, StringType(), True),
        StructField(STANDARD_DOCUMENT_ID_HARMONIZED, StringType(), True),
    ]
)

PATH = table_config.LANDING_CSV_STANDARD_DOCID_HARMONIZED
