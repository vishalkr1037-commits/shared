from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config


class DeclarationsPooledRawCsv:
    SSO = "SSO"
    STANDARD_PROJECT = "Standard Project"
    STANDARD_DOCUMENT_ID = "Standard Document ID"
    DECLARING_COMPANY = "Declaring Company"
    DECLARING_COMPANY_HARMONIZED = "Declaring Company Harmonized"
    APPLICATION_AS_TO_DECLARATION = "Application as to Declaration"
    PUBLICATION_AS_TO_DECLARATION = "Publication as to Declaration"
    DECLARATION_DATE = "Declaration Date"
    PUBLICATION_NUMBER = "Publication Number"
    INPADOC_FAMILY_ID = "INPADOC Family ID"
    INPADOC_FAMILY_EXTENSIONS = "INPADOC Family Extensions"
    SINGLE_FAMILY_EXTENSIONS = "Single Family Extensions"
    PATENT_POOLED = "Patent Pooled?"
    STANDARD_MATCH_ID = "Standard match ID"
    LICENSING_TERMS = "Licensing Terms"
    SPECIFIC_LICENSING_CONDITIONS = "Specific Licensing Conditions"
    RECIPROCITY_STATEMENT = "Reciprocity statement"
    LICENSING_COMMENT = "Licensing Comment"
    DECLARANT_AFFILIATES_GRANT_LICENSES = "Declarant/Affiliates are prepared to grant licenses"
    CONTACT_PERSON_FOR_LICENSE = "Contact Person for License"
    CONTACT_PERSON_POSITION = "Contact Person Position"
    CONTACT_ADDRESS_FOR_LICENSE = "Contact Address for License"
    CONTACT_PHONE_NUMBER_FOR_LICENSE = "Contact Phone Number for License"
    CONTACT_EMAIL_FOR_LICENSE = "Contact Email for License"
    ISLD = "ISLD"
    DISCLOSURE_NUMBER = "Disclosure Number"
    APPLICATION_AS_TO_DECLARATION_OTHER = "Application as to Declaration Other"
    PUBLICATION_AS_TO_DECLARATION_OTHER = "Publication as to Declaration Other"
    SECTION = "Section"
    ESSENTIAL_CLAIMS = "Essential Claims"
    COUNTRY_OF_REGISTRATION = "Country Of Registration"
    PATENT_PROPRIETORS = "Patent Proprietors"
    PROPRIETORS_OTHER_MEMBERS = "Proprietors Other Members"
    PATENT_TITLE = "Patent Title"
    DECLARANT_IS_PROPRIETOR = "Declarant is Proprietor"

    SCHEMA = StructType(
        [
            StructField(SSO, StringType(), True),
            StructField(STANDARD_PROJECT, StringType(), True),
            StructField(STANDARD_DOCUMENT_ID, StringType(), True),
            StructField(DECLARING_COMPANY, StringType(), True),
            StructField(DECLARING_COMPANY_HARMONIZED, StringType(), True),
            StructField(APPLICATION_AS_TO_DECLARATION, StringType(), True),
            StructField(PUBLICATION_AS_TO_DECLARATION, StringType(), True),
            StructField(DECLARATION_DATE, StringType(), True),
            StructField(PUBLICATION_NUMBER, StringType(), True),
            StructField(INPADOC_FAMILY_ID, StringType(), True),
            StructField(INPADOC_FAMILY_EXTENSIONS, StringType(), True),
            StructField(SINGLE_FAMILY_EXTENSIONS, StringType(), True),
            StructField(PATENT_POOLED, StringType(), True),
            StructField(STANDARD_MATCH_ID, StringType(), True),
            StructField(LICENSING_TERMS, StringType(), True),
            StructField(SPECIFIC_LICENSING_CONDITIONS, StringType(), True),
            StructField(RECIPROCITY_STATEMENT, StringType(), True),
            StructField(LICENSING_COMMENT, StringType(), True),
            StructField(DECLARANT_AFFILIATES_GRANT_LICENSES, StringType(), True),
            StructField(CONTACT_PERSON_FOR_LICENSE, StringType(), True),
            StructField(CONTACT_PERSON_POSITION, StringType(), True),
            StructField(CONTACT_ADDRESS_FOR_LICENSE, StringType(), True),
            StructField(CONTACT_PHONE_NUMBER_FOR_LICENSE, StringType(), True),
            StructField(CONTACT_EMAIL_FOR_LICENSE, StringType(), True),
            StructField(ISLD, StringType(), True),
            StructField(DISCLOSURE_NUMBER, StringType(), True),
            StructField(APPLICATION_AS_TO_DECLARATION_OTHER, StringType(), True),
            StructField(PUBLICATION_AS_TO_DECLARATION_OTHER, StringType(), True),
            StructField(SECTION, StringType(), True),
            StructField(ESSENTIAL_CLAIMS, StringType(), True),
            StructField(COUNTRY_OF_REGISTRATION, StringType(), True),
            StructField(PATENT_PROPRIETORS, StringType(), True),
            StructField(PROPRIETORS_OTHER_MEMBERS, StringType(), True),
            StructField(PATENT_TITLE, StringType(), True),
            StructField(DECLARANT_IS_PROPRIETOR, StringType(), True),
        ]
    )

    PATH = table_config.LANDING_CSV_LOCATION_DECLARATIONS_POOLED_RAW
