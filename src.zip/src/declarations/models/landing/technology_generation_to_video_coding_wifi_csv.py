from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config.table_config import (
    LANDING_CSV_TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI,
)


class TechnologyGenerationToVideoCodingWifiCsv:
    TECHNOLOGY_GENERATION = "technology_generation"
    STANDARD_DOCUMENT_IDS = "standard_document_ids"

    SCHEMA = StructType(
        [StructField(TECHNOLOGY_GENERATION, StringType(), True), StructField(STANDARD_DOCUMENT_IDS, StringType(), True)]
    )

    PATH = LANDING_CSV_TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI
