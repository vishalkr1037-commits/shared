from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

INDUSTRY_CLASS = " industry_class"
FIELD_ENGLISH = "field_english"
FIELD_NUMBER = "field_number"
SECTOR_ENGLISH = "sector_english"

SCHEMA = StructType(
    [
        StructField(INDUSTRY_CLASS, StringType(), True),
        StructField(FIELD_ENGLISH, StringType(), True),
        StructField(FIELD_NUMBER, StringType(), True),
        StructField(SECTOR_ENGLISH, StringType(), True),
    ]
)

PATH = table_config.LANDING_CSV_INDUSTRY_CLASS_SECTOR
