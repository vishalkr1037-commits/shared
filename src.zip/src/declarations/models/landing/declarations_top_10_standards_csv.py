from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

TECHNOLOGY_GENERATION = "technology_generation"
GROUP = "group"
STANDARD_DOCUMENT_ID = "standard_document_id"

SCHEMA = StructType(
    [
        StructField(TECHNOLOGY_GENERATION, StringType(), True),
        StructField(GROUP, StringType(), True),
        StructField(STANDARD_DOCUMENT_ID, StringType(), True),
    ]
)

PATH = table_config.DECLARATIONS_TOP_10_STANDARDS_CSV
