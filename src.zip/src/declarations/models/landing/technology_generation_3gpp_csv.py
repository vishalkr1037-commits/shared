from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config.table_config import (
    LANDING_CSV_TECHNOLOGY_GENERATION_3GPP,
)


class TechnologyGeneration3GPPCsv:
    ID = "id"
    SPECNO = "Spec No"
    TYPE = "Type"
    TITLE = "Title"
    STATUS = "Status"
    PRIMARY_RESP_GRP = "Primary Resp Grp"
    AUTHOR = "Author"
    INITIAL_PLANNED_RELEASE = "Initial Planned Release"
    PUBLICATION = "Publication"
    COMMON_IMS = "Common IMS"
    TECHNOLOGY_GENERATION = "Technology Generation"

    SCHEMA = StructType(
        [
            StructField(ID, StringType(), True),
            StructField(SPECNO, StringType(), True),
            StructField(TYPE, StringType(), True),
            StructField(TITLE, StringType(), True),
            StructField(STATUS, StringType(), True),
            StructField(PRIMARY_RESP_GRP, StringType(), True),
            StructField(AUTHOR, StringType(), True),
            StructField(INITIAL_PLANNED_RELEASE, StringType(), True),
            StructField(PUBLICATION, StringType(), True),
            StructField(COMMON_IMS, StringType(), True),
            StructField(TECHNOLOGY_GENERATION, StringType(), True),
        ]
    )

    PATH = LANDING_CSV_TECHNOLOGY_GENERATION_3GPP
