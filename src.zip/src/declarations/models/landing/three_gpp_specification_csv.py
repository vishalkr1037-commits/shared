from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config.table_config import (
    LANDING_CSV_THREE_GPP_SPECIFICATION_PATH,
)

STANDARD_DOC_ID = "Standard Doc Id"
RELEASE = "Release"
TECHNOLOGY = "Technology"
TITLE = "Title"
GROUP = "Group"
FOR_PUBLICATION = "For Publication"
FREEZE_DATE = "Freeze Date"
FROZEN = "Frozen"
CSV_FILE_NAME = "csv_file_name"

SCHEMA = StructType(
    [
        StructField(STANDARD_DOC_ID, StringType(), True),
        StructField(RELEASE, StringType(), True),
        StructField(TECHNOLOGY, StringType(), True),
        StructField(TITLE, StringType(), True),
        StructField(GROUP, StringType(), True),
        StructField(FOR_PUBLICATION, StringType(), True),
        StructField(FREEZE_DATE, StringType(), True),
        StructField(FROZEN, StringType(), True),
    ]
)

PATH = LANDING_CSV_THREE_GPP_SPECIFICATION_PATH
