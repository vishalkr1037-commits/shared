from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config


class DeclaringCompanyLookupCsv:
    ORIGINAL_NAME = "original_name"
    HARMONIZED_NAME = "harmonized_name"

    SCHEMA = StructType(
        [StructField(ORIGINAL_NAME, StringType(), True), StructField(HARMONIZED_NAME, StringType(), True)]
    )

    PATH = table_config.LANDING_CSV_LOCATION_DECLARING_COMPANY_LOOKUP
