from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config.table_config import (
    LANDING_CSV_MANUAL_MATCHING,
)

WORKING_NUMBER = "working_number"
PUBLICATION_NUMBER = "publication_number"
SOURCE = "source"

SCHEMA = StructType(
    [
        StructField(WORKING_NUMBER, StringType(), True),
        StructField(PUBLICATION_NUMBER, StringType(), True),
        StructField(SOURCE, StringType(), True),
    ]
)

PATH = LANDING_CSV_MANUAL_MATCHING
