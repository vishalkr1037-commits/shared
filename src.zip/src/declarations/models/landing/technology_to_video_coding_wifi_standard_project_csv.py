from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config


class TechnologyToVideoCodingWifiStandardProjectCsv:
    TECHNOLOGY_GENERATION = "technology_generation"
    STANDARD_PROJECTS = "standard_projects"

    SCHEMA = StructType(
        [StructField(TECHNOLOGY_GENERATION, StringType(), True), StructField(STANDARD_PROJECTS, StringType(), True)]
    )

    PATH = table_config.LANDING_CSV_TECHNOLOGY_TO_VIDEO_CODING_WIFI_STANDARD_PROJECT
