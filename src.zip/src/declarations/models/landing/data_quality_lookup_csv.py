from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config

RULE_ID = "rule_id"
RULE_DESC = "rule_desc"
DIMENSION = "dimension"
SOURCE_NAME = "source_name"
COLUMN_NAME = "column_name"
RULE_CATEGORY = "rule_category"


SCHEMA = StructType(
    [
        StructField(RULE_ID, StringType(), True),
        StructField(RULE_DESC, StringType(), True),
        StructField(DIMENSION, StringType(), True),
        StructField(SOURCE_NAME, StringType(), True),
        StructField(COLUMN_NAME, StringType(), True),
        StructField(RULE_CATEGORY, StringType(), True),
    ]
)

PATH = table_config.LANDING_DATA_QUALITY_LOOKUP
