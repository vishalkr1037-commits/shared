from pyspark.sql.types import StringType, StructField, StructType

from src.declarations.common.declarations_table_config import table_config


class DeclarationsBlackListedCsv:
    BLACKLISTED_WORKING_NUMBER = "blacklisted_working_number"
    BLACKLISTED_PUBLICATION_NUMBER = "blacklisted_publication_number"

    SCHEMA = StructType(
        [
            StructField(BLACKLISTED_WORKING_NUMBER, StringType(), True),
            StructField(BLACKLISTED_PUBLICATION_NUMBER, StringType(), True),
        ]
    )

    PATH = table_config.LANDING_CSV_BLACKLISTED
