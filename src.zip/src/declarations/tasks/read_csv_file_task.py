from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from pyspark.sql.types import StructType


class CSVReaderTask:
    def __init__(
        self, spark: SparkSession, schema: StructType, file_path: list, file_name: bool = False, delimiter: str = ","
    ):
        """
        Initializes the CSVReader with Spark session, schema, and CSV file path.

        :param spark: SparkSession instance
        :param schema: Schema for the CSV file as a StructType
        :param file_path: Path to the CSV file
        """
        self.spark = spark
        self.schema = schema
        self.file_path = file_path
        self.file_name = file_name
        self.delimiter = delimiter

    def load_csv(self):
        """
        Reads the CSV file and loads it into a Spark DataFrame based on the provided schema.

        :return: DataFrame containing the CSV data
        """
        return (
            self.spark.read.format("csv")
            .option("header", True)
            .option("escape", '"')
            .option("quote", '"')
            .option("wholeFile", True)
            .option("multiline", True)
            .option("recursiveFileLookup", True)
            .option("delimiter", self.delimiter)
            .schema(self.schema)
            .load(self.file_path)
        )

    def run(self):
        if self.file_name:
            df = self.load_csv().na.fill("").withColumn("csv_file_name", col("_metadata.file_path"))
        else:
            df = self.load_csv().na.fill("")
        return df
