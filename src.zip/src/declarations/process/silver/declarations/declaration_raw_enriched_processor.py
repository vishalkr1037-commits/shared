from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import CreateOrUpdateDeltaTableTask

import src.declarations.mappers.bronze.declarations.declarations_technology_generation_3gpp_mapper as declarations_technology_generation_3gpp_mapper
import src.declarations.mappers.bronze.declarations.declarations_technology_generation_3gpp_specifications_set_mapper as declarations_technology_generation_3gpp_specifications_set_mapper
import src.declarations.mappers.bronze.declarations.declarations_videocoding_wifi_standard_doc_id_mapper as declarations_videocoding_wifi_standard_doc_id_mapper
import src.declarations.mappers.bronze.declarations.declarations_videocoding_wifi_standard_project_mapper as declarations_videocoding_wifi_standard_project_mapper
import src.declarations.mappers.silver.declarations.declaration_clean_standard_document_id_mapper as declaration_clean_standard_document_id_mapper
import src.declarations.mappers.silver.declarations.declaration_etsi_bare_number_enrichment_mapper as declarations_etsi_bare_number_enrichment_mapper
import src.declarations.mappers.silver.declarations.declaration_etsi_bare_number_exploded_mapper as declaration_etsi_bare_number_exploded_mapper
import src.declarations.mappers.silver.declarations.declaration_raw_enrichment_mapper as declaration_raw_enrichment_mapper
import src.declarations.mappers.silver.declarations.declaration_technology_enrichment_mapper as declaration_technology_enrichment_mapper
import src.declarations.mappers.silver.declarations.declaration_via_la_enrichment_mapper as declaration_via_la_enrichment_mapper
import src.declarations.models.bronze.declarations.technology_generation_3gpp as TechnologyGeneration3gpp
import src.declarations.models.bronze.declarations.technology_generation_classification as TechnologyGenerationClassification
import src.declarations.models.bronze.declarations.technology_generation_to_video_coding_wifi as TechnologyGenerationToVideoCodingWifi
import src.declarations.models.bronze.declarations.technology_to_video_coding_wifi_standard_project as TechnologyToVideoCodingWifiStandardProject
import src.declarations.models.bronze.declarations.three_gpp_specification as ThreeGppSpecificationSet
import src.declarations.models.bronze.declarations.via_la_claims_and_sections as ViaLaClaimsAndSections
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw


def process(
    spark: SparkSession,
    catalog_name: str,
    bronze_db_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):
    # Declaration Raw Read
    declaration_raw_df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=bronze_db_name, table=DeclarationRaw.PATH
        ),
        streaming=False,
    ).run()

    # Technology Generation + Classification + Via La Claims and Sections Data Reads
    technology_generation_3gpp_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=bronze_db_name, table=TechnologyGeneration3gpp.PATH
            ),
            streaming=False,
        )
        .run()
        .select(col(TechnologyGeneration3gpp.ID), col(TechnologyGeneration3gpp.TECHNOLOGY_GENERATION))
        .transform(declarations_technology_generation_3gpp_mapper.apply)
    )

    technology_generation_3gpp_specifications_set_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=bronze_db_name, table=ThreeGppSpecificationSet.PATH
            ),
            streaming=False,
        )
        .run()
        .transform(declarations_technology_generation_3gpp_specifications_set_mapper.apply)
    )

    technology_classification_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=bronze_db_name, table=TechnologyGenerationClassification.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            col(TechnologyGenerationClassification.STANDARD_DOC_ID),
            col(TechnologyGenerationClassification.TECHNOLOGY_CLASSIFICATION),
        )
        .withColumnRenamed(TechnologyGenerationClassification.STANDARD_DOC_ID, "prefix_clean_standard_doc_id")
    )

    via_la_claims_and_sections_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=bronze_db_name, table=ViaLaClaimsAndSections.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            col(ViaLaClaimsAndSections.STANDARD_PROJECT),
            col(ViaLaClaimsAndSections.PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE),
            col(ViaLaClaimsAndSections.ESSENTIAL_CLAIMS),
            col(ViaLaClaimsAndSections.SECTION),
        )
        .withColumnRenamed(
            ViaLaClaimsAndSections.PATENT_NUMBER_WITH_ORIGINAL_COUNTRY_CODE,
            DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION,
        )
    )

    video_coding_wifi_technology_generation_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=bronze_db_name, table=TechnologyGenerationToVideoCodingWifi.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            col(TechnologyGenerationToVideoCodingWifi.STANDARD_DOCUMENT_IDS),
            col(TechnologyGenerationToVideoCodingWifi.TECHNOLOGY_GENERATION),
        )
        .transform(declarations_videocoding_wifi_standard_doc_id_mapper.apply)
    )

    video_coding_wifi_technology_generation_standard_project_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=bronze_db_name, table=TechnologyToVideoCodingWifiStandardProject.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            col(TechnologyToVideoCodingWifiStandardProject.TECHNOLOGY_GENERATION),
            col(TechnologyToVideoCodingWifiStandardProject.STANDARD_PROJECTS),
        )
        .transform(declarations_videocoding_wifi_standard_project_mapper.apply)
    )

    # Technology Generation 3GPP Enrichment + Join
    declaration_raw_df = declaration_clean_standard_document_id_mapper.apply(declaration_raw_df)
    declaration_silver_df = declaration_raw_df.join(
        technology_generation_3gpp_df, DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID, "left"
    )
    declaration_silver_df = declaration_silver_df.join(
        technology_generation_3gpp_specifications_set_df, DeclarationRawEnriched.CLEAN_STANDARD_DOC_ID, "left"
    )
    # Via La Claims and Sections Join + Mapping
    declaration_silver_df = declaration_silver_df.join(
        via_la_claims_and_sections_df,
        _get_multi_join_sequentials(
            DeclarationRawEnriched.STANDARD_PROJECT, DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION
        ),
        "left",
    )
    declaration_silver_df = declaration_via_la_enrichment_mapper.apply(declaration_silver_df)

    # Technology Classification Join + Technology Generation VVC Mapping + Communications Technology Mapping
    declaration_silver_df = declaration_silver_df.join(
        technology_classification_df, "prefix_clean_standard_doc_id", "left"
    )
    declaration_silver_df = declaration_technology_enrichment_mapper.apply(declaration_silver_df)

    # Wifi Technology Joins + Mapping
    declaration_silver_df = declaration_silver_df.join(
        video_coding_wifi_technology_generation_df, DeclarationRawEnriched.STANDARD_DOCUMENT_ID, "left"
    )

    declaration_silver_df = declaration_silver_df.join(
        video_coding_wifi_technology_generation_standard_project_df, DeclarationRawEnriched.STANDARD_PROJECT, "left"
    )

    declaration_silver_final_df = declaration_raw_enrichment_mapper.apply(declaration_silver_df)

    # Bare Number Enrichment + Join
    declaration_etsi_bare_number_enrichment_df = declarations_etsi_bare_number_enrichment_mapper.apply(
        declaration_silver_final_df
    )
    declaration_etsi_bare_number_df = declaration_etsi_bare_number_exploded_mapper.apply(
        declaration_etsi_bare_number_enrichment_df
    )
    declaration_silver_final_df = (
        declaration_silver_final_df.drop(DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER)
        .drop(DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER)
        .drop(DeclarationRaw.COUNTRY_OF_REGISTRATION_OTHER)
    )
    declaration_silver_final_df = declaration_silver_final_df.join(
        declaration_etsi_bare_number_df, DeclarationRaw.ID, "left"
    ).dropDuplicates([DeclarationRaw.ID])

    declaration_silver_final_df = declaration_silver_final_df.na.fill("")

    # Add a hash column for each column's content

    # Check for duplicate column names
    column_names = declaration_silver_final_df.columns
    duplicates = {}

    for i, name in enumerate(column_names):
        if column_names.count(name) > 1:
            if name not in duplicates:
                duplicates[name] = 0
            duplicates[name] += 1
            # Rename duplicate columns with a suffix
            new_name = f"{name}_duplicate_{duplicates[name]}"
            declaration_silver_final_df = declaration_silver_final_df.withColumnRenamed(name, new_name)

    # Now you can selectively drop the duplicate columns
    # For example, if you want to keep the original 'title' and 'technology_classification'
    if "title_duplicate_1" in declaration_silver_final_df.columns:
        declaration_silver_final_df = declaration_silver_final_df.drop("title_duplicate_1")

    if "technology_classification_duplicate_1" in declaration_silver_final_df.columns:
        declaration_silver_final_df = declaration_silver_final_df.drop("technology_classification_duplicate_1")

    declaration_silver_final_df = declaration_silver_final_df.withColumnRenamed(
        "reciprocity_statement", "recipocity_statement"
    )

    declaration_silver_final_df.printSchema()
    # Write to Silver with the cleaned dataframe
    CreateOrUpdateDeltaTableTask(
        spark=spark,
        target_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table=DeclarationRawEnriched.PATH
        ),
        config=config,
        merge_column_name=DeclarationRawEnriched.ID,
        partition_col_names=[DeclarationRawEnriched.ID_FIRST_CHAR],
        partition_restriction_values=[],
    ).run(declaration_silver_final_df)


def _get_multi_join_sequentials(*fields):
    return list(fields)
