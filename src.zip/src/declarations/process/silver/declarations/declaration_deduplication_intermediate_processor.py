from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import (
    array_contains,
    col,
    concat_ws,
    lit,
    regexp_replace,
    substring,
    trim,
    udf,
    when,
)
from pyspark.sql.types import StringType
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.bronze.declarations.industry_class_sector as IndustryClassSector
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched
from src.declarations.mappers.silver.declarations.declaration_deduplication_mapper import (
    apply as deduplication_mapper,
)
from src.declarations.mappers.silver.declarations.declaration_duplication_joining_mapper import (
    apply as duplication_joining_mapper,
)
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.silver.declarations import (
    declaration_deduplicated_intermediate as DeclarationDeduplicatedIntermediate,
)
from src.declarations.models.silver.declarations import (
    declaration_patent_number_matching_candidates as PatentNumberMatchingCandidates,
)
from src.declarations.models.silver.declarations import (
    declaration_raw_aggregated as DeclarationRawAggregated,
)

BLACKLISTED_INDUSTRY_SECTORS = ["Chemistry", "Mechanical engineering", "Other fields", ""]


def get_industry_sector_field_delta_table(spark: SparkSession, catalog_name: str, source_db_name: str) -> dict:
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=IndustryClassSector.PATH
        ),
        streaming=False,
    ).run()
    return {row["industry_class"].strip().upper(): row["sector_english"] for row in df.collect()}


def extract_codes(cpc_current, ipc_current):
    """Extract and clean CPC and IPC codes into a flat list."""
    codes = []
    for field in [cpc_current, ipc_current]:
        if field:
            codes.extend(code.strip().upper() for code in field.split("|") if code.strip())
    return codes


def get_sector_from_prefix(prefix, sector_map):
    """Return (sector, blacklisted_sector) tuple for a given prefix."""
    sector = sector_map.get(prefix)
    if not sector:
        return None, None
    if sector in BLACKLISTED_INDUSTRY_SECTORS:
        return None, sector
    return sector, None


def select_sector_from_codes(codes, sector_map):
    """Select valid sector or blacklisted sector from codes."""
    blacklisted = ""
    for code in codes:
        if len(code) < 4:
            continue
        prefix = code[:4].strip().upper()
        sector, blacklisted_sector = get_sector_from_prefix(prefix, sector_map)
        if sector:
            return sector
        if blacklisted_sector:
            blacklisted = blacklisted_sector
    return blacklisted or ""


def make_get_industry_sector_udf(spark, industry_sector_map):
    """Return a Spark UDF that determines the industry sector."""
    broadcast_map = spark.sparkContext.broadcast(industry_sector_map)

    def get_industry_sector(cpc_current, ipc_current):
        codes = extract_codes(cpc_current, ipc_current)
        return select_sector_from_codes(codes, broadcast_map.value)

    return udf(get_industry_sector, StringType())


def get_declaration_raw(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    declaration_raw_df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=DeclarationRawEnriched.PATH
        ),
        streaming=False,
    ).run()

    return declaration_raw_df.select(
        DeclarationRaw.ID,
        DeclarationRaw.SSO,
        DeclarationRaw.DATA_PROVIDER,
        DeclarationRaw.STANDARD_PROJECT,
        DeclarationRaw.STANDARD_DOCUMENT_ID,
        DeclarationRaw.DECLARING_COMPANY,
        DeclarationRaw.APPLICATION_AS_TO_DECLARATION,
        DeclarationRaw.PUBLICATION_AS_TO_DECLARATION,
        DeclarationRaw.DECLARATION_DATE,
        DeclarationRaw.PATENT_POOL_NAME,
        DeclarationRaw.STANDARD_MATCH_ID,
        DeclarationRaw.LICENSING_TERMS,
        DeclarationRaw.SPECIFIC_LICENSING_CONDITIONS,
        DeclarationDeduplicatedIntermediate.RECIPOCITY_STATEMENT,
        DeclarationRaw.LICENSING_COMMENT,
        DeclarationRaw.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES,
        DeclarationRaw.CONTACT_PERSON_FOR_LICENSE,
        DeclarationRaw.CONTACT_PERSON_POSITION,
        DeclarationRaw.CONTACT_ADDRESS_FOR_LICENSE,
        DeclarationRaw.CONTACT_PHONE_FOR_LICENSE,
        DeclarationRaw.CONTACT_EMAIL_FOR_LICENSE,
        DeclarationRawAggregated.ISLD_AGGREGATED,
        DeclarationRawAggregated.DISCLOSURE_NUMBER_AGGREGATED,
        DeclarationRaw.SECTION,
        DeclarationRaw.ESSENTIAL_CLAIM_NUMBER,
        DeclarationRaw.APPLICATION_AS_TO_DECLARATION_OTHER,
        DeclarationRaw.PUBLICATION_AS_TO_DECLARATION_OTHER,
        DeclarationDeduplicatedIntermediate.TECHNOLOGY_GENERATION_ARRAY,
        DeclarationDeduplicatedIntermediate.GROUP_ARRAY,
        col("title"),
        DeclarationRaw.TYPE,
        DeclarationRaw.POOL_PROVIDER,
        DeclarationDeduplicatedIntermediate.TECHNOLOGY_CLASSIFICATION,
        DeclarationRaw.POOL_NAME_HARMONIZED,
        DeclarationRaw.STANDARD_DOCUMENT_TITLE,
    )


def get_declaration_patent_number_matched(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    fq_table_name = fully_qualified_table_name(
        catalog=catalog_name, database=source_db_name, table=PatentNumberMatchingCandidates.PATH
    )
    df = ReadDeltaTableTask(spark=spark, fq_source_table=fq_table_name, streaming=False).run()

    return df.select(
        PatentNumberMatchingCandidates.DECLARATION_ID,
        PatentNumberMatchingCandidates.SELECTED_PUBLICATION_NUMBER,
        PatentNumberMatchingCandidates.MATCHED,
        PatentNumberMatchingCandidates.APPLIED_RULES,
        PatentNumberMatchingCandidates.ID_FIRST_CHAR,
        PatentNumberMatchingCandidates.SOURCE,
        PatentNumberMatchingCandidates.WORKING_NUMBER,
    )


def get_boolean_value_for_applied_rules(rules):
    # Handle NULL values first, then check for perfect_match
    return (
        when(col("applied_rules").isNull(), lit(False))
        .when(array_contains(rules, "[perfect_match]"), True)  # Check for exact string match
        .otherwise(False)
    )


def get_patent_index(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    fq_table_name = fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table="patents_index")
    patent_df = ReadDeltaTableTask(spark=spark, fq_source_table=fq_table_name, streaming=False).run()

    return patent_df.select(
        DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER,
        DeclarationDeduplicatedIntermediate.PUBLICATION_ID,
        DeclarationDeduplicatedIntermediate.CPC_CURRENT,
        DeclarationDeduplicatedIntermediate.IPC_CURRENT,
        DeclarationDeduplicatedIntermediate.INPADOC_FAMILY_ID,
        DeclarationDeduplicatedIntermediate.PUBLICATION_MONTH,
        DeclarationDeduplicatedIntermediate.APPLICATION_NUMBER,
    )


def transform(spark: SparkSession, catalog_name: str, silver_db_name: str) -> DataFrame:
    industry_sector_map = get_industry_sector_field_delta_table(spark, catalog_name, silver_db_name)
    get_industry_sector_udf = make_get_industry_sector_udf(spark, industry_sector_map)

    aggregated_patent_number_matched_data_df = get_declaration_patent_number_matched(
        spark, catalog_name, silver_db_name
    )
    aggregated_patent_number_matched_data = aggregated_patent_number_matched_data_df.transform(deduplication_mapper)

    declaration_raw_df = get_declaration_raw(spark, catalog_name, silver_db_name)
    declaration_raw_and_patent_number_matched_data = (
        declaration_raw_df.withColumn(DeclarationDeduplicatedIntermediate.DECLARATION_ID, col(DeclarationRaw.ID))
        .join(aggregated_patent_number_matched_data, [DeclarationDeduplicatedIntermediate.DECLARATION_ID], "left")
        .transform(duplication_joining_mapper)
        .withColumns(
            {
                DeclarationDeduplicatedIntermediate.ID_FIRST_CHAR: substring(col("declaration_id"), 1, 1),
                DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER: col(
                    DeclarationDeduplicatedIntermediate.SELECTED_PUBLICATION_NUMBER
                ),
                DeclarationDeduplicatedIntermediate.APPLIED_RULES: get_boolean_value_for_applied_rules(
                    col(DeclarationDeduplicatedIntermediate.APPLIED_RULES)
                ),
                DeclarationDeduplicatedIntermediate.MATCHED: col(DeclarationDeduplicatedIntermediate.MATCHED),
                DeclarationDeduplicatedIntermediate.WORKING_NUMBER: col(
                    DeclarationDeduplicatedIntermediate.WORKING_NUMBER
                ),
            }
        )
        .drop(PatentNumberMatchingCandidates.DECLARATION_ID)
        .repartition(col(DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER))
    )

    # Remove brackets from publication_number string for join
    declaration_raw_and_patent_number_matched_data = declaration_raw_and_patent_number_matched_data.withColumn(
        DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER,
        trim(regexp_replace(col(DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER), r"^\[|\]$", "")),
    )

    patent_index_joined_with_main_table = declaration_raw_and_patent_number_matched_data.join(
        get_patent_index(spark, catalog_name, silver_db_name),
        [DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER],
        "left",
    ).withColumns(
        {
            DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR: get_industry_sector_udf(
                col(DeclarationDeduplicatedIntermediate.CPC_CURRENT),
                col(DeclarationDeduplicatedIntermediate.IPC_CURRENT),
            ),
            DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_CPC: get_industry_sector_udf(
                col(DeclarationDeduplicatedIntermediate.CPC_CURRENT), lit("")
            ),
            DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_IPC: get_industry_sector_udf(
                lit(""), col(DeclarationDeduplicatedIntermediate.IPC_CURRENT)
            ),
            DeclarationDeduplicatedIntermediate.CONCATENATED_INDUSTRY_SECTOR: concat_ws(
                "|",
                col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_CPC),
                col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_IPC),
            ),
            DeclarationDeduplicatedIntermediate.INPADOC_FAMILY_ID: col(
                DeclarationDeduplicatedIntermediate.INPADOC_FAMILY_ID
            ),
        }
    )

    return patent_index_joined_with_main_table


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):
    transformed_data = transform(spark, catalog_name, silver_db_name)
    target_table = fully_qualified_table_name(
        catalog=catalog_name,
        database=silver_db_name,
        table=DeclarationDeduplicatedIntermediate.DEDUPLICATED_INTERMEDIATE_PATH,
    )
    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(transformed_data)
