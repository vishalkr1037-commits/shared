from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

from src.declarations.mappers.silver.declarations.declaration_priority_date_filtered_mapper import (
    apply_mapper,
    initialize_whitelisted_pub_nums_broadcast,
)
from src.declarations.models.bronze.patents import patent_family as PatentFamily
from src.declarations.models.silver.declarations import (
    declaration_industry_class_filtered as IndustryClassFiltered,
)
from src.declarations.models.silver.declarations import (
    declaration_priority_date_filtered as PriorityDateFiltered,
)


def get_declaration_industry_class_filtered(spark: SparkSession, catalog_name: str, silver_db_name: str) -> DataFrame:
    """
    Read the Delta table and filter rows where is_ipc_cpc_valid is True.
    """
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table=IndustryClassFiltered.PATH
        ),
        streaming=False,
    ).run()

    return df.filter(col(PriorityDateFiltered.IS_IPC_CPC_VALID) == True)


def get_declaration_publication_ids(declaration_industry_class_filtered: DataFrame) -> list:
    """
    Read the Delta table, filter rows, and collect distinct publication IDs.
    """
    publication_ids = (
        declaration_industry_class_filtered.select(PriorityDateFiltered.PUBLICATION_ID).na.drop().distinct().collect()
    )
    return [row[0] for row in publication_ids]


def get_patent_priority_dates(
    spark: SparkSession, catalog_name: str, silver_db_name: str, publication_ids: list
) -> DataFrame:
    """
    Read the Delta table and filter rows based on publication IDs.
    """
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table=PatentFamily.PATH
        ),
        streaming=False,
    ).run()

    return (
        df.filter(col(PriorityDateFiltered.PUBLICATION_ID).isin(publication_ids))
        .select(PriorityDateFiltered.PUBLICATION_ID, PriorityDateFiltered.EARLIEST_PRIORITY_DATE)
        .dropDuplicates()
    )


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
) -> None:
    """
    Perform the transformation logic for the declaration priority date filtered process.
    """
    declaration_industry_class_filtered = get_declaration_industry_class_filtered(spark, catalog_name, silver_db_name)

    publication_ids = get_declaration_publication_ids(declaration_industry_class_filtered)

    # Perform the transformation
    patent_priority_dates = get_patent_priority_dates(spark, catalog_name, silver_db_name, publication_ids)

    # Join and apply the mapper
    transformed_df = declaration_industry_class_filtered.join(
        patent_priority_dates, [PriorityDateFiltered.PUBLICATION_ID], "left"
    )
    whitelisted_pub_nums_broadcast = initialize_whitelisted_pub_nums_broadcast(spark)
    transformed_df = apply_mapper(transformed_df, whitelisted_pub_nums_broadcast)
    transformed_df = transformed_df.drop("_commit_version")

    # Write the transformed data to the target Delta table
    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=silver_db_name, table=PriorityDateFiltered.PATH
    )

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(transformed_df)
