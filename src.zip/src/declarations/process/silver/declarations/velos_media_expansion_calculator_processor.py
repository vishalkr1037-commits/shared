from pyspark.sql import SparkSession
from pyspark.sql.functions import expr
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.silver.declarations.velos_media_expansion_calculator as VelosMediaCalculator


def get_patent_assignee_applicant_data(spark, catalog_name, silver_db_name):
    # Read patent transferred flag current assignee table
    patent_assignee_df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table="patent_assignees"
        ),
        streaming=False,
    ).run()

    # Filter for patents with "velos media" in harmonized assignee names
    velos_media_patents = patent_assignee_df.filter(
        expr(f"exists({VelosMediaCalculator.ASSIGNEE_HARMONIZED_NAME_ARRAY}, x -> lower(x) like '%velos media%')")
    ).select(VelosMediaCalculator.PUBLICATION_ID)

    return velos_media_patents


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):
    # Declaration Raw Read
    target_df = get_patent_assignee_applicant_data(
        spark=spark, catalog_name=catalog_name, silver_db_name=silver_db_name
    )

    target_table = fully_qualified_table_name(
        catalog=catalog_name,
        database=silver_db_name,
        table=VelosMediaCalculator.PATH,
    )

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(target_df)
