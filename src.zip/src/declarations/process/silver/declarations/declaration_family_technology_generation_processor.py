from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.silver.declarations.declarations_family_technology_generation as DeclarationsFamilyTechnologyGeneration
from src.declarations.mappers.silver.declarations.declaration_family_technology_generation_mapper import (
    apply,
)
from src.declarations.models.bronze.patents import patents_index as PatentIndex
from src.declarations.models.silver.declarations import (
    declaration_company_filtered as DeclarationCompanyFiltered,
)


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):
    # Read the bronze table
    declaration_df: DataFrame = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=DeclarationCompanyFiltered.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(col(DeclarationsFamilyTechnologyGeneration.IS_COMPANY_VALID) == True)
    ).select(
        DeclarationsFamilyTechnologyGeneration.ID,
        DeclarationsFamilyTechnologyGeneration.PUBLICATION_ID,
        DeclarationsFamilyTechnologyGeneration.TECHNOLOGY_GENERATION_ARRAY,
    )

    list_all_publications_ids = get_all_publication(declaration_df)

    all_involved_family_members_df = get_all_family_members(
        spark, catalog_name, silver_db_name, list_all_publications_ids
    )

    result_df = apply(declaration_df, all_involved_family_members_df)
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=silver_db_name,
            table=DeclarationsFamilyTechnologyGeneration.PATH,
        ),
        config=config,
        mode="overwrite",
    ).run(result_df)


def get_all_publication(declaration_df: DataFrame) -> list:
    rows = declaration_df.select(DeclarationsFamilyTechnologyGeneration.PUBLICATION_ID).distinct().na.drop().collect()
    return [row.publication_id for row in rows]


def get_all_family_members(
    spark: SparkSession, catalog_name: str, silver_db_name: str, list_all_publications_ids: list
) -> DataFrame:
    patent_index_df: DataFrame = (
        (
            ReadDeltaTableTask(
                spark=spark,
                fq_source_table=fully_qualified_table_name(
                    catalog=catalog_name,
                    database=silver_db_name,
                    table=PatentIndex.PATH,
                ),
                streaming=False,
            ).run()
        )
        .select(
            DeclarationsFamilyTechnologyGeneration.PUBLICATION_ID,
            DeclarationsFamilyTechnologyGeneration.INPADOC_FAMILY_ID,
        )
        .filter(col(DeclarationsFamilyTechnologyGeneration.PUBLICATION_ID).isin(list_all_publications_ids))
    )
    return patent_index_df
