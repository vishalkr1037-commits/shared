from pyspark.sql import SparkSession
from pyspark.sql.functions import col, split, when
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import CreateOrUpdateDeltaTableTask

from src.declarations.mappers.silver.declarations.raw_declaration_companies_harmonization_mapper import (
    RawDeclarationCompaniesHarmonizationMapper,
)
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.bronze.declarations.declaring_company_lookup import (
    DeclaringCompanyLookup,
)
from src.declarations.models.silver.declarations.raw_declaration_companies_harmonization import (
    RawDeclarationCompaniesHarmonizations,
)


class RawDeclarationCompaniesHarmonizationsProcessor:

    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        bronze_database: str,
        silver_database: str,
        config: PipelineConfig,
    ):
        self.spark = spark
        self.catalog_name = catalog_name
        self.bronze_database = bronze_database
        self.silver_database = silver_database
        self.config = config

        self.source_declaration_company_lookup_path = fully_qualified_table_name(
            catalog=self.catalog_name, database=self.bronze_database, table=DeclaringCompanyLookup.PATH
        )

        self.source_declaration_raw_path = fully_qualified_table_name(
            catalog=self.catalog_name, database=self.bronze_database, table=DeclarationRaw.PATH
        )

        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name, database=self.silver_database, table=RawDeclarationCompaniesHarmonizations.PATH
        )

    def process(self):

        company_lookup_df = (
            ReadDeltaTableTask(
                spark=self.spark,
                fq_source_table=self.source_declaration_company_lookup_path,
                streaming=False,
            )
            .run()
            .select(DeclaringCompanyLookup.DECLARING_COMPANY, DeclaringCompanyLookup.DECLARING_COMPANY_HARMONIZED)
        )

        declaration_raw_df = (
            ReadDeltaTableTask(spark=self.spark, fq_source_table=self.source_declaration_raw_path, streaming=False)
            .run()
            .select(DeclarationRaw.ID, DeclarationRaw.DECLARING_COMPANY, DeclarationRaw.ID_FIRST_CHAR)
        )

        joined_df = declaration_raw_df.join(company_lookup_df, on=DeclaringCompanyLookup.DECLARING_COMPANY, how="left")

        final_df = RawDeclarationCompaniesHarmonizationMapper.apply(joined_df)
        final_df = final_df.withColumn(
            "harmonized_name",
            when(col("harmonized_name").isNull() | (col("harmonized_name") == ""), col("original_name")).otherwise(
                col("harmonized_name")
            ),
        )
        final_df = final_df.withColumn(
            "harmonized_name", split(col("harmonized_name"), ",")  # Convert comma-separated string to array<string>
        ).withColumn(
            "original_name", split(col("original_name"), ",")  # Convert comma-separated string to array<string>
        )
        final_df = final_df.dropDuplicates(["declaration_id"])

        CreateOrUpdateDeltaTableTask(
            spark=self.spark,
            target_table=self.target_table,
            config=self.config,
            merge_column_name="declaration_id",
            partition_col_names=[DeclarationRaw.ID_FIRST_CHAR],
            partition_restriction_values=[],
        ).run(final_df)
