from pyspark.sql import DataFrame, SparkSession, Window
from pyspark.sql.functions import array_join, col
from pyspark.sql.functions import min as spark_min
from pyspark.sql.functions import substring, to_date
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.silver.declarations.all_declarations_most_meaningful_mapper as AllDeclarationsMostMeaningfulMapper
import src.declarations.mappers.silver.declarations.declarations_with_most_meaningful_standardInfo_mapper as DeclarationsWithMostMeaningFulStandardInfoMapper
import src.declarations.mappers.silver.declarations.etsi_standards_agg_mapper as EtsiStandardsAggMapper
import src.declarations.models.silver.declarations.declaration_most_meaningful_standard_info as DeclarationsMostMeaningfulStandardInfo
import src.declarations.models.silver.declarations.declarations as Declarations
import src.declarations.models.silver.standards.standard_description_url_csv as standard_description_url_csv
import src.declarations.models.silver.standards.standards as Standards
import src.declarations.utils.standard_docId_utility as standard_docId_utility
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


def get_original_standard_url(spark: SparkSession, catalog_name: str, db_name: str) -> DataFrame:
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=db_name, table="standards"),
        streaming=False,
    ).run()
    return (
        df.select(
            col(Standards.AC_CODE), col(Standards.DOCUMENT_URL), col(Standards.STANDARD_DOCUMENT_ID), col(Standards.ID)
        )
        .withColumnRenamed(Standards.ID, DeclarationsMostMeaningfulStandardInfo.STANDARD_ID)
        .withColumnRenamed(Standards.STANDARD_DOCUMENT_ID, "most_meaningful_standard_document_id")
    )


def get_enriched_document_url(spark: SparkSession, catalog_name: str, db_name: str) -> DataFrame:
    original = get_original_standard_url(spark, catalog_name, db_name)
    df = CSVReaderTask(spark, standard_description_url_csv.SCHEMA, [standard_description_url_csv.PATH]).run()
    csv = (
        df.drop(standard_description_url_csv.FILE_TEXT)
        .filter(
            col(standard_description_url_csv.AC_CODE).isNotNull()
            & col(standard_description_url_csv.FILE_URL).isNotNull()
        )
        .select(
            col(standard_description_url_csv.AC_CODE).alias("ac_code"),
            col(standard_description_url_csv.FILE_URL).alias("enriched_document_url"),
        )
    )

    return original.join(csv, on=[Standards.AC_CODE], how="left").select(
        col(Standards.DOCUMENT_URL),
        col("enriched_document_url"),
        col("most_meaningful_standard_document_id"),
        col(Standards.AC_CODE),
        col(DeclarationsMostMeaningfulStandardInfo.STANDARD_ID),
    )


def get_aggregated_etsi_standard(spark: SparkSession, catalog_name: str, db_name: str) -> DataFrame:
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=db_name, table="standards"),
        streaming=False,
    ).run()
    window = Window.partitionBy("standard_document_number")
    df = (
        df.filter(col("data_provider") == "ETSI")
        .select(col("standard_document_id"), col("publication_date"))
        .withColumn(
            "standard_document_number", standard_docId_utility.parse_standard_doc_id_udf(col("standard_document_id"))
        )
        .withColumnRenamed("standard_document_id", "standard_doc_id")
        .withColumn("min_publication_date", spark_min(to_date(col("publication_date"))).over(window))
        .filter(col("standard_document_number").isNotNull() & (col("standard_document_number") != ""))
    )
    return df


def get_declarations(spark: SparkSession, catalog_name: str, db_name: str) -> DataFrame:
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=db_name, table="declarations_company_filtered"
        ),
        streaming=False,
    ).run()
    df = (
        df.withColumn(
            "standard_document_number",
            standard_docId_utility.parse_standard_doc_id_udf(col(Declarations.STANDARD_DOCUMENT_ID)),
        )
        .withColumn("technology_generation", array_join(col("technology_generation_array"), ", "))
        .select(
            col("id_first_char"),
            col("id"),
            col("standard_document_id"),
            col("standard_document_number"),
            col("sso"),
            col("technology_generation"),
            col("declaration_date"),
        )
    )
    return df


def get_all_declarations(spark: SparkSession, catalog_name: str, db_name: str) -> DataFrame:
    declarations = get_declarations(spark, catalog_name, db_name)
    etsi = get_aggregated_etsi_standard(spark, catalog_name, db_name)
    df = declarations.join(etsi, on=["standard_document_number"], how="left").filter(
        (col(Declarations.DECLARATION_DATE).isNull())
        | (col(Declarations.DECLARATION_DATE) == "")
        | (to_date(col(Declarations.DECLARATION_DATE)) >= to_date(col(Standards.PUBLICATION_DATE)))
        | (to_date(col(Standards.PUBLICATION_DATE)) == to_date(col("min_publication_date")))
    )

    df = EtsiStandardsAggMapper.apply(df)
    df = AllDeclarationsMostMeaningfulMapper.apply(df).select(
        col("most_meaningful_standard_document_id"), col("id"), col("sso")
    )
    return df


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
) -> DataFrame:
    all_decls = get_all_declarations(spark, catalog_name, silver_db_name)
    enriched = get_enriched_document_url(spark, catalog_name, silver_db_name)
    df = all_decls.join(enriched, on=["most_meaningful_standard_document_id"], how="left")
    df = (
        DeclarationsWithMostMeaningFulStandardInfoMapper.apply(df)
        .withColumn(
            DeclarationsMostMeaningfulStandardInfo.ID_FIRST_CHAR,
            substring(col(DeclarationsMostMeaningfulStandardInfo.DECLARATION_ID), 1, 1),
        )
        .dropDuplicates([DeclarationsMostMeaningfulStandardInfo.DECLARATION_ID])
        .select(
            col(DeclarationsMostMeaningfulStandardInfo.DECLARATION_ID),
            col(DeclarationsMostMeaningfulStandardInfo.ID_FIRST_CHAR),
            col("document_url").alias(DeclarationsMostMeaningfulStandardInfo.ORIGINAL_STANDARD_DOCUMENT_URL),
            col(DeclarationsMostMeaningfulStandardInfo.STANDARD_DOCUMENT_REF),
            col(DeclarationsMostMeaningfulStandardInfo.STANDARD_ID),
        )
    )
    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=silver_db_name, table=DeclarationsMostMeaningfulStandardInfo.PATH
    )
    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(df)
