import logging

from pyspark import StorageLevel
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

from src.declarations.mappers.silver.declarations.declaration_sep_family_expansion_declarations_mapper import (
    apply as prepare_initial_declarations_data_apply,
)
from src.declarations.mappers.silver.declarations.declaration_sep_family_expansion_id_mapper import (
    apply as id_generator_apply,
)
from src.declarations.mappers.silver.declarations.declaration_sep_family_expansion_publication_mapper import (
    apply as explode_publication_ids_apply,
)
from src.declarations.models.bronze.patents import patents_index
from src.declarations.models.silver.declarations import declaration_company_filtered
from src.declarations.models.silver.declarations import (
    declaration_sep_family_expansion as DeclarationSepFamilyExpansion,
)

# Configure the root logger
logging.basicConfig(
    level=logging.INFO,  # or logging.DEBUG for more detailed logs
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

# Create a logger for your application
logger = logging.getLogger("declarations_sep_family_expansion_processor")

BLACKLISTED_PUBLICATION_NUMBERS_DELTA_PATH = "blacklisted_family_publication_numbers"


def process(spark: SparkSession, catalog_name: str, bronze_db_name: str, silver_db_name: str, config: PipelineConfig):
    logger.info("Processor started - logging initialized")
    spark.sparkContext.setCheckpointDir("/dbfs/tmp/checkpoints")
    join_seq_id = ["id"]
    join_seq_pub_id = ["publication_id"]

    patent_document_values_df = get_patents_index(spark, catalog_name, silver_db_name)
    logger.info("reading patent document values is finished.")
    all_declarations = get_all_declarations(spark, catalog_name, silver_db_name, patent_document_values_df)
    all_declarations = all_declarations.checkpoint(eager=True)
    logger.info("reading all declarations is finished.")
    blacklisted_family_publication_numbers_df = get_blacklisted_family_publication_numbers(
        spark, catalog_name, bronze_db_name
    )
    logger.info("reading blacklisted family publication numbers is finished.")
    simple_family_ids = get_simple_family_ids_from_declarations(all_declarations)
    logger.info("getting simple family ids from declarations is finished.")
    all_involved_family_members = get_all_family_members(
        patent_document_values_df,
        blacklisted_family_publication_numbers_df,
        simple_family_ids,
    )
    all_involved_family_members = all_involved_family_members.checkpoint(eager=True)
    patent_document_values_df.unpersist()
    logger.info("reading data is finished.")

    result = prepare_initial_declarations_data_apply(all_declarations)

    join_seq_fam_id = ["simple_family_id"]
    result = result.join(all_involved_family_members, join_seq_fam_id, "left")

    logger.info("prepare initial declarations data and join after that are finished.")
    result = explode_publication_ids_apply(result)
    result = result.checkpoint(eager=True)

    all_declarations_by_id = all_declarations.select(
        declaration_company_filtered.ID, declaration_company_filtered.STANDARD_DOCUMENT_ID
    )
    all_declarations_by_id = all_declarations_by_id.persist(storageLevel=StorageLevel.MEMORY_AND_DISK)

    all_publication_numbers = all_declarations.select(
        declaration_company_filtered.PUBLICATION_NUMBER, declaration_company_filtered.PUBLICATION_ID
    ).distinct()
    logger.info("exploding publication ids and preparing all declarations by id are finished.")
    result = result.join(all_declarations_by_id, join_seq_id, "left").select(
        "publication_id", "id", "standard_document_id"
    )
    result = result.checkpoint(eager=True)
    all_declarations_by_id.unpersist()
    logger.info("result1 is prepared")

    result_without_id = (
        all_declarations.drop("publication_number", "publication_id", "standard_document_id")
        .join(result, join_seq_id, "inner")
        .join(all_publication_numbers, join_seq_pub_id, "inner")
    )
    result_without_id = result_without_id.checkpoint(eager=True)
    logger.info("joining all declarations by id and publication numbers is finished.")
    result_with_id = id_generator_apply(result_without_id)

    result_with_id = result_with_id.checkpoint(eager=True)
    logger.info("id generation is finished.")
    publication_to_be_filtered = result_with_id.join(all_declarations.select("id"), join_seq_id, "inner").select(
        "publication_id", "take_declaration_data_from", "standard_document_id"
    )

    result_final = (
        result.dropDuplicates(["publication_id", "standard_document_id"])
        .withColumnRenamed("id", "take_declaration_data_from")
        .select(
            DeclarationSepFamilyExpansion.PUBLICATION_ID,
            DeclarationSepFamilyExpansion.TAKE_DECLARATION_DATA_FROM,
            DeclarationSepFamilyExpansion.STANDARD_DOCUMENT_ID,
        )
        .subtract(publication_to_be_filtered)
    )

    result_final = result_final.checkpoint(eager=True)
    logger.info("id generation and filtering publications are finished.")
    repartitioned_df = result_final.repartition(DeclarationSepFamilyExpansion.PUBLICATION_ID)
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table=DeclarationSepFamilyExpansion.PATH
        ),
        config=config,
        mode="overwrite",
    ).run(repartitioned_df)
    logger.info("writing result to delta table is finished.")


def get_blacklisted_family_publication_numbers(spark, catalog_name, bronze_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=bronze_db_name, table=BLACKLISTED_PUBLICATION_NUMBERS_DELTA_PATH
        ),
        streaming=False,
    ).run()
    return df


def get_blacklisted_publication_id_from_family(blacklisted_family_publication_numbers_df):
    return (
        blacklisted_family_publication_numbers_df.select(F.col("blacklisted_publication_id_family"))
        .rdd.map(lambda c: c[0])
        .collect()
    )


def get_blacklisted_simple_family_id(blacklisted_family_publication_numbers_df):
    return blacklisted_family_publication_numbers_df.select(F.col("simple_family_id")).rdd.map(lambda c: c[0]).collect()


def get_all_family_members(patents_index_df, blacklisted_family_publication_numbers_df, simple_family_ids):

    family_members = (
        patents_index_df.select(patents_index.PUBLICATION_ID, F.col(patents_index.SIMPLE_FAMILY_ID), F.col("country"))
        .join(simple_family_ids, on="simple_family_id", how="left_semi")
        .filter(
            ~(
                F.col(patents_index.SIMPLE_FAMILY_ID).isin(
                    get_blacklisted_simple_family_id(blacklisted_family_publication_numbers_df)
                )
                & F.col(patents_index.PUBLICATION_ID).isin(
                    get_blacklisted_publication_id_from_family(blacklisted_family_publication_numbers_df)
                )
            )
        )
    )
    logger.info("filter simple family ids and blacklisted publication ids is finished.")

    selected_family_members = (
        family_members.repartition(patents_index.SIMPLE_FAMILY_ID)
        .groupBy(patents_index.SIMPLE_FAMILY_ID)
        .agg(F.collect_set(patents_index.PUBLICATION_ID).alias(patents_index.PUBLICATION_ID))
        .withColumn("count", F.size(F.col(patents_index.PUBLICATION_ID)))
        .sort(F.col("count").desc())
        .persist(storageLevel=StorageLevel.MEMORY_AND_DISK)
    )
    logger.info("group by simple family id and collect publication ids is finished.")

    return selected_family_members


def get_all_declarations(spark, catalog_name, silver_db_name, patent_document_values_df):
    join_seq_pub_id = ["publication_id"]
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table="declarations_company_filtered"
        ),
        streaming=False,
    ).run()

    return (
        df.filter(F.col("is_company_valid") == True)
        .select(
            declaration_company_filtered.ID,
            declaration_company_filtered.PUBLICATION_ID,
            declaration_company_filtered.STANDARD_DOCUMENT_ID,
            declaration_company_filtered.STANDARD_PROJECT,
            declaration_company_filtered.DECLARING_COMPANY,
            declaration_company_filtered.DECLARATION_DATE,
            declaration_company_filtered.PUBLICATION_NUMBER,
            declaration_company_filtered.ISLD,
        )
        .distinct()
        .repartition(declaration_company_filtered.PUBLICATION_ID)
        .join(get_simple_family_ids(patent_document_values_df), join_seq_pub_id, "left")
        .filter(F.col(patents_index.PUBLICATION_ID).isNotNull())
        .cache()
    )


def get_simple_family_ids_from_declarations(all_declarations):
    return all_declarations.select(F.col(patents_index.SIMPLE_FAMILY_ID)).distinct().na.drop()


def get_patents_index(spark, catalog_name, silver_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table="patents_index"
        ),
        streaming=False,
    ).run()
    return (
        df.select(
            F.col(patents_index.PUBLICATION_ID),
            F.col(patents_index.SIMPLE_FAMILY_ID),
            F.col("country"),
        )
    ).persist(storageLevel=StorageLevel.MEMORY_AND_DISK)


def get_simple_family_ids(patents_index_df):
    return (
        patents_index_df.select(patents_index.PUBLICATION_ID, F.col(patents_index.SIMPLE_FAMILY_ID))
        .filter(F.col(patents_index.SIMPLE_FAMILY_ID).isNotNull())
        .filter(F.col(patents_index.SIMPLE_FAMILY_ID) > 0)
        .distinct()
        .repartition(patents_index.PUBLICATION_ID)
    )
