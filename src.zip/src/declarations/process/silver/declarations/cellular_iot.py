from pyspark.sql import SparkSession
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.bronze.declarations.cellular_iot_data as CellularIotData
import src.declarations.models.bronze.patents.patents_index as PatentsIndex
import src.declarations.models.silver.declarations.cellular_technology_classification as CellularTechnologyClassification


def get_cellular_iot_data(spark, catalog_name, source_db_name):
    # Read bronze cellular IoT table
    return ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=CellularIotData.PATH
        ),
        streaming=False,
    ).run()


def get_patent_index_data(spark, catalog_name, source_db_name):
    # Read bronze patent index table
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=PatentsIndex.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            PatentsIndex.PUBLICATION_NUMBER,
            PatentsIndex.SIMPLE_FAMILY_ID,
        )
    )


def process(
    spark: SparkSession,
    catalog_name: str,
    bronze_db_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):
    # Load bronze data
    bronze_cellular_df = get_cellular_iot_data(spark, catalog_name, bronze_db_name)
    bronze_patents_df = get_patent_index_data(spark, catalog_name, silver_db_name)

    # Join on SIMPLE_FAMILY_ID
    joined_df = bronze_cellular_df.join(bronze_patents_df, on=PatentsIndex.SIMPLE_FAMILY_ID, how="inner")

    # Select relevant columns
    final_df = joined_df.select(
        PatentsIndex.PUBLICATION_NUMBER,
        PatentsIndex.SIMPLE_FAMILY_ID,
        CellularTechnologyClassification.TECHNOLOGY_CLASSIFICATION,
    )

    # Write result to silver table
    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=silver_db_name, table=CellularTechnologyClassification.PATH
    )

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(final_df)
