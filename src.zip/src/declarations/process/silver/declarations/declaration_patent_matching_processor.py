from pyspark.sql import SparkSession
from pyspark.sql.functions import col, trim, upper
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.silver.declarations.declaration_patent_number_matching_candidates_mapper as DeclarationPatentNumberMatchingCandidatesMapper
import src.declarations.mappers.silver.declarations.patent_number_matching_manual_mapper as patent_number_matching_manual_mapper
import src.declarations.models.bronze.declarations.declarations_manual_matching as DeclarationsManualMatchedPublicationNumbers
import src.declarations.models.silver.declarations.declaration_patent_number_matching_candidates as DeclarationPatentNumberMatchingCandidates
import src.declarations.models.silver.declarations.declaration_raw_enriched as DeclarationRawEnriched


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):

    # Declaration Raw Enriched Read
    declaration_raw_enriched_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=DeclarationRawEnriched.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            DeclarationRawEnriched.ID,
            DeclarationRawEnriched.ID_FIRST_CHAR,
            DeclarationRawEnriched.SSO,
            DeclarationRawEnriched.DATA_PROVIDER,
            DeclarationRawEnriched.COUNTRY_OF_REGISTRATION,
            DeclarationRawEnriched.PUBLICATION_AS_TO_DECLARATION,
            DeclarationRawEnriched.PUBLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION,
            DeclarationRawEnriched.APPLICATION_AS_TO_DECLARATION_OTHER,
        )
    )

    declaration_patent_matching_candidates_df = DeclarationPatentNumberMatchingCandidatesMapper.apply(
        declaration_raw_enriched_df
    )

    left_df = declaration_patent_matching_candidates_df.withColumn(
        DeclarationPatentNumberMatchingCandidates.WORKING_NUMBER,
        trim(upper(col(DeclarationPatentNumberMatchingCandidates.WORKING_NUMBER))),
    ).withColumn(
        DeclarationPatentNumberMatchingCandidates.SOURCE,
        trim(upper(col(DeclarationPatentNumberMatchingCandidates.SOURCE))),
    )

    right_df = (
        get_manual_matched_publication_numbers(spark, catalog_name, silver_db_name)
        .withColumn("manual_matched_working_number", trim(upper(col("manual_matched_working_number"))))
        .withColumn("manual_matched_source", trim(upper(col("manual_matched_source"))))
    )

    join_condition = (
        left_df[DeclarationPatentNumberMatchingCandidates.WORKING_NUMBER] == right_df["manual_matched_working_number"]
    ) & (left_df[DeclarationPatentNumberMatchingCandidates.SOURCE] == right_df["manual_matched_source"])

    joined_df = left_df.join(right_df, join_condition, "left")
    declarations_final_df = patent_number_matching_manual_mapper.apply(joined_df)
    declarations_silver_df = declarations_final_df.dropDuplicates([DeclarationPatentNumberMatchingCandidates.ID])
    repartitioned_df = declarations_silver_df.repartition(DeclarationPatentNumberMatchingCandidates.ID)

    # Write to Silver patent_number_matching_candidates
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=silver_db_name,
            table=DeclarationPatentNumberMatchingCandidates.PATH,
        ),
        config=config,
    ).run(repartitioned_df)


def get_manual_matched_publication_numbers(spark, catalog_name, source_db_name):
    # Read manually matched publication numbers
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationsManualMatchedPublicationNumbers.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            col("working_number").alias("manual_matched_working_number"),
            col("source").alias("manual_matched_source"),
            col("publication_number"),
        )
    )
