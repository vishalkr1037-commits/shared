from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.read_delta_table_task import (
    ReadDeltaTableTask,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col

from src.declarations.mappers.silver.declarations.declaration_ipc_filtered_mapper import (
    DeclarationIpcFilteredMapper,
)
from src.declarations.models.silver.declarations import (
    declaration_deduplicated_intermediate as DeclarationDeduplicatedIntermediate,
)
from src.declarations.models.silver.declarations import (
    declaration_ipc_filtered as DeclarationIPCFiltered,
)


def get_declaration_and_patent_index_data(
    spark: SparkSession,
    catalog_name: str,
    source_db_name: str,
) -> DataFrame:
    df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name,
                database=source_db_name,
                table=DeclarationDeduplicatedIntermediate.DEDUPLICATED_INTERMEDIATE_PATH,
            ),
            streaming=False,
        )
        .run()
        .select(
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER),
            col(DeclarationDeduplicatedIntermediate.ID),
            col(DeclarationDeduplicatedIntermediate.SSO),
            col(DeclarationDeduplicatedIntermediate.DATA_PROVIDER),
            col(DeclarationDeduplicatedIntermediate.STANDARD_PROJECT),
            col(DeclarationDeduplicatedIntermediate.STANDARD_DOCUMENT_ID),
            col(DeclarationDeduplicatedIntermediate.DECLARING_COMPANY),
            col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION),
            col(DeclarationDeduplicatedIntermediate.DECLARATION_DATE),
            col(DeclarationDeduplicatedIntermediate.PATENT_POOL_NAME),
            col(DeclarationDeduplicatedIntermediate.STANDARD_MATCH_ID),
            col(DeclarationDeduplicatedIntermediate.LICENSING_TERMS),
            col(DeclarationDeduplicatedIntermediate.SPECIFIC_LICENSING_CONDITIONS),
            col(DeclarationDeduplicatedIntermediate.RECIPOCITY_STATEMENT),
            col(DeclarationDeduplicatedIntermediate.LICENSING_COMMENT),
            col(DeclarationDeduplicatedIntermediate.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES),
            col(DeclarationDeduplicatedIntermediate.CONTACT_PERSON_FOR_LICENSE),
            col(DeclarationDeduplicatedIntermediate.CONTACT_PERSON_POSITION),
            col(DeclarationDeduplicatedIntermediate.CONTACT_ADDRESS_FOR_LICENSE),
            col(DeclarationDeduplicatedIntermediate.CONTACT_PHONE_FOR_LICENSE),
            col(DeclarationDeduplicatedIntermediate.CONTACT_EMAIL_FOR_LICENSE),
            col(DeclarationDeduplicatedIntermediate.SECTION),
            col(DeclarationDeduplicatedIntermediate.ESSENTIAL_CLAIM_NUMBER),
            col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION_OTHER),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION_OTHER),
            col(DeclarationDeduplicatedIntermediate.TECHNOLOGY_GENERATION_ARRAY),
            col(DeclarationDeduplicatedIntermediate.GROUP_ARRAY),
            col(DeclarationDeduplicatedIntermediate.TITLE),
            col(DeclarationDeduplicatedIntermediate.TYPE),
            col(DeclarationDeduplicatedIntermediate.POOL_PROVIDER),
            col(DeclarationDeduplicatedIntermediate.TECHNOLOGY_CLASSIFICATION),
            col(DeclarationDeduplicatedIntermediate.POOL_NAME_HARMONIZED),
            col(DeclarationDeduplicatedIntermediate.STANDARD_DOCUMENT_TITLE),
            col(DeclarationDeduplicatedIntermediate.SELECTED_PUBLICATION_NUMBER),
            col(DeclarationDeduplicatedIntermediate.APPLIED_RULES),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER_SOURCE),
            col(DeclarationDeduplicatedIntermediate.MATCHED),
            col(DeclarationDeduplicatedIntermediate.WORKING_NUMBER),
            col(DeclarationDeduplicatedIntermediate.ISLD),
            col(DeclarationDeduplicatedIntermediate.DISCLOSURE_NUMBER),
            col(DeclarationDeduplicatedIntermediate.ID_FIRST_CHAR),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_ID),
            col(DeclarationDeduplicatedIntermediate.CPC_CURRENT),
            col(DeclarationDeduplicatedIntermediate.IPC_CURRENT),
            col(DeclarationDeduplicatedIntermediate.INPADOC_FAMILY_ID),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_MONTH),
            col(DeclarationDeduplicatedIntermediate.APPLICATION_NUMBER),
            col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR),
            col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_CPC),
            col(DeclarationDeduplicatedIntermediate.INDUSTRY_SECTOR_IPC),
            col(DeclarationDeduplicatedIntermediate.CONCATENATED_INDUSTRY_SECTOR),
        )
    )
    return df


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
) -> None:
    df = get_declaration_and_patent_index_data(spark, catalog_name, silver_db_name)
    transformed_df = DeclarationIpcFilteredMapper.apply(df)

    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=silver_db_name, table=DeclarationIPCFiltered.PATH
    )
    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(transformed_df)
