from pyspark.sql import SparkSession
from pyspark.sql.functions import col
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.silver.declarations.declaration_industry_class_filtered_mapper as DeclarationIndustryClassFilteredMapper
import src.declarations.models.silver.declarations.declaration_industry_class_filtered as DeclarationIndustryClassFiltered
import src.declarations.models.silver.declarations.declaration_ipc_filtered as DeclarationIPCFiltered


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):

    # Declaration IPC Filtered Read
    declaration_ipc_filtered_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=DeclarationIPCFiltered.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(col(DeclarationIPCFiltered.IS_INDUSTRY_SECTOR_VALID) == True)
    )

    declaration_industry_class_filted_df = DeclarationIndustryClassFilteredMapper.apply(declaration_ipc_filtered_df)

    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    for col_name in columns_to_drop:
        if col_name in declaration_industry_class_filted_df.columns:
            declaration_industry_class_filted_df = declaration_industry_class_filted_df.drop(col_name)
    declaration_industry_class_filted_df_repartitioned = declaration_industry_class_filted_df.repartition(
        DeclarationIndustryClassFiltered.DECLARATION_ID
    )

    # Write to Silver declarations_industry_class_filtered
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=silver_db_name,
            table=DeclarationIndustryClassFiltered.PATH,
        ),
        config=config,
        mode="overwrite",
    ).run(declaration_industry_class_filted_df_repartitioned)
