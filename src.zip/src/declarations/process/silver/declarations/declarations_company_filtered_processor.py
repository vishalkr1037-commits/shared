from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.functions import col, explode
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.silver.declarations.declaration_priority_date_filtered as DeclarationPriorityDateFiltered
import src.declarations.utils.declaration_deduplication_helper as declaration_deduplication_helper
from src.declarations.mappers.silver.declarations.declaration_company_filtered_col_renaming_mapper import (
    apply_declaration_company_filtered_mapper,
)
from src.declarations.mappers.silver.declarations.declaration_company_filtered_transformation_mapper import (
    apply,
)
from src.declarations.models.silver.declarations import (
    declaration_company_filtered as DeclarationCompanyFiltered,
)
from src.declarations.models.silver.declarations import (
    declaration_deduplicated_intermediate as DeclarationDeduplicatedIntermediate,
)
from src.declarations.models.silver.declarations.raw_declaration_companies_harmonization import (
    RawDeclarationCompaniesHarmonizations as RawDeclarationCompaniesHarmonization,
)
from src.declarations.models.silver.patents import (
    patent_family_applicants as PatentFamilyApplicants,
)
from src.declarations.models.silver.patents import (
    patent_family_assignees as PatentFamilyAssignees,
)
from src.declarations.models.silver.patents import patent_kind_type as PatentKindType
from src.declarations.models.silver.patents import (
    patent_transferred_flag_current_assignee as PatentTransferredFlagCurrentAssignee,
)
from src.declarations.utils.declarations_id_generator_helper import (
    DeclarationsIdGeneratorHelper,
)


def process(
    spark: SparkSession,
    catalog_name: str,
    bronze_db_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):
    aggregated_declarations_df = get_aggregated_declarations(spark, catalog_name, silver_db_name)
    patent_index_joined_with_main_table_df = apply_declaration_company_filtered_mapper(
        get_priority_date_filtered_declaration_data(spark, catalog_name, silver_db_name)
    ).repartition(DeclarationCompanyFiltered.PUBLICATION_ID)

    blacklisted_publication_numbers_df = get_blacklisted_publication_numbers(spark, catalog_name, bronze_db_name)
    blacklisted_working_numbers_df = get_blacklisted_working_numbers(spark, catalog_name, bronze_db_name)
    whitelisted_publication_numbers_df = get_whitelisted_publication_numbers(spark, catalog_name, bronze_db_name)
    whitelisted_working_numbers_df = get_whitelisted_working_numbers(spark, catalog_name, bronze_db_name)
    patent_assignee_applicant_df = get_patent_assignee_applicant_data(spark, catalog_name, silver_db_name)
    patent_kind_type_df = get_patent_kind_type(spark, catalog_name, silver_db_name)
    patent_family_assignees_df = get_patent_family_assignees_data(spark, catalog_name, silver_db_name)
    patent_family_applicants_df = get_patent_family_applicants_data(spark, catalog_name, silver_db_name)
    harmonized_declaring_companies_df = get_harmonized_declaring_companies(spark, catalog_name, silver_db_name)

    declaration_deduplication_helper.init(spark)
    patent_index_joined_with_main_table_df_new = apply(
        patent_index_joined_with_main_table_df,
        blacklisted_publication_numbers_df,
        blacklisted_working_numbers_df,
        whitelisted_publication_numbers_df,
        whitelisted_working_numbers_df,
        patent_assignee_applicant_df,
        patent_kind_type_df,
        patent_family_assignees_df,
        patent_family_applicants_df,
        harmonized_declaring_companies_df,
        aggregated_declarations_df,
    ).drop("_commit_version")

    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=silver_db_name, table=DeclarationCompanyFiltered.PATH
    )
    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(
        patent_index_joined_with_main_table_df_new
    )


def get_priority_date_filtered_declaration_data(spark, catalog_name, silver_db_name):
    df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=DeclarationPriorityDateFiltered.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(F.col("is_priority_date_valid") == True)
        .drop(
            DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION,
            DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION,
            DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION_OTHER,
            DeclarationDeduplicatedIntermediate.DISCLOSURE_NUMBER,
        )
    )
    return df


def get_aggregated_declarations(spark, catalog_name, silver_db_name):

    df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name,
                database=silver_db_name,
                table=DeclarationDeduplicatedIntermediate.DEDUPLICATED_INTERMEDIATE_PATH,
            ),
            streaming=False,
        )
        .run()
        .select(
            col(DeclarationDeduplicatedIntermediate.STANDARD_DOCUMENT_ID),
            col(DeclarationDeduplicatedIntermediate.STANDARD_PROJECT),
            col(DeclarationDeduplicatedIntermediate.DECLARING_COMPANY),
            col(DeclarationDeduplicatedIntermediate.DECLARATION_DATE),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER),
            col(DeclarationDeduplicatedIntermediate.ISLD),
            col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION),
            col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION_OTHER),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION_OTHER),
            col(DeclarationDeduplicatedIntermediate.DISCLOSURE_NUMBER),
            col(DeclarationDeduplicatedIntermediate.TYPE),
            col(DeclarationDeduplicatedIntermediate.POOL_PROVIDER),
            col(DeclarationDeduplicatedIntermediate.ESSENTIAL_CLAIM_NUMBER),
            col(DeclarationDeduplicatedIntermediate.POOL_NAME_HARMONIZED),
        )
    )

    df = df.withColumn(
        DeclarationCompanyFiltered.ID,
        DeclarationsIdGeneratorHelper.make_id_for_declaration_raw_udf(
            col(DeclarationDeduplicatedIntermediate.STANDARD_DOCUMENT_ID),
            col(DeclarationDeduplicatedIntermediate.STANDARD_PROJECT),
            F.initcap(col(DeclarationDeduplicatedIntermediate.DECLARING_COMPANY)),
            col(DeclarationDeduplicatedIntermediate.DECLARATION_DATE),
            col(DeclarationDeduplicatedIntermediate.PUBLICATION_NUMBER),
            col(DeclarationDeduplicatedIntermediate.ISLD),
        ),
    )

    aggregated_df = df.groupBy(DeclarationCompanyFiltered.ID).agg(
        F.flatten(
            F.collect_set(F.split(col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION), "\\|"))
        ).alias(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION),
        F.flatten(
            F.collect_set(F.split(col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION), "\\|"))
        ).alias(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION),
        F.flatten(
            F.collect_set(F.split(col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION_OTHER), "\\|"))
        ).alias(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION_OTHER),
        F.flatten(
            F.collect_set(F.split(col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION_OTHER), "\\|"))
        ).alias(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION_OTHER),
        F.flatten(F.collect_set(F.split(col(DeclarationDeduplicatedIntermediate.DISCLOSURE_NUMBER), "\\|"))).alias(
            DeclarationDeduplicatedIntermediate.DISCLOSURE_NUMBER
        ),
    )

    aggregated_df = (
        aggregated_df.withColumn(
            DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION,
            F.array_join(col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION), ", "),
        )
        .withColumn(
            DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION_OTHER,
            F.array_join(col(DeclarationDeduplicatedIntermediate.APPLICATION_AS_TO_DECLARATION_OTHER), ", "),
        )
        .withColumn(
            DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION,
            F.array_join(col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION), ", "),
        )
        .withColumn(
            DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION_OTHER,
            F.array_join(col(DeclarationDeduplicatedIntermediate.PUBLICATION_AS_TO_DECLARATION_OTHER), ", "),
        )
        .withColumn(
            DeclarationDeduplicatedIntermediate.DISCLOSURE_NUMBER,
            F.array_join(col(DeclarationDeduplicatedIntermediate.DISCLOSURE_NUMBER), ", "),
        )
    )

    return aggregated_df


def get_blacklisted_publication_numbers(spark, catalog_name, bronze_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=bronze_db_name, table="blacklisted_publication_numbers"
        ),
        streaming=False,
    ).run()
    return [row["blacklisted_publication_number"] for row in df.select("blacklisted_publication_number").collect()]


def get_blacklisted_working_numbers(spark, catalog_name, bronze_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=bronze_db_name, table="blacklisted_publication_numbers"
        ),
        streaming=False,
    ).run()
    return [row["blacklisted_working_number"] for row in df.select("blacklisted_working_number").collect()]


def get_whitelisted_publication_numbers(spark, catalog_name, bronze_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=bronze_db_name, table="whitelisted_publication_numbers"
        ),
        streaming=False,
    ).run()
    return [row["whitelisted_publication_number"] for row in df.select("whitelisted_publication_number").collect()]


def get_whitelisted_working_numbers(spark, catalog_name, bronze_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=bronze_db_name, table="whitelisted_publication_numbers"
        ),
        streaming=False,
    ).run()
    return [row["whitelisted_working_number"] for row in df.select("whitelisted_working_number").collect()]


def get_harmonized_declaring_companies(spark, catalog_name, silver_db_name):

    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table=RawDeclarationCompaniesHarmonization.PATH
        ),
        streaming=False,
    ).run()
    return df.select(
        col("declaration_id").alias("declaration_id_harmonized"),
        col("id_first_char").alias("id_first_char_harmonized_declaring_companies"),
        explode(col("harmonized_name")).alias("harmonized_company_name"),
    )


def get_patent_family_applicants_data(spark, catalog_name, silver_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table="family_applicants"
        ),
        streaming=False,
    ).run()
    return df.select(
        col(PatentFamilyApplicants.INPADOC_FAMILY_ID),
        col(PatentFamilyApplicants.HARMONIZED_NAME).alias("harmonized_patent_family_applicants_name"),
    )


def get_patent_family_assignees_data(spark, catalog_name, silver_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table="family_assignees"
        ),
        streaming=False,
    ).run()
    return df.select(
        col(PatentFamilyAssignees.INPADOC_FAMILY_ID),
        col(PatentFamilyAssignees.HARMONIZED_NAME).alias("harmonized_patent_family_assignees_name"),
    )


def get_patent_assignee_applicant_data(spark, catalog_name, silver_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table="patent_assignees"
        ),
        streaming=False,
    ).run()
    return df.select(
        col(PatentTransferredFlagCurrentAssignee.PUBLICATION_ID),
        col(PatentTransferredFlagCurrentAssignee.ASSIGNEE_NAME_ARRAY),
        col(PatentTransferredFlagCurrentAssignee.APPLICANT_NAME_ARRAY),
    )


def get_patent_kind_type(spark, catalog_name, silver_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=silver_db_name, table="kind_type"),
        streaming=False,
    ).run()
    return df.select(col(PatentKindType.PUBLICATION_ID), col(PatentKindType.KIND_TYPE_SHORT))
