from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, expr
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.silver.declarations.declaration_solr_against_company_filter_id_diff_mapper as DiffMapper
import src.declarations.models.gold.declarations.declaration_gold as Declarations
import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFiltered
import src.declarations.models.silver.declarations.declaration_diff_ids as DeclarationDiffIds


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    golden_db_name: str,
    config: PipelineConfig,
) -> DataFrame:
    company_filter_only_id_column = get_company_filter_declarations(spark, catalog_name, silver_db_name)
    declarations_solr_data_only_id_column = get_declarations_solr_data(spark, catalog_name, golden_db_name)
    df = calculate(company_filter_only_id_column, declarations_solr_data_only_id_column)

    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=silver_db_name, table=DeclarationDiffIds.PATH
    )
    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config).run(df)


def calculate(company_filter: DataFrame, declarations_solr_data: DataFrame) -> DataFrame:
    # Find ADDED records (in company_filter but not in solr)
    added = (
        company_filter.alias("left")
        .join(declarations_solr_data.alias("right"), expr("left.id = right.id"), "left")
        .filter(col("right.id").isNull())
        .select(col("left.id").alias(DeclarationDiffIds.DECLARATION_ID))
    )
    added = DiffMapper.apply(added, "ADDED")

    # Find REMOVED records (in solr but not in company_filter)
    removed = (
        company_filter.alias("left")
        .join(declarations_solr_data.alias("right"), expr("left.id = right.id"), "right")
        .filter(col("left.id").isNull())
        .select(col("right.id").alias(DeclarationDiffIds.DECLARATION_ID))
    )
    removed = DiffMapper.apply(removed, "REMOVED")

    return added.union(removed)


def get_declarations_solr_data(spark: SparkSession, catalog_name: str, golden_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=golden_db_name, table=Declarations.PATH
            ),
            streaming=False,
        )
        .run()
        .select(Declarations.ID)
    )


def get_company_filter_declarations(spark: SparkSession, catalog_name: str, database_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=database_name, table=DeclarationCompanyFiltered.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(expr(f"{DeclarationCompanyFiltered.IS_COMPANY_VALID} = true"))
        .select(DeclarationCompanyFiltered.ID)
    )
