import logging

from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.read_delta_table_task import (
    ReadDeltaTableTask,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

from src.declarations.mappers.silver.essentiality.essentiality_semsim_mapper import (
    apply_ses_transformation as SemsimMapper,
)
from src.declarations.models.silver.essentiality import semsim as SemsimModel
from src.declarations.models.silver.essentiality import ses_scoring_model as ses_score

logger = logging.getLogger(__name__)


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    technology: str,
    config: PipelineConfig,
) -> None:

    if not technology:
        raise ValueError("tech must be provided")
    logger.info(f"Processing semantic similarity scores for technology: {technology}")

    # Get and transform data
    semantic_score_df = get_semantic_score_data_per_tech(spark, catalog_name, silver_db_name, technology).transform(
        SemsimMapper
    )

    record_count = semantic_score_df.count()
    if record_count == 0:
        logger.warning(f"No records found for technology: {technology}")

    logger.info(f"Found {record_count} records for technology: {technology}")

    # Get target table name based on technology
    target_table_attr = f"SILVER_{technology}_SEMSIM"
    if not hasattr(SemsimModel, target_table_attr):
        raise AttributeError(
            f"Target table attribute '{target_table_attr}' not found in SemsimModel. "
            f"Available attributes: {[attr for attr in dir(SemsimModel) if not attr.startswith('_')]}"
        )

    target_table = getattr(SemsimModel, target_table_attr)

    fq_table_name = fully_qualified_table_name(
        catalog=catalog_name,
        database=silver_db_name,
        table=target_table,
    )

    logger.info(f"Writing {record_count} records to {fq_table_name}")
    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    for col_name in columns_to_drop:
        if col_name in semantic_score_df.columns:
            semantic_score_df = semantic_score_df.drop(col_name)

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fq_table_name,
        config=config,
        mode="overwrite",
    ).run(semantic_score_df)

    logger.info(f"Successfully processed technology: {technology}")


def get_semantic_score_data_per_tech(
    spark: SparkSession,
    catalog_name: str,
    source_db_name: str,
    technology: str,
):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name,
            database=source_db_name,
            table=ses_score.SES_SCORING_SIMILARITIES_TABLE,
        ),
        streaming=False,
    ).run()
    # Use upper() on BOTH sides for case-insensitive comparison
    return df.filter(F.upper(F.col(ses_score.TECH)) == technology.upper()).select(
        F.col(ses_score.SES_ID),
        F.col(ses_score.SES_PUBLICATION_CLAIM_ID),
        F.col(ses_score.SES_STANDARD_SECTION_NUMBER),
        F.col(ses_score.SES_SIMILARITY_SCORE),
    )
