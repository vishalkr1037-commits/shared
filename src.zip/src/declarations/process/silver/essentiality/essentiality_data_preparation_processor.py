import logging
from typing import Any, Dict

from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.models.silver.essentiality.essentiality_consolidated as ConsolidatedModel
from src.declarations.mappers.silver.essentiality.essentiality_consolidation_mapper import (
    add_tech_column,
    consolidate_abs_title_data,
    consolidate_claims_data,
    consolidate_std_text_data,
)
from src.declarations.utils.essentiality_utils import (
    TextPreprocessor,
    get_abstract_title_text,
    get_claims_text,
    get_section_text,
    load_declarations,
    load_standards,
)

logger = logging.getLogger("EssentialityDataPreparation")


def load_and_extract_text(spark: SparkSession, tech: str, include_standards: bool = True) -> Dict[str, Any]:
    logger.info(f"Loading raw data for technology: {tech.upper()}")

    try:
        patent_df = load_declarations(spark, tech, f"{tech}_declarations_without_most_meaningful")
        logger.info(f"  ✓ Loaded {patent_df.count()} patent records")

        standards_section_df = None
        if include_standards:
            standards_df = load_standards(spark, tech, f"{tech}_declarations")
            logger.info(f"  ✓ Loaded {standards_df.count()} standards records")

        logger.info(f"Extracting text fields for {tech}...")
        claims_df = get_claims_text(patent_df)
        abs_title_df = get_abstract_title_text(patent_df)
        logger.info(f"  ✓ Extracted {claims_df.count()} claim records")
        logger.info(f"  ✓ Extracted {abs_title_df.count()} abstract/title records")

        if include_standards:
            standards_section_df = get_section_text(standards_df, tech)
            logger.info(f"  ✓ Extracted {standards_section_df.count()} section records")
        else:
            logger.info("  ✓ Skipping standards extraction for this technology")

        return {"claims": claims_df, "abstract_title": abs_title_df, "standards_sections": standards_section_df}
    except Exception as e:
        logger.error(f"Error loading and extracting text for {tech}: {str(e)}")
        raise


def apply_text_preprocessing(text_dfs: Dict[str, Any], preprocessor) -> Dict[str, Any]:
    logger.info("Applying text preprocessing...")

    try:
        logger.info("  Processing claims...")
        preprocessed_claims_df = preprocessor.preprocess_dataset(text_dfs["claims"])
        logger.info(f"    ✓ Processed {preprocessed_claims_df.count()} records")

        logger.info("  Processing abstracts & titles...")
        preprocessed_abs_title_df = preprocessor.preprocess_dataset(text_dfs["abstract_title"])
        logger.info(f"    ✓ Processed {preprocessed_abs_title_df.count()} records")

        preprocessed_std_df = None
        if text_dfs["standards_sections"] is not None:
            logger.info("  Processing standards sections...")
            preprocessed_std_df = preprocessor.preprocess_dataset(text_dfs["standards_sections"])
            logger.info(f"    ✓ Processed {preprocessed_std_df.count()} records")
        else:
            logger.info("  Skipping standards preprocessing (no standards data)")

        return {
            "claims": preprocessed_claims_df,
            "abstract_title": preprocessed_abs_title_df,
            "standards": preprocessed_std_df,
        }
    except Exception as e:
        logger.error(f"Error applying text preprocessing: {str(e)}")
        raise


def process_single_technology(spark: SparkSession, tech: str, preprocessor) -> Dict[str, Any]:
    logger.info(f"\n{'─' * 80}")
    logger.info(f"Processing technology: {tech.upper()}")
    logger.info(f"{'─' * 80}")

    try:
        include_standards = tech != "true_negative"
        text_dfs = load_and_extract_text(spark, tech, include_standards)
        preprocessed_dfs = apply_text_preprocessing(text_dfs, preprocessor)

        logger.info("Adding tech column to preprocessed data...")
        tech_tagged_dfs = {
            "claims": add_tech_column(preprocessed_dfs["claims"], tech),
            "abstract_title": add_tech_column(preprocessed_dfs["abstract_title"], tech),
            "standards": (
                add_tech_column(preprocessed_dfs["standards"], tech)
                if preprocessed_dfs["standards"] is not None
                else None
            ),
        }
        logger.info("  ✓ Tech column added")

        return tech_tagged_dfs

    except Exception as e:
        logger.error(f"Error processing technology {tech}: {str(e)}")
        raise


def process(
    spark: SparkSession, tech: str, catalog_name: str, target_db_name: str, config: PipelineConfig, mode: str = "append"
) -> None:

    logger.info(f"\n{'█' * 80}")
    logger.info(f"PROCESSING TECHNOLOGY: {tech.upper()}")
    logger.info(f"Write mode: {mode.upper()}")
    logger.info(f"{'█' * 80}")

    preprocessor = TextPreprocessor(keep_named_entities=True)
    all_claims_dfs = []
    all_abs_title_dfs = []
    all_std_dfs = []

    try:
        logger.info(f"\nProcessing {tech.upper()}...")
        tech_dfs = process_single_technology(spark, tech, preprocessor)

        all_claims_dfs.append(tech_dfs["claims"])
        all_abs_title_dfs.append(tech_dfs["abstract_title"])
        if tech_dfs["standards"] is not None:
            all_std_dfs.append(tech_dfs["standards"])

        logger.info(f"  ✓ {tech.upper()} completed")

    except Exception as e:
        logger.error(f"  ✗ Failed to process {tech.upper()}: {str(e)}")
        raise

    logger.info(f"\n{'─' * 80}")
    logger.info("Consolidating data...")
    logger.info(f"{'─' * 80}")

    claims_df = consolidate_claims_data(all_claims_dfs)
    abstract_title_df = consolidate_abs_title_data(all_abs_title_dfs)
    standards_df = consolidate_std_text_data(all_std_dfs) if all_std_dfs else None

    logger.info(f"  ✓ Claims: {claims_df.count():,} records")
    logger.info(f"  ✓ Abstract/Title: {abstract_title_df.count():,} records")
    if standards_df is not None:
        logger.info(f"  ✓ Standards: {standards_df.count():,} records")
    else:
        logger.info("  ✓ Standards: skipped (no standards data)")
    tables_config = [
        {"dataframe": claims_df, "table_name": ConsolidatedModel.PREPROCESSED_CLAIMS_TABLE, "description": "Claims"},
        {
            "dataframe": abstract_title_df,
            "table_name": ConsolidatedModel.PREPROCESSED_ABS_TITLE_TABLE,
            "description": "Abstract/Title",
        },
        (
            {
                "dataframe": standards_df,
                "table_name": ConsolidatedModel.PREPROCESSED_STD_TEXT_TABLE,
                "description": "Standards Text",
            }
            if standards_df is not None
            else None
        ),
    ]

    logger.info(f"\n{'─' * 80}")
    logger.info(f"Writing consolidated data to tables (mode: {mode.upper()})...")
    logger.info(f"{'─' * 80}")

    for table_config in tables_config:
        if table_config is None:
            continue
        try:
            target_table = fully_qualified_table_name(
                catalog=catalog_name, database=target_db_name, table=table_config["table_name"]
            )

            logger.info(f"\nWriting {table_config['description']} to {target_table}...")
            logger.info(f"  Records: {table_config['dataframe'].count():,}")

            WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode=mode).run(
                table_config["dataframe"]
            )

            logger.info(f"  ✓ Successfully written ({mode} mode)")

        except Exception as e:
            logger.error(f"  ✗ Failed to write {table_config['description']}: {str(e)}")
            raise

    logger.info(f"\n{'█' * 80}")
    logger.info("PROCESSING COMPLETE")
    logger.info(f"{'█' * 80}\n")
