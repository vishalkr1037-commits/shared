# import logging

# from pyspark.sql import SparkSession
# from pyspark.sql import functions as F
# from pyspark.sql.types import DoubleType

# from src.common.table_config.table_name import fully_qualified_table_name

# # from src.declarations.mappers.silver.essentiality.score_normalization_mapper import (
# #     apply as NormalizedSESMapper,
# # )
# from src.declarations.models.silver.essentiality import (
#     semantic_similarity_score_with_text as SemanticScoreModel,
# )
# from src.patents.config import PipelineConfig
# from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
# from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

# logging.basicConfig(
#     level=logging.INFO,
#     format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
# )
# logger = logging.getLogger("essentiality_score_normalization_scaling_processor")


# def process(
#     spark: SparkSession,
#     catalog_name: str,
#     silver_db_name: str,
#     technology: str,
#     config: PipelineConfig,
# ):
#     source_table_for_semantic_scores = getattr(
#         SemanticScoreModel,
#         f"SILVER_{technology}_SEMANTIC_SIMILARITY_SCORES",
#     )

#     def get_declaration_data(
#         spark: SparkSession,
#         catalog_name: str,
#         source_db_name: str,
#         technology: str,
#     ):
#         df = ReadDeltaTableTask(
#             spark=spark,
#             fq_source_table=fully_qualified_table_name(
#                 catalog=catalog_name,
#                 database=source_db_name,
#                 table=f"{technology}_declarations",
#             ),
#             streaming=False,
#         ).run()
#         # Use upper() on BOTH sides for case-insensitive comparison
#         return (
#             df.select(F.col("most_meaningful_standard_document_id"), F.col("most_meaningful_section_array").distinct()),
#         )

#     def get_semantic_score_data(
#         spark: SparkSession,
#         catalog_name: str,
#         source_db_name: str,
#         technology: str,
#     ):
#         df = ReadDeltaTableTask(
#             spark=spark,
#             fq_source_table=fully_qualified_table_name(
#                 catalog=catalog_name,
#                 database=source_db_name,
#                 table=source_table_for_semantic_scores,
#             ),
#             streaming=False,
#         ).run()

#     def get_without_mostMeaningful_data(
#         spark: SparkSession,
#         catalog_name: str,
#         source_db_name: str,
#         technology: str,
#     ):
#         df = ReadDeltaTableTask(
#             spark=spark,
#             fq_source_table=fully_qualified_table_name(
#                 catalog=catalog_name,
#                 database=source_db_name,
#                 table=f"{technology}_declarations_without_most_meaningful",
#             ),
#             streaming=False,
#         ).run()
#         return (
#             df.select(
#                 F.col("id"), F.col("section"), F.col("claims"), F.col("standard_document_id"), F.col("document_origin")
#             ),
#         )
