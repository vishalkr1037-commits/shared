from functools import partial

from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.read_delta_table_task import (
    ReadDeltaTableTask,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, length

import src.declarations.models.silver.standards.standards as StandardsModel
from src.declarations.mappers.silver.essentiality.etsi_standards_mapper import (
    EtsiStandardsMapper,
)
from src.declarations.mappers.silver.essentiality.tech_standards_mapper import (
    TechStandardsMapper,
)
from src.declarations.models.silver.essentiality.ses_standards_model import (
    EssentialityStandardsModel,
)
from src.declarations.models.silver.standards.standards_description import (
    StandardsDescription as StandardsDescriptionModel,
)


# Important Note: This Processor is not currently in use - no notebook + databricks job is calling it purposely
# Section Extraction job along with other steps of SES Data Preparation job is supposed to keep running on legacy system (original airflow dag: essentiality_v2.run_all_pipelines)
# As of decision stated in USER STORY: 99668
class EssentialitySectionExtractionProcessor:
    """Processor for extracting essentiality sections from standards data."""

    # Minimum number of characters required in standard description
    MIN_NUMBER_CHARACTERS_IN_STANDARD_DESCRIPTION = 1000

    # Technology-specific AC_CODE filters
    WIFI_AC_CODES = [
        "US45610749",
        "US45608380",
        "US45515327",
        "US45853907",
        "IEEE80211ac20132013-12-18",
        "IEEE80211ax20212021-05-19",
        "IEEE80211be2024",
    ]

    AUDIO_AC_CODES = [
        "ISO_IEC_13818_7_2006E",
        "opus_audio_codec_definition_IETF_2012",
        "opus_audio_codec_update_IETF_2017",
        "opus_ambisonics_ogg_IETF_2018",
        "audio_ISO_IEC_14496_3_2019",
        "3daudio_ISO_IEC_23008_3_2022",
        "3daudio_conformance_testing_ISO_IEC_23008_9_2023",
    ]

    VIDEO_AC_CODES = [
        "ISOIEC144961020202020-01-01",
        "CANCSAISOIEC230082212021-03-01",
        "ISOIEC23090320212021-02-01",
        "vp9_v6_31_01_2016",
        "av1_v1_18_1_2019",
    ]

    def __init__(self, spark: SparkSession, catalog: str, silver_db: str, config: PipelineConfig, technology: str):
        """
        Initialize the processor.

        Args:
            spark: SparkSession instance
            catalog: Catalog name for Delta tables
            silver_db: Silver database name
            config: Pipeline configuration
            technology: Technology type (atsc, qi, wifi, etsi, audio, video)
        """
        self.spark = spark
        self.catalog_name = catalog
        self.silver_db = silver_db
        self.config = config
        self.technology = technology

    def process(self):
        """
        Process standards data for the configured technology.

        Steps:
            1. Load standards based on technology-specific filter
            2. Retrieve standards descriptions
            3. Join standards with descriptions
            4. Apply mapper transformations
            5. Filter results based on technology
            6. Write output to Delta table

        Returns:
            Transformed DataFrame with standards and sections
        """

        # get filtered standards and descriptions
        standards_df = self.get_standards(filter_condition=self._get_standards_filter())
        standards_description_df = self.get_standards_description(
            filter_condition=self._get_description_filter(standards_df)
        )

        # select mapper
        transform_mapper = EtsiStandardsMapper if self.technology == "etsi" else TechStandardsMapper

        # join, transform and filter
        result_df = (
            standards_df.join(standards_description_df, on=EssentialityStandardsModel.AC_CODE, how="left")
            .transform(
                transform_mapper.apply
                if self.technology == "etsi"
                else partial(transform_mapper.apply, technology=self.technology)
            )
            .filter(self._get_result_filter())
        )

        # Get target table name based on technology
        if self.technology == "etsi":
            target_table = ""
        else:
            target_table = getattr(
                EssentialityStandardsModel,
                f"SILVER_{self.technology}_STANDARDS",
            )

        fq_table_name = fully_qualified_table_name(
            catalog=self.catalog_name,
            database=self.silver_db,
            table=target_table,
        )

        WriteDeltaTableTask(
            spark=self.spark,
            fq_table_name=fq_table_name,
            config=self.config,
            mode="overwrite",
        ).run(result_df)

    def _get_standards_filter(self):
        if self.technology == "atsc":
            return col(StandardsModel.AUTHOR) == "ATSC 3.0"
        if self.technology == "qi":
            return col(StandardsModel.STANDARD_DOCUMENT_ID).isin("Qi-v1.3", "Qi-v2.0")
        if self.technology == "wifi":
            return col(StandardsModel.AC_CODE).isin(*self.WIFI_AC_CODES)
        if self.technology == "etsi":
            return col(StandardsModel.DATA_PROVIDER) == "ETSI"
        if self.technology == "audio":
            return col(StandardsModel.AC_CODE).isin(*self.AUDIO_AC_CODES)
        if self.technology == "video":
            return col(StandardsModel.AC_CODE).isin(*self.VIDEO_AC_CODES)
        raise ValueError(f"Unsupported technology: {self.technology}")

    def _get_description_filter(self, standards_df: DataFrame):
        if self.technology == "atsc":
            ac_code_list = (
                standards_df.select(col(EssentialityStandardsModel.AC_CODE))
                .distinct()
                .rdd.map(lambda r: r[0])
                .collect()
            )
            return col(StandardsDescriptionModel.AC_CODE).isin(ac_code_list)
        if self.technology == "audio":
            return col(StandardsDescriptionModel.AC_CODE).isin(*self.AUDIO_AC_CODES)
        if self.technology == "video":
            return col(StandardsDescriptionModel.AC_CODE).isin(*self.VIDEO_AC_CODES)
        return None

    def _get_result_filter(self):
        filter_non_null_description = col(EssentialityStandardsModel.DESCRIPTION).isNotNull() & (
            length(col(EssentialityStandardsModel.DESCRIPTION)) >= self.MIN_NUMBER_CHARACTERS_IN_STANDARD_DESCRIPTION
        )

        if self.technology in {"atsc", "qi", "wifi", "audio", "video"}:
            return filter_non_null_description

        if self.technology == "etsi":
            return (
                filter_non_null_description
                & col(EssentialityStandardsModel.STANDARD_DOCUMENT_NUMBER).isNotNull()
                & (col(EssentialityStandardsModel.STANDARD_DOCUMENT_NUMBER) != "")
            )

        raise ValueError(f"Unsupported technology: {self.technology}")

    def get_standards(self, filter_condition) -> DataFrame:
        """
        Load and filter standards from Delta table.

        Args:
            filter_condition: PySpark Column condition to filter standards

        Returns:
            DataFrame with selected standards columns
        """
        df = ReadDeltaTableTask(
            spark=self.spark,
            fq_source_table=fully_qualified_table_name(
                catalog=self.catalog_name,
                database=self.silver_db,
                table=StandardsModel.DELTA_PATH,
            ),
            streaming=False,
        ).run()

        return df.filter(filter_condition).select(
            col(EssentialityStandardsModel.AC_CODE),
            col(EssentialityStandardsModel.STANDARD_DOCUMENT_ID),
            col(EssentialityStandardsModel.PUBLICATION_DATE),
            col(EssentialityStandardsModel.DESCRIPTION).alias("normalDescription"),
        )

    def get_standards_description(self, filter_condition) -> DataFrame:
        """
        Load and filter standards descriptions from Delta table.

        Args:
            filter_condition: PySpark Column condition to filter descriptions

        Returns:
            DataFrame with AC_CODE and standardsDescription columns
        """
        # Load standards description table
        df = ReadDeltaTableTask(
            spark=self.spark,
            fq_source_table=fully_qualified_table_name(
                catalog=self.catalog_name,
                database=self.silver_db,
                table=StandardsDescriptionModel.PATH,
            ),
            streaming=False,
        ).run()

        # Filter by and select required columns
        return df.filter(filter_condition).select(
            col(StandardsDescriptionModel.AC_CODE),
            col(StandardsDescriptionModel.DESCRIPTION).alias("standardsDescription"),
        )
