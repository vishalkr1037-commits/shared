import gc
import logging
import os
from typing import Any, Dict

import numpy as np
from gensim.corpora import Dictionary
from gensim.models import TfidfModel, Word2Vec
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.read_delta_table_task import (
    ReadDeltaTableTask,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import ArrayType, FloatType, StringType, StructField, StructType
from tqdm import tqdm

import src.declarations.models.silver.essentiality.essentiality_consolidated as ConsolidatedModel
import src.declarations.models.silver.essentiality.sep_vector as model
from src.declarations.mappers.silver.essentiality import sep_vector_mapper as mapper
from src.declarations.models.silver.essentiality import sep_vector

logger = logging.getLogger("SEPScoringProcessor")


# Tech-specific vectorization configurations
TECH_VECTOR_CONFIG = {
    "atsc": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS_ABS,
        "token_set": "claims_and_abstract_std",
        "use_tfidf": False,
        "use_svd": True,
    },
    "audio": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS_ABS,
        "token_set": "claims_and_abstract_std",
        "use_tfidf": False,
        "use_svd": False,
    },
    "etsi": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS_ABS,
        "token_set": "claims_and_abstract_std",
        "use_tfidf": True,
        "use_svd": True,
    },
    "qi": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS,
        "token_set": "claims_only_std",
        "use_tfidf": True,
        "use_svd": False,
    },
    "video": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS,
        "token_set": "claims_only_std",
        "use_tfidf": False,
        "use_svd": True,
    },
    "wifi": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS,
        "token_set": "claims_only_std",
        "use_tfidf": False,
        "use_svd": True,
    },
}


def load_model_artifacts(model_name: str, models_dir: str, use_tfidf: bool = False) -> Dict[str, Any]:
    logger.info("Loading pre-trained models and enhancement artifacts...")

    models = {}

    # Direct path to model directory
    model_subdir = os.path.join(models_dir, model_name)

    if not os.path.isdir(model_subdir):
        logger.warning(f"Directory not found for model '{model_name}' at {model_subdir}. Skipping.")
        return models

    logger.info(f"  Looking for model in: {model_subdir}")

    models[model_name] = {}
    try:
        # Try direct path first, then nested
        candidate_model_paths = [
            f"{model_subdir.rstrip('/')}/full_model.model",
            f"{model_subdir.rstrip('/')}/{model_name}/full_model.model",
        ]
        model_path = next((p for p in candidate_model_paths if os.path.isfile(p)), None)

        if not model_path:
            raise FileNotFoundError(f"full_model.model not found in {candidate_model_paths}")

        # Determine base path for TF-IDF files (same directory as model)
        model_base_dir = os.path.dirname(model_path)
        dict_path = os.path.join(model_base_dir, "tfidf_dictionary.dict")
        tfidf_path = os.path.join(model_base_dir, "tfidf_model.tfidf")

        logger.info(f"  Attempting to load model from: {model_path}")
        models[model_name]["model"] = Word2Vec.load(model_path)
        logger.info(f"  ✓ Successfully loaded complete {model_name} model.")

        if use_tfidf:
            models[model_name]["dictionary"] = Dictionary.load(dict_path)
            models[model_name]["tfidf_model"] = TfidfModel.load(tfidf_path)
            logger.info(f"    ✓ Loaded TF-IDF components for {model_name}.")

    except Exception as e:
        logger.error(f"Could not load artifacts for model {model_name}. Error: {e}")
        if model_name in models:
            del models[model_name]

    return models


def get_document_vector(models: Dict[str, Any], model_name: str, tokens: list, use_tfidf: bool = False) -> np.ndarray:
    model_artifacts = models.get(model_name)
    if not model_artifacts:
        return None

    model = model_artifacts["model"]
    wv = model.wv
    vector_size = wv.vector_size

    if use_tfidf and "tfidf_model" in model_artifacts:
        dictionary = model_artifacts["dictionary"]
        tfidf_model = model_artifacts["tfidf_model"]

        tfidf_weights = {dictionary.get(idx): weight for idx, weight in tfidf_model[dictionary.doc2bow(tokens)]}
        weighted_vectors = [wv[t] * tfidf_weights.get(t, 0.0) for t in tokens if t in wv]

        if not weighted_vectors:
            return np.zeros(vector_size)
        doc_vector = np.sum(weighted_vectors, axis=0)
        norm = np.linalg.norm(doc_vector)
        return doc_vector / norm if norm > 0 else np.zeros(vector_size)
    else:
        vectors = [wv[token] for token in tokens if token in wv]
        return np.mean(vectors, axis=0) if vectors else np.zeros(vector_size)


def process_dataframe_vectorize(
    df: DataFrame, models: Dict[str, Any], token_col: str, id_col: str, use_tfidf: bool = False
) -> list:
    results = []
    row_count = df.count()
    logger.info(f"Processing {row_count} rows... (TF-IDF enabled: {use_tfidf})")

    for row in tqdm(df.select(id_col, token_col).toLocalIterator(), total=row_count, desc="Vectorizing Texts"):
        tokens = row[token_col] if row[token_col] is not None else []
        record = {id_col: row[id_col]}
        for model_name in models.keys():
            vector = get_document_vector(models, model_name, tokens, use_tfidf)
            if vector is not None:
                record[model_name] = vector.tolist()
        results.append(record)
    return results


def load_tokenized_text(
    spark: SparkSession, tech: str, table_name: str, catalog_name: str, source_db_name: str
) -> DataFrame:
    logger.info(f"Loading tokenized {table_name} for {tech}...")
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table=table_name),
        streaming=False,
    ).run()

    df = df.filter(F.col("tech") == tech)
    logger.info(f"  ✓ Filtered {df.count()} records for {tech}")

    return df


def generate_vectors(
    spark: SparkSession,
    input_df: DataFrame,
    model_name: str,
    models_dir: str,
    use_tfidf: bool = False,
    use_svd: bool = False,
) -> tuple:
    logger.info(f"Generating vectors using {model_name}...")

    models = load_model_artifacts(model_name, models_dir, use_tfidf)
    distinct_input_df = input_df.select("document_id", "processed_tokens").distinct()

    vectorized_data = process_dataframe_vectorize(
        distinct_input_df, models, "processed_tokens", "document_id", use_tfidf
    )

    schema_fields = [StructField("document_id", StringType(), False)]
    model_cols = list(models.keys())

    if not model_cols:
        raise ValueError(f"No models loaded from {models_dir}")

    for model_name_col in model_cols:
        schema_fields.append(StructField(model_name_col, ArrayType(FloatType()), True))

    output_schema = StructType(schema_fields)

    del models
    gc.collect()

    result_spark_df = spark.createDataFrame(vectorized_data, schema=output_schema)

    if use_svd:
        result_spark_df = mapper.apply_multiple_svd_enhancements(result_spark_df, model_cols, models_dir)
        logger.info("✓ SVD enhancement applied")

    return result_spark_df, model_cols


def process(
    spark: SparkSession,
    tech: str,
    catalog_name: str,
    target_db_name: str,
    config: Dict[str, Any],
    models_dir_override: str = None,
    model_name: str = None,
    token_set_type: str = None,
    use_tfidf: bool = None,
    use_svd: bool = None,
):
    logger.info(f"\n{'█' * 80}")
    logger.info(f"SEP SCORING VECTOR GENERATION FOR {tech.upper()}")
    logger.info(f"{'█' * 80}")

    # Get tech config and apply overrides
    tech_config = TECH_VECTOR_CONFIG.get(tech, {})
    model_name = model_name or tech_config.get("model_name", "Word2Vec_Claims")
    token_set_type = token_set_type or tech_config.get("token_set", "claims_only_std")
    use_tfidf = use_tfidf if use_tfidf is not None else tech_config.get("use_tfidf", False)
    use_svd = use_svd if use_svd is not None else tech_config.get("use_svd", True)

    logger.info(
        f"Using config: model_name={model_name}, token_set={token_set_type}, use_tfidf={use_tfidf}, use_svd={use_svd}"
    )

    try:
        if models_dir_override:
            models_dir_dbfs = models_dir_override
            logger.info(f"Using custom models directory: {models_dir_dbfs}")
        else:
            models_dir_dbfs = mapper.get_models_directory(tech, catalog_name, target_db_name)
            logger.info(f"Using Volume path: {models_dir_dbfs}")

        logger.info(f"\nStep 1: Loading tokenized text for {tech}...")
        tech_dfs = {
            "claims": load_tokenized_text(
                spark, tech, ConsolidatedModel.PREPROCESSED_CLAIMS_TABLE, catalog_name, target_db_name
            ),
            "abstract_title": load_tokenized_text(
                spark, tech, ConsolidatedModel.PREPROCESSED_ABS_TITLE_TABLE, catalog_name, target_db_name
            ),
            "std": load_tokenized_text(
                spark, tech, ConsolidatedModel.PREPROCESSED_STD_TEXT_TABLE, catalog_name, target_db_name
            ),
        }
        logger.info("  ✓ Loaded all text types")

        logger.info("\nStep 2: Preparing token sets...")
        final_dfs = mapper.prepare_token_sets(tech_dfs["claims"], tech_dfs["abstract_title"], tech_dfs["std"])
        logger.info("  ✓ Token sets prepared")

        # Select the appropriate token set based on config
        input_df = final_dfs.get(token_set_type, final_dfs["claims_only_std"])
        logger.info(f"Using token set: {token_set_type}")

        logger.info("\nStep 3: Generating Word2Vec vectors...")
        vectors_df, model_cols = generate_vectors(
            spark=spark,
            input_df=input_df,
            model_name=model_name,
            models_dir=models_dir_dbfs,
            use_tfidf=use_tfidf,
            use_svd=use_svd,
        )
        logger.info(f"  ✓ Generated {vectors_df.count():,} vectors")

        logger.info("\nStep 4: Applying mapper transformations...")
        vectors_df = mapper.add_tech_column(vectors_df, tech)
        vectors_df = mapper.reorder_columns(vectors_df, model_cols)
        logger.info("  ✓ Mapper transformations applied")

        logger.info("\nStep 5: Writing vectors to Delta Lake...")
        target_table = fully_qualified_table_name(catalog=catalog_name, database=target_db_name, table=model.PATH)

        logger.info(f"  Writing to: {target_table}")
        logger.info(f"  Records: {vectors_df.count():,}")

        WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="append").run(vectors_df)

        logger.info("  ✓ Successfully written")

    except Exception as e:
        logger.error(f"Error in SEP scoring vector generation: {str(e)}")
        raise
