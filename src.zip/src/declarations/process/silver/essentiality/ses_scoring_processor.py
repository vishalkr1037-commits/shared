"""
SES Scoring Processor
Orchestrates the complete SES similarity scoring pipeline
"""

import logging
from logging import config

import pyspark.sql.functions as F
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

from src.declarations.mappers.silver.essentiality import ses_scoring_mapper as mapper
from src.declarations.models.silver.essentiality import sep_vector
from src.declarations.models.silver.essentiality.ses_scoring_model import (
    SES_SCORING_SIMILARITIES_TABLE,
)
from src.declarations.utils.essentiality_utils import load_standards

logger = logging.getLogger("SESProcessor")

# Configure logger to print to console with INFO level
if not logger.handlers:
    handler = logging.StreamHandler()
    handler.setLevel(logging.INFO)
    formatter = logging.Formatter("[%(name)s] %(levelname)s: %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    logger.setLevel(logging.INFO)


# Tech-specific scoring configurations
TECH_SCORING_CONFIG = {
    "atsc": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS_ABS,
        "requires_standards": True,
    },
    "audio": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS_ABS,
        "requires_standards": False,
    },
    "etsi": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS_ABS,
        "requires_standards": False,
    },
    "qi": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS,
        "requires_standards": True,
    },
    "video": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS,
        "requires_standards": False,
    },
    "wifi": {
        "model_name": sep_vector.VECTORS_WORD2VEC_CLAIMS,
        "requires_standards": False,
    },
}

# Fixed checkpoint directory to reduce lineage during batch processing
CHECKPOINT_DIR = "dbfs:/tmp/ses_scoring_checkpoint"


def load_data(
    spark: SparkSession, tech: str, catalog_name: str, target_db_name: str, use_standards_join: bool = False
) -> dict:
    """
    Load declarations, vectors, and optionally standards data

    Args:
        spark: SparkSession
        tech: Technology identifier
        catalog_name: Databricks catalog name
        target_db_name: Databricks database name
        use_standards_join: If True, load standards for get_most_meaningful_standard_document_id join

    Returns:
        Dictionary with 'declarations', 'vectors', and optionally 'standards' DataFrames
    """
    # Load declarations
    try:
        decl_path = f"{tech}_declarations_without_most_meaningful"
        declarations_df = spark.read.format("delta").load(
            f"abfs://raw@lnipdevstorage.dfs.core.windows.net/release/test/essentiality_v2/{decl_path}"
        )
        logger.info(f"✓ Loaded declarations for {tech}")
    except Exception as e:
        logger.error(f"Could not load declarations: {e}")
        raise

    # Load vectors from SEP vector processor output
    try:
        vectors_table = f"{catalog_name}.{target_db_name}.sep_scoring_vectors"
        vectors_df = spark.table(vectors_table).filter(F.col("tech") == tech)
        # Split document_id by pipe separator into main_id and sub_id
        vectors_df = vectors_df.withColumn("main_id", F.split(F.col("document_id"), "\\|").getItem(0)).withColumn(
            "sub_id", F.split(F.col("document_id"), "\\|").getItem(1)
        )
        logger.info(f"✓ Loaded vectors for {tech}")
    except Exception as e:
        logger.error(f"Could not load vectors table: {e}")
        raise

    result = {"declarations": declarations_df, "vectors": vectors_df}

    # Load standards if needed (for ATSC-like technologies)
    if use_standards_join:
        try:
            # standards_table = f"{catalog_name}.{target_db_name}.preprocessed_std_text"
            # standards_df = spark.table(standards_table).filter(F.col("tech") == tech)
            standards_df = load_standards(spark, tech, f"{tech}_declarations")

            result["standards"] = standards_df
            logger.info(f"✓ Loaded standards for {tech}")
        except Exception as e:
            logger.error(f"Could not load standards table: {e}")
            raise

    return result


def process(
    spark: SparkSession,
    tech: str,
    model_name: str,
    catalog_name: str,
    target_db_name: str,
    top_k: int = 3,
    use_standards_join: bool = False,
) -> str:
    """
    Execute complete SES scoring pipeline with automatic data loading

    Args:
        spark: SparkSession
        tech: Technology identifier (wifi, etsi, atsc, etc.)
        model_name: Name of vector model to use
        catalog_name: Databricks catalog name
        target_db_name: Databricks database name
        top_k: Number of top results per ID
        use_standards_join: If True, join with standards table first (for ATSC). If False, skip join (for WiFi)

    Returns:
        Output table name where results were written
    """
    try:
        logger.info(f"Starting SES scoring pipeline for {tech}...")

        # Load data
        logger.info("Loading data...")
        data = load_data(spark, tech, catalog_name, target_db_name, use_standards_join)
        declarations_df = data["declarations"]
        vectors_df = data["vectors"]

        # Step 1: Get most meaningful standard document ID (if needed for ATSC-like technologies)
        if use_standards_join:
            logger.info("Step 1: Getting most meaningful standard document ID...")
            standards_df = data["standards"]
            declarations_df = mapper.get_most_meaningful_standard_document_id(declarations_df, standards_df)
            step_offset = 1
        else:
            step_offset = 0

        # Step 1/2: Pair declarations with vectors
        logger.info(f"Step {1 + step_offset}: Pairing declarations with vectors...")
        paired_df = mapper.pair_declarations_with_vectors(declarations_df, vectors_df, model_name)

        # Step 2/3: Filter by matched sections
        logger.info(f"Step {2 + step_offset}: Filtering by matched sections...")
        filtered_df = mapper.filter_by_matched_sections(paired_df)

        # Step 3/4: Calculate cosine similarities
        logger.info(f"Step {3 + step_offset}: Calculating cosine similarities...")
        similarity_df = mapper.calculate_similarities(filtered_df)

        # Step 4/5: Get top-k results
        logger.info(f"Step {4 + step_offset}: Getting top-{top_k} results...")
        top_k_df = mapper.get_top_k_results(similarity_df, k=top_k)

        # Step 5/6: Reorder columns
        logger.info(f"Step {5 + step_offset}: Reordering columns...")
        result_df = mapper.reorder_columns(top_k_df)

        # Step 6/7: Write results
        logger.info(f"Step {6 + step_offset}: Writing results...")
        output_table = f"{catalog_name}.{target_db_name}.{SES_SCORING_SIMILARITIES_TABLE}"

        result_df.write.format("delta").mode("overwrite").option("mergeSchema", "true").saveAsTable(output_table)

        logger.info(f"✓ SES scoring complete. Results saved to {output_table}")

        return output_table

    except Exception as e:
        logger.error(f"Error in SES scoring pipeline: {e}", exc_info=True)
        raise


def process_batch(
    spark: SparkSession,
    tech: str,
    model_name: str,
    catalog_name: str,
    target_db_name: str,
    top_k: int = 3,
    batch_partitions: list = None,
    use_standards_join: bool = False,
) -> None:
    """
    Process SES scoring in batches and write to table storage

    Args:
        spark: SparkSession
        tech: Technology identifier
        model_name: Name of vector model to use
        catalog_name: Databricks catalog name
        target_db_name: Databricks database name
        top_k: Number of top results per ID
        batch_partitions: List of batch identifiers to process (e.g., ['0a', '0b', ...])
        use_standards_join: If True, join with standards table first (for ATSC). If False, skip join (for WiFi)
    """
    if batch_partitions is None:
        batch_partitions = [str(i) for i in range(10)] + ["a", "b", "c", "d", "e", "f", "t"]

    logger.info(f"Processing {len(batch_partitions)} batches for {tech}...")

    # Configure checkpointing once per run using fixed tmp location
    try:
        spark.sparkContext.setCheckpointDir(CHECKPOINT_DIR)
        logger.info(f"Checkpoint dir set to {CHECKPOINT_DIR}")
    except Exception as e:
        logger.warning(f"Unable to set checkpoint dir {CHECKPOINT_DIR}: {e}")

    # Load data once
    data = load_data(spark, tech, catalog_name, target_db_name, use_standards_join)
    declarations_df = data["declarations"]
    vectors_df = data["vectors"]
    standards_df = data.get("standards") if use_standards_join else None

    # Global diagnostics removed to avoid expensive counts

    for batch_id in batch_partitions:
        try:
            logger.info(f"Processing batch: {batch_id}")

            # Filter declarations by batch
            batch_declarations = declarations_df.filter(F.col("id").startswith(batch_id))
            logger.info(f"Batch {batch_id}: declarations filtered")

            # Get most meaningful standard document ID if needed (for ATSC-like technologies)
            if use_standards_join:
                batch_declarations = mapper.get_most_meaningful_standard_document_id(batch_declarations, standards_df)

            # Pair with vectors
            paired_df = mapper.pair_declarations_with_vectors(batch_declarations, vectors_df, model_name)
            logger.info(f"Batch {batch_id}: pairing complete")

            # Filter by matched sections
            filtered_df = mapper.filter_by_matched_sections(paired_df)
            logger.info(f"Batch {batch_id}: section filter complete")

            # Optional checkpoint to cut lineage and speed later stages
            filtered_df = filtered_df.checkpoint(eager=True)
            logger.info("Batch %s: checkpointed filtered_df", batch_id)

            # Calculate similarities and get top-k in one step
            top_k_df = mapper.find_top_k_similarities(filtered_df, k=top_k)
            logger.info(f"Batch {batch_id}: top-{top_k} selection complete")

            # Add tech column to results
            result_df = top_k_df.withColumn("tech", F.lit(tech))
            target_table = fully_qualified_table_name(
                catalog=catalog_name, database=target_db_name, table=SES_SCORING_SIMILARITIES_TABLE
            )

            # target_table = "personal_dev.shankarg.ses_scoring_similarities_etsi"
            WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="append").run(result_df)

            # No caching, so no unpersist required

            logger.info(f"\u2713 Batch {batch_id} complete")

        except Exception as e:
            logger.error(f"Error processing batch {batch_id}: {e}", exc_info=True)
            continue

    logger.info("✓ All batches processed")
