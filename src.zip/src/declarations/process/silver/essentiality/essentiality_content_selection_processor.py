import logging
from functools import partial

from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.read_delta_table_task import (
    ReadDeltaTableTask,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window

from src.declarations.mappers.silver.essentiality.essentiality_top3_claim_chart_mapper import (
    apply as TopThreeClaimChartMapper,
)
from src.declarations.mappers.silver.essentiality.semantic_similarity_scores_with_text_mapper import (
    apply as SemsimWithTextMapper,
)
from src.declarations.models.silver.essentiality import (
    normalized_semantic_similarity_scores as NormalizedSESModel,
)
from src.declarations.models.silver.essentiality import (
    semantic_similarity_scores_with_text as SemanticSimilarityScoresWithTextModel,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("essentiality_semantic_score_with_text_processor")


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    technology: str,
    config: PipelineConfig,
):
    """
    Process semantic similarity scores with text data.

    Steps:
    1. Load and join semantic scores with declarations data
    2. Apply mapper to parse claims and sections
    3. Add score ranking per ID
    4. Filter out 'full' sections
    5. Aggregate top scores into lists
    6. Keep only top-ranked record per ID and join with aggregated data
    """
    if not technology:
        raise ValueError("tech must be provided")

    # Define window for score ranking within each ID
    declaration_score_window = Window.partitionBy("id").orderBy(F.col("score").desc())

    # Load source data
    semantic_score_df = get_normalized_score_data(spark, catalog_name, silver_db_name, technology)
    declarations_df = get_declarations_data(spark, catalog_name, silver_db_name, technology)
    without_most_meaningful_df = get_without_most_meaningful_data(spark, catalog_name, silver_db_name, technology)

    # Join all data sources and apply transformations
    result = (
        semantic_score_df.join(without_most_meaningful_df, on=["id"], how="left")
        .join(declarations_df, on=["most_meaningful_standard_document_id"], how="left")
        .select(
            "id",
            "score",
            "most_meaningful_standard_document_id",
            "section_reference",
            "claim_id",
            "section",
            "claims",
            "most_meaningful_section_array",
            "standard_document_id",
            "document_origin",
        )
        .transform(
            partial(SemsimWithTextMapper, technology=technology)
        )  # Parse claims and sections, add predictions based on technology
        .withColumn("score_rank", F.row_number().over(declaration_score_window))
        .filter(F.col("section_number") != "full")
    )

    # Aggregate top scores into lists per ID
    semantic_score_grouped_df = result.transform(TopThreeClaimChartMapper)

    # Keep only the top-ranked record and join with aggregated lists
    result = (
        result.filter(F.col("score_rank") == 1)  # Keep only top-ranked record per ID
        .join(semantic_score_grouped_df, on=["id"], how="inner")  # Add aggregated lists
        .drop("score_rank")  # Remove temporary ranking column
    )

    # Get target table name based on technology
    target_table = getattr(
        SemanticSimilarityScoresWithTextModel,
        f"SILVER_{technology}_SEMANTIC_SIMILARITY_SCORE_WITH_TEXT",
    )

    fq_table_name = fully_qualified_table_name(
        catalog=catalog_name,
        database=silver_db_name,
        table=target_table,
    )

    logger.info(f"Writing result to {fq_table_name}")

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fq_table_name,
        config=config,
        mode="overwrite",
    ).run(result)


def get_normalized_score_data(
    spark: SparkSession,
    catalog_name: str,
    source_db_name: str,
    technology: str,
):
    """Load normalized semantic similarity scores for the technology."""
    source_table = getattr(
        NormalizedSESModel,
        f"SILVER_{technology}_NORMALIZED_SEMSIM",
    )
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name,
            database=source_db_name,
            table=source_table,
        ),
        streaming=False,
    ).run()
    return df


def get_declarations_data(
    spark: SparkSession,
    catalog_name: str,
    source_db_name: str,
    technology: str,
):
    """Load declarations data with most meaningful sections."""
    source_table = technology.lower() + "_declarations"
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name,
            database=source_db_name,
            table=source_table,
        ),
        streaming=False,
    ).run()

    return df.select(
        "most_meaningful_standard_document_id",
        "most_meaningful_section_array",
    ).distinct()


def get_without_most_meaningful_data(
    spark: SparkSession,
    catalog_name: str,
    source_db_name: str,
    technology: str,
):
    """Load declarations without most meaningful data."""
    source_table = technology.lower() + "_declarations_without_most_meaningful"
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name,
            database=source_db_name,
            table=source_table,
        ),
        streaming=False,
    ).run()

    return df.select(
        "id",
        "section",
        "claims",
        "standard_document_id",
        "document_origin",
    )
