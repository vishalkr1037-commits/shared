import logging

from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.read_delta_table_task import (
    ReadDeltaTableTask,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import DoubleType

from src.declarations.mappers.silver.essentiality.score_normalization_mapper import (
    apply as NormalizedSESMapper,
)
from src.declarations.models.silver.essentiality import (
    normalized_semantic_similarity_scores as NormalizedSESModel,
)
from src.declarations.models.silver.essentiality import semsim as semsimModel

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("essentiality_score_normalization_scaling_processor")


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    technology: str,
    config: PipelineConfig,
):
    if not technology:
        raise ValueError("tech must be provided")

    semantic_score_df = get_semantic_score_data(spark, catalog_name, silver_db_name, technology).transform(
        NormalizedSESMapper
    )

    target_table = getattr(
        NormalizedSESModel,
        f"SILVER_{technology}_NORMALIZED_SEMSIM",
    )

    fq_table_name = fully_qualified_table_name(
        catalog=catalog_name,
        database=silver_db_name,
        table=target_table,
    )

    logger.info(f"Writing result to {fq_table_name}")

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fq_table_name,
        config=config,
        mode="overwrite",
    ).run(semantic_score_df)


def get_semantic_score_data(
    spark: SparkSession,
    catalog_name: str,
    source_db_name: str,
    technology: str,
):
    source_table = getattr(
        semsimModel,
        f"SILVER_{technology}_SEMSIM",
    )
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name,
            database=source_db_name,
            table=source_table,
        ),
        streaming=False,
    ).run()

    # Use upper() on BOTH sides for case-insensitive comparison
    return df.withColumn(semsimModel.SCORE, F.col(semsimModel.SCORE).cast(DoubleType())).select(
        semsimModel.ID,
        semsimModel.PUBLICATION_NUMBER,
        semsimModel.CLAIM_ID,
        semsimModel.MOST_MEANINGFUL_STANDARD_DOCUMENT_ID,
        semsimModel.SECTION_REFERENCE,
        semsimModel.SCORE,
    )
