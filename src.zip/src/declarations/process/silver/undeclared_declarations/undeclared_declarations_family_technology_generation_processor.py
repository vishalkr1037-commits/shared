from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.silver.declarations.declaration_family_technology_generation_mapper as UndeclaredDeclarationsFamilyTechnologyGenerationMapper
import src.declarations.models.silver.undeclared_declarations.undeclared_declarations_family_technology_generation as UndeclaredDeclarationsFamilyTechnologyGeneration
from src.declarations.models.bronze.patents import patents_index as PatentIndex


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):

    undeclared_declarations_df = get_undeclared_patents(
        spark=spark,
        catalog_name=catalog_name,
        silver_db_name=silver_db_name,
    )

    list_all_publications_ids = get_all_publication(undeclared_declarations_df)

    all_involved_family_members_df = get_all_family_members(
        spark, catalog_name, silver_db_name, list_all_publications_ids
    )

    undeclared_declarations_final_df = UndeclaredDeclarationsFamilyTechnologyGenerationMapper.apply(
        undeclared_declarations_df, all_involved_family_members_df
    )

    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    for col_name in columns_to_drop:
        if col_name in undeclared_declarations_final_df.columns:
            undeclared_declarations_final_df = undeclared_declarations_final_df.drop(col_name)

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=silver_db_name,
            table=UndeclaredDeclarationsFamilyTechnologyGeneration.PATH,
        ),
        config=config,
    ).run(undeclared_declarations_final_df)


def get_undeclared_patents(spark: SparkSession, catalog_name: str, silver_db_name: str) -> DataFrame:
    table_paths = [
        "undeclared_patents_avc_expansion",
        "undeclared_patents_vvc_expansion",
        "undeclared_patents_hevc_expansion",
        "undeclared_patents_wifi4_expansion",
        "undeclared_patents_wifi5_expansion",
        "undeclared_patents_wifi6_expansion",
        "undeclared_patents_wifi7_expansion",
        "undeclared_patents_qi1_expansion",
        "undeclared_patents_qi2_expansion",
        "undeclared_patents_aac_expansion",
        "undeclared_patents_opus_expansion",
        "undeclared_patents_mpeg_h_3d_expansion",
        "undeclared_patents_vp9_expansion",
        "undeclared_patents_av1_expansion",
    ]

    def read_table(path: str) -> DataFrame:
        return (
            ReadDeltaTableTask(
                spark=spark,
                fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=silver_db_name, table=path),
                streaming=False,
            )
            .run()
            .select(
                col("id"),
                col("publication_id"),
                col("technology_generation_array"),
            )
        )

    # Read and union all tables
    combined_df = None
    for path in table_paths:
        df = read_table(path)
        if combined_df is None:
            combined_df = df
        else:
            combined_df = combined_df.unionByName(df)

    return combined_df.cache()


def get_all_publication(declaration_df: DataFrame) -> list:
    rows = declaration_df.select("publication_id").distinct().na.drop().collect()
    return [row.publication_id for row in rows]


def get_all_family_members(
    spark: SparkSession, catalog_name: str, silver_db_name: str, list_all_publications_ids: list
) -> DataFrame:
    patent_index_df: DataFrame = (
        (
            ReadDeltaTableTask(
                spark=spark,
                fq_source_table=fully_qualified_table_name(
                    catalog=catalog_name,
                    database=silver_db_name,
                    table=PatentIndex.PATH,
                ),
                streaming=False,
            ).run()
        )
        .select(
            col(PatentIndex.PUBLICATION_ID),
            col(PatentIndex.INPADOC_FAMILY_ID),
        )
        .filter(col(PatentIndex.PUBLICATION_ID).isin(list_all_publications_ids))
    )
    return patent_index_df
