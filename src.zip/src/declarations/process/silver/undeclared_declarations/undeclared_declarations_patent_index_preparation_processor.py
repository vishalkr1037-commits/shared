from functools import reduce

from pyspark import StorageLevel
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql.functions import col, lit
from pyspark.sql.types import StringType
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.gold.declarations.solr_declaration_mapper as SolrDeclarationMapper
import src.declarations.mappers.silver.undeclared_declarations.undeclared_declarations_standard_doc_id_harmonized_mapper as UndeclaredDeclarationsStandardDocIdHarmonizedMapper
import src.declarations.mappers.silver.undeclared_declarations.undeclared_declarations_technology_generation_mapper as UndeclaredDeclarationsTechnologyGenerationMapper
import src.declarations.models.bronze.declarations.declarations_standard_docid_harmonized as DeclarationsStandardDocidHarmonized
import src.declarations.models.bronze.patents.patents_index as PatentsIndex
import src.declarations.models.silver.undeclared_declarations.undeclared_declarations_family_technology_generation as UndeclaredDeclarationsFamilyTechnologyGeneration
import src.declarations.models.silver.undeclared_declarations.undeclared_declarations_patent_index_preparation_model as UndeclaredDeclarationsPatentIndexPreparationModel
from src.declarations.mappers.gold.declarations.solr_declaration_companies_mapper import (
    apply as solr_declaration_companies_mapper,
)
from src.declarations.models.silver.declarations.raw_declaration_companies_harmonization import (
    RawDeclarationCompaniesHarmonizations,
)


def process(
    spark: SparkSession,
    catalog_name: str,
    bronze_db_name: str,
    silver_db_name: str,
    config: PipelineConfig,
    technology: str,
    output_path: str,
):
    # Read family technology generation data
    family_technology_generation_df = get_undeclared_family_technology_generation(spark, catalog_name, silver_db_name)
    # Read harmonized standard document IDs for video coding/WiFi
    video_coding_wifi_std_doc_id_harmonized_df = get_video_coding_standard_document_id_harmonized(
        spark, catalog_name, bronze_db_name
    )
    # Read harmonized declaring companies
    get_declaration_companies = get_harmonized_raw_declaring_companies(spark, catalog_name, silver_db_name)

    # Read and persist all artificial declarations for the given technology
    all_artificial_declarations_df = get_all_artificial_declarations(
        spark, technology, catalog_name, silver_db_name
    ).persist(StorageLevel.MEMORY_AND_DISK)
    # Get distinct publication IDs from artificial declarations
    all_artification_publication_ids = all_artificial_declarations_df.select(
        col(UndeclaredDeclarationsPatentIndexPreparationModel.PUBLICATION_ID)
    ).distinct()

    # Get patent mapping for the publication IDs and persist
    get_patent_mapping_df = get_patent_mapping(
        spark, catalog_name, silver_db_name, all_artification_publication_ids
    ).persist(StorageLevel.MEMORY_AND_DISK)

    # Drop unnecessary columns before mapping
    all_artificial_declarations_df_droped = (
        all_artificial_declarations_df.drop(col(UndeclaredDeclarationsPatentIndexPreparationModel.DECLARING_COMPANY))
        .drop(col("selected_publication_number"))
        .withColumns(
            {
                UndeclaredDeclarationsPatentIndexPreparationModel.DATA_PROVIDER: lit(None).cast(StringType()),
                UndeclaredDeclarationsPatentIndexPreparationModel.TECHNOLOGY_CLASSIFICATION: lit(None).cast(
                    StringType()
                ),
                UndeclaredDeclarationsPatentIndexPreparationModel.DARTS_IP_URL: lit(None).cast(StringType()),
            }
        )
    )

    # Apply Solr declaration mapping
    undeclared_declarations_df = SolrDeclarationMapper.apply(all_artificial_declarations_df_droped)

    # Join with family technology generation data
    undeclared_declarations_df = undeclared_declarations_df.join(
        family_technology_generation_df, UndeclaredDeclarationsPatentIndexPreparationModel.ID, "left"
    )

    # Apply technology generation mapping
    undeclared_declarations_df = UndeclaredDeclarationsTechnologyGenerationMapper.apply(undeclared_declarations_df)

    # Join with harmonized standard document IDs based on technology generation
    undeclared_declarations_with_tech_gen_df = undeclared_declarations_df.join(
        video_coding_wifi_std_doc_id_harmonized_df,
        UndeclaredDeclarationsPatentIndexPreparationModel.TECHNOLOGY_GENERATION,
        "left",
    )

    # Apply standard doc ID harmonization mapping
    undeclared_declarations_final_df = UndeclaredDeclarationsStandardDocIdHarmonizedMapper.apply(
        undeclared_declarations_with_tech_gen_df
    )

    # Join with declaring companies and patent mapping
    undeclared_declarations_final_silver_df = undeclared_declarations_final_df.join(
        get_declaration_companies, UndeclaredDeclarationsPatentIndexPreparationModel.ID, "left"
    ).join(get_patent_mapping_df, UndeclaredDeclarationsPatentIndexPreparationModel.PUBLICATION_NUMBER, "left")

    # Drop technical columns if present
    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    for col_name in columns_to_drop:
        if col_name in undeclared_declarations_final_silver_df.columns:
            undeclared_declarations_final_silver_df = undeclared_declarations_final_silver_df.drop(col_name)

    # Repartition by ID for optimized write
    undeclared_declarations_final_silver_df_repartitioned = undeclared_declarations_final_silver_df.repartition(
        UndeclaredDeclarationsPatentIndexPreparationModel.ID
    )

    # Write the final DataFrame to the Delta table
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=silver_db_name,
            table=output_path,
        ),
        config=config,
    ).run(undeclared_declarations_final_silver_df_repartitioned)


def get_all_artificial_declarations(spark: SparkSession, technology: str, catalog_name: str, source_db_name: str):
    df = choose_technology(spark, technology, catalog_name, source_db_name)
    if df is None:
        return None

    return df.withColumns(
        {
            UndeclaredDeclarationsPatentIndexPreparationModel.DATA_PROVIDER: lit(None),
            UndeclaredDeclarationsPatentIndexPreparationModel.TECHNOLOGY_CLASSIFICATION: lit(None),
            "standard_document_title": lit(None),
        }
    )


def choose_technology(spark: SparkSession, technology: str, catalog_name: str, source_db_name: str):
    if technology == "WIFI":
        return get_artificial_declarations_wifi(spark, catalog_name, source_db_name)
    elif technology == "VIDEOCODING":
        return get_artificial_declarations_video_coding(spark, catalog_name, source_db_name)
    elif technology == "QI":
        return get_artificial_declarations_qi(spark, catalog_name, source_db_name)
    elif technology == "VP9-AV1":
        return get_artificial_declarations_vp9_av1(spark, catalog_name, source_db_name)
    elif technology == "AUDIOCODING":
        return get_artificial_declarations_audio_coding(spark, catalog_name, source_db_name)
    return None


def get_artificial_declarations_wifi(spark, catalog_name, source_db_name):
    tables = [
        "undeclared_patents_wifi4_expansion",
        "undeclared_patents_wifi5_expansion",
        "undeclared_patents_wifi6_expansion",
        "undeclared_patents_wifi7_expansion",
    ]
    dfs = [
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table=table),
            streaming=False,
        ).run()
        for table in tables
    ]
    return reduce(lambda df1, df2: df1.unionByName(df2), dfs)


def get_artificial_declarations_video_coding(spark, catalog_name, source_db_name):
    tables = [
        "undeclared_patents_avc_expansion",
        "undeclared_patents_vvc_expansion",
        "undeclared_patents_hevc_expansion",
    ]
    dfs = [
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table=table),
            streaming=False,
        ).run()
        for table in tables
    ]
    return reduce(lambda df1, df2: df1.unionByName(df2), dfs)


def get_artificial_declarations_vp9_av1(spark, catalog_name, source_db_name):
    tables = ["undeclared_patents_vp9_expansion", "undeclared_patents_av1_expansion"]
    dfs = [
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table=table),
            streaming=False,
        ).run()
        for table in tables
    ]
    return reduce(lambda df1, df2: df1.unionByName(df2), dfs)


# def get_artificial_declarations_qi1(spark, catalog_name, source_db_name):
#     return ReadDeltaTableTask(
#         spark,
#         fully_qualified_table_name(catalog_name, source_db_name, "undeclared_patents_qi1_expansion"),
#         streaming=False,
#     ).run()


def get_artificial_declarations_qi(spark, catalog_name, source_db_name):
    tables = ["undeclared_patents_qi1_expansion", "undeclared_patents_qi2_expansion"]
    dfs = [
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table=table),
            streaming=False,
        ).run()
        for table in tables
    ]
    return reduce(lambda df1, df2: df1.unionByName(df2), dfs)


def get_artificial_declarations_audio_coding(spark, catalog_name, source_db_name):
    tables = [
        "undeclared_patents_aac_expansion",
        "undeclared_patents_opus_expansion",
        "undeclared_patents_mpeg_h_3d_expansion",
    ]
    dfs = [
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table=table),
            streaming=False,
        ).run()
        for table in tables
    ]
    return reduce(lambda df1, df2: df1.unionByName(df2), dfs)


def get_undeclared_family_technology_generation(spark: SparkSession, catalog_name: str, source_db_name: str):
    return ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=UndeclaredDeclarationsFamilyTechnologyGeneration.PATH
        ),
        streaming=False,
    ).run()


def get_harmonized_raw_declaring_companies(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_db_name, RawDeclarationCompaniesHarmonizations.PATH),
        streaming=False,
    ).run()

    return df.select(
        col(RawDeclarationCompaniesHarmonizations.DECLARING_ID),
        col(RawDeclarationCompaniesHarmonizations.HARMONIZED_NAME),
    ).transform(solr_declaration_companies_mapper)


def get_video_coding_standard_document_id_harmonized(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_db_name, DeclarationsStandardDocidHarmonized.PATH),
        streaming=False,
    ).run()
    return df.select(
        col(DeclarationsStandardDocidHarmonized.TECHNOLOGY_GENERATION),
        col(DeclarationsStandardDocidHarmonized.STANDARD_DOCUMENT_ID_HARMONIZED_VAL),
    )


def get_patent_mapping(
    spark: SparkSession, catalog_name, source_database, all_artification_publication_ids: DataFrame
) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, PatentsIndex.PATH),
        streaming=False,
    ).run()

    return df.join(all_artification_publication_ids, PatentsIndex.PUBLICATION_ID, "left_semi").select(
        col(PatentsIndex.PUBLICATION_NUMBER), col(PatentsIndex.PUBLICATION_YEAR)
    )
