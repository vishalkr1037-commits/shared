import logging

import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, lit
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.bronze.patents.patents_index as PatentIndex
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.models.silver.undeclared_declarations.undeclared_top10_etsi_standards as UnDeclaredTop10EtsiStandards
from src.declarations.mappers.silver.undeclared_declarations.declaration_top10_standard_expansion_mapper import (
    apply as expand_top10_standards,
)
from src.declarations.mappers.silver.undeclared_declarations.declaration_top_group_mapper import (
    apply as map_top10_groups,
)
from src.declarations.models.bronze.undeclared_declarations import (
    top_10_standards_per_committee as Top10StandardsPerCommittee,
)

# Configure the root logger
logging.basicConfig(
    level=logging.INFO,  # or logging.DEBUG for more detailed logs
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("undeclared_patent_all_index_preparation_processor")

join_condition = (
    (F.col("top10_technology_generation") == F.col("technology_generation"))
    & (F.col("top10_standard_document_id") == F.col("standard_document_id"))
    & (F.col("top10_group") == F.col("harmonized_group"))
)

join_condition_1 = (
    (F.col("top10_standard_document_id") == F.col("harmonized_standard_doc_id"))
    & (F.col("top10_technology_generation") == F.col("technology_generation"))
    & (F.col("top10_group") == F.col("harmonized_group"))
)


join_condition_final = (
    (F.col(DeclarationGoldModel.TECHNOLOGY_GENERATION) == F.col("technology_generation_remove"))
    & (F.col("standard_document_id") == F.col("standard_document_id_remove"))
    & (F.col("publication_number") == F.col("publication_number_remove"))
    & (F.col("harmonized_group") == F.col("group_remove"))
)


join_condition_stdDocId = F.col("standard_document_id") == F.col("harmonized_standard_doc_id")
join_condition_stdDocId_last = F.col("standard_document_ref") == F.col("standard_document_id")


def process(spark: SparkSession, catalog_name: str, silver_db_name: str, gold_db_name: str, config: PipelineConfig):

    declarations_data_df = get_declarations(spark, catalog_name, gold_db_name)
    declarations_data_df.cache()
    logger.info("Fetching declarations count: %d", declarations_data_df.count())
    top10_standards_df = get_top10_standards(spark, catalog_name, silver_db_name)
    logger.info("Fetching declarations count: %d", top10_standards_df.count())
    top10_standards_df.cache()

    non_declared_ts_to_be_expanded_df = (
        declarations_data_df.select(
            DeclarationGoldModel.PUBLICATION_NUMBER,
            F.col(DeclarationGoldModel.HARMONIZED_STANDARD_DOC_ID),
            F.col(DeclarationGoldModel.TECHNOLOGY_GENERATION),
            F.col("harmonized_group"),
        )
        .crossJoin(top10_standards_df)
        .dropDuplicates(
            ["publication_number", "top10_standard_document_id", "harmonized_group", "technology_generation"]
        )
        .select(
            F.col(DeclarationGoldModel.PUBLICATION_NUMBER),
            F.col(DeclarationGoldModel.TECHNOLOGY_GENERATION),
            F.col("top10_standard_document_id").alias("standard_document_id"),
            F.col("harmonized_group"),
        )
        .join(top10_standards_df, join_condition, how="inner")
        .drop("top10_standard_document_id", "top10_technology_generation", "top10_group")
    )

    logger.info("All possible declarations combination count: %d", non_declared_ts_to_be_expanded_df.count())

    already_declared_ts_from_declarations_df = (
        declarations_data_df.select(
            DeclarationGoldModel.PUBLICATION_NUMBER,
            F.col(DeclarationGoldModel.HARMONIZED_STANDARD_DOC_ID),
            F.col(DeclarationGoldModel.TECHNOLOGY_GENERATION),
            F.col("harmonized_group"),
        )
        .join(top10_standards_df, join_condition_1, how="inner")
        .dropDuplicates(["publication_number", "top10_standard_document_id"])
        .withColumnRenamed("publication_number", "publication_number_remove")
        .withColumnRenamed("harmonized_standard_doc_id", "standard_document_id_remove")
        .withColumnRenamed("technology_generation", "technology_generation_remove")
        .withColumnRenamed("harmonized_group", "group_remove")
        .drop("top10_standard_document_id", "top10_technology_generation", "top10_group")
    )

    logger.info("Existing declarations combination: %d", already_declared_ts_from_declarations_df.count())

    final_df = (
        non_declared_ts_to_be_expanded_df.join(
            already_declared_ts_from_declarations_df, join_condition_final, how="left_anti"
        )
        .join(
            declarations_data_df.select(
                F.col(DeclarationGoldModel.HARMONIZED_STANDARD_DOC_ID),
                F.col(DeclarationGoldModel.STANDARD_DOCUMENT_REF),
            ).distinct(),
            join_condition_stdDocId,
            how="left",
        )
        .drop(F.col("standard_document_id"))
        .join(get_patent_index_data(spark, catalog_name, silver_db_name), on="publication_number", how="left")
        .join(get_standards_data(spark, catalog_name, silver_db_name), join_condition_stdDocId_last, how="left")
        .withColumnRenamed("harmonized_group", "group")
        .withColumns(
            {
                "publication_date_flag": F.when(
                    F.col("publication_date") < F.col("patent_publication_date"), F.lit(True)
                ).otherwise(F.lit(False))
            }
        )
        .transform(expand_top10_standards)
    )

    logger.info("Writing %d number of records", final_df.count())

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table=UnDeclaredTop10EtsiStandards.PATH
        ),
        config=config,
        mode="overwrite",
    ).run(final_df)

    logger.info("Data written to Delta table successfully.")


def get_declarations(spark, catalog_name, gold_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=gold_db_name, table=DeclarationGoldModel.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(
            (col(DeclarationGoldModel.SSO) == lit("ETSI"))
            & (col(DeclarationGoldModel.TECHNOLOGY_GENERATION) != lit(""))
            & (col(DeclarationGoldModel.HARMONIZED_STANDARD_DOC_ID).isNotNull())
            & (col(DeclarationGoldModel.GROUP).isNotNull())
            & (col(DeclarationGoldModel.GROUP) != lit(""))
        )
        .transform(map_top10_groups)
        .select(
            DeclarationGoldModel.PUBLICATION_NUMBER,
            DeclarationGoldModel.TECHNOLOGY_GENERATION,
            F.col("harmonized_standard_doc_id"),
            DeclarationGoldModel.TECHNOLOGY_GENERATION,
            DeclarationGoldModel.STANDARD_DOCUMENT_REF,
            DeclarationGoldModel.STANDARD_PROJECT,
            F.col("harmonized_group"),
        )
        .distinct()
    )


def get_top10_standards(spark, catalog_name, silver_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=Top10StandardsPerCommittee.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            col(Top10StandardsPerCommittee.STANDARD_DOCUMENT_ID).alias("top10_standard_document_id"),
            col(Top10StandardsPerCommittee.TECHNOLOGY_GENERATION).alias("top10_technology_generation"),
            col(Top10StandardsPerCommittee.GROUP).alias("top10_group"),
        )
    )


def get_patent_index_data(spark, catalog_name, silver_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=PatentIndex.PATH
            ),
            streaming=False,
        )
        .run()
        .select(col(PatentIndex.PUBLICATION_NUMBER), col(PatentIndex.PUBLICATION_DATE).alias("patent_publication_date"))
    )


def get_standards_data(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table="standards"
            ),
            streaming=False,
        )
        .run()
        .select(col("standard_document_id"), col("publication_date"))
    )
