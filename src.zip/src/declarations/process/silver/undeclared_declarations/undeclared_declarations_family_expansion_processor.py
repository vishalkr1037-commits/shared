import logging

from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.silver.undeclared_declarations.undeclared_declarations_family_expansion as UndeclaredModel
from src.declarations.models.bronze.patents import patents_index as PatentIndex
from src.declarations.process.silver.declarations.declaration_sep_family_expansion_processor import (
    get_all_family_members,
    get_blacklisted_family_publication_numbers,
    get_patents_index,
    get_simple_family_ids_from_declarations,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("undeclared_declarations_family_expansion_processor")


def process(
    spark: SparkSession,
    catalog_name: str,
    bronze_db_name: str,
    silver_db_name: str,
    output_path: str = None,
    config: PipelineConfig = None,
):
    logger.info("Expanding undeclared declarations by family...")
    spark.sparkContext.setCheckpointDir("/dbfs/tmp/checkpoints")

    # Get undeclared patents data
    undeclared_declarations_df = get_undeclared_patents(
        spark=spark, catalog_name=catalog_name, source_db_name=silver_db_name, undeclared_table=output_path
    )

    undeclared_declarations_df = undeclared_declarations_df.checkpoint(eager=True)
    logger.info("Reading undeclared declarations is finished.")

    # Get patent index and blacklisted data - reusing functions from sep_family_expansion_processor
    patent_document_values_df = get_patents_index(spark, catalog_name, silver_db_name)
    logger.info("Reading patent document values is finished.")

    blacklisted_family_publication_numbers_df = get_blacklisted_family_publication_numbers(
        spark, catalog_name, bronze_db_name
    )
    logger.info("Reading blacklisted family publication numbers is finished.")

    simple_family_ids = get_simple_family_ids_from_declarations(undeclared_declarations_df)

    # Make sure the simple_family_ids DataFrame has the correct column name for joining
    if PatentIndex.SIMPLE_FAMILY_ID not in simple_family_ids.columns:
        simple_family_ids = simple_family_ids.withColumnRenamed(
            simple_family_ids.columns[0], PatentIndex.SIMPLE_FAMILY_ID
        )

    logger.info("Getting simple family IDs from declarations is finished.")

    all_involved_family_members = get_all_family_members(
        patent_document_values_df,
        blacklisted_family_publication_numbers_df,
        simple_family_ids,
    )

    all_involved_family_members = all_involved_family_members.checkpoint(eager=True)
    patent_document_values_df.unpersist()
    logger.info("Getting all family members is finished.")

    # Prepare result data with family expansion
    result = (
        undeclared_declarations_df.repartition(PatentIndex.SIMPLE_FAMILY_ID)
        .groupBy(PatentIndex.SIMPLE_FAMILY_ID)
        .agg(F.collect_set(UndeclaredModel.ID).alias(UndeclaredModel.ID))
        .cache()
    )

    # Join with family members
    result = result.join(all_involved_family_members, UndeclaredModel.JOIN_SEQ_FAM_ID, "left").cache()

    logger.info("Joining with family members is finished.")

    # Explode publication IDs
    result = result.withColumn(UndeclaredModel.PUBLICATION_ID, F.explode(F.col(UndeclaredModel.PUBLICATION_ID))).cache()

    logger.info("Exploding publication IDs is finished.")

    # Explode declaration IDs
    result = (
        result.repartition(UndeclaredModel.ID)
        .withColumn(UndeclaredModel.ID, F.explode(F.col(UndeclaredModel.ID)))
        .cache()
    )
    explode_decl_count = result.count()
    logger.info(f"Result after exploding declaration IDs count: {explode_decl_count}")
    logger.info("Exploding declaration IDs is finished.")

    # Get all declarations by ID
    all_declarations_by_id = (
        undeclared_declarations_df.select(UndeclaredModel.ID, UndeclaredModel.STANDARD_DOCUMENT_ID)
        .repartition(UndeclaredModel.ID)
        .cache()
    )

    # Get all publication numbers
    all_publication_numbers = (
        undeclared_declarations_df.select(UndeclaredModel.PUBLICATION_NUMBER, UndeclaredModel.PUBLICATION_ID)
        .distinct()
        .repartition(UndeclaredModel.PUBLICATION_ID)
        .cache()
    )

    # Join with declarations by ID
    result = (
        result.join(all_declarations_by_id, UndeclaredModel.JOIN_SEQ_ID, "left")
        .select(UndeclaredModel.PUBLICATION_ID, UndeclaredModel.ID, UndeclaredModel.STANDARD_DOCUMENT_ID)
        .cache()
    )

    logger.info("Joining with declarations by ID is finished.")

    # Create results with ID
    result_without_id = (
        undeclared_declarations_df.drop(
            UndeclaredModel.PUBLICATION_NUMBER, UndeclaredModel.PUBLICATION_ID, UndeclaredModel.STANDARD_DOCUMENT_ID
        )
        .join(result, UndeclaredModel.JOIN_SEQ_ID, "inner")
        .join(all_publication_numbers, UndeclaredModel.JOIN_SEQ_PUB_ID, "inner")
    )

    result_without_id = result_without_id.checkpoint(eager=True)
    logger.info("Joining all declarations by ID and publication numbers is finished.")

    # Generate IDs
    result_with_id = result_without_id.withColumnRenamed(UndeclaredModel.ID, UndeclaredModel.TAKE_DECLARATION_DATA_FROM)
    result_with_id = result_with_id.withColumn(UndeclaredModel.ID, generate_declaration_id())
    result_with_id = result_with_id.select(
        UndeclaredModel.PUBLICATION_ID,
        UndeclaredModel.ID,
        UndeclaredModel.STANDARD_DOCUMENT_ID,
        UndeclaredModel.TAKE_DECLARATION_DATA_FROM,
    )

    # Filter publications
    publication_to_be_filtered = result_with_id.join(
        undeclared_declarations_df.select(UndeclaredModel.ID), UndeclaredModel.JOIN_SEQ_ID, "inner"
    ).select(*UndeclaredModel.RESULT_COLS)

    # Prepare final result
    result_final = (
        result.dropDuplicates([UndeclaredModel.PUBLICATION_ID, UndeclaredModel.STANDARD_DOCUMENT_ID])
        .withColumnRenamed(UndeclaredModel.ID, UndeclaredModel.TAKE_DECLARATION_DATA_FROM)
        .select(*UndeclaredModel.RESULT_COLS)
        .subtract(publication_to_be_filtered)
        .cache()
    )

    # Write result to Delta table
    repartitioned_df = result_final.repartition(UndeclaredModel.PUBLICATION_ID)

    # Use the output_path if provided, otherwise use default table name
    # Dynamically generate the target table name based on output_path
    if output_path:
        # Import the variable dynamically from the UndeclaredModel module
        target_table = getattr(UndeclaredModel, f"SILVER_FAMILY_{output_path.upper()}_EXPANSION")
    else:
        raise ValueError("output_path must be provided to generate the target table name.")

    fq_table_name = fully_qualified_table_name(catalog=catalog_name, database=silver_db_name, table=target_table)
    logger.info(f"Writing result to delta full table name {fq_table_name} is started.")
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fq_table_name,
        config=config,
        mode="overwrite",
    ).run(repartitioned_df)
    logger.info(f"Writing result to delta table {target_table} is finished.")


def generate_declaration_id():
    return F.concat_ws(
        "_",
        F.col(UndeclaredModel.STANDARD_DOCUMENT_ID),
        F.col(UndeclaredModel.STANDARD_PROJECT),
        F.initcap(F.col(UndeclaredModel.DECLARING_COMPANY)),
        F.date_format(F.col(UndeclaredModel.DECLARATION_DATE), "yyyy-MM-dd"),
        F.col(UndeclaredModel.PUBLICATION_NUMBER),
        F.concat_ws(" | ", F.col(UndeclaredModel.ISLD)),
    )


def get_undeclared_patents(spark, catalog_name, source_db_name, undeclared_table):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=undeclared_table
        ),
        streaming=False,
    ).run()

    # Get simple family IDs and join with undeclared declarations
    simple_family_ids_df = get_simple_family_ids(spark, catalog_name, source_db_name)

    return (
        df.select(*UndeclaredModel.DECLARATION_COLS)
        .distinct()
        .repartition(UndeclaredModel.PUBLICATION_ID)
        .join(simple_family_ids_df, [UndeclaredModel.PUBLICATION_ID], "left")
        .filter(F.col(PatentIndex.SIMPLE_FAMILY_ID).isNotNull())
        .cache()
    )


def get_simple_family_ids(spark, catalog_name, source_db_name):
    patents_index_df = get_patents_index(spark, catalog_name, source_db_name)
    return (
        patents_index_df.select(PatentIndex.PUBLICATION_ID, F.col(PatentIndex.SIMPLE_FAMILY_ID))
        .filter(F.col(PatentIndex.SIMPLE_FAMILY_ID).isNotNull())
        .filter(F.col(PatentIndex.SIMPLE_FAMILY_ID) > 0)
        .distinct()
        .repartition(PatentIndex.PUBLICATION_ID)
    )
