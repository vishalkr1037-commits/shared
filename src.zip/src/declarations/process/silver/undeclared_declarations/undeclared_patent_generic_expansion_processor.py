import logging

import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.silver.undeclared_declarations.undeclared_patent_expansion_mapper as UndeclaredPatentExpansionMapper
import src.declarations.models.bronze.patents.patent_family as PatentFamily
import src.declarations.models.bronze.patents.patent_status as PatentStatus
import src.declarations.models.bronze.patents.patents_index as PatentIndex
import src.declarations.models.gold.declarations.declaration_expanded_gold as DeclarationExpandedGold
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGold

logger = logging.getLogger(__name__)


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    gold_db_name: str,
    bronze_db_name: str,
    config: PipelineConfig,
    input_path: str,
    output_path: str,
    technology: str,
    technology_generation: str,
    start_date: int,
    end_date: int,
    include_expired_flag: str,
) -> DataFrame:
    logger.info(f"Creating Undeclared Patents for {technology}")

    patents_index_df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=silver_db_name, table=PatentIndex.PATH
        ),
        streaming=False,
    ).run()

    expanding_simple_family_id = (
        get_simple_family_ids(spark, catalog_name, bronze_db_name, input_path, technology)
        .join(get_publication_ids(patents_index_df), ["simple_family_id"], "left")
        .join(get_patent_status_data(spark, catalog_name, silver_db_name), ["publication_id"], "left")
    )

    if include_expired_flag:
        logger.info(f"Include the Expired Patents for {technology}")

        all_publication_ids_expanded = (
            expanding_simple_family_id.join(
                get_patent_priority_dates(spark, catalog_name, silver_db_name), ["publication_id"], "left"
            )
            .filter(
                F.when(F.lit(end_date) == 0, F.col("earliest_priority_year") >= start_date).otherwise(
                    (F.col("earliest_priority_year") >= start_date) & (F.col("earliest_priority_year") <= end_date)
                )
            )
            .select(PatentFamily.PUBLICATION_ID)
            .dropDuplicates([str(PatentFamily.PUBLICATION_ID)])
        )

        all_undeclared_publication_ids = all_publication_ids_expanded.join(
            get_declared_declarations(spark, catalog_name, gold_db_name, technology_generation),
            ["publication_id"],
            "left_anti",
        )

        final_dataset = (
            all_undeclared_publication_ids.join(get_patent_index_data(patents_index_df), ["publication_id"], "left")
            .withColumn("technology", F.lit(technology))
            .withColumn("declaration_date", F.lit(" "))
            .transform(UndeclaredPatentExpansionMapper.apply)
            .coalesce(10)
        )

        df = final_dataset

    else:
        print("Exclude the Expired Patents")
        removing_non_active_patents = (
            expanding_simple_family_id.groupBy(PatentIndex.SIMPLE_FAMILY_ID)
            .agg(
                F.collect_list(PatentFamily.PUBLICATION_ID).alias("publication_id_list"),
                F.collect_list(PatentStatus.ACTIVE).alias("active_list"),
            )
            .filter(F.array_contains(F.col("active_list"), True))
            .drop("active_list", "publication_id_list")
        )

        all_publication_ids_expanded = (
            expanding_simple_family_id.join(removing_non_active_patents, ["simple_family_id"], "inner")
            .join(get_patent_priority_dates(spark, catalog_name, silver_db_name), ["publication_id"], "left")
            .filter(
                F.when(F.lit(end_date) == 0, F.col("earliest_priority_year") >= start_date).otherwise(
                    (F.col("earliest_priority_year") >= start_date) & (F.col("earliest_priority_year") <= end_date)
                )
            )
            .select(PatentFamily.PUBLICATION_ID)
            .dropDuplicates([str(PatentFamily.PUBLICATION_ID)])
            .join(
                get_declared_declarations(spark, catalog_name, gold_db_name, technology_generation),
                ["publication_id"],
                "left_anti",
            )
            .join(get_patent_index_data(patents_index_df), ["publication_id"], "left")
            .withColumn("technology", F.lit(technology))
            .transform(UndeclaredPatentExpansionMapper.apply)
            .coalesce(10)
        )

        df = all_publication_ids_expanded

    # Add this line - call the fix_void_columns function
    df_new = fix_void_columns(df)

    fq_table_name = fully_qualified_table_name(catalog=catalog_name, database=silver_db_name, table=output_path)
    print(fq_table_name)
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(catalog=catalog_name, database=silver_db_name, table=output_path),
        config=config,
        mode="overwrite",
    ).run(df_new)


from pyspark.sql import DataFrame
from pyspark.sql.functions import lit
from pyspark.sql.types import NullType, StringType


def fix_void_columns(df: DataFrame, default_type=StringType()) -> DataFrame:
    """
    Replace void/NullType columns in a DataFrame with lit(None) of a default type.

    :param df: Input DataFrame
    :param default_type: Type to cast NullType columns into (default: StringType)
    :return: DataFrame with void columns fixed
    """
    for field in df.schema.fields:
        if isinstance(field.dataType, NullType):  # void/NullType detected
            df = df.withColumn(field.name, lit(None).cast(default_type))
    return df


def get_patent_status_data(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=PatentStatus.PATH
            ),
            streaming=False,
        )
        .run()
        .select(PatentStatus.PUBLICATION_ID, PatentStatus.ACTIVE)
    )


def get_patent_priority_dates(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=PatentFamily.PATH
            ),
            streaming=False,
        )
        .run()
        .withColumn("earliest_priority_year", F.year(F.to_date(PatentFamily.EARLIEST_PRIORITY_DATE, "yyyyMMdd")))
        .select(PatentFamily.PUBLICATION_ID, F.col("earliest_priority_year"))
        .dropDuplicates()
    )


def get_simple_family_ids(
    spark: SparkSession, catalog_name: str, source_db_name: str, input_path: str, technology: str
) -> DataFrame:
    """
    Get simple family IDs from the input path, filtered by technology that starts with the given parameter.
    Case-insensitive matching is applied.

    Args:
        spark: SparkSession
        catalog_name: Name of the catalog
        source_db_name: Name of the source database
        input_path: Path to the input data
        technology: Technology prefix to filter by

    Returns:
        DataFrame with simple_family_id column filtered by technology starting with the given parameter
    """
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(catalog=catalog_name, database=source_db_name, table=input_path),
            streaming=False,
        )
        .run()
        .filter(F.lower(F.col("technology")).startswith(F.lower(F.lit(technology))))  # Case-insensitive prefix matching
        .select(F.col("simple_family_id"))
        .dropDuplicates()
    )


def get_publication_ids(patents_index_df: DataFrame) -> DataFrame:
    return (
        patents_index_df.select(PatentIndex.PUBLICATION_ID, F.col(PatentIndex.SIMPLE_FAMILY_ID))
        .filter(F.col(PatentIndex.SIMPLE_FAMILY_ID).isNotNull())
        .filter(F.col(PatentIndex.SIMPLE_FAMILY_ID) > 0)
        .distinct()
        .repartition(PatentFamily.PUBLICATION_ID)
    )


def get_patent_index_data(patents_index_df: DataFrame) -> DataFrame:
    return patents_index_df.select(PatentIndex.PUBLICATION_NUMBER, PatentIndex.PUBLICATION_ID)


def get_declared_declarations(
    spark: SparkSession, catalog_name: str, source_db_name: str, technology_generation: str
) -> DataFrame:
    return (
        get_declarations(spark, catalog_name, source_db_name, technology_generation)
        .unionByName(get_expanded_declarations(spark, catalog_name, source_db_name, technology_generation))
        .dropDuplicates([str(DeclarationGold.PUBLICATION_ID)])
    )


def get_declarations(
    spark: SparkSession, catalog_name: str, source_db_name: str, technology_generation: str
) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationGold.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(F.col(DeclarationGold.TECHNOLOGY_GENERATION) == technology_generation)
        .select(DeclarationGold.PUBLICATION_ID, F.col(DeclarationGold.TECHNOLOGY_GENERATION))
        .drop(F.col(DeclarationGold.TECHNOLOGY_GENERATION))
        .dropDuplicates([str(DeclarationGold.PUBLICATION_ID)])
    )


def get_expanded_declarations(
    spark: SparkSession, catalog_name: str, source_db_name: str, technology_generation: str
) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationExpandedGold.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(F.col(DeclarationExpandedGold.TECHNOLOGY_GENERATION) == technology_generation)
        .select(DeclarationExpandedGold.PUBLICATION_ID, F.col(DeclarationExpandedGold.TECHNOLOGY_GENERATION))
        .drop(F.col(DeclarationExpandedGold.TECHNOLOGY_GENERATION))
        .dropDuplicates([str(DeclarationExpandedGold.PUBLICATION_ID)])
    )
