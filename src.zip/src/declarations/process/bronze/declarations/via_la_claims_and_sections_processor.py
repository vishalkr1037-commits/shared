from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, rank
from pyspark.sql.window import Window

import src.declarations.models.bronze.declarations.via_la_claims_and_sections as ViaLAClaimsAndSections
from src.declarations.mappers.bronze.declarations.via_la_claims_and_sections_mapper import (
    ViaLaClaimsAndSectionsMapper,
)
from src.declarations.models.landing.via_la_claims_and_sections_csv import (
    ViaLAClaimsAndSectionsCsv,
)
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


class ViaLAClaimAndSectionsProcessor:
    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        target_db_name: str,
        config: PipelineConfig,
    ):
        self.spark = spark
        self.catalog_name = catalog_name
        self.target_db_name = target_db_name
        self.source_csv_path = ViaLAClaimsAndSectionsCsv.PATH
        self.config = config
        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name, database=self.target_db_name, table=ViaLAClaimsAndSections.PATH
        )

    def process(self):
        df = CSVReaderTask(self.spark, ViaLAClaimsAndSectionsCsv.SCHEMA, [self.source_csv_path], file_name=True).run()

        final_df = ViaLaClaimsAndSectionsMapper.apply(df)
        window_spec = (
            Window.partitionBy("csv_file_name")
            .orderBy(col("csv_file_name").desc())
            .rowsBetween(Window.unboundedPreceding, Window.currentRow)
        )
        final_df = (
            final_df.withColumn("Rank", rank().over(window_spec))
            .filter(col("Rank") == 1)
            .drop("csv_file_name", "Rank")
            .dropDuplicates()
        )
        WriteDeltaTableTask(
            spark=self.spark, fq_table_name=self.target_table, config=self.config, mode="overwrite"
        ).run(final_df)
