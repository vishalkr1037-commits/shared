from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.models.bronze.declarations.technology_generation_to_video_coding_wifi as TechnologyGenerationToVideoCodingWifi
from src.declarations.mappers.bronze.declarations.technology_generation_to_video_coding_wifi_mapper import (
    TechnologyGenerationToVideoCodingWifiMapper,
)
from src.declarations.models.landing.technology_generation_to_video_coding_wifi_csv import (
    TechnologyGenerationToVideoCodingWifiCsv,
)
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


class TechnologyGenerationToVideoCodingWifiProcessor:

    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        target_db_name: str,
        config: PipelineConfig,
    ):
        self.spark = spark
        self.catalog_name = catalog_name
        self.target_db_name = target_db_name
        self.source_csv_path = TechnologyGenerationToVideoCodingWifiCsv.PATH
        self.config = config
        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name,
            database=self.target_db_name,
            table=TechnologyGenerationToVideoCodingWifi.PATH,
        )

    def process(self):
        df = CSVReaderTask(self.spark, TechnologyGenerationToVideoCodingWifiCsv.SCHEMA, [self.source_csv_path]).run()
        final_df = TechnologyGenerationToVideoCodingWifiMapper.apply(df)

        WriteDeltaTableTask(
            spark=self.spark, fq_table_name=self.target_table, config=self.config, mode="overwrite"
        ).run(final_df)
