from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.models.bronze.declarations.technology_to_video_coding_wifi_standard_project as TechnologyToVideoCodingWifiStandardProject
from src.declarations.mappers.bronze.declarations.technology_to_video_coding_wifi_standard_project_processor_mapper import (
    TechnologyToVideoCodingWifiStandardProjectMapper,
)
from src.declarations.models.landing.technology_to_video_coding_wifi_standard_project_csv import (
    TechnologyToVideoCodingWifiStandardProjectCsv,
)
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


class TechnologyToVideoCodingWifiStandardProjectProcessor:

    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        target_db_name: str,
        config: PipelineConfig,
    ):
        self.spark = spark
        self.catalog_name = catalog_name
        self.target_db_name = target_db_name
        self.source_csv_path = TechnologyToVideoCodingWifiStandardProjectCsv.PATH
        self.config = config
        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name,
            database=self.target_db_name,
            table=TechnologyToVideoCodingWifiStandardProject.PATH,
        )

    def process(self):
        df = CSVReaderTask(
            self.spark, TechnologyToVideoCodingWifiStandardProjectCsv.SCHEMA, [self.source_csv_path]
        ).run()
        final_df = TechnologyToVideoCodingWifiStandardProjectMapper.apply(df)
        WriteDeltaTableTask(
            spark=self.spark, fq_table_name=self.target_table, config=self.config, mode="overwrite"
        ).run(final_df)
