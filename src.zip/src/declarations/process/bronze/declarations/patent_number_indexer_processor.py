from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.read_delta_table_task import (
    ReadDeltaTableTask,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql.functions import col, size

import src.declarations.mappers.bronze.declarations.patent_number_indexer_mapper as PatentNumberIndexerMapper
import src.declarations.models.bronze.patents.patent_family as PatentFamily
import src.declarations.models.bronze.patents.patent_status as PatentStatus
import src.declarations.models.bronze.patents.patents_index as PatentsIndex
import src.declarations.models.silver.patents.patent_number_index as PatentNumberIndex


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    config: PipelineConfig,
):
    patents_index_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=PatentsIndex.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            col(PatentsIndex.PUBLICATION_ID),
            col(PatentsIndex.PUBLICATION_DATE),
            col(PatentsIndex.PUBLICATION_NUMBER),
            col(PatentsIndex.APPLICATION_NUMBER),
        )
    )

    patent_family_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=PatentFamily.PATH
            ),
            streaming=False,
        )
        .run()
        .select(col(PatentFamily.PUBLICATION_ID), col(PatentFamily.ALL_PRIORITY_NUMBERS))
        .filter(size(col(PatentFamily.ALL_PRIORITY_NUMBERS)) != 0)
    )

    patent_status_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=PatentStatus.PATH
            ),
            streaming=False,
        )
        .run()
        .select(col(PatentStatus.PUBLICATION_ID), col(PatentStatus.GRANTED))
    )

    joined_df = patents_index_df.join(patent_family_df, on=PatentsIndex.PUBLICATION_ID, how="left")
    joined_df = joined_df.join(patent_status_df, on=PatentsIndex.PUBLICATION_ID, how="left")
    final_df = PatentNumberIndexerMapper.apply(joined_df)
    final_df_repartitioned = final_df.repartition(1)
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=silver_db_name,
            table=PatentNumberIndex.PATH,
        ),
        config=config,
    ).run(final_df_repartitioned)

    return final_df_repartitioned
