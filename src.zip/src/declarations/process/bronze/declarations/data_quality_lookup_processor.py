from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.models.bronze.declarations.data_quality_lookup as DataQualityLookup
import src.declarations.models.landing.data_quality_lookup_csv as DataQualityLookupCsv
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


def process(spark: SparkSession, catalog_name: str, target_db_name: str, config: PipelineConfig):
    df = CSVReaderTask(spark, DataQualityLookupCsv.SCHEMA, DataQualityLookupCsv.PATH, True).run()

    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=target_db_name, table=DataQualityLookup.PATH
    )

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(df)
