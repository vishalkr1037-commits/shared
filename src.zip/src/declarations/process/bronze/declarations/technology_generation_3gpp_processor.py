from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql import functions as F

import src.declarations.models.bronze.declarations.technology_generation_3gpp as TechnologyGeneration3gpp
from src.declarations.mappers.bronze.declarations.technology_generation_3gpp_mapper import (
    TechnologyGeneration3GPPMapper,
)
from src.declarations.models.landing.technology_generation_3gpp_csv import (
    TechnologyGeneration3GPPCsv,
)
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


class TechnologyGeneration3GPPProcessor:

    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        target_db_name: str,
        config: PipelineConfig,
    ):
        self.spark = spark
        self.catalog_name = catalog_name
        self.target_db_name = target_db_name
        self.source_csv_path = TechnologyGeneration3GPPCsv.PATH
        self.config = config
        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name,
            database=self.target_db_name,
            table=TechnologyGeneration3gpp.PATH,
        )

    def process(self):
        df = CSVReaderTask(self.spark, TechnologyGeneration3GPPCsv.SCHEMA, [self.source_csv_path]).run()
        df = df.filter(F.col("id").isNotNull() & (F.col("id") != ""))
        final_df = TechnologyGeneration3GPPMapper.apply(df)
        final_df = final_df.dropDuplicates(["id"])

        WriteDeltaTableTask(
            spark=self.spark, fq_table_name=self.target_table, config=self.config, mode="overwrite"
        ).run(final_df)
