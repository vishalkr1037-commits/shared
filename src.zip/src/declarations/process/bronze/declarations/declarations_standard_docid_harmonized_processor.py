from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.mappers.bronze.declarations.declarations_standard_docid_harmonized_mapper as DeclarationsStandardDocIdHarmonizedMapper
import src.declarations.models.bronze.declarations.declarations_standard_docid_harmonized as DeclarationsStandardDocIdHarmonized
import src.declarations.models.landing.declarations_standard_docid_harmonized_csv as DeclarationsStandardDocIdHarmonizedCsv
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


# StandardDocumentIdHarmonizedForVideoAndWifiImporterJob
def process(spark: SparkSession, catalog_name: str, target_db_name: str, config: PipelineConfig):
    df = CSVReaderTask(
        spark,
        DeclarationsStandardDocIdHarmonizedCsv.SCHEMA,
        [DeclarationsStandardDocIdHarmonizedCsv.PATH],
        delimiter=";",
    ).run()
    final_df = DeclarationsStandardDocIdHarmonizedMapper.apply(df)
    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=target_db_name, table=DeclarationsStandardDocIdHarmonized.PATH
    )
    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(final_df)
