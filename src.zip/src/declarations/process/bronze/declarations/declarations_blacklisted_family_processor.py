from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

from src.declarations.mappers.bronze.declarations.declarations_blacklisted_family_mapper import (
    DeclarationsBlackListedFamilyMapper,
)
from src.declarations.models.bronze.declarations.declarations_blacklisted_family import (
    DeclarationsBlackListedFamily,
)
from src.declarations.models.landing.declarations_blacklisted_family_csv import (
    DeclarationsBlackListedFamilyCsv,
)
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


class DeclarationsBlackListedFamilyProcessor:
    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        target_db_name: str,
        config: PipelineConfig,
    ):
        self.spark = spark
        self.catalog_name = catalog_name
        self.target_db_name = target_db_name
        self.source_csv_path = DeclarationsBlackListedFamilyCsv.PATH
        self.config = config
        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name, database=self.target_db_name, table=DeclarationsBlackListedFamily.PATH
        )

    def process(self):
        df = CSVReaderTask(self.spark, DeclarationsBlackListedFamilyCsv.SCHEMA, [self.source_csv_path]).run()
        final_df = DeclarationsBlackListedFamilyMapper.apply(df)
        WriteDeltaTableTask(
            spark=self.spark, fq_table_name=self.target_table, config=self.config, mode="overwrite"
        ).run(final_df)
