from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

import src.declarations.mappers.bronze.declarations.three_gpp_specification_mapper as three_gpp_specification_mapper
import src.declarations.models.bronze.declarations.three_gpp_specification as three_gpp_spec
import src.declarations.models.landing.three_gpp_specification_csv as three_gpp_spec_csv
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


def process(spark: SparkSession, catalog_name: str, target_db_name: str, config: PipelineConfig):
    df = CSVReaderTask(spark, three_gpp_spec_csv.SCHEMA, three_gpp_spec_csv.PATH, True).run()
    filtered_df = df.filter(
        col(three_gpp_spec_csv.STANDARD_DOC_ID).isNotNull() & (col(three_gpp_spec_csv.STANDARD_DOC_ID) != "")
    )
    target_table = fully_qualified_table_name(catalog=catalog_name, database=target_db_name, table=three_gpp_spec.PATH)
    final_df = three_gpp_specification_mapper.apply(filtered_df).dropDuplicates([three_gpp_spec.ID])
    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(final_df)
