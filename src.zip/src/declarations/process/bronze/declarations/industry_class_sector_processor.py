from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.mappers.bronze.declarations.industry_class_sector_mapper as IndustryClassSectorMapper
import src.declarations.models.bronze.declarations.industry_class_sector as IndustryClassSector
import src.declarations.models.landing.industry_class_sector_csv as IndustryClassSectorCsv
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


def process(
    spark: SparkSession,
    catalog_name: str,
    target_db_name: str,
    config: PipelineConfig,
):
    df = CSVReaderTask(spark, IndustryClassSectorCsv.SCHEMA, [IndustryClassSectorCsv.PATH]).run()
    df_bronze = IndustryClassSectorMapper.apply(df)
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name, database=target_db_name, table=IndustryClassSector.PATH
        ),
        config=config,
        mode="overwrite",
    ).run(df_bronze)
