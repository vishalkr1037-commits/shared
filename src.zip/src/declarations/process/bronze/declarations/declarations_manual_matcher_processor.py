from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.models.bronze.declarations.declarations_manual_matching as DeclarationsManualMatching
import src.declarations.models.landing.declarations_manual_matching_csv as DeclarationsManualMatchedCsv
from src.declarations.mappers.bronze.declarations.declarations_manual_matcher_mapper import (
    DeclarationsManualMatchingMapper,
)
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


class DeclarationsManualMatchingProcessor:
    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        target_db_name: str,
        config: PipelineConfig,
    ) -> None:
        self.spark = spark
        self.catalog_name = catalog_name
        self.target_db_name = target_db_name
        self.config = config

        self.source_csv_path = DeclarationsManualMatchedCsv.PATH

        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name,
            database=self.target_db_name,
            table=DeclarationsManualMatching.PATH,
        )

    def process(self) -> None:
        df = CSVReaderTask(
            spark=self.spark,
            schema=DeclarationsManualMatchedCsv.SCHEMA,
            file_path=[self.source_csv_path],
        ).run()

        final_df = DeclarationsManualMatchingMapper.apply(df)

        WriteDeltaTableTask(
            spark=self.spark,
            config=self.config,
            target_table=self.target_table,
            mode="overwrite",
        ).run(final_df)
