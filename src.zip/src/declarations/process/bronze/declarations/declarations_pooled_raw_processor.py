from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    CreateOrUpdateDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

import src.declarations.mappers.bronze.declarations.declarations_raw_aggregated_mapper as declarations_raw_aggregated_mapper
from src.declarations.mappers.bronze.declarations.declarations_pooled_raw_mapper import (
    DeclarationsPooledRawMapper,
)
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.models.landing.declarations_pooled_raw_csv import (
    DeclarationsPooledRawCsv,
)
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


class DeclarationsPooledRawProcessor:
    def __init__(
        self,
        spark: SparkSession,
        catalog_name: str,
        target_db_name: str,
        config: PipelineConfig,
    ):
        self.spark = spark
        self.catalog_name = catalog_name
        self.target_db_name = target_db_name
        self.source_csv_path = DeclarationsPooledRawCsv.PATH
        self.config = config
        self.target_table = fully_qualified_table_name(
            catalog=self.catalog_name, database=self.target_db_name, table=DeclarationRaw.PATH
        )
        self.file_name = True
        self.merge_column_name = DeclarationRaw.ID
        self.partition_col_names = [DeclarationRaw.ID_FIRST_CHAR]
        self.partition_restriction_values = []

    def process(self):
        df = CSVReaderTask(self.spark, DeclarationsPooledRawCsv.SCHEMA, [self.source_csv_path], self.file_name).run()
        df = df.withColumn(DeclarationRaw.CSV_FILE_NAME, col("csv_file_name"))
        df_raw = DeclarationsPooledRawMapper.apply(df)
        df_raw_aggregated = declarations_raw_aggregated_mapper.apply(df_raw)
        df_bronze = df_raw.join(df_raw_aggregated, DeclarationRaw.ID, "left").dropDuplicates([DeclarationRaw.ID])
        CreateOrUpdateDeltaTableTask(
            spark=self.spark,
            target_table=self.target_table,
            config=self.config,
            merge_column_name=self.merge_column_name,
            partition_col_names=self.partition_col_names,
            partition_restriction_values=self.partition_restriction_values,
        ).run(df_bronze)
