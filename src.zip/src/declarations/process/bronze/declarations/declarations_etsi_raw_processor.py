from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    CreateOrUpdateDeltaTableTask,
)
from pyspark.sql import SparkSession
from pyspark.sql.functions import col

import src.declarations.mappers.bronze.declarations.declarations_etsi_raw_mapper as declarations_etsi_raw_mapper
import src.declarations.mappers.bronze.declarations.declarations_raw_aggregated_mapper as declarations_raw_aggregated_mapper
import src.declarations.models.landing.declarations_etsi_raw_csv as DeclarationsEtsiRawCsv
from src.declarations.models.bronze.declarations.declaration_raw import DeclarationRaw
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


def process(
    spark: SparkSession,
    catalog_name: str,
    target_db_name: str,
    config: PipelineConfig,
):
    df = CSVReaderTask(spark, DeclarationsEtsiRawCsv.SCHEMA, [DeclarationsEtsiRawCsv.PATH], True).run()
    df = df.withColumn(DeclarationRaw.CSV_FILE_NAME, col("csv_file_name"))
    df_raw = declarations_etsi_raw_mapper.apply(df)
    df_raw_filtered = df_raw.filter(col(DeclarationRaw.SSO) == "ETSI")
    df_raw_aggregated = declarations_raw_aggregated_mapper.apply(df_raw_filtered)
    df_bronze = df_raw_filtered.join(df_raw_aggregated, DeclarationRaw.ID, "left").dropDuplicates([DeclarationRaw.ID])
    CreateOrUpdateDeltaTableTask(
        spark=spark,
        target_table=fully_qualified_table_name(
            catalog=catalog_name, database=target_db_name, table=DeclarationRaw.PATH
        ),
        config=config,
        merge_column_name=DeclarationRaw.ID,
        partition_col_names=[DeclarationRaw.ID_FIRST_CHAR],
        partition_restriction_values=[],
    ).run(df_bronze)
