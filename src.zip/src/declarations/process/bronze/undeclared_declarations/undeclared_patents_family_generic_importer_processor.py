from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.mappers.bronze.undeclared_declarations.undeclared_simple_families_mapper as undeclared_simple_families_mapper
import src.declarations.models.bronze.undeclared_declarations.undeclared_simple_families as UndeclaredSimpleFamilies
import src.declarations.models.landing.undeclared_simple_family_id_csv as UndeclaredSimpleFamilyIdCsv
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


def process(spark: SparkSession, catalog_name: str, bronze_db_name: str, config: PipelineConfig):
    df = CSVReaderTask(spark, UndeclaredSimpleFamilyIdCsv.SCHEMA, UndeclaredSimpleFamilyIdCsv.PATH, True).run()

    final_df = undeclared_simple_families_mapper.apply(df)

    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=bronze_db_name, table=UndeclaredSimpleFamilies.PATH
    )

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(final_df)
