from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from lnip_data_platform_shared_libs.config.table_config.table_name import (
    fully_qualified_table_name,
)
from lnip_data_platform_shared_libs.io.tasks.write_delta_table_task import (
    WriteDeltaTableTask,
)
from pyspark.sql import SparkSession

import src.declarations.mappers.bronze.declarations.declarations_top_10_standards_mapper as top_10_standards_mapper
import src.declarations.models.bronze.undeclared_declarations.top_10_standards_per_committee as top_10_standards
import src.declarations.models.landing.declarations_top_10_standards_csv as top_10_standards_csv
from src.declarations.tasks.read_csv_file_task import CSVReaderTask


def process(spark: SparkSession, catalog_name: str, silver_db_name: str, config: PipelineConfig):
    df = CSVReaderTask(spark, top_10_standards_csv.SCHEMA, top_10_standards_csv.PATH, True).run()
    final_df = top_10_standards_mapper.apply(df)

    target_table = fully_qualified_table_name(
        catalog=catalog_name, database=silver_db_name, table=top_10_standards.PATH
    )

    WriteDeltaTableTask(spark=spark, fq_table_name=target_table, config=config, mode="overwrite").run(final_df)
