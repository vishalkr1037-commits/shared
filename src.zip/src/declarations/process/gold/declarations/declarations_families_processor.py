from functools import reduce

from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.bronze.patents.patents_index as PatentsIndexModel
import src.declarations.models.gold.declarations.declaration_expanded_gold as DeclarationExpandedGoldModel
import src.declarations.models.gold.declarations.declaration_families_gold as DeclarationFamiliesGoldModel
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.models.gold.declarations.declarations_gold_velos_media_index_preparation as VelosMediaDeclarationsGoldModel
import src.declarations.models.gold.undeclared_declarations.expanded_top_10_etsi_declarations as ExpandedTop10EtsiDeclarationsModel
import src.declarations.models.gold.undeclared_declarations.undeclared_patent_all as UndeclaredPatentAllGoldModel


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    gold_db_name: str,
    config: PipelineConfig,
):

    declarations_gold_df = get_declarations_gold(spark, catalog_name, gold_db_name)
    declarations_expanded_gold_df = get_declarations_expanded_gold(spark, catalog_name, gold_db_name)
    top_10_etsi_declarations_gold_df = get_top_10_etsi_declarations_gold(spark, catalog_name, gold_db_name)
    undeclared_all_gold_df = get_undeclared_all_gold(spark, catalog_name, gold_db_name)
    velos_media_gold_df = get_velos_media_declarations_gold(spark, catalog_name, gold_db_name)

    all_union_df = union_by_name(
        [
            declarations_gold_df,
            declarations_expanded_gold_df,
            top_10_etsi_declarations_gold_df,
            undeclared_all_gold_df,
            velos_media_gold_df,
        ]
    ).dropDuplicates()

    patents_index_df = get_patents_index(spark, catalog_name, silver_db_name)
    joined_df = all_union_df.join(
        patents_index_df,
        all_union_df[DeclarationFamiliesGoldModel.PUBLICATION_NUMBER]
        == patents_index_df[PatentsIndexModel.PUBLICATION_NUMBER],
        "left",
    ).select(
        all_union_df["*"],
        patents_index_df[PatentsIndexModel.INPADOC_FAMILY_ID],
    )

    decl_cols = extract_model_columns()

    # Build aggregation: collect distinct values per family
    agg_exprs = [F.collect_set(F.col(c)).alias(c) for c in decl_cols]

    final_df = (
        joined_df.filter(F.col(PatentsIndexModel.INPADOC_FAMILY_ID).isNotNull())
        .groupBy(F.col(PatentsIndexModel.INPADOC_FAMILY_ID).alias(PatentsIndexModel.INPADOC_FAMILY_ID))
        .agg(*agg_exprs)
    )

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=gold_db_name,
            table=DeclarationFamiliesGoldModel.PATH,
        ),
        config=config,
    ).run(final_df)


def get_declarations_gold(spark: SparkSession, catalog_name, source_database) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, DeclarationGoldModel.PATH),
        streaming=False,
    ).run()
    model_cols = extract_model_columns()
    return df.select(*model_cols).drop()


def get_declarations_expanded_gold(spark: SparkSession, catalog_name, source_database) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, DeclarationExpandedGoldModel.PATH),
        streaming=False,
    ).run()
    model_cols = extract_model_columns()
    return df.select(*model_cols)


def get_top_10_etsi_declarations_gold(spark: SparkSession, catalog_name, source_database) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, ExpandedTop10EtsiDeclarationsModel.PATH),
        streaming=False,
    ).run()
    model_cols = extract_model_columns()
    return df.select(*model_cols)


def get_undeclared_all_gold(spark: SparkSession, catalog_name, source_database) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, UndeclaredPatentAllGoldModel.PATH),
        streaming=False,
    ).run()
    model_cols = extract_model_columns()
    return df.select(*model_cols)


def get_velos_media_declarations_gold(spark: SparkSession, catalog_name, source_database) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, VelosMediaDeclarationsGoldModel.PATH),
        streaming=False,
    ).run()
    model_cols = extract_model_columns()
    return df.select(*model_cols)


def get_patents_index(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark, fully_qualified_table_name(catalog_name, source_db_name, PatentsIndexModel.PATH), streaming=False
    ).run()

    return df.select(
        F.col(PatentsIndexModel.PUBLICATION_NUMBER),
        F.col(PatentsIndexModel.INPADOC_FAMILY_ID),
    )


def extract_model_columns() -> list:
    """
    Return list of column name constants (UPPER_CASE attributes) defined on a model module.
    Reusable for multiple readers.
    """
    cols = [
        getattr(DeclarationFamiliesGoldModel, name)
        for name in dir(DeclarationFamiliesGoldModel)
        if name.isupper() and name != "PATH" and isinstance(getattr(DeclarationFamiliesGoldModel, name), str)
    ]
    path_val = getattr(DeclarationFamiliesGoldModel, "PATH", None)
    return [c for c in cols if c != path_val]


def union_by_name(dfs: list[DataFrame]) -> DataFrame:
    dfs = [d for d in dfs if d is not None]
    if not dfs:
        raise ValueError("No DataFrames to union")
    return reduce(lambda a, b: a.unionByName(b), dfs)
