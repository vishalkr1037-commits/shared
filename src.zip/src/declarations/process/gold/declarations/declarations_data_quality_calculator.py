from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.window import Window
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.bronze.patents.patents_index as PatentIndexModel
import src.declarations.models.gold.declarations.data_quality_tracker as DeclarationDQModel
import src.declarations.models.gold.declarations.declaration_expanded_gold as DeclarationExpandedGoldModel
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFilteredModel
from src.declarations.mappers.gold.declarations.data_quality_declaration_mapper import (
    apply as data_quality_mapper,
)


def process(spark: SparkSession, catalog_name: str, silver_db_name: str, gold_db_name: str, config: PipelineConfig):
    dec_family_df = prepare_declaration_family_data(spark, catalog_name, silver_db_name, gold_db_name)
    patent_candidates_df = get_patent_candidates(spark, catalog_name, silver_db_name)
    declaration_raw_df = get_declaration_raw(spark, catalog_name, silver_db_name)
    declaration_compamny_filtered_df = get_declarations_company_filtered(spark, catalog_name, silver_db_name)
    extended_family_df = get_patent_extended_family(spark, catalog_name, silver_db_name)

    declaration_data_quality_dfs = transform_declaration_families(dec_family_df)
    declaration_count_df = transform_declaration_count(patent_candidates_df)
    working_no_count_df = transform_working_number_count(patent_candidates_df, declaration_raw_df)
    etsi_isld_count_df = transform_matched_etsi(patent_candidates_df, declaration_raw_df)
    pooled_data_quality_df = transform_pooled_declarations(dec_family_df)
    scored_tech_data_quality_df = transform_scored_tech_universes(dec_family_df)
    declaration_data_completeness_df = declaration_date_completeness(dec_family_df)
    etsi_disclosure_isld_count_df = transform_disclosure_number_isld_etsi(patent_candidates_df, declaration_raw_df)
    matched_data_quality_df = transform_matched_declarations(dec_family_df)
    etsi_data_quality_df = transform_etsi_declarations(dec_family_df)
    false_positive_rule_df = transform_false_positive_rule(declaration_compamny_filtered_df, extended_family_df)
    non_etsi_validation_rules_df = non_etsi_based_validation_rules(dec_family_df)
    non_pooled_validation_rules_df = non_pooled_validation_rules(dec_family_df)
    tech_generation_dq_rule_df = transform_technology_generation_dq_rule(dec_family_df)
    tech_classification_dq_rule_df = transform_technology_classification_dq_rule(dec_family_df)
    simple_family_id_validity_rule_df = transform_simply_family_id_validity_rule(dec_family_df)
    declaration_date_validity_rule_df = transform_declaration_date_validity_rule(dec_family_df)
    tech_classification_accuracy_df = transform_tech_classification_accuracy_rule(dec_family_df)
    release_accuracy_df = transform_release_accuracy_rule(dec_family_df)
    pool_provider_accuracy_df = transform_pool_provider_accuracy_rule(dec_family_df)
    group_accuracy_df = transform_group_accuracy_rule(dec_family_df)
    sso_accuracy_df = transform_sso_accuracy_rule(dec_family_df)
    tech_gen_accuracy_df = transform_tech_gen_accuracy_rule(dec_family_df)

    declaration_dq = (
        declaration_data_quality_dfs.unionByName(declaration_count_df, allowMissingColumns=True)
        .unionByName(working_no_count_df, allowMissingColumns=True)
        .unionByName(etsi_isld_count_df, allowMissingColumns=True)
        .unionByName(pooled_data_quality_df, allowMissingColumns=True)
        .unionByName(scored_tech_data_quality_df, allowMissingColumns=True)
        .unionByName(declaration_data_completeness_df, allowMissingColumns=True)
        .unionByName(etsi_disclosure_isld_count_df, allowMissingColumns=True)
        .unionByName(matched_data_quality_df, allowMissingColumns=True)
        .unionByName(etsi_data_quality_df, allowMissingColumns=True)
        .unionByName(false_positive_rule_df, allowMissingColumns=True)
        .unionByName(non_etsi_validation_rules_df, allowMissingColumns=True)
        .unionByName(non_pooled_validation_rules_df, allowMissingColumns=True)
        .unionByName(tech_generation_dq_rule_df, allowMissingColumns=True)
        .unionByName(tech_classification_dq_rule_df, allowMissingColumns=True)
        .unionByName(simple_family_id_validity_rule_df, allowMissingColumns=True)
        .unionByName(declaration_date_validity_rule_df, allowMissingColumns=True)
        .unionByName(tech_classification_accuracy_df, allowMissingColumns=True)
        .unionByName(release_accuracy_df, allowMissingColumns=True)
        .unionByName(pool_provider_accuracy_df, allowMissingColumns=True)
        .unionByName(group_accuracy_df, allowMissingColumns=True)
        .unionByName(sso_accuracy_df, allowMissingColumns=True)
        .unionByName(tech_gen_accuracy_df, allowMissingColumns=True)
    )

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=gold_db_name,
            table=DeclarationDQModel.PATH,
        ),
        config=config,
    ).run(declaration_dq)


def transform_declaration_families(dec_family_df: DataFrame) -> DataFrame:
    """
    Transform declaration families with rule-based aggregations.
    """
    declaration_agg = (
        dec_family_df.groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.countDistinct("id").alias("Rule_9"),
            F.count(
                F.when((F.col("standard_document_id").isNotNull()) & (F.col("standard_document_id") != ""), 1)
            ).alias("Rule_13"),
            F.count(F.when(F.col("standard_project").isNotNull(), 1)).alias("Rule_15"),
            F.count(
                F.when(
                    (F.col("standard_document_id_harmonized").isNotNull())
                    & (F.col("standard_document_id_harmonized") != ""),
                    1,
                )
            ).alias("Rule_25"),
            F.count(F.when((F.col("type").isNotNull()) & (F.col("type") != ""), 1)).alias("Rule_28"),
            F.count(F.when((F.col("declaring_company").isNotNull()) & (F.col("declaring_company") != ""), 1)).alias(
                "Rule_31"
            ),
            F.count(
                F.when((F.col("standard_document_ref").isNotNull()) & (F.col("standard_document_ref") != ""), 1)
            ).alias("Rule_36"),
            F.count(F.when((F.col("sso").isNotNull()) & (F.col("sso") != ""), 1)).alias("Rule_66"),
        )
        .transform(data_quality_mapper)
    )

    return declaration_agg


def transform_declaration_count(patent_candidates: DataFrame) -> DataFrame:
    """
    Transform patent_candidates into aggregated declaration counts.

    Equivalent to the Java method transformDeclarationCount.
    """

    declaration_id_win = Window.partitionBy("declaration_id")

    # Add column counting matched = "true" per declaration_id
    patent_candidates = patent_candidates.withColumn(
        "declaration_id_agg", F.count(F.when(F.col("matched") == "true", 1)).over(declaration_id_win)
    )

    # Aggregate per data_provider
    declaration_count_df = (
        patent_candidates.groupBy("data_provider")
        .agg(
            F.countDistinct("declaration_id").alias("total_count"),
            F.countDistinct(F.when(F.col("declaration_id_agg") != 0, F.col("declaration_id"))).alias("Rule_24"),
        )
        .transform(data_quality_mapper)  # apply your mapper
    )

    return declaration_count_df


def transform_working_number_count(patent_candidates: DataFrame, declarations_raw: DataFrame) -> DataFrame:
    """
    Transform working number counts for non-blanket declarations.

    Equivalent to the Java method transformWorkingNumberCount.
    """

    # Window partitioned by working_number
    working_number_win = Window.partitionBy("working_number")

    # Filter out BLANKET_DECLARATION
    non_blanket_declarations = declarations_raw.filter(F.col("type") != "BLANKET_DECLARATION").select(
        F.col("id").alias("nbt_id")
    )

    # Join patent candidates with non-blanket declarations
    working_number_count_df = (
        patent_candidates.alias("pc")
        .join(non_blanket_declarations, F.expr("pc.declaration_id = nbt_id"), "inner")
        .withColumn(
            "working_number_agg",
            F.count(F.when(F.col("matched") == "true", 1)).over(working_number_win),
        )
        .groupBy("data_provider")
        .agg(
            F.countDistinct("working_number").alias("total_count"),
            F.countDistinct(F.when(F.col("working_number_agg") != 0, F.col("working_number"))).alias("Rule_23"),
        )
        .transform(data_quality_mapper)
    )

    return working_number_count_df


def transform_matched_etsi(patent_candidates: DataFrame, declarations_raw: DataFrame) -> DataFrame:
    non_blanket = declarations_raw.filter(
        (F.col("data_provider") == "ETSI") & (F.col("type") != "BLANKET_DECLARATION")
    ).alias("dr")
    matched = (
        patent_candidates.filter((F.col("data_provider") == "ETSI") & (F.col("matched") == True))
        .select("declaration_id")
        .alias("pc")
    )

    agg = (
        non_blanket.join(matched, F.expr("dr.id = pc.declaration_id"), "left")
        .agg(
            F.first("data_provider").alias("data_provider"),
            F.countDistinct("dr.isld").alias("total_count"),
            F.countDistinct(F.when(F.col("pc.declaration_id").isNotNull(), F.col("dr.isld"))).alias("Rule_62"),
        )
        .transform(data_quality_mapper)
    )
    return agg


def transform_etsi_declarations(declaration_df: DataFrame) -> DataFrame:
    isld_pattern = "^ISLD-\\d+-\\d+$"
    gd_pattern = "^GD-\\d+-\\d+$"

    isld_df = (
        declaration_df.filter(F.col("data_provider") == "ETSI")
        .select("data_provider", "isld")
        .withColumn("exploded_isld", F.explode("isld"))
        .agg(
            F.first("data_provider").alias("data_provider"),
            F.count("*").alias("total_count"),
            F.count(
                F.when(
                    (F.regexp_extract("exploded_isld", isld_pattern, 0) != "")
                    | (F.regexp_extract("exploded_isld", gd_pattern, 0) != ""),
                    "exploded_isld",
                )
            ).alias("Rule_18"),
        )
        .transform(data_quality_mapper)
    )

    etsi_decl_df = (
        declaration_df.filter(F.col("data_provider") == "ETSI")
        .agg(
            F.first("data_provider").alias("data_provider"),
            F.count("*").alias("total_count"),
            F.count(F.when((F.col("release").isNotNull()) & (F.col("release") != ""), "release")).alias("Rule_30"),
            F.count(F.when((F.col("group").isNotNull()) & (F.col("group") != ""), "group")).alias("Rule_32"),
            F.count(
                F.when((~F.array_contains("isld", "")) & (F.col("isld").isNotNull()) & (F.size("isld") > 0), "isld")
            ).alias("Rule_64"),
            F.count(
                F.when(
                    (F.col("disclosure_number").isNotNull()) & (F.size("disclosure_number") > 0), "disclosure_number"
                )
            ).alias("Rule_65"),
        )
        .transform(data_quality_mapper)
    )

    return isld_df.unionByName(etsi_decl_df)


def transform_disclosure_number_isld_etsi(patent_candidates: DataFrame, declarations_raw: DataFrame) -> DataFrame:
    candidates = (
        patent_candidates.filter(F.col("data_provider") == "ETSI")
        .select("declaration_id", "working_number", "matched", "data_provider")
        .alias("pc")
    )

    raw = (
        declarations_raw.filter(F.col("data_provider") == "ETSI")
        .withColumn("disclosure_number", F.explode("disclosure_number_aggregated"))
        .groupBy("isld", "disclosure_number")
        .agg(F.first("id").alias("id"))
        .select("id", "isld", "disclosure_number")
        .alias("dr")
    )

    result = (
        candidates.join(raw, F.expr("pc.declaration_id = dr.id"), "left")
        .groupBy("data_provider")
        .agg(
            F.countDistinct("pc.working_number").alias("total_count"),
            F.countDistinct(F.when(F.col("pc.matched") == True, "pc.working_number")).alias("Rule_68"),
        )
        .transform(data_quality_mapper)
    )
    return result


# -------------------------
# Validation Rules
# -------------------------


def non_etsi_based_validation_rules(declaration_df: DataFrame) -> DataFrame:
    return (
        declaration_df.filter(F.col("data_provider") != "ETSI")
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when(F.array_contains("isld", "") | F.col("isld").isNull() | (F.size("isld") == 0), "id")).alias(
                "Rule_77"
            ),
            F.count(F.when(F.col("disclosure_number").isNull() | (F.size("disclosure_number") == 0), "id")).alias(
                "Rule_78"
            ),
            F.count(F.when((F.col("release") == "") | F.col("release").isNull(), "id")).alias("Rule_79"),
            F.count(F.when((F.col("group") == "") | F.col("group").isNull(), "id")).alias("Rule_80"),
        )
        .transform(data_quality_mapper)
    )


def non_pooled_validation_rules(declaration_df: DataFrame) -> DataFrame:
    return (
        declaration_df.filter(F.col("type") != "POOLED")
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when((F.col("pool_provider") == "") | F.col("pool_provider").isNull(), "id")).alias("Rule_81"),
            F.count(F.when((F.col("pool_name_harmonized") == "") | F.col("pool_name_harmonized").isNull(), "id")).alias(
                "Rule_82"
            ),
        )
        .transform(data_quality_mapper)
    )


def transform_pooled_declarations(declaration_df: DataFrame) -> DataFrame:
    return (
        declaration_df.filter(F.col("type") == "POOLED")
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(
                F.when((F.col("pool_provider").isNotNull()) & (F.col("pool_provider") != ""), "pool_provider")
            ).alias("Rule_38"),
            F.count(F.when(F.col("pooled").isNotNull(), "pooled")).alias("Rule_39"),
            F.count(
                F.when(
                    (F.col("pool_name_harmonized").isNotNull()) & (F.col("pool_name_harmonized") != ""),
                    "pool_name_harmonized",
                )
            ).alias("Rule_40"),
        )
        .transform(data_quality_mapper)
    )


def transform_scored_tech_universes(declaration_df: DataFrame) -> DataFrame:
    """
    Transform scored technology universes (tech generations + ETSI).
    """

    scored_tech_generation_values = [
        "Wi-Fi 7 (IEEE 802.11be)",
        "Wi-Fi 6 (IEEE 802.11ax)",
        "Wi-Fi 5 (IEEE 802.11ac)",
        "Wi-Fi 4 (IEEE 802.11n)",
        "Wi-Fi 3 (IEEE 802.11g)",
        "Wi-Fi 2 (IEEE 802.11a)",
        "Wi-Fi 1 (IEEE 802.11b)",
        "VVC (H.266)",
        "Qi1",
        "HEVC (H.265)",
    ]

    scored_df = (
        declaration_df.filter(
            (F.col("technology_generation").isin(scored_tech_generation_values)) | (F.col("data_provider") == "ETSI")
        )
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when(F.col("score").isNotNull(), "score")).alias("Rule_35"),
        )
        .transform(data_quality_mapper)
    )

    return scored_df


def declaration_date_completeness(declaration_df: DataFrame) -> DataFrame:
    """
    Completeness check for declaration dates (excludes pooled and undeclared patents).
    """

    decl_date_df = (
        declaration_df.filter((F.col("type") != "POOLED") & (F.col("type") != "UNDECLARED_PATENT"))
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when(F.col("declaration_date").isNotNull(), "declaration_date")).alias("Rule_29"),
        )
        .transform(data_quality_mapper)
    )

    return decl_date_df


def transform_matched_declarations(declaration_df: DataFrame) -> DataFrame:
    """
    Data quality check for matched declarations.
    """

    matched_declarations_df = (
        declaration_df.filter((F.col("publication_number").isNotNull()) & (F.col("publication_number") != ""))
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(
                F.when(
                    (F.col("inpadoc_family_id").isNotNull()) & (F.col("inpadoc_family_id") != ""),
                    F.col("inpadoc_family_id"),
                )
            ).alias("Rule_33"),
            F.count(
                F.when(
                    F.col("owner_name_friendly").isNotNull(),
                    F.col("owner_name_friendly"),
                )
            ).alias("Rule_34"),
            F.count(
                F.when(
                    (F.col("application_number").isNotNull()) & (F.col("application_number") != ""),
                    F.col("application_number"),
                )
            ).alias("Rule_63"),
            F.count(
                F.when(
                    (F.col("simple_family_id").isNotNull()) & (F.col("simple_family_id") != -1),
                    F.col("simple_family_id"),
                )
            ).alias("Rule_83"),
            F.count(
                F.when(
                    (F.col("kind_type_short").isNotNull()) & (F.col("kind_type_short") != ""),
                    F.col("kind_type_short"),
                )
            ).alias("Rule_85"),
        )
        .transform(data_quality_mapper)
    )

    return matched_declarations_df


def transform_false_positive_rule(company_filter: DataFrame, extended_family: DataFrame) -> DataFrame:
    """
    Calculate false positive rule (Rule_74) based on working numbers and inpadoc family count.
    """

    # Filter valid and matched companies
    company_df = company_filter.filter((F.col("is_company_valid") == True) & (F.col("matched") == True))

    # Join with extended family and compute inpadoc_family_count per working_number
    intermediate_df = (
        company_df.alias("cf")
        .join(extended_family.alias("ef"), F.expr("cf.publication_id = ef.publication_id"), "inner")
        .groupBy(F.col("cf.data_provider"), F.col("cf.working_number"))
        .agg(F.countDistinct(F.col("ef.inpadoc_family_id")).alias("inpadoc_family_count"))
    )

    # Aggregate per data_provider
    false_positive_df = (
        intermediate_df.groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when(F.col("inpadoc_family_count") == 1, F.col("working_number"))).alias("Rule_74"),
        )
        .transform(data_quality_mapper)
    )

    return false_positive_df


def transform_technology_generation_dq_rule(dec_family_df: DataFrame) -> DataFrame:
    """
    Transform for Technology Generation DQ Rule (Rule_20)
    """
    data_providers = [
        "ISO",
        "ATIS",
        "ANSI",
        "Wireless Power Consortium",
        "CCSA",
        "ITUT",
        "Access Advance",
        "SISVEL",
        "Via LA",
        "ETSI",
        "IEEE",
        "IEC",
    ]

    tech_df = (
        dec_family_df.filter(F.col("data_provider").isin(data_providers))
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(
                F.when(
                    F.col("technology_generation").isNotNull() & (F.col("technology_generation") != ""),
                    F.col("technology_generation"),
                )
            ).alias("Rule_20"),
        )
        .transform(data_quality_mapper)
    )

    return tech_df


def transform_technology_classification_dq_rule(dec_family_df: DataFrame) -> DataFrame:
    """
    Transform for Technology Classification DQ Rule (Rule_27)
    """
    data_providers = ["SISVEL", "ETSI", "CCSA", "ATIS"]

    tech_classification_df = (
        dec_family_df.filter(F.col("data_provider").isin(data_providers))
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(
                F.when(
                    F.col("technology_classification").isNotNull() & (F.col("technology_classification") != ""),
                    F.col("technology_classification"),
                )
            ).alias("Rule_27"),
        )
        .transform(data_quality_mapper)
    )

    return tech_classification_df


def transform_simply_family_id_validity_rule(dec_family_df: DataFrame) -> DataFrame:
    df = (
        dec_family_df.filter(
            F.col("simple_family_id").isNotNull()
            & (F.col("simple_family_id") != -1)
            & (F.col("publication_number") != "")
            & F.col("publication_number").isNotNull()
        )
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when(F.col("simple_family_id").rlike("^[0-9]+$"), F.col("simple_family_id"))).alias("Rule_84"),
        )
        .transform(data_quality_mapper)
    )
    return df


def transform_declaration_date_validity_rule(dec_family_df: DataFrame) -> DataFrame:
    df = (
        dec_family_df.filter(F.col("declaration_date").isNotNull() & (F.col("type") != "POOLED"))
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(
                F.when(
                    F.date_format(F.to_date(F.col("declaration_date"), "yyyy-MM-dd"), "yyyy-MM-dd").isNotNull(),
                    F.col("declaration_date"),
                )
            ).alias("Rule_22"),
        )
        .transform(data_quality_mapper)
    )
    return df


def transform_tech_classification_accuracy_rule(dec_family_df: DataFrame) -> DataFrame:
    tech_classification_values = [
        "V2X | 5G and bridging technologies",
        "LTE-M",
        "LTE-M | 5G and bridging technologies",
        "EVS | 5G and bridging technologies",
        "5G and bridging technologies",
        "EVS",
        "NB-IoT",
        "LTE CAT-1 | 5G and bridging technologies",
        "NB-IoT | 5G and bridging technologies",
        "LTE CAT-1",
        "V2X",
    ]

    df = (
        dec_family_df.filter(
            F.col("technology_classification").isNotNull() & (F.col("technology_classification") != "")
        )
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(
                F.when(
                    F.col("technology_classification").isin(tech_classification_values),
                    F.col("technology_classification"),
                )
            ).alias("Rule_70"),
        )
        .transform(data_quality_mapper)
    )
    return df


def transform_release_accuracy_rule(dec_family_df: DataFrame) -> DataFrame:
    release_values = [
        "Release 19",
        "Release 18",
        "Release 17",
        "Release 16",
        "Release 15",
        "Release 14",
        "Release 13",
        "Release 12",
        "Release 11",
        "Release 10",
        "Release 9",
        "Release 8",
        "Release 7",
        "Release 6",
        "Release 5",
        "Release 4",
        "Release 2000",
        "Release 1999",
        "Release 1998",
        "Release 1997",
        "Phase 2+",
        "Phase 2",
        "Phase 1",
        "",
    ]

    df = (
        dec_family_df.filter(
            (F.col("data_provider") == "ETSI") & F.col("release").isNotNull() & (F.col("release") != "")
        )
        .withColumn("exploded_release", F.explode_outer(F.split(F.col("release"), "\\|")))
        .withColumn("exploded_release", F.trim(F.col("exploded_release")))
        .agg(
            F.first("data_provider").alias("data_provider"),
            F.countDistinct("id").alias("total_count"),
            (
                F.countDistinct("id")
                - F.countDistinct(F.when(~F.col("exploded_release").isin(release_values), F.col("id")))
            ).alias("Rule_71"),
        )
        .transform(data_quality_mapper)
    )
    return df


def transform_pool_provider_accuracy_rule(dec_family_df: DataFrame) -> DataFrame:
    pool_provider_values = ["Access Advance", "Via LA", "SISVEL", "ONE-BLUE", "Uldage Pool", "Vectis IP"]

    df = (
        dec_family_df.filter(
            (F.col("type") == "POOLED") & (F.col("pool_provider") != "") & F.col("pool_provider").isNotNull()
        )
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when(F.col("pool_provider").isin(pool_provider_values), F.col("pool_provider"))).alias("Rule_72"),
        )
        .transform(data_quality_mapper)
    )
    return df


def transform_group_accuracy_rule(dec_family_df: DataFrame) -> DataFrame:
    group_values = [
        "RAN6",
        "RAN3",
        "RAN5",
        "CT6",
        "SA4",
        "SA5",
        "CT4",
        "RAN1",
        "CT1",
        "SA3",
        "SA6",
        "CT",
        "RAN4",
        "SA1",
        "SA",
        "SA2",
        "RAN2",
        "CT3",
        "RAN",
    ]

    df = (
        dec_family_df.filter((F.col("data_provider") == "ETSI") & F.col("group").isNotNull() & (F.col("group") != ""))
        .agg(
            F.first("data_provider").alias("data_provider"),
            F.count("*").alias("total_count"),
            F.count(F.when(F.col("group").isin(group_values), F.col("group"))).alias("Rule_73"),
        )
        .transform(data_quality_mapper)
    )
    return df


def transform_sso_accuracy_rule(dec_family_df: DataFrame) -> DataFrame:
    sso_values = [
        "Wireless Power Consortium",
        "VESA",
        "TIA",
        "SMPTE",
        "SD Association",
        "Satellite-UHDTV",
        "SAE",
        "OASIS",
        "JEDEC",
        "ITUT",
        "ITUR",
        "ISO",
        "IPTV",
        "IEEE",
        "ETSI",
        "ECMA",
        "DMTF",
        "CEN",
        "CCSA",
        "CATV-UHDTV",
        "CATV-Compliant",
        "CATV",
        "Broadband Forum",
        "Blu-ray Disc™ Association",
        "ATSC",
        "ATIS",
        "ARIB",
        "OMA",
        "IEC",
        "ANSI",
        "ISO/IEC",
        "IETF",
        "ETSI | ITU-T",
    ]

    df = (
        dec_family_df.filter(F.col("sso").isNotNull() & (F.col("sso") != ""))
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(F.when(F.col("sso").isin(sso_values), F.col("sso"))).alias("Rule_75"),
        )
        .transform(data_quality_mapper)
    )
    return df


def transform_tech_gen_accuracy_rule(dec_family_df: DataFrame) -> DataFrame:
    tech_generation_values = [
        "Wi-Fi 7 (IEEE 802.11be)",
        "Wi-Fi 6 (IEEE 802.11ax)",
        "Wi-Fi 5 (IEEE 802.11ac)",
        "Wi-Fi 4 (IEEE 802.11n)",
        "Wi-Fi 3 (IEEE 802.11g)",
        "Wi-Fi 2 (IEEE 802.11a)",
        "Wi-Fi 1 (IEEE 802.11b)",
        "VVC (H.266)",
        "VP9",
        "Qi1",
        "HEVC (H.265)",
        "Bridging (5G, 4G)",
        "Bridging (5G, 4G, 3G)",
        "Bridging (5G, 4G, 3G, 2G)",
        "Bridging (4G, 3G)",
        "Bridging (4G, 3G, 2G)",
        "Bridging (3G, 2G)",
        "AVC (H.264)",
        "AV1",
        "5G",
        "4G",
        "3G",
        "2G",
    ]

    df = (
        dec_family_df.filter(F.col("technology_generation").isNotNull() & (F.col("technology_generation") != ""))
        .groupBy("data_provider")
        .agg(
            F.count("*").alias("total_count"),
            F.count(
                F.when(F.col("technology_generation").isin(tech_generation_values), F.col("technology_generation"))
            ).alias("Rule_76"),
        )
        .transform(data_quality_mapper)
    )
    return df


# ----------------------------
# Main family preparation
# ----------------------------
def prepare_declaration_family_data(
    spark: SparkSession, catalog_name: str, silver_db_name: str, gold_db_name: str
) -> DataFrame:
    publication_id_join = "publication_id"
    id_join = "id"

    # Combine all declarations
    declaration_df = (
        get_declarations(spark, catalog_name, gold_db_name)
        .unionByName(get_expanded_declarations(spark, catalog_name, gold_db_name), allowMissingColumns=True)
        .join(
            get_etsi_semantic_scores(spark, catalog_name, silver_db_name)
            .unionByName(get_ve_semantic_scores(spark, catalog_name, silver_db_name), allowMissingColumns=True)
            .unionByName(get_wifi_semantic_scores(spark, catalog_name, silver_db_name), allowMissingColumns=True)
            .unionByName(
                get_qi_standards_semantic_scores(spark, catalog_name, silver_db_name), allowMissingColumns=True
            ),
            on=id_join,
            how="left",
        )
        .repartition(F.col("publication_id"))
    )
    # Join with patent-related tables
    dec_family_data = (
        declaration_df.join(
            get_patent_extended_family(spark, catalog_name, silver_db_name), on=publication_id_join, how="left"
        )
        .join(get_patent_index(spark, catalog_name, silver_db_name), on=publication_id_join, how="left")
        .join(get_patent_ultimate_owner(spark, catalog_name, silver_db_name), on=publication_id_join, how="left")
        .join(get_patent_kind_type(spark, catalog_name, silver_db_name), on=publication_id_join, how="left")
        .repartition(F.col("data_provider"))
    )
    return dec_family_data


# ----------------------------
# Declarations
# ----------------------------
def get_declaration_raw(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    columns = ["id", "isld", "data_provider", "type", "disclosure_number_aggregated"]

    df = (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="declaration_raw_enriched"),
            streaming=False,
        )
        .run()
        .filter(F.col("data_provider").isNotNull())
        .select(*columns)
    )

    return df


def get_declarations(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    columns = [
        "id",
        "publication_number",
        "sso",
        "isld",
        "standard_project",
        "standard_document_id",
        "standard_document_id_harmonized",
        "declaration_date",
        "data_provider",
        "publication_id",
        "declaring_company",
        "technology_generation",
        "technology_classification",
        "type",
        "release",
        "group",
        "standard_document_ref",
        "pooled",
        "pool_provider",
        "pool_name_harmonized",
        "declaration_id",
        "disclosure_number",
    ]

    df = (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, DeclarationGoldModel.PATH),
            streaming=False,
        )
        .run()
        .filter(F.col("data_provider").isNotNull())
        .select(*columns)
    )

    return df


def get_expanded_declarations(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    columns = [
        "id",
        "publication_number",
        "sso",
        "isld",
        "standard_project",
        "standard_document_id",
        "standard_document_id_harmonized",
        "declaration_date",
        "data_provider",
        "publication_id",
        "declaring_company",
        "technology_generation",
        "technology_classification",
        "type",
        "release",
        "group",
        "standard_document_ref",
        "pooled",
        "pool_provider",
        "pool_name_harmonized",
        "disclosure_number",
    ]

    df = (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, DeclarationExpandedGoldModel.PATH),
            streaming=False,
        )
        .run()
        .filter(F.col("data_provider").isNotNull())
        .select(*columns)
        .withColumnRenamed("id", "declaration_id")
    )

    return df


# ----------------------------
# Semantic scores (normalized)
# ----------------------------
def get_etsi_semantic_scores(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="etsi_semantic_similarity_score"),
            streaming=False,
        )
        .run()
        .select("id", F.col("score"))
    )


def get_ve_semantic_scores(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="ve_semantic_similarity_score"),
            streaming=False,
        )
        .run()
        .select("id", F.col("score"))
    )


def get_wifi_semantic_scores(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="wifi_semantic_similarity_score"),
            streaming=False,
        )
        .run()
        .select("id", F.col("score"))
    )


def get_qi_standards_semantic_scores(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="qi_semantic_similarity_score"),
            streaming=False,
        )
        .run()
        .select("id", F.col("score"))
    )


# ----------------------------
# Patent tables
# ----------------------------
def get_patent_extended_family(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="extended_family_id"),
            streaming=False,
        )
        .run()
        .select("publication_id", "inpadoc_family_id", "simple_family_id")
        .distinct()
    )


def get_patent_ultimate_owner(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="ultimate_owner_enriched_final"),
            streaming=False,
        )
        .run()
        .select("publication_id", "owner_name_friendly")
        .distinct()
    )


def get_patent_index(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, PatentIndexModel.PATH),
            streaming=False,
        )
        .run()
        .select("publication_id", "application_number")
        .distinct()
    )


def get_declarations_company_filtered(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, DeclarationCompanyFilteredModel.PATH),
            streaming=False,
        )
        .run()
        .select("publication_id", "working_number", "data_provider", "is_company_valid", "matched")
        .distinct()
    )


def get_patent_kind_type(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, source_db_name, table="kind_type"),
            streaming=False,
        )
        .run()
        .select("publication_id", "kind_type_short")
        .distinct()
    )


def get_patent_candidates(spark: SparkSession, catalog_name: str, source_db_name: str) -> DataFrame:
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(
                catalog_name, source_db_name, table="declaration_patent_number_matching_candidates"
            ),
            streaming=False,
        )
        .run()
        .filter(F.col("data_provider").isNotNull())
        .select("declaration_id", "selected_publication_number", "working_number", "matched", "data_provider")
    )
