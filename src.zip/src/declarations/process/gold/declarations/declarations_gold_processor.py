from pyspark import StorageLevel
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.gold.declarations.cellular_technology_classification_mapper as CellularTechnologyClassificationMapper
import src.declarations.mappers.gold.declarations.solr_declaration_enrichment_mapper as SolrDeclarationEnrichmentMapper
import src.declarations.mappers.gold.declarations.solr_declaration_group_normalized_mapper as SolrDeclarationGroupNormalizedMapper
import src.declarations.mappers.gold.declarations.solr_declaration_mapper as SolrDeclarationMapper
import src.declarations.mappers.gold.declarations.solr_technology_generation_mapper as SolrTechnologyGenerationMapper
import src.declarations.models.bronze.declarations.declarations_groups_normalizer as declarations_groups_normalizer
import src.declarations.models.bronze.declarations.declarations_standard_docid_harmonized as declarations_standard_docid_harmonized
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.models.silver.declarations.cellular_technology_classification as CellularTechnologyClassification
import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFilteredModel
import src.declarations.models.silver.declarations.declaration_most_meaningful_standard_info as declarations_most_meaningful_standard_info
from src.declarations.common.declarations_table_config.table_config import (
    BRONZE_DECLARATIONS_GROUPS_NORMALIZED,
    BRONZE_PATENTS_INDEX,
    BRONZE_STANDARD_DOCID_HARMONIZED,
    SILVER_CELLULAR_TECHNOLOGY_CLASSIFICATION,
    SILVER_DECLARATION_FAMILY_TECHNOLOGY_GENERATION,
    SILVER_DECLARATION_WITH_MOST_MEANINGFUL_STANDARD_INFO,
    SILVER_HARMONIZED_RAW_DECLARING_COMPANIES,
)
from src.declarations.mappers.gold.declarations.patents_index_mapper import (
    apply as patents_index_mapper,
)
from src.declarations.mappers.gold.declarations.solr_declaration_companies_mapper import (
    apply as solr_declaration_companies_mapper,
)
from src.declarations.models.silver.declarations.raw_declaration_companies_harmonization import (
    RawDeclarationCompaniesHarmonizations,
)


def process(
    spark: SparkSession,
    catalog_name: str,
    bronze_db_name: str,
    silver_db_name: str,
    gold_db_name: str,
    config: PipelineConfig,
):

    declarations_company_filtered_df = get_declarations_company_filtered(spark, catalog_name, silver_db_name)
    family_technology_generation_df = get_family_technology_generation(spark, catalog_name, silver_db_name)
    video_coding_wifi_std_doc_id_harmonized_df = get_standard_document_id_harmonized(
        spark, catalog_name, bronze_db_name
    )
    most_meaningful_standard_info_df = get_declarations_with_most_meaningful_standard_info(
        spark, catalog_name, silver_db_name
    )
    get_declaration_companies = get_harmonized_raw_declaring_companies(spark, catalog_name, silver_db_name)
    get_patent_mapping = get_patents_index(spark, catalog_name, silver_db_name, declarations_company_filtered_df)
    get_normalized_group = get_declarations_groups_normalized(spark, catalog_name, bronze_db_name)
    cellular_technology_classification_df = get_cellular_tech_classification_df(spark, catalog_name, silver_db_name)

    declarations_df = get_declarations(
        declarations_company_filtered_df,
        family_technology_generation_df,
        video_coding_wifi_std_doc_id_harmonized_df,
        most_meaningful_standard_info_df,
        cellular_technology_classification_df,
    )

    declarations_gold_df = (
        declarations_df.join(get_declaration_companies, DeclarationGoldModel.ID, "left")
        .join(get_patent_mapping, DeclarationGoldModel.PUBLICATION_NUMBER, "left")
        .join(get_normalized_group, DeclarationGoldModel.GROUP, "left")
    )

    declarations_final_gold_df = SolrDeclarationGroupNormalizedMapper.apply(declarations_gold_df)
    declarations_final_gold_df = declarations_final_gold_df.withColumn(
        DeclarationGoldModel.EXPANDED, F.lit("Original declaration")
    )

    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    for col_name in columns_to_drop:
        if col_name in declarations_final_gold_df.columns:
            declarations_final_gold_df = declarations_final_gold_df.drop(col_name)
    declarations_final_gold_df_repartitioned = declarations_final_gold_df.repartition(DeclarationGoldModel.ID)

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=gold_db_name,
            table=DeclarationGoldModel.PATH,
        ),
        config=config,
    ).run(declarations_final_gold_df_repartitioned)


def get_declarations(
    declarations_company_filtered_df: DataFrame,
    family_technology_generation_df: DataFrame,
    video_coding_wifi_std_doc_id_harmonized_df: DataFrame,
    most_meaningful_standard_info_df: DataFrame,
    cellular_technology_classification_df: DataFrame,
):

    declarations_df = (
        declarations_company_filtered_df.join(
            family_technology_generation_df, DeclarationCompanyFilteredModel.ID, "left"
        ).join(cellular_technology_classification_df, on=DeclarationCompanyFilteredModel.PUBLICATION_NUMBER, how="left")
    ).persist(StorageLevel.MEMORY_AND_DISK)

    declarations_df = CellularTechnologyClassificationMapper.apply(declarations_df)

    declarations_df = SolrDeclarationMapper.apply(declarations_df)
    declarations_df = SolrTechnologyGenerationMapper.apply(declarations_df)

    declarations_preparation_df = declarations_df.join(
        video_coding_wifi_std_doc_id_harmonized_df, DeclarationGoldModel.TECHNOLOGY_GENERATION, "left"
    ).join(most_meaningful_standard_info_df, DeclarationGoldModel.ID, "left")

    return SolrDeclarationEnrichmentMapper.apply(declarations_preparation_df)


def get_declarations_groups_normalized(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_db_name, BRONZE_DECLARATIONS_GROUPS_NORMALIZED),
        streaming=False,
    ).run()

    return (
        df.withColumnRenamed("groups", declarations_groups_normalizer.GROUP)
        .withColumnRenamed("groups_normalized", declarations_groups_normalizer.GROUP_NORMALIZED)
        .select(
            F.col(declarations_groups_normalizer.GROUP),
            F.col(declarations_groups_normalizer.GROUP_NORMALIZED),
        )
    )


def get_patents_index(
    spark: SparkSession, catalog_name: str, source_db_name: str, declaration_company_filtered_model: DataFrame
):
    company_filter_df = declaration_company_filtered_model.select(F.col("publication_id")).distinct()
    df = ReadDeltaTableTask(
        spark, fully_qualified_table_name(catalog_name, source_db_name, BRONZE_PATENTS_INDEX), streaming=False
    ).run()

    return df.join(company_filter_df, "publication_id", "left_semi").transform(patents_index_mapper)


def get_standard_document_id_harmonized(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_db_name, BRONZE_STANDARD_DOCID_HARMONIZED),
        streaming=False,
    ).run()
    return df.select(
        F.col(declarations_standard_docid_harmonized.TECHNOLOGY_GENERATION),
        F.col(declarations_standard_docid_harmonized.STANDARD_DOCUMENT_ID_HARMONIZED_VAL),
    )


def get_declarations_company_filtered(spark: SparkSession, catalog_name: str, silver_db_name: str):
    return (
        ReadDeltaTableTask(
            spark,
            fully_qualified_table_name(catalog_name, silver_db_name, DeclarationCompanyFilteredModel.PATH),
            streaming=False,
        )
        .run()
        .filter(F.col(DeclarationCompanyFilteredModel.IS_COMPANY_VALID) == True)
        .select(
            F.col(DeclarationCompanyFilteredModel.PUBLICATION_ID),
            F.col(DeclarationCompanyFilteredModel.PUBLICATION_NUMBER),
            F.col(DeclarationCompanyFilteredModel.SSO),
            F.col(DeclarationCompanyFilteredModel.DATA_PROVIDER),
            F.col(DeclarationCompanyFilteredModel.STANDARD_PROJECT),
            F.col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_ID),
            F.col(DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION),
            F.col(DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION),
            F.col(DeclarationCompanyFilteredModel.DECLARATION_DATE),
            F.col(DeclarationCompanyFilteredModel.PATENT_POOL_NAME),
            F.col(DeclarationCompanyFilteredModel.LICENSING_TERMS),
            F.col(DeclarationCompanyFilteredModel.SPECIFIC_LICENSING_CONDITIONS),
            F.col(DeclarationCompanyFilteredModel.RECIPOCITY_STATEMENT),
            F.col(DeclarationCompanyFilteredModel.LICENSING_COMMENT),
            F.col(DeclarationCompanyFilteredModel.DECLARANT_IS_PREPARED_TO_GRANT_LICENSES),
            F.col(DeclarationCompanyFilteredModel.CONTACT_PERSON_FOR_LICENSE),
            F.col(DeclarationCompanyFilteredModel.CONTACT_PERSON_POSITION),
            F.col(DeclarationCompanyFilteredModel.CONTACT_ADDRESS_FOR_LICENSE),
            F.col(DeclarationCompanyFilteredModel.CONTACT_PHONE_FOR_LICENSE),
            F.col(DeclarationCompanyFilteredModel.CONTACT_EMAIL_FOR_LICENSE),
            F.col(DeclarationCompanyFilteredModel.SECTION),
            F.col(DeclarationCompanyFilteredModel.APPLICATION_AS_TO_DECLARATION_OTHER),
            F.col(DeclarationCompanyFilteredModel.PUBLICATION_AS_TO_DECLARATION_OTHER),
            F.col(DeclarationCompanyFilteredModel.TECHNOLOGY_GENERATION_ARRAY),
            F.col(DeclarationCompanyFilteredModel.GROUP_ARRAY),
            F.col(DeclarationCompanyFilteredModel.TITLE),
            F.col(DeclarationCompanyFilteredModel.PUBLICATION_NUMBER_SOURCE),
            F.col(DeclarationCompanyFilteredModel.ISLD),
            F.col(DeclarationCompanyFilteredModel.DISCLOSURE_NUMBER),
            F.col(DeclarationCompanyFilteredModel.DECLARATION_ID),
            F.col(DeclarationCompanyFilteredModel.ID),
            F.col(DeclarationCompanyFilteredModel.ID_FIRST_CHAR),
            F.col(DeclarationCompanyFilteredModel.TYPE),
            F.col(DeclarationCompanyFilteredModel.ESSENTIAL_CLAIM_NUMBER),
            F.col(DeclarationCompanyFilteredModel.POOL_PROVIDER),
            F.col(DeclarationCompanyFilteredModel.POOL_NAME_HARMONIZED),
            F.col(DeclarationCompanyFilteredModel.TECHNOLOGY_CLASSIFICATION),
            F.col(DeclarationCompanyFilteredModel.STANDARD_DOCUMENT_TITLE),
        )
        .persist(StorageLevel.MEMORY_AND_DISK)
    )


def get_harmonized_raw_declaring_companies(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_db_name, SILVER_HARMONIZED_RAW_DECLARING_COMPANIES),
        streaming=False,
    ).run()

    return df.select(
        F.col(RawDeclarationCompaniesHarmonizations.DECLARING_ID),
        F.col(RawDeclarationCompaniesHarmonizations.HARMONIZED_NAME),
    ).transform(solr_declaration_companies_mapper)


def get_family_technology_generation(spark: SparkSession, catalog_name: str, silver_db_name: str):
    return ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, silver_db_name, SILVER_DECLARATION_FAMILY_TECHNOLOGY_GENERATION),
        streaming=False,
    ).run()


def get_declarations_with_most_meaningful_standard_info(spark: SparkSession, catalog_name: str, silver_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, silver_db_name, SILVER_DECLARATION_WITH_MOST_MEANINGFUL_STANDARD_INFO),
        streaming=False,
    ).run()
    return (
        df.withColumnRenamed(declarations_most_meaningful_standard_info.DECLARATION_ID, "id")
        .withColumnRenamed(
            declarations_most_meaningful_standard_info.ORIGINAL_STANDARD_DOCUMENT_URL, "original_standard"
        )
        .select(
            F.col("id"),
            F.col(declarations_most_meaningful_standard_info.STANDARD_DOCUMENT_REF),
            F.col("original_standard"),
        )
    )


def get_cellular_tech_classification_df(spark: SparkSession, catalog_name: str, silver_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, silver_db_name, SILVER_CELLULAR_TECHNOLOGY_CLASSIFICATION),
        streaming=False,
    ).run()

    return df.select(
        CellularTechnologyClassification.TECHNOLOGY_CLASSIFICATION,
        CellularTechnologyClassification.PUBLICATION_NUMBER,
    ).withColumnRenamed(
        CellularTechnologyClassification.TECHNOLOGY_CLASSIFICATION, "technology_classification_cellular"
    )
