from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.gold.declarations.declaration_velos_media_mapper as DeclarationVelosMediaMapper
import src.declarations.models.bronze.patents.patents_index as PatentsIndexModel
import src.declarations.models.gold.declarations.declarations_gold_velos_media_index_preparation as DeclarationsVelosMediaGoldModel
import src.declarations.models.silver.declarations.declaration_most_meaningful_standard_info as DeclarationMostMeaningfulStandardInfo
import src.declarations.models.silver.declarations.velos_media_expansion_calculator as VelosMediaExpansionModel
import src.declarations.models.silver.patents.patent_transferred_flag_current_assignee as PatentsAssigneesModel


def process(spark: SparkSession, catalog_name: str, silver_db_name: str, gold_db_name: str, config: PipelineConfig):

    velos_media_publication_ids = get_velos_media_publication_ids(spark, catalog_name, silver_db_name)
    declarations_with_most_meaningful_standard_info = get_declarations_with_most_meaningful_standard_info(
        spark, catalog_name, silver_db_name
    )
    patents_index = get_patents_index(spark, catalog_name, silver_db_name)
    patents_assignee_data = get_patent_assignee_data(spark, catalog_name, silver_db_name)

    velos_media_gold_df = velos_media_publication_ids.join(
        patents_index, DeclarationsVelosMediaGoldModel.PUBLICATION_ID, "left"
    ).join(patents_assignee_data, DeclarationsVelosMediaGoldModel.PUBLICATION_ID, "left")

    velos_media_gold_final_df = DeclarationVelosMediaMapper.apply(velos_media_gold_df)
    velos_media_gold_final_df = (
        (
            velos_media_gold_final_df.join(
                declarations_with_most_meaningful_standard_info, DeclarationsVelosMediaGoldModel.ID, "left"
            )
        )
        .withColumn(
            DeclarationsVelosMediaGoldModel.STANDARD_DOCUMENT_REF,
            F.col(DeclarationMostMeaningfulStandardInfo.STANDARD_DOCUMENT_REF),
        )
        .withColumn(DeclarationsVelosMediaGoldModel.ORIGINAL_STANDARD, F.col("original_standard"))
    )

    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    for col_name in columns_to_drop:
        if col_name in velos_media_gold_final_df.columns:
            velos_media_gold_final_df = velos_media_gold_final_df.drop(col_name)
    velos_media_gold_final_df_repartitioned = velos_media_gold_final_df.repartition(DeclarationsVelosMediaGoldModel.ID)

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=gold_db_name,
            table=DeclarationsVelosMediaGoldModel.PATH,
        ),
        config=config,
    ).run(velos_media_gold_final_df_repartitioned)


def get_velos_media_publication_ids(spark: SparkSession, catalog_name: str, source_db_name: str):
    return ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_db_name, VelosMediaExpansionModel.PATH),
        streaming=False,
    ).run()


def get_declarations_with_most_meaningful_standard_info(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_db_name, DeclarationMostMeaningfulStandardInfo.PATH),
        streaming=False,
    ).run()

    return (
        df.withColumnRenamed(DeclarationMostMeaningfulStandardInfo.DECLARATION_ID, "id")
        .withColumnRenamed(DeclarationMostMeaningfulStandardInfo.ORIGINAL_STANDARD_DOCUMENT_URL, "original_standard")
        .select(
            F.col("id"),
            F.col(DeclarationMostMeaningfulStandardInfo.STANDARD_DOCUMENT_REF),
            F.col("original_standard"),
        )
    )


def get_patents_index(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = ReadDeltaTableTask(
        spark, fully_qualified_table_name(catalog_name, source_db_name, PatentsIndexModel.PATH), streaming=False
    ).run()

    return df.select(
        F.col(PatentsIndexModel.PUBLICATION_ID),
        F.col(PatentsIndexModel.PUBLICATION_NUMBER),
        F.col(PatentsIndexModel.PUBLICATION_DATE),
    )


def get_patent_assignee_data(spark, catalog_name, source_db_name):
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=PatentsAssigneesModel.PATH
        ),
        streaming=False,
    ).run()

    return df.select(
        F.col(PatentsAssigneesModel.PUBLICATION_ID),
        F.col(PatentsAssigneesModel.ASSIGNEE_HARMONIZED_NAME_ARRAY),
        F.col(PatentsAssigneesModel.ASSIGNEE_NAME_ARRAY),
    )
