from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

from src.declarations.models.gold.declarations import (
    declaration_all_gold as DeclarationAllGoldModel,
)

TABLES = {
    "GOLD_DECLARATION": "declarations_gold",
    "GOLD_DECLARATION_EXPANDED": "declarations_expanded_gold",
    "GOLD_DECLARATION_VELOAS_MEDIA": "velos_media_declarations",
    "GOLD_EXPANDED_TOP_10_ETSI_DECLARATIONS": "expanded_top_10_etsi_declarations",
    "GOLD_UNDECLARED_PATENT_ALL": "undeclared_patent_all",
    "GOLD_UNDECLARED_PATENT_EXPANDED": "undeclared_patent_expanded",
}


def process(
    spark: SparkSession,
    catalog_name: str,
    gold_db_name: str,
    config: PipelineConfig,
):
    """Combine all gold declaration tables into declarations_all_gold"""

    def read_table(spark: SparkSession, catalog_name: str, source_db_name: str, table_path: str):
        return ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(catalog_name, source_db_name, table_path),
            streaming=False,
        ).run()

    dfs = [read_table(spark, catalog_name, gold_db_name, TABLES[t]) for t in TABLES]

    #  Normalize BOOLEAN column types before union to cover datatype mismatch---
    boolean_columns = ["pooled", "basis_patent"]
    normalized_dfs = []

    for df in dfs:
        for col_name in boolean_columns:
            if col_name in df.columns:
                df = df.withColumn(col_name, F.col(col_name).cast("boolean"))
        normalized_dfs.append(df)

    combined_df = normalized_dfs[0]
    for df in normalized_dfs[1:]:
        combined_df = combined_df.unionByName(df, allowMissingColumns=True)

    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    for col_name in columns_to_drop:
        if col_name in combined_df.columns:
            combined_df = combined_df.drop(col_name)

    # Write final combined DataFrame to gold
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=gold_db_name,
            table=DeclarationAllGoldModel.PATH,
        ),
        config=config,
        mode="overwrite",
    ).run(combined_df)
