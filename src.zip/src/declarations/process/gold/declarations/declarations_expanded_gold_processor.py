from pyspark import StorageLevel
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.gold.declarations.cellular_technology_classification_mapper as CellularTechnologyClassificationMapper
import src.declarations.models.bronze.patents.patents_index as patents_index
import src.declarations.models.gold.declarations.declaration_expanded_gold as DeclarationExpandedGold
import src.declarations.models.gold.declarations.declaration_gold as declaration
import src.declarations.models.silver.declarations.cellular_technology_classification as CellularTechnologyClassification
import src.declarations.models.silver.declarations.declaration_most_meaningful_standard_info as declarations_most_meaningful_standard_info
import src.declarations.models.silver.declarations.declaration_sep_family_expansion as familySepExpansion
from src.declarations.common.declarations_table_config.table_config import (
    BRONZE_PATENTS_INDEX,
    GOLD_DECLARATION,
    SILVER_CELLULAR_TECHNOLOGY_CLASSIFICATION,
    SILVER_DECLARATION_SEP_FAMILY_EXPANSION,
    SILVER_DECLARATION_WITH_MOST_MEANINGFUL_STANDARD_INFO,
)
from src.declarations.mappers.gold.declarations.declaration_expanded_id_generator_mapper import (
    apply as declaration_expanded_id_generator_mapper,
)

PARTITION_SIZE = 50000


def process(spark: SparkSession, catalog_name: str, silver_db_name: str, gold_db_name: str, config: PipelineConfig):
    publication_id_join = ["publication_id"]
    declaration_id_join = ["id"]

    family_sep_expansion_df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=silver_db_name, table=SILVER_DECLARATION_SEP_FAMILY_EXPANSION
            ),
            streaming=False,
        )
        .run()
        .drop("_commit_version")
        .persist(StorageLevel.MEMORY_AND_DISK)
    )

    family_expanded_publication_ids = get_family_expanded_publication_ids(family_sep_expansion_df)
    declaration_ids_used_to_enrich = get_declaration_ids_used_to_enrich(family_sep_expansion_df)

    result = (
        get_family_expansion_table(family_sep_expansion_df)
        .withColumnRenamed(familySepExpansion.TAKE_DECLARATION_DATA_FROM, "id")
        .join(
            get_declarations_data_from_ids(spark, catalog_name, gold_db_name, declaration_ids_used_to_enrich),
            declaration_id_join,
            "left",
        )
        .join(
            get_publication_numbers(spark, catalog_name, silver_db_name, family_expanded_publication_ids),
            publication_id_join,  # Keep only this join condition
            "left",
        )
        .join(
            get_cellular_tech_classification_df(spark, catalog_name, silver_db_name),
            CellularTechnologyClassification.PUBLICATION_NUMBER,
            "left",
        )
    )
    result = declaration_expanded_id_generator_mapper(result)

    family_expanded_documents = (
        result.join(declaration_ids_used_to_enrich, "id", "left_anti")
        .join(get_most_meaning_full_standard_info(spark, catalog_name, silver_db_name), declaration_id_join, "left")
        .transform(CellularTechnologyClassificationMapper.apply)
    )

    result = family_expanded_documents.dropDuplicates(["id"])
    result = result.withColumn(DeclarationExpandedGold.DECLARATION_ID, F.lit(None).cast(StringType())).withColumn(
        DeclarationExpandedGold.PUBLICATION_YEAR, F.year(F.col(DeclarationExpandedGold.DECLARATION_DATE))
    )

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=gold_db_name,
            table=DeclarationExpandedGold.PATH,
        ),
        config=config,
        mode="overwrite",
    ).run(result)


def get_declaration_ids_used_to_enrich(family_sep_expansion: DataFrame) -> DataFrame:
    return family_sep_expansion.select(F.col(familySepExpansion.TAKE_DECLARATION_DATA_FROM).alias("id")).distinct()


def get_family_expanded_publication_ids(family_sep_expansion: DataFrame) -> DataFrame:
    return family_sep_expansion.select(familySepExpansion.PUBLICATION_ID).distinct()


def get_family_expansion_table(family_sep_expansion: DataFrame) -> DataFrame:
    return family_sep_expansion.select(
        familySepExpansion.PUBLICATION_ID, familySepExpansion.TAKE_DECLARATION_DATA_FROM
    ).withColumn("expanded", F.lit("Simple Family expansion"))


def get_declarations_data_from_ids(
    spark: SparkSession, catalog_name, source_database, declaration_ids_df: DataFrame
) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, GOLD_DECLARATION),
        streaming=False,
    ).run()
    return df.join(declaration_ids_df, declaration.ID, "left_semi").drop(
        declaration.DECLARATION_ID,
        declaration.PUBLICATION_ID,
        declaration.PUBLICATION_NUMBER,
        declaration.PUBLICATION_YEAR,
        declarations_most_meaningful_standard_info.STANDARD_DOCUMENT_REF,
        declaration.ORIGINAL_STANDARD,
        declaration.EXPANDED,
        "_commit_version",
    )


def get_publication_numbers(
    spark: SparkSession, catalog_name, source_database, publication_ids_df: DataFrame
) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, BRONZE_PATENTS_INDEX),
        streaming=False,
    ).run()
    return df.join(publication_ids_df, "publication_id", "left_semi").select(
        patents_index.PUBLICATION_NUMBER, F.col("publication_id")
    )


def get_cellular_tech_classification_df(spark: SparkSession, catalog_name: str, source_database: str):
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(catalog_name, source_database, SILVER_CELLULAR_TECHNOLOGY_CLASSIFICATION),
        streaming=False,
    ).run()

    return df.select(
        CellularTechnologyClassification.TECHNOLOGY_CLASSIFICATION,
        CellularTechnologyClassification.PUBLICATION_NUMBER,
    ).withColumnRenamed(
        CellularTechnologyClassification.TECHNOLOGY_CLASSIFICATION, "technology_classification_cellular"
    )


def get_most_meaning_full_standard_info(spark: SparkSession, catalog_name, source_database) -> DataFrame:
    df = ReadDeltaTableTask(
        spark,
        fully_qualified_table_name(
            catalog_name, source_database, SILVER_DECLARATION_WITH_MOST_MEANINGFUL_STANDARD_INFO
        ),
        streaming=False,
    ).run()
    return (
        df.withColumnRenamed(declarations_most_meaningful_standard_info.DECLARATION_ID, "id")
        .withColumnRenamed(
            declarations_most_meaningful_standard_info.ORIGINAL_STANDARD_DOCUMENT_URL, "original_standard"
        )
        .select(
            F.col("id"),
            F.col(declarations_most_meaningful_standard_info.STANDARD_DOCUMENT_REF),
            F.col("original_standard"),
        )
    )
