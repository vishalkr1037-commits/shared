import logging

from pyspark import StorageLevel
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.dataframe import DataFrame
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.bronze.patents.patents_index as patents_index
import src.declarations.models.gold.declarations.declaration_expanded_gold as DeclarationExpandedGold
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
from src.declarations.mappers.silver.undeclared_declarations.undeclared_patent_expanded_index_preparation_id_mapper import (
    apply as id_generator_apply,
)
from src.declarations.models.gold.undeclared_declarations import (
    undeclared_patent_expanded as UndeclaredPatentExpanded,
)

# Configure the root logger
logging.basicConfig(
    level=logging.INFO,  # or logging.DEBUG for more detailed logs
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

# Create a logger for your application
logger = logging.getLogger("undeclared_patent_expanded_index_preparation_processor")


def align_to_base_schema(base_df: DataFrame, df: DataFrame) -> DataFrame:
    """
    Align df to have the same columns and data types as base_df.
    Missing columns are added as nulls; extra columns are dropped.
    Column order is aligned to base_df.
    """
    base_schema = {f.name: f.dataType for f in base_df.schema.fields}

    # Add missing columns and cast existing ones
    for col_name, col_type in base_schema.items():
        if col_name not in df.columns:
            df = df.withColumn(col_name, F.lit(None).cast(col_type))
        else:
            df = df.withColumn(col_name, df[col_name].cast(col_type))

    # Drop extra columns
    extra_cols = set(df.columns) - set(base_schema.keys())
    df = df.drop(*extra_cols)

    # Reorder columns to match base
    return df.select(*base_schema.keys())


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    gold_db_name: str,
    config: PipelineConfig,
):
    logger.info("Starting undeclared patent expanded index preparation processor...")
    undeclared_family_patent_df = (
        get_undeclared_expanded_table(spark, catalog_name, silver_db_name, "video_encoding")
        .unionByName(get_undeclared_expanded_table(spark, catalog_name, silver_db_name, "audio_encoding"))
        .unionByName(get_undeclared_expanded_table(spark, catalog_name, silver_db_name, "vp9_av1"))
        .unionByName(get_undeclared_expanded_table(spark, catalog_name, silver_db_name, "wifi"))
        .unionByName(get_undeclared_expanded_table(spark, catalog_name, silver_db_name, "qi"))
        .persist(StorageLevel.MEMORY_AND_DISK)
    )

    union_all_tech_df = (
        get_undeclared_patent_tech_table(spark, catalog_name, silver_db_name, "wifi")
        .unionByName(
            get_undeclared_patent_tech_table(spark, catalog_name, silver_db_name, "audio_encoding"),
            allowMissingColumns=True,
        )
        .unionByName(
            get_undeclared_patent_tech_table(spark, catalog_name, silver_db_name, "vp9_av1"), allowMissingColumns=True
        )
        .unionByName(
            get_undeclared_patent_tech_table(spark, catalog_name, silver_db_name, "video_encoding"),
            allowMissingColumns=True,
        )
        .unionByName(
            get_undeclared_patent_tech_table(spark, catalog_name, silver_db_name, "qi"), allowMissingColumns=True
        )
    )
    logger.debug("Undeclared family patent DataFrame loaded.")

    simple_family_expanded_publication_ids_df = get_simple_family_expanded_declaration_ids(
        spark, catalog_name, gold_db_name
    )
    original_declaration_ids_df = get_original_declaration_ids(spark, catalog_name, gold_db_name)

    family_expanded_publication_ids_df = get_family_expanded_publication_ids(undeclared_family_patent_df)
    declaration_ids_used_to_enrich_df = get_declaration_ids_used_to_enrich(undeclared_family_patent_df)
    logger.debug("DataFrames for publication IDs and declaration IDs prepared.")

    family_expanded_documents = (
        get_family_expansion_table(undeclared_family_patent_df)
        .join(
            get_declarations_data_from_ids(declaration_ids_used_to_enrich_df, union_all_tech_df),
            ["id"],
            "left",
        )
        .join(
            get_publication_numbers(spark, catalog_name, silver_db_name, family_expanded_publication_ids_df),
            ["publication_id"],
            "left",
        )
    )
    logger.debug("Family expanded documents DataFrame prepared.")
    family_expanded_documents = (
        id_generator_apply(family_expanded_documents)
        .join(declaration_ids_used_to_enrich_df, "id", "left_anti")
        .join(simple_family_expanded_publication_ids_df, "publication_id", "left_anti")
        .join(original_declaration_ids_df, "publication_id", "left_anti")
        .withColumn("id_first_char", F.substring(F.col("id"), 1, 1))
        .withColumn("original_standard", F.lit(""))
        .withColumn("standard_document_ref", F.lit(""))
    )
    logger.debug("Family expanded documents DataFrame after joins and ID generation.")

    repartitioned_df = (
        family_expanded_documents.dropDuplicates(["id"]).drop("_commit_version").repartition("id_first_char")
    )
    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name, database=gold_db_name, table=UndeclaredPatentExpanded.PATH
        ),
        config=config,
        mode="overwrite",
    ).run(repartitioned_df)
    logger.info("Data written to Delta table successfully.")


def get_declaration_ids_used_to_enrich(undeclared_family_patent_df: DataFrame):
    return undeclared_family_patent_df.select(F.col("take_declaration_data_from").alias("id")).distinct()


def get_undeclared_expanded_table(spark, catalog_name: str, source_db_name: str, tech: str):
    return ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=f"family_undeclared_patent_{tech}_expansion"
        ),
        streaming=False,
    ).run()


def get_undeclared_patent_tech_table(spark, catalog_name: str, source_db_name: str, tech: str):
    # Read the Delta table
    df = ReadDeltaTableTask(
        spark=spark,
        fq_source_table=fully_qualified_table_name(
            catalog=catalog_name, database=source_db_name, table=f"undeclared_patent_{tech}"
        ),
        streaming=False,
    ).run()

    return df


def get_family_expanded_publication_ids(undeclared_family_patent_df: DataFrame):
    return undeclared_family_patent_df.select("publication_id").distinct()


def get_family_expansion_table(undeclared_family_patent_df: DataFrame):
    return undeclared_family_patent_df.select(
        F.col("publication_id"), F.col("take_declaration_data_from").alias("id")
    ).withColumn("expanded", F.lit("Undeclared patent"))


def get_declarations_data_from_ids(declaration_ids_df: DataFrame, undeclared_patents: DataFrame) -> DataFrame:
    return (
        undeclared_patents.join(declaration_ids_df, "id", "left_semi")
        .filter(F.col("publication_id").isNotNull())
        .drop("declaration_id", "id_first_char", "publication_id", "publication_number", "publication_year", "expanded")
    )


def get_publication_numbers(spark, catalog_name: str, source_db_name: str, publication_ids_df: DataFrame):
    # This would need to be implemented based on your IfiPatentDocumentValuesReader equivalent
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=patents_index.PATH
            ),
            streaming=False,
        )
        .run()
        .join(publication_ids_df, "publication_id", "left_semi")
        .select("publication_number", "publication_id", "publication_year")
    )


def get_original_declaration_ids(spark, catalog_name: str, source_db_name: str):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationGoldModel.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(F.col("publication_id").isNotNull())
        .select("publication_id")
        .distinct()
    )


def get_simple_family_expanded_declaration_ids(spark, catalog_name: str, source_db_name: str):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationExpandedGold.PATH
            ),
            streaming=False,
        )
        .run()
        .filter(F.col("publication_id").isNotNull())
        .select("publication_id")
        .distinct()
    )
