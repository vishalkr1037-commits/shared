import logging

from pyspark import StorageLevel
from pyspark.sql import SparkSession
from pyspark.sql.functions import array, col, lit
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.mappers.gold.undeclared_declarations.undeclared_patent_all_mapper as UndeclaredPatentAllMapper
import src.declarations.models.gold.declarations.declaration_expanded_gold as DeclarationExpandedGold
import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
from src.declarations.models.gold.undeclared_declarations import (
    undeclared_patent_all as UndeclaredPatentAll,
)
from src.declarations.models.gold.undeclared_declarations import (
    undeclared_patent_expanded as UndeclaredPatentExpanded,
)

# Configure the root logger
logging.basicConfig(
    level=logging.INFO,  # or logging.DEBUG for more detailed logs
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("undeclared_patent_all_index_preparation_processor")


columns_to_select = [
    "publication_number",
    "id",
    "technology_generation",
    "publication_id",
    "standard_document_id",
    "standard_project",
    "declaration_date",
    "isld",
    "section",
    "id_first_char",
    "sso",
    "application_as_to_declaration",
    "publication_as_to_declaration",
    "licensing_terms",
    "specific_licensing_conditions",
    "licensing_comment",
    "contact_person_for_license",
    "contact_person_position",
    "contact_address_for_license",
    "contact_phone_for_license",
    "contact_email_for_license",
    "disclosure_number",
    "declaration_id",
    "application_as_to_declaration_other",
    "publication_as_to_declaration_other",
    "technology_generation_array",
    "release",
    "group_array",
    "expanded",
    "data_provider",
    "sso_search",
    "standard_project_search",
    "declaration_year",
    "pooled",
    "pool_name",
    "pool_name_search",
    "basis_patent",
    "application_as_to_declaration_search",
    "application_as_to_declaration_array",
    "publication_as_to_declaration_search",
    "publication_as_to_declaration_array",
    "application_as_to_declaration_other_search",
    "application_as_to_declaration_other_array",
    "publication_as_to_declaration_other_search",
    "publication_as_to_declaration_other_array",
    "reciprocity_statement",
    "prepared_to_grant_licenses",
    "isld_search",
    "standard_document_id_search",
    "family_technology_generation",
    "group",
    "release_array",
    "family_technology_generation_array",
    "harmonized_standard_doc_id",
    "standard_document_id_harmonized",
    "standard_document_id_harmonized_search",
    "darts_ip_url",
    "declaring_company",
    "declaring_company_search",
    "declaring_company_array",
    "publication_year",
    "type",
]


join_keys = ["publication_id", "technology_generation"]


def process(
    spark: SparkSession,
    catalog_name: str,
    silver_db_name: str,
    gold_db_name: str,
    config: PipelineConfig,
):
    expanded_artificial_declarations_refined_df = get_expanded_artificial_declarations(
        spark, catalog_name, gold_db_name
    ).drop("_commit_version")

    all_undeclared_patent_df = (
        get_all_artificial_declarations(spark, catalog_name, silver_db_name)
        .unionByName(expanded_artificial_declarations_refined_df, allowMissingColumns=True)
        .join(get_declarations(spark, catalog_name, gold_db_name), on=join_keys, how="left_anti")
        .dropDuplicates(["id"])
        .persist(StorageLevel.MEMORY_AND_DISK)
    )

    repartitioned_df = all_undeclared_patent_df.repartition("id_first_char")
    repartitioned_df = UndeclaredPatentAllMapper.apply(repartitioned_df)

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name,
            database=gold_db_name,
            table=UndeclaredPatentAll.PATH,
        ),
        config=config,
        mode="overwrite",
    ).run(repartitioned_df)

    logger.info("Data written to Delta table successfully.")


def get_artificial_declarations_wifi(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table="undeclared_patent_wifi"
            ),
            streaming=False,
        )
        .run()
        .select(*[col(c) for c in columns_to_select])
    )


def get_artificial_declarations_video_coding(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table="undeclared_patent_video_encoding"
            ),
            streaming=False,
        )
        .run()
        .select(*[col(c) for c in columns_to_select])
    )


def get_artificial_declarations_qi(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table="undeclared_patent_qi"
            ),
            streaming=False,
        )
        .run()
        .select(*[col(c) for c in columns_to_select])
    )


def get_artificial_declarations_vp9_av1(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table="undeclared_patent_vp9_av1"
            ),
            streaming=False,
        )
        .run()
        .select(*[col(c) for c in columns_to_select])
    )


def get_artificial_declarations_audio_coding(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table="undeclared_patent_audio_encoding"
            ),
            streaming=False,
        )
        .run()
        .select(*[col(c) for c in columns_to_select])
    )


def get_declarations_publication_tech(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationGoldModel.PATH
            ),
            streaming=False,
        )
        .run()
        .select(DeclarationGoldModel.PUBLICATION_ID, DeclarationGoldModel.TECHNOLOGY_GENERATION)
        .distinct()
    )


def get_expanded_declarations_publication_tech(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationExpandedGold.PATH
            ),
            streaming=False,
        )
        .run()
        .select(DeclarationExpandedGold.PUBLICATION_ID, DeclarationExpandedGold.TECHNOLOGY_GENERATION)
        .distinct()
    )


def get_expanded_artificial_declarations(spark, catalog_name, source_db_name):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=UndeclaredPatentExpanded.PATH
            ),
            streaming=False,
        )
        .run()
        .withColumns({"declaration_id": lit("")})
    )


# def get_all_artificial_declarations(spark, catalog_name, source_db_name):
#     wifi_df = get_artificial_declarations_wifi(spark, catalog_name, source_db_name)
#     video_coding_df = get_artificial_declarations_video_coding(spark, catalog_name, source_db_name)
#     qi_df = get_artificial_declarations_qi(spark, catalog_name, source_db_name)
#     vp9_av1_df = get_artificial_declarations_vp9_av1(spark, catalog_name, source_db_name)
#     audio_coding_df = get_artificial_declarations_audio_coding(spark, catalog_name, source_db_name)

#     all_artificial_declarations_df = (
#         wifi_df.unionByName(video_coding_df, allowMissingColumns=True)
#         .unionByName(qi_df, allowMissingColumns=True)
#         .unionByName(vp9_av1_df, allowMissingColumns=True)
#         .unionByName(audio_coding_df, allowMissingColumns=True)
#         .withColumns(
#             {
#                 "pooled": lit("No"),
#                 "isld": array(lit("")),
#                 "isld_search": array(lit("")),
#             }
#         )
#     )

#     return all_artificial_declarations_df


def get_all_artificial_declarations(spark, catalog_name, source_db_name):
    wifi_df = get_artificial_declarations_wifi(spark, catalog_name, source_db_name)
    video_coding_df = get_artificial_declarations_video_coding(spark, catalog_name, source_db_name)
    qi_df = get_artificial_declarations_qi(spark, catalog_name, source_db_name)
    vp9_av1_df = get_artificial_declarations_vp9_av1(spark, catalog_name, source_db_name)
    audio_coding_df = get_artificial_declarations_audio_coding(spark, catalog_name, source_db_name)

    dfs = [wifi_df, video_coding_df, qi_df, vp9_av1_df, audio_coding_df]
    base_schema = wifi_df.schema  # WiFi as the reference schema

    standardized_dfs = []
    for df in dfs:
        # 🔹 Ensure 'pooled' exists and is boolean everywhere
        if "pooled" in df.columns:
            df = df.withColumn("pooled", col("pooled").cast("boolean"))
        else:
            df = df.withColumn("pooled", lit(False).cast("boolean"))

        # 🔹 Add missing columns from base schema as nulls
        for field in base_schema.fields:
            if field.name not in df.columns:
                df = df.withColumn(field.name, lit(None).cast(field.dataType))

        # 🔹 Reorder columns to match base schema
        df = df.select(*[f.name for f in base_schema.fields])
        standardized_dfs.append(df)

    # 🔹 Safe union after schema + type alignment
    all_artificial_declarations_df = standardized_dfs[0]
    for next_df in standardized_dfs[1:]:
        all_artificial_declarations_df = all_artificial_declarations_df.unionByName(next_df)

    # 🔹 Add uniform columns (keeping pooled as boolean)
    all_artificial_declarations_df = all_artificial_declarations_df.withColumns(
        {
            "pooled": lit(False).cast("boolean"),
            "isld": array(lit("")),
            "isld_search": array(lit("")),
        }
    )

    return all_artificial_declarations_df


def get_declarations(spark, catalog_name: str, gold_db_name: str):
    declarations_publication_tech_df = get_declarations_publication_tech(spark, catalog_name, gold_db_name)
    expanded_declarations_publication_tech_df = get_expanded_declarations_publication_tech(
        spark, catalog_name, gold_db_name
    )

    return declarations_publication_tech_df.unionByName(expanded_declarations_publication_tech_df)
