import logging

import pyspark.sql.functions as F
from pyspark.sql import SparkSession
from src.common.table_config.table_name import fully_qualified_table_name
from src.patents.config import PipelineConfig
from src.patents.tasks.read_delta_table_task import ReadDeltaTableTask
from src.patents.tasks.write_delta_table_task import WriteDeltaTableTask

import src.declarations.models.gold.declarations.declaration_gold as DeclarationGoldModel
import src.declarations.models.gold.undeclared_declarations.expanded_top_10_etsi_declarations as expanded_top_10
import src.declarations.models.silver.declarations.cellular_technology_classification as cellular_technology_classification
import src.declarations.models.silver.declarations.declaration_company_filtered as DeclarationCompanyFilteredModel
import src.declarations.models.silver.undeclared_declarations.undeclared_top10_etsi_standards as top10_etsi_standards
from src.declarations.mappers.gold.declarations.cellular_technology_classification_mapper import (
    apply as cellular_technology_classification_mapper,
)
from src.declarations.mappers.gold.undeclared_declarations.top10_etsi_aggregation_mapper import (
    apply as agrregator_mapper,
)
from src.declarations.mappers.gold.undeclared_declarations.top10_etsi_col_renaming_mapper import (
    apply as renaming_mapper,
)
from src.declarations.mappers.gold.undeclared_declarations.top10_etsi_standards_final_mapper import (
    apply as top10_final_mapper,
)
from src.declarations.mappers.gold.undeclared_declarations.top10_etsi_standards_intermediate_mapper import (
    apply as intermediate_mapper,
)
from src.declarations.mappers.silver.undeclared_declarations.declaration_top_group_mapper import (
    apply as top10_group_mapper,
)

# Configure the root logger
logging.basicConfig(
    level=logging.INFO,  # or logging.DEBUG for more detailed logs
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)

publ_number_group_join = ["publication_number", "harmonized_group", "technology_generation"]
publ_number_join = ["publication_number"]
standard_doc_id_join = (F.col("standard_document_id_top10") == F.col("standard_document_ref")) & (
    F.col("harmonized_standard_doc_id_top10") == F.col("harmonized_standard_doc_id")
)


def process(spark: SparkSession, catalog_name: str, silver_db_name: str, gold_db_name: str, config: PipelineConfig):

    declarations_company_filtered_df = get_declarations_company_filtered(spark, catalog_name, silver_db_name)
    top10_standards_df = get_top10_etsi_standards(spark, catalog_name, silver_db_name)

    joined_df = top10_standards_df.join(declarations_company_filtered_df, on=publ_number_join, how="left_anti")

    standard_project_df = get_standard_project_from_declaration(spark, catalog_name, gold_db_name)
    joined_df = joined_df.join(standard_project_df, on=standard_doc_id_join, how="left")

    joined_df = joined_df.drop("standard_document_id_top10", "harmonized_standard_doc_id_top10", "publication_year")

    declarations_data_df = get_declarations_data_from_ids(spark, catalog_name, gold_db_name)
    joined_df = joined_df.join(declarations_data_df, on=publ_number_group_join, how="left")

    cellular_iot_df = get_cellular_iot_data(spark, catalog_name, silver_db_name)
    joined_df = joined_df.join(cellular_iot_df, on=publ_number_join, how="left")

    joined_df = joined_df.transform(top10_final_mapper)

    joined_df = joined_df.transform(cellular_technology_classification_mapper).distinct()

    columns_to_drop = ["_commit_version", "_commit_timestamp", "_change_type"]
    existing_cols_to_drop = [c for c in columns_to_drop if c in joined_df.columns]
    expanded_top_10_df = joined_df.drop(*existing_cols_to_drop)

    WriteDeltaTableTask(
        spark=spark,
        fq_table_name=fully_qualified_table_name(
            catalog=catalog_name, database=gold_db_name, table=expanded_top_10.PATH
        ),
        config=config,
        mode="overwrite",
    ).run(expanded_top_10_df)
    logging.info("DataFrame written to Delta table successfully.")


def get_top10_etsi_standards(spark: SparkSession, catalog_name: str, source_db_name: str):
    df = (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name,
                database=source_db_name,
                table=top10_etsi_standards.PATH,
            ),
            streaming=False,
        )
        .run()
        .transform(top10_group_mapper)
        .transform(renaming_mapper)
        .drop("group")
    )

    return df


def get_declarations_company_filtered(spark: SparkSession, catalog_name: str, source_db_name: str):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationCompanyFilteredModel.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            F.col(DeclarationCompanyFilteredModel.PUBLICATION_NUMBER),
            F.col(DeclarationCompanyFilteredModel.IS_COMPANY_VALID),
        )
        .transform(agrregator_mapper)
        .select(F.col(DeclarationCompanyFilteredModel.PUBLICATION_NUMBER))
    )


def get_declarations_data_from_ids(spark: SparkSession, catalog_name: str, source_db_name: str):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationGoldModel.PATH
            ),
            streaming=False,
        )
        .run()
        .transform(top10_group_mapper)
        .dropDuplicates(["publication_number", "harmonized_group", "technology_generation"])
        .drop(
            "group",
            "harmonized_standard_doc_id",
            "standard_document_ref",
            "standard_document_id_harmonized_search",
            "standard_document_id_harmonized",
            "original_standard",
            "standard_document_id_search",
            DeclarationGoldModel.ID,
            DeclarationGoldModel.STANDARD_PROJECT,
            DeclarationGoldModel.STANDARD_DOCUMENT_ID,
            DeclarationGoldModel.STANDARD_PROJECT_SEARCH,
            DeclarationGoldModel.ID_FIRST_CHAR,
        )
    )


def get_standard_project_from_declaration(spark: SparkSession, catalog_name: str, source_db_name: str):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=DeclarationGoldModel.PATH
            ),
            streaming=False,
        )
        .run()
        .transform(intermediate_mapper)
    )


def get_cellular_iot_data(spark: SparkSession, catalog_name: str, source_db_name: str):
    return (
        ReadDeltaTableTask(
            spark=spark,
            fq_source_table=fully_qualified_table_name(
                catalog=catalog_name, database=source_db_name, table=cellular_technology_classification.PATH
            ),
            streaming=False,
        )
        .run()
        .select(
            F.col(cellular_technology_classification.PUBLICATION_NUMBER),
            F.col(cellular_technology_classification.TECHNOLOGY_CLASSIFICATION),
        )
        .transform(renaming_mapper)
    )
