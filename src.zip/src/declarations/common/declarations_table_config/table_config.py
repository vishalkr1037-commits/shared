import os

from lnip_data_platform_shared_libs.config.table_config.config import (
    CONFIG_TABLE_NAME,
    TableConfig,
)

# this value maps to the project field in the declarations config files below,
# it is a convience for the codebase
PROJECT_DECLARATIONS = "declarations"
LANDING_CSV_LOCATION_VIA_LA_CLAIMS_SECTION = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/via_la_claims_and_sections/*"
)
LANDING_CSV_LOCATION_DECLARING_COMPANY_LOOKUP = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/declaring_company_harmonization/*"
)
LANDING_CSV_STANDARD_DOCID_HARMONIZED = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/standards/standard_document_id_harmonized/StdDocIdHarmonizedLookUp.csv"
LANDING_CSV_LOCATION_DECLARATIONS_OTHERS_RAW = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/declarations_others/others/*"
)


LANDING_CSV_LOCATION_DECLARATIONS_POOLED_RAW = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/pooled/*"
)

LANDING_CSV_LOCATION_DECLARATIONS_RAW = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/declarations/*"
)

LANDING_CSV_TECHNOLOGY_TO_VIDEO_CODING_WIFI_STANDARD_PROJECT = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/video_coding_wifi_technology_mapping/technology_generation_video_coding_to_standard_projects.csv"

LANDING_CSV_TECHNOLOGY_CLASSIFICATION = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/technology_classification/*"
LANDING_CSV_TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/video_coding_wifi_technology_mapping/technology_generation_to_video_coding_wifi.csv"
LANDING_CSV_TECHNOLOGY_GENERATION_3GPP = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/3gpp/*"
)


LANDING_CSV_BLACKLISTED = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/blacklisted/blacklisted_working_pub_nums.csv"

LANDING_CSV_WHITELISTED = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/whitelisted/whitelisted_working_pub_nums.csv"
LANDING_CSV_MANUAL_MATCHING = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/manual_matched/*"
)

LANDING_CSV_BLACKLISTED_FAMILY = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/blacklisted/blacklisted_family_pub_nums.csv"

LANDING_CSV_THREE_GPP_SPECIFICATION_PATH = [
    "abfss://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/3gpp_set_page/",
    "abfss://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/3gpp_set/",
    "abfss://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/3gpp_specification_status_report/",
]


LANDING_CSV_INDUSTRY_CLASS_SECTOR = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/industry_class_sector/industry_class_sector.csv"
LANDING_CSV_CELLULAR_IOT_DATA = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/technology_generation/cellular_iot_data/cellular_iot_landspaces.csv"
LANDING_UNDECLARED_SIMPLE_FAMILY_ID = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/undeclared_families/"
)
LANDING_DATA_QUALITY_LOOKUP = (
    "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/data_quality/*"
)
STANDARD_DESCRIPTION = "abfss://raw@lnipdevstorage.dfs.core.windows.net/release/test/standards/description"
STANDARD_DESCRIPTION_CURATED_PATH = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/standards/description"


DECLARATIONS_GROUPS_NORMALIZED_CSV = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/normalized_groups/declarations_distinct_groups_update.csv"
DECLARATIONS_TOP_10_STANDARDS_CSV = "abfs://raw@lnipdevstorage.dfs.core.windows.net/release/declarations/landing/top_10_standards/top10StdDocIdsPerCommitteeGroup.csv"

# config files we're going to load for the declarations project
DECLARATIONS_CORE_CFG = "declarations_core_cfg.yaml"

config_files = [
    os.path.join(os.path.dirname(__file__), DECLARATIONS_CORE_CFG),
]

DECLARATIONS_TABLE_CONFIG_MAP = TableConfig.add_config_from_files(config_files)


# this wrapper is used to tidy up the fields below
def config_wrapper(table_name: str):
    return DECLARATIONS_TABLE_CONFIG_MAP[table_name][CONFIG_TABLE_NAME]


# bronze tables
BRONZE_DECLARATIONS_RAW = config_wrapper("declaration_raw")
BRONZE_DECLARATIONS_VIA_LA_CLAIMS_SECTION = config_wrapper("declaration_via_la_claims_and_sections")
BRONZE_DECLARATIONS_COMPANY_LOOKUP = config_wrapper("declaring_company_lookup")
TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI_STANDARD_PROJECTS = config_wrapper(
    "technology_generation_to_video_coding_wifi_standard_projects"
)
TECHNOLOGY_GENERATION_3GPP = config_wrapper("technology_generation_3gpp")

TECHNOLOGY_GENERATION_CLASSIFICATION = config_wrapper("technology_generation_classification")
TECHNOLOGY_GENERATION_TO_VIDEO_CODING_WIFI = config_wrapper("technology_generation_to_video_coding_wifi")
BRONZE_DECLARATIONS_BLACKLISTED = config_wrapper("blacklisted_publication_numbers")
BRONZE_DECLARATIONS_BLACKLISTED_FAMILY = config_wrapper("blacklisted_family_publication_numbers")
BRONZE_DECLARATIONS_WHITELISTED = config_wrapper("whitelisted_publication_numbers")

BRONZE_DECLARATIONS_MANUAL_MATCHING = config_wrapper("manual_matched_publication_numbers")
BRONZE_THREE_GPP_SPECIFICATIONS_SET = config_wrapper("three_gpp_specifications_set")

BRONZE_INDUSTRY_CLASS_SECTOR = config_wrapper("industry_class_sector")

BRONZE_PATENTS_INDEX = "patents_index"
BRONZE_PATENT_FAMILY = "patent_family"
BRONZE_PATENT_STATUS = "patent_status"
BRONZE_PATENT_ASSIGNEES = "patent_assignees"
BRONZE_STANDARD_DOCID_HARMONIZED = config_wrapper("declarations_standard_docid_harmonized")

BRONZE_DECLARATIONS_GROUPS_NORMALIZED = config_wrapper("declarations_groups_normalized")
BRONZE_DECLARATIONS_TOP_10_STANDARDS = config_wrapper("top_10_standards_per_committee")
BRONZE_UNDECLARED_SIMPLE_FAMILIES = config_wrapper("undeclared_simple_families")
CELLULAR_IOT_DATA = config_wrapper("cellular_iot_data")
DATA_QUALITY_LOOKUP = config_wrapper("data_quality_lookup")

# silver tables
SILVER_DECLARATIONS_RAW_ENRICHED = config_wrapper("declaration_raw_enriched")
SILVER_HARMONIZED_RAW_DECLARING_COMPANIES = config_wrapper("harmonized_raw_declaring_companies")
SILVER_PATENT_NUMBER_INDEX = "patent_number_index"
SILVER_DECLARATION_DEDUPLICATED_INTERMEDIATE = config_wrapper("declaration_deduplicated_intermediate")
SILVER_IPC_FILTERED_PATH = config_wrapper("declarations_ipc_filtered")
SILVER_INDUSTRY_CLASS_FILTERED_PATH = config_wrapper("declarations_industry_class_filtered")
SILVER_DECLARATION_PATENT_NUMBER_MATCHING_CANDIDATES = config_wrapper("declaration_patent_number_matching_candidates")
SILVER_DECLARATION_PRIORITY_DATE_FILTERED = config_wrapper("declarations_priority_date_filtered")
SILVER_DECLARATION_SEP_FAMILY_EXPANSION = config_wrapper("declarations_sep_family_expansion")
SILVER_DECLARATION_COMPANY_FILTERED = config_wrapper("declarations_company_filtered")
SILVER_DECLARATION_WITH_MOST_MEANINGFUL_STANDARD_INFO = config_wrapper(
    "declarations_with_most_meaningful_standard_info"
)
SILVER_DECLARATION_FAMILY_TECHNOLOGY_GENERATION = config_wrapper("declarations_family_technology_generation")
SILVER_DECLARATION_DIFF_IDS = config_wrapper("declarations_diff_ids")

SILVER_VELOS_MEDIA_CALCULATOR = config_wrapper("velos_media_expansion_calculator")
SILVER_CELLULAR_TECHNOLOGY_CLASSIFICATION = config_wrapper("cellular_technology_classification")
SILVER_UNDECLARED_DECLARATIONS_FAMILY_TECHNOLOGY_GENERATION = config_wrapper(
    "undeclared_declarations_family_technology_generation"
)
SILVER_FAMILY_UNDECLARED_PATENT_AUDIO_ENCODING_EXPANSION = config_wrapper(
    "family_undeclared_patent_audio_encoding_expansion"
)
SILVER_FAMILY_UNDECLARED_PATENT_VIDEO_ENCODING_EXPANSION = config_wrapper(
    "family_undeclared_patent_video_encoding_expansion"
)
SILVER_FAMILY_UNDECLARED_PATENT_VP9_AV1_EXPANSION = config_wrapper("family_undeclared_patent_vp9_av1_expansion")
SILVER_FAMILY_UNDECLARED_PATENT_WIFI_EXPANSION = config_wrapper("family_undeclared_patent_wifi_expansion")
SILVER_FAMILY_UNDECLARED_PATENT_QI_EXPANSION = config_wrapper("family_undeclared_patent_qi_expansion")

SILVER_UNDECLARED_TOP10_ETSI_STANDARDS = config_wrapper("undeclared_top10_etsi_standards")
# gold tables
GOLD_DECLARATION = config_wrapper("declarations_gold")
GOLD_DECLARATION_EXPANDED = config_wrapper("declarations_expanded_gold")
GOLD_VELOS_MEDIA_INDEX_PREPARATION = config_wrapper("velos_media_declarations")
GOLD_EXPANDED_TOP_10_ETSI_DECLARATIONS = config_wrapper("expanded_top_10_etsi_declarations")
GOLD_UNDECLARED_PATENT_ALL = config_wrapper("undeclared_patent_all")
GOLD_UNDECLARED_PATENT_EXPANDED = config_wrapper("undeclared_patent_expanded")
GOLD_DECLARATION_DATA_QUALITY = config_wrapper("data_quality_tracker")
GOLD_DECLARATIONS_SEPS_GOLD = config_wrapper("seps_gold")
GOLD_DECLARATIONS_ALL_GOLD = config_wrapper("declarations_all_gold")
GOLD_DECLARATION_FAMILIES = config_wrapper("declarations_families_gold")

# SES
SILVER_PREPROCESSED_CLAIMS = config_wrapper("preprocessed_claims")
SILVER_PREPROCESSED_ABS_TITLE = config_wrapper("preprocessed_abs_title")
SILVER_PREPROCESSED_STD_TEXT = config_wrapper("preprocessed_std_text")
SILVER_SEP_SCORING_VECTORS = config_wrapper("sep_scoring_vectors")
SILVER_SES_SCORING_SIMILARITIES = config_wrapper("ses_scoring_similarities")
SILVER_WIFI_SEMSIM = config_wrapper("wifi_semsim")
SILVER_ETSI_SEMSIM = config_wrapper("etsi_semsim")
SILVER_ATSC_SEMSIM = config_wrapper("atsc_semsim")
SILVER_VIDEO_SEMSIM = config_wrapper("ve_semsim")
SILVER_AUDIO_SEMSIM = config_wrapper("ae_semsim")
SILVER_QI_SEMSIM = config_wrapper("qi_semsim")
SILVER_WIFI_NORMALIZED_SEMSIM = config_wrapper("wifi_normalized_semsim")
SILVER_ETSI_NORMALIZED_SEMSIM = config_wrapper("etsi_normalized_semsim")
SILVER_ATSC_NORMALIZED_SEMSIM = config_wrapper("atsc_normalized_semsim")
SILVER_VIDEO_NORMALIZED_SEMSIM = config_wrapper("ve_normalized_semsim")
SILVER_AUDIO_NORMALIZED_SEMSIM = config_wrapper("ae_normalized_semsim")
SILVER_QI_NORMALIZED_SEMSIM = config_wrapper("qi_normalized_semsim")
SILVER_ETSI_STANDARDS = config_wrapper("etsi_standards")
SILVER_ATSC_STANDARDS = config_wrapper("atsc_standards")
SILVER_QI_STANDARDS = config_wrapper("qi_standards")
SILVER_WIFI_STANDARDS = config_wrapper("wifi_standards")
SILVER_AE_STANDARDS = config_wrapper("ae_standards")
SILVER_VE_STANDARDS = config_wrapper("ve_standards")
SILVER_WIFI_SEMANTIC_SIMILARITY_SCORE_WITH_TEXT = config_wrapper("wifi_semantic_similarity_score_with_text")
SILVER_AUDIO_SEMANTIC_SIMILARITY_SCORE_WITH_TEXT = config_wrapper("ae_semantic_similarity_score_with_text")
SILVER_VIDEO_SEMANTIC_SIMILARITY_SCORE_WITH_TEXT = config_wrapper("ve_semantic_similarity_score_with_text")
SILVER_ATSC_SEMANTIC_SIMILARITY_SCORE_WITH_TEXT = config_wrapper("atsc_semantic_similarity_score_with_text")
SILVER_ETSI_SEMANTIC_SIMILARITY_SCORE_WITH_TEXT = config_wrapper("etsi_semantic_similarity_score_with_text")
SILVER_QI_SEMANTIC_SIMILARITY_SCORE_WITH_TEXT = config_wrapper("qi_semantic_similarity_score_with_text")
