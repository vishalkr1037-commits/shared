import re
from typing import List

from src.declarations.patent_matching.cleaners.number_cleaner_helper import (
    ep_country_codes as epCountryCodes,
)

ccEpPattern = re.compile(r"\w\w\(EP\d+\)")
ccEaPattern = re.compile(r"\w\w(EA\d+)")
ccEpattern = re.compile(r"\w\w(E\d+)")
ccPattern = re.compile(r"\w\w(\d+)")
brPattern = re.compile(r"BR.+-\d")
bareNumberPattern = re.compile(r"\d+")


def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> List[str]:
    if publication_as_to_declaration[:2] in epCountryCodes:
        bare_number = extract_cc_enumber(publication_as_to_declaration)
        if ccEpattern.match(publication_as_to_declaration):
            return [publication_as_to_declaration[:2] + "EP0" + bare_number]

        elif ccEpPattern.match(publication_as_to_declaration):
            return [re.sub(r"[\(| \)]", "", publication_as_to_declaration)]

        else:
            return [publication_as_to_declaration]

    elif ccEaPattern.match(publication_as_to_declaration):
        bare_number = extract_cc_enumber(publication_as_to_declaration)
        return [publication_as_to_declaration[:2] + bare_number, "EA" + bare_number]

    elif brPattern.match(publication_as_to_declaration):
        return [publication_as_to_declaration.rsplit("-", 1)[0]]

    else:
        return [publication_as_to_declaration]


def extract_cc_enumber(as_to_declaration: str) -> str:
    bare_number_matcher = bareNumberPattern.search(as_to_declaration)
    if bare_number_matcher:
        return bare_number_matcher.group()
    return ""


def clean_application_as_to_declaration(application_as_to_declaration: str) -> List[str]:
    return clean_publication_as_to_declaration(application_as_to_declaration)
