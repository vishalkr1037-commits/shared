import re

_P_EP_PREFIX = re.compile(r"EP([a-zA-Z]{2})(.*)")
_P_NUMBER_EP = re.compile(r"(\d\d)EP(.*)")
_P_DOUBLE_CC = re.compile(r"\w{4}(.*)")
_P_SG_PATTERN = re.compile(r"SG\d{5,}\w")


def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> list:
    if not publication_as_to_declaration:
        return []

    if _P_EP_PREFIX.match(publication_as_to_declaration):
        return [ep_cc_to_ep(publication_as_to_declaration)]

    elif _P_NUMBER_EP.match(publication_as_to_declaration):
        return [number_ep_to_ep(publication_as_to_declaration)]

    elif (
        _P_DOUBLE_CC.match(publication_as_to_declaration)
        and publication_as_to_declaration[0] == publication_as_to_declaration[2]
        and publication_as_to_declaration[1] == publication_as_to_declaration[3]
    ):
        return [double_cc_to_cc(publication_as_to_declaration)]

    elif _P_SG_PATTERN.match(publication_as_to_declaration):

        return [publication_as_to_declaration + "A"]

    return [publication_as_to_declaration]


def clean_application_as_to_declaration(application_as_to_declaration: str) -> list:
    return clean_publication_as_to_declaration(application_as_to_declaration)


# Handle patent number that starts with EPCC by Creating two numbers EP and CC
def ep_cc_to_ep(ep_cc: str) -> str:

    local_country = ep_cc[2:4]
    p_number = ep_cc[4:]
    return f"{local_country}EP{p_number}"


# xx EP ##### to be EP xx #####
def number_ep_to_ep(number_ep: str) -> str:

    prefix_number = number_ep[:2]
    p_number = number_ep[4:]
    return f"EP{prefix_number}{p_number}"


# CC CC ##### to be CC #####
def double_cc_to_cc(double_cc: str) -> str:

    cleaned_number = double_cc[2:]
    return cleaned_number
