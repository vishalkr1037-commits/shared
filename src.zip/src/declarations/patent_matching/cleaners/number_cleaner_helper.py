import re
from typing import List

_P_NUMBER_SPACE = re.compile(r"\b\d{2}\s\d{4}\s\d{3}\s\d{3}\b|\b\d\s\d{3}\s\d{3}\b|\b\d{1,4}\s\d{3,}\b|\b\d{5,}\b")

ep_country_codes = {
    "AL",
    "AT",
    "BE",
    "BG",
    "CH",
    "CY",
    "CZ",
    "DE",
    "DK",
    "EE",
    "ES",
    "FI",
    "FR",
    "GB",
    "GR",
    "HR",
    "HU",
    "IE",
    "IS",
    "IT",
    "LI",
    "LT",
    "LU",
    "LV",
    "MC",
    "ME",
    "MK",
    "MT",
    "NL",
    "NO",
    "PL",
    "PT",
    "RO",
    "RS",
    "SE",
    "SI",
    "SK",
    "SM",
    "TR",
    "UK",
}


def contains_number_space(clean_text: str) -> List[str]:
    return [f"US{match.replace(' ', '')}" for match in _P_NUMBER_SPACE.findall(clean_text)]
