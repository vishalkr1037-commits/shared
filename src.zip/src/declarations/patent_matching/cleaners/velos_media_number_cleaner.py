def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> list[str]:
    if not publication_as_to_declaration:
        return [publication_as_to_declaration]

    length = len(publication_as_to_declaration)
    prefix = publication_as_to_declaration[:2]

    if (length == 11 and publication_as_to_declaration.startswith("20")) or (
        length == 8 and prefix in {"11", "12", "13", "14", "15"}
    ):
        if publication_as_to_declaration.isnumeric():
            publication_as_to_declaration = "US" + publication_as_to_declaration
        return [publication_as_to_declaration]

    elif length == 14 and publication_as_to_declaration.startswith("SG"):
        publication_as_to_declaration += "A"
        return [publication_as_to_declaration]


def clean_application_as_to_declaration(application_as_to_declaration: str) -> list[str]:
    return clean_publication_as_to_declaration(application_as_to_declaration)
