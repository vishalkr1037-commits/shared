import csv
import json
import re
from collections import OrderedDict, defaultdict
from pathlib import Path
from typing import Dict, List, Set

import src.declarations.patent_matching.utils.patent_office_helper as patent_office_helper
from src.declarations.patent_matching.cleaners.number_cleaner_helper import (
    ep_country_codes,
)

po_with_letters_in_patent_number = ["US", "SG", "MY", "IN", "IT", "ID", "TW", "BR"]
us_special_cases = ["RE", "D", "PP", "H", "T"]
indian_regional_offices_pn = ["DE", "DN", "KO", "KN", "MU", "MN", "CH", "CN"]
indian_regional_offices_an = ["DEL", "KOL", "MUM", "CHE"]
indian_regional_offices_an_nat_phase = ["DELNP", "KOLNP", "MUMNP", "CHENP"]
singapore_check_digit = ["P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y"]

kind_codes_per_po: Dict[str, Set[str]] = {}
italian_province_codes: Set[str] = set()
po_to_be_changed: Dict[str, str] = OrderedDict(
    sorted(
        {
            "PCT": "",
            "KOREAREPUBLICOF": "KR",
            "KOREA": "KR",
            "REPUBLICOFKOREA": "KR",
            "KOREAREPUBLICOFKR": "KR",
            "ZL": "CN",
            "WOPCT": "",
            "WO1CR": "KR",
            "CANADA": "CA",
            "INDIA": "IN",
            "NETHERLANDS": "NL",
            "GERMANYFEDERALREPUBLICOF": "DE",
            "GERMANY": "DE",
            "EUROPEANPATENT": "EP",
            "EUROPEANPALENT": "EP",
            "EUROPEANPATENTCONVENTION": "EP",
            "CZECHREPUBLIC": "CZ",
            "SWEDEN": "SE",
            "FINLAND": "FI",
            "UNITEDKINGDOM": "GB",
            "FRANCE": "FR",
            "CHILE": "CL",
            "ISRAEL": "IL",
            "AUSTRALIA": "AU",
            "POLAND": "PL",
            "RUSSIANFEDERALION": "RU",
            "RUSSIANFEDERATION": "RU",
            "RUSSIAN": "RU",
            "NORWAY": "NO",
            "NEWZEALAND": "NZ",
            "JAPAN": "JP",
            "JAP": "JP",
            "TAIWAN": "TW",
            "TAIW": "TW",
            "BRAZIL": "BR",
            "BRASIL": "BR",
            "ARGENTINA": "AR",
            "UNITEDSTATESOFAMERICA": "US",
            "UNITEDSTATESOFAMERI": "US",
            "UNITEDSTATES": "US",
            "UNITEDSTALESOFAMERICA": "US",
            "USA": "US",
            "CHINA": "CN",
            "CHINAPR": "CN",
            "MALAYSIA": "MY",
            "MEXICO": "MX",
            "HONGKO": "HK",
            "HONGKONG": "HK",
            "SINGAPORE": "SG",
            "SIGNAPORE": "SG",
            "PHILIPPINES": "PH",
            "THAILAND": "TH",
            "VIETNAM": "VN",
            "SOUTHAFRICA": "ZA",
            "UKRAINE": "UA",
        }.items(),
        key=lambda item: len(item[0]),
        reverse=True,
    )
)


us_ocr_issues_regex = re.compile(r"(U|L1|LI|11|LJ|1J)*([S5])*([01])(\d+)")
us_original_application_number_regex = re.compile(r"([01])(\d)(\d{6})A?")
us_original_application_number_with_date_regex = re.compile(r"20\d{2}([01])(\d)(\d{6})A?")
us_original_publication_number_regex = re.compile(r"(\d{7})(B)?(\d)?")
ep_original_application_number_regex = re.compile(r"(EP)?(\d{8,})")
ep_original_publication_number_regex = re.compile(r"(\d{7,})")
kr_original_application_number_regex = re.compile(r"\w*((10)?((19)|(20))\d{8,})")
kr_original_publication_number_regex = re.compile(r"P?(10)?(\d{7})")
jp_an_jap_publication_number_regex = re.compile(r"AN(\d{7})")
tw_an_jap_publication_number_regex = re.compile(r"AN(\d{8})")
cn_original_application_number_regex = re.compile(r"\D*(((19)|(20))?\d{8,})\D?")
mx_original_application_number_regex = re.compile(r"\D*(((19)|(20))?\d{8})\D?")
my_original_application_number_regex = re.compile(r"\D*(((19)|(20))?\d{8,})\D?")


def load_kind_codes_per_po():
    base_path = Path(__file__).resolve().parent.parent
    file_path = base_path / "resources" / "kind_code_type_and_description.csv"  # Update the file name if needed

    kc_per_po = defaultdict(set)

    with file_path.open("r", encoding="utf-8") as file:
        reader = csv.DictReader(file)
        for record in reader:
            po = record["Country Code"]
            kind = record["Kind Code"]
            kc_per_po[po].add(kind)

    return kc_per_po


def load_italian_province_code_values():
    base_path = Path(__file__).resolve().parent.parent
    file_path = base_path / "resources" / "italian_provinces.json"

    with file_path.open(encoding="utf-8") as f:
        data = json.load(f)

    return set(data.values())


def initialize_metadata():
    global kind_codes_per_po, italian_province_codes

    kind_codes_per_po = load_kind_codes_per_po()
    italian_province_codes = load_italian_province_code_values()


def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> List[str]:
    initialize_metadata()
    publication_nr = []

    # 0. Check that there is something worth analyzing
    if not publication_as_to_declaration or len(publication_as_to_declaration) <= 3:
        return publication_nr

    # 0.5
    publication_as_to_declaration = preprocess_publication_number(publication_as_to_declaration)

    # 1. Check if the number looks already well-formed (ie PO + NUMBER + KIND_CODE)
    # Then return it as it is (only OCR-cleaned)
    if handle_well_formed_number(publication_as_to_declaration, publication_nr):
        return publication_nr

    # 2. Check if the PO could have been OCR-affected
    # 3. Check if the PO is at the end (and could have been OCR-affected)
    if handle_po_corrections(publication_as_to_declaration, publication_nr):
        return publication_nr

    # 4. Check if the PO is wrongly input but could be corrected
    corrected = correct_po_multiples(
        publication_as_to_declaration, po_to_be_changed, patent_office_helper.get_list_patent_office_codes()
    )
    if is_well_formed_pn(corrected):
        publication_nr.extend(clean_ocr_issues(corrected))
        return publication_nr

    # 5. Check if the PO is present multiple times
    # 6. PO-specific regexes
    return try_handle_special_cases(publication_as_to_declaration, publication_nr)


def clean_application_as_to_declaration(application_as_to_declaration: str) -> List[str]:
    return clean_publication_as_to_declaration(application_as_to_declaration)


def get_preferred_po(pn_clean, valid_po_codes):
    for po in valid_po_codes:
        if pn_clean.startswith(po):
            return po
    return ""


def apply_po_corrections(pn_clean, po_to_be_changed, preferred_po):
    for typo, correction in po_to_be_changed.items():
        if pn_clean.startswith(typo):
            pn_clean = pn_clean[len(typo) :]
            pn_clean = (preferred_po or correction) + pn_clean
        if pn_clean.endswith(typo):
            pn_clean = pn_clean[: -len(typo)]
            pn_clean = (preferred_po or correction) + pn_clean
    return pn_clean


def remove_inner_po_duplicates(pn_clean, valid_po_codes):
    for po in valid_po_codes:
        if pn_clean.startswith(po):
            po_code = po
            number = pn_clean[len(po) :]
            for inner_po in valid_po_codes:
                number = re.sub(f"^{inner_po}", "", number)
                number = re.sub(f"{inner_po}$", "", number)
            return po_code + re.sub(r"\s+", "", number)
    return pn_clean


def correct_po_multiples(pn_raw, po_to_be_changed, valid_po_codes):
    pn_clean = pn_raw
    preferred_po = get_preferred_po(pn_clean, valid_po_codes)
    pn_clean = apply_po_corrections(pn_clean, po_to_be_changed, preferred_po)
    pn_clean = remove_inner_po_duplicates(pn_clean, valid_po_codes)
    return pn_clean


def preprocess_publication_number(publication_as_to_declaration: str) -> str:
    return re.sub(r"\W", "", publication_as_to_declaration).upper().replace("APPL", "")


def handle_well_formed_number(patd: str, publication_nr: List[str]) -> bool:
    if is_well_formed_pn(patd):
        publication_nr.extend(clean_ocr_issues(patd))
        return True
    return False


def handle_po_corrections(publication_as_to_declaration: str, publication_nr: List[str]) -> bool:
    # 2. Check if the PO could have been OCR-affected
    po_to_be_checked = publication_as_to_declaration[:2]
    working_publication_number = publication_as_to_declaration[2:].replace(" ", "")
    if correct_po_prefix(po_to_be_checked, working_publication_number, publication_nr):
        return True

    # 3. Check if the PO is at the end (and could have been OCR-affected)
    po_to_be_checked = publication_as_to_declaration[-2:]
    if correct_po_suffix(po_to_be_checked, publication_as_to_declaration, publication_nr):
        return True

    return handle_wrong_po(publication_as_to_declaration, publication_nr)


def correct_po_prefix(po_to_be_checked: str, working_publication_number: str, publication_nr: List[str]) -> bool:
    if any(
        replace_numbers_by_letters_ocr_issues(po_to_be_checked) == po
        for po in patent_office_helper.get_list_patent_office_codes()
    ):
        corrected_po = replace_numbers_by_letters_ocr_issues(po_to_be_checked).upper()
        patd = corrected_po + working_publication_number
        return handle_well_formed_number(patd, publication_nr)
    return False


def correct_po_suffix(po_to_be_checked: str, publication_as_to_declaration: str, publication_nr: List[str]) -> bool:
    if any(
        replace_numbers_by_letters_ocr_issues(po_to_be_checked) == po
        for po in patent_office_helper.get_list_patent_office_codes()
    ):
        corrected_po = replace_numbers_by_letters_ocr_issues(po_to_be_checked).upper()
        patd = corrected_po + publication_as_to_declaration[:-2].replace(" ", "")
        return handle_well_formed_number(patd, publication_nr)
    return False


def handle_wrong_po(publication_as_to_declaration: str, publication_nr: List[str]) -> bool:
    for wrong_po in po_to_be_changed:
        if publication_as_to_declaration.startswith(wrong_po):
            number = publication_as_to_declaration[len(wrong_po) :]
            corrected_po = po_to_be_changed[wrong_po]
            patd = corrected_po + number.replace(" ", "")
            return handle_well_formed_number(patd, publication_nr)
    return False


def try_handle_special_cases(publication_as_to_declaration: str, publication_nr: List[str]) -> List[str]:
    # 5. Check if the PO is present multiple times
    pn_clean_po = clean_po_typo(publication_as_to_declaration)
    if handle_well_formed_number(pn_clean_po, publication_nr):
        return publication_nr

    # 6. PO-specific regexes
    return handle_country_specific_candidates(pn_clean_po, publication_nr)


def clean_po_typo(publication_as_to_declaration: str) -> str:
    pn_clean_po = publication_as_to_declaration
    preferred_po = ""
    po_codes = patent_office_helper.get_list_patent_office_codes()

    if any(pn_clean_po.startswith(po) for po in po_codes):
        preferred_po = pn_clean_po[:2]

    for typo in po_to_be_changed:
        if pn_clean_po.startswith(typo):
            pn_clean_po = pn_clean_po[len(typo) :]
            pn_clean_po = (preferred_po if preferred_po else po_to_be_changed[typo]) + pn_clean_po
        elif pn_clean_po.endswith(typo):
            pn_clean_po = pn_clean_po[: -len(typo)]
            pn_clean_po = (preferred_po if preferred_po else po_to_be_changed[typo]) + pn_clean_po

    return pn_clean_po


def handle_country_specific_candidates(pn_clean_po: str, publication_nr: List[str]) -> List[str]:
    if any(pn_clean_po.startswith(po) for po in patent_office_helper.get_list_patent_office_codes()):
        po = pn_clean_po[:2]
        candidate_functions = {
            "US": us_number_candidates,
            "EP": ep_number_candidates,
            "KR": kr_number_candidates,
            "CN": cn_number_candidates,
            "MX": mx_number_candidates,
            "MY": my_number_candidates,
            "JP": jp_number_candidates,
            "TW": tw_number_candidates,
        }
        if po in candidate_functions:
            return candidate_functions[po](pn_clean_po[2:])

    if pn_clean_po.startswith("P"):
        return kr_number_candidates(pn_clean_po)

    publication_nr.append(pn_clean_po)
    return publication_nr


def is_well_formed_pn(pn: str) -> bool:
    patent_office_codes = patent_office_helper.get_list_patent_office_codes()

    if len(pn) < 3 or not any(pn.startswith(code) for code in patent_office_codes):
        return False

    po = pn[:2]
    number = pn[2:]
    number = strip_kind_code(po, pn, number)
    validator = get_validator(po)
    return validator(number)


def strip_kind_code(po: str, pn: str, number: str) -> str:
    if po in kind_codes_per_po:
        kind_codes = kind_codes_per_po[po]
        kc = next((kc for kc in kind_codes if pn.endswith(kc)), "")
        if kc:
            number = number[: -len(kc)]

    return number


def get_validator(po: str):
    validators_with_letters = {
        "US": is_well_formed_us_number,
        "IN": is_well_formed_indian_number,
        "IT": is_well_formed_italian_number,
        "BR": is_well_formed_brazilian_number,
        "TW": is_well_formed_taiwan_number,
        "SG": is_well_formed_sg_number,
        "ID": is_well_formed_id_number,
        "MY": is_well_formed_my_number,
    }

    validators_without_letters = {
        "EP": is_well_formed_ep_number,
        "KR": is_well_formed_kr_number,
        "CN": is_well_formed_cn_number,
    }

    if po in po_with_letters_in_patent_number:
        return validators_with_letters.get(po, str.isdigit)

    return validators_without_letters.get(po, str.isdigit)


def is_well_formed_us_number(us_number: str) -> bool:
    if us_original_application_number_regex.fullmatch(us_number):
        return True
    if us_original_publication_number_regex.fullmatch(us_number):
        return True
    if us_original_application_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(us_number)):
        return True
    if us_original_publication_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(us_number)):
        return True
    if any(us_number.startswith(sc) for sc in us_special_cases):
        number_without_letter = us_number[2:]
        return replace_letters_by_numbers_ocr_issues(number_without_letter).isdigit()
    return False


def is_well_formed_ep_number(ep_number: str) -> bool:
    return bool(ep_original_application_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(ep_number)))


def is_well_formed_indian_number(in_number: str) -> bool:
    def split_and_validate(number: str, office_codes) -> bool:
        for ro in office_codes:
            if ro in number:
                number_before, number_after = number.split(ro, 1)
                return (
                    replace_letters_by_numbers_ocr_issues(number_before).isdigit()
                    and replace_letters_by_numbers_ocr_issues(number_after).isdigit()
                )
        return False

    if in_number.startswith("PCT") and any(in_number.endswith(ro) for ro in indian_regional_offices_an):
        number_between = in_number[3:-3]
        return replace_letters_by_numbers_ocr_issues(number_between).isdigit()

    if split_and_validate(in_number, indian_regional_offices_an_nat_phase):
        return True

    if split_and_validate(in_number, indian_regional_offices_an):
        return True

    if split_and_validate(in_number, indian_regional_offices_pn):
        return True

    return replace_letters_by_numbers_ocr_issues(in_number).isdigit()


def is_well_formed_italian_number(it_number: str) -> bool:
    if any(it_number.startswith(province) for province in italian_province_codes):
        number_without_province = it_number[2:]
        return replace_letters_by_numbers_ocr_issues(number_without_province).isdigit()
    return replace_letters_by_numbers_ocr_issues(it_number).isdigit()


def is_well_formed_brazilian_number(br_number: str) -> bool:
    if br_number.startswith("PI"):
        number_without_pi = br_number[2:]
        return replace_letters_by_numbers_ocr_issues(number_without_pi).isdigit()
    return replace_letters_by_numbers_ocr_issues(br_number).isdigit()


def is_well_formed_taiwan_number(tw_number: str) -> bool:
    if tw_number.startswith("I"):
        number_without_i = tw_number[1:]
        return replace_letters_by_numbers_ocr_issues(number_without_i).isdigit()
    return replace_letters_by_numbers_ocr_issues(tw_number).isdigit()


def is_well_formed_sg_number(sg_number: str) -> bool:
    if any(sg_number.endswith(cd) for cd in singapore_check_digit):
        number_without_check_digit = sg_number[:-1]
        return replace_letters_by_numbers_ocr_issues(number_without_check_digit).isdigit()
    return replace_letters_by_numbers_ocr_issues(sg_number).isdigit()


def is_well_formed_id_number(id_number: str) -> bool:
    if id_number.startswith("P"):
        number_without_p = id_number[1:]
        return replace_letters_by_numbers_ocr_issues(number_without_p).isdigit()
    return replace_letters_by_numbers_ocr_issues(id_number).isdigit()


def is_well_formed_kr_number(kr_number: str) -> bool:
    return bool(
        kr_original_application_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(kr_number))
    ) or bool(kr_original_publication_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(kr_number)))


def is_well_formed_cn_number(cn_number: str) -> bool:
    return bool(cn_original_application_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(cn_number)))


def is_well_formed_my_number(my_number: str) -> bool:
    my_expected_application_number_regex = re.compile(r"PI((19)|(20))\d{8}")
    my_expected_publication_number_regex = re.compile(r"\d{6}")
    return bool(
        my_expected_application_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(my_number))
    ) or bool(my_expected_publication_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(my_number)))


def clean_ocr_issues(pn_with_ocr_issues: str) -> List[str]:
    po = pn_with_ocr_issues[:2]
    number = pn_with_ocr_issues[2:]
    kc = ""

    if po in kind_codes_per_po and any(pn_with_ocr_issues.endswith(k) for k in kind_codes_per_po[po]):
        kc = next(k for k in kind_codes_per_po[po] if pn_with_ocr_issues.endswith(k))
        number = number[: -len(kc)]  # Equivalent to StringUtils.removeEnd

    po_upper = po.upper()
    kc_upper = kc.upper()

    if po_upper == "US":
        return clean_ocr_issues_us(number, kc)
    elif po_upper == "EP":
        return clean_ocr_issues_ep(number, kc)
    elif po_upper == "IN":
        return [f"{po_upper}{clean_ocr_issues_in(number).upper()}{kc_upper}"]
    elif po_upper == "IT":
        return [f"{po_upper}{clean_ocr_issues_it(number).upper()}{kc_upper}"]
    elif po_upper == "BR":
        return [f"{po_upper}{clean_ocr_issues_br(number).upper()}{kc_upper}"]
    elif po_upper == "TW":
        return [f"{po_upper}{clean_ocr_issues_tw(number).upper()}{kc_upper}"]
    elif po_upper == "SG":
        return [f"{po_upper}{clean_ocr_issues_sg(number).upper()}{kc_upper}"]
    elif po_upper == "ID":
        return [f"{po_upper}{clean_ocr_issues_id(number).upper()}{kc_upper}"]
    elif po_upper == "KR":
        return clean_ocr_issues_kr(number, kc)
    elif po_upper == "CN":
        return clean_ocr_issues_cn(number, kc_upper)
    else:
        return [f"{po_upper}{replace_letters_by_numbers_ocr_issues(number).upper()}{kc_upper}"]


def clean_ocr_issues_us(us_number: str, kc: str) -> List[str]:
    us_number_without_po = us_number
    while us_number_without_po.startswith("US"):
        us_number_without_po = us_number_without_po[2:]

    if us_original_application_number_regex.fullmatch(us_number_without_po):
        return us_number_candidates(us_number)
    if us_original_application_number_with_date_regex.fullmatch(us_number_without_po):
        return us_number_candidates(
            us_number[4:],
        )
    if us_original_publication_number_regex.fullmatch(us_number_without_po):
        return ["US" + us_number + kc]
    if us_original_application_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(us_number_without_po)):
        return us_number_candidates(replace_letters_by_numbers_ocr_issues(us_number))
    if us_original_application_number_with_date_regex.fullmatch(us_number_without_po):
        return us_number_candidates(replace_letters_by_numbers_ocr_issues(us_number)[4:])
    if us_original_publication_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(us_number_without_po)):
        return ["US" + replace_letters_by_numbers_ocr_issues(us_number) + kc]
    if any(us_number.startswith(sc) for sc in us_special_cases):
        number_without_letter = us_number[2:]
        return ["US" + us_number[:2] + replace_letters_by_numbers_ocr_issues(number_without_letter) + kc]
    return [replace_letters_by_numbers_ocr_issues(us_number) + kc]


def strip_country_code(ep_number: str) -> str:
    while ep_number.startswith("EP") or any(ep_number.startswith(cc) for cc in ep_country_codes):
        ep_number = ep_number[2:]
    return ep_number


def match_and_append(regex, number: str, kc: str, result: List[str]) -> bool:
    match = regex.match(number)
    if match:
        cleaned = match.group(2)
        if len(cleaned) >= 8:
            result.append("EP" + cleaned + kc)
        return True
    return False


def clean_ocr_issues_ep(ep_number: str, kc: str) -> List[str]:
    result = []
    ep_number_without_po = strip_country_code(ep_number)

    if match_and_append(ep_original_application_number_regex, ep_number_without_po, kc, result):
        return result

    if ep_original_publication_number_regex.fullmatch(ep_number_without_po):
        if len(ep_number_without_po) == 8:
            result.append("EP" + ep_number_without_po + kc)
        return result

    cleaned_number = replace_letters_by_numbers_ocr_issues(ep_number_without_po)
    if match_and_append(ep_original_application_number_regex, cleaned_number, kc, result):
        return result

    if ep_original_publication_number_regex.fullmatch(cleaned_number):
        if len(cleaned_number) == 8:
            result.append("EP" + cleaned_number + kc)
        return result

    return [replace_letters_by_numbers_ocr_issues(ep_number) + kc]


def clean_ocr_issues_in(in_number: str) -> str:
    if in_number.startswith("PCT") and any(in_number.endswith(ro) for ro in indian_regional_offices_an):
        in_regional_office = in_number[-3:]
        number_between = in_number[3:-3]
        return "PCT" + replace_letters_by_numbers_ocr_issues(number_between) + in_regional_office
    if any(ro in in_number for ro in indian_regional_offices_an_nat_phase):
        in_regional_office = next(ro for ro in indian_regional_offices_an_nat_phase if ro in in_number)
        number_before = in_number[: in_number.index(in_regional_office)]
        number_after = in_number[in_number.index(in_regional_office) + len(in_regional_office) :]
        return (
            replace_letters_by_numbers_ocr_issues(number_before)
            + in_regional_office
            + replace_letters_by_numbers_ocr_issues(number_after)
        )
    if any(ro in in_number for ro in indian_regional_offices_an):
        in_regional_office = next(ro for ro in indian_regional_offices_an if ro in in_number)
        number_before = in_number[: in_number.index(in_regional_office)]
        number_after = in_number[in_number.index(in_regional_office) + len(in_regional_office) :]
        return (
            replace_letters_by_numbers_ocr_issues(number_before)
            + in_regional_office
            + replace_letters_by_numbers_ocr_issues(number_after)
        )
    if any(ro in in_number for ro in indian_regional_offices_pn):
        in_regional_office = next(ro for ro in indian_regional_offices_pn if ro in in_number)
        number_before = in_number[: in_number.index(in_regional_office)]
        number_after = in_number[in_number.index(in_regional_office) + len(in_regional_office) :]
        return (
            replace_letters_by_numbers_ocr_issues(number_before)
            + in_regional_office
            + replace_letters_by_numbers_ocr_issues(number_after)
        )
    return replace_letters_by_numbers_ocr_issues(in_number)


def clean_ocr_issues_it(it_number: str) -> str:
    if any(it_number.startswith(province) for province in italian_province_codes):
        province = it_number[:2]
        number_without_province = it_number[2:]
        return province + replace_letters_by_numbers_ocr_issues(number_without_province)
    return replace_letters_by_numbers_ocr_issues(it_number)


def clean_ocr_issues_br(br_number: str) -> str:
    if br_number.startswith("PI"):
        number_without_pi = br_number[2:]
        return "PI" + replace_letters_by_numbers_ocr_issues(number_without_pi)
    return replace_letters_by_numbers_ocr_issues(br_number)


def clean_ocr_issues_tw(tw_number: str) -> str:
    if tw_number.startswith("I"):
        number_without_i = tw_number[1:]
        return "I" + replace_letters_by_numbers_ocr_issues(number_without_i)
    return replace_letters_by_numbers_ocr_issues(tw_number)


def clean_ocr_issues_sg(sg_number: str) -> str:
    if any(sg_number.endswith(cd) for cd in singapore_check_digit):
        check_digit = sg_number[-1]
        number_without_check_digit = sg_number[:-1]
        return replace_letters_by_numbers_ocr_issues(number_without_check_digit) + check_digit
    return replace_letters_by_numbers_ocr_issues(sg_number)


def clean_ocr_issues_id(id_number: str) -> str:
    if id_number.startswith("P"):
        id_number = "P" + id_number[1:]
    return replace_letters_by_numbers_ocr_issues(id_number)


def clean_ocr_issues_cn(cn_number: str, kc: str) -> List[str]:
    if cn_original_application_number_regex.fullmatch(cn_number):
        cleaned_cn_number = cn_original_application_number_regex.fullmatch(cn_number).group(1)
        return ["CN" + cleaned_cn_number + kc]
    if cn_original_application_number_regex.fullmatch(replace_letters_by_numbers_ocr_issues(cn_number)):
        cleaned_cn_number = cn_original_application_number_regex.fullmatch(
            replace_letters_by_numbers_ocr_issues(cn_number)
        ).group(1)
        return ["CN" + replace_letters_by_numbers_ocr_issues(cleaned_cn_number) + kc]
    return []


def clean_ocr_issues_kr(kr_number: str, kc: str) -> List[str]:
    return [num + kc for num in kr_number_candidates(kr_number)]


def us_number_candidates(us_number: str) -> List[str]:
    while us_number.startswith("US"):
        us_number = us_number[2:]

    candidates = []

    if us_original_application_number_regex.fullmatch(us_number.replace(" ", "")):
        series_code = us_original_application_number_regex.fullmatch(us_number.replace(" ", "")).group(
            1
        ) + us_original_application_number_regex.fullmatch(us_number.replace(" ", "")).group(2)
        serial_number = us_original_application_number_regex.fullmatch(us_number.replace(" ", "")).group(3)
        cleaned_number = "US" + series_code + serial_number
        if len(serial_number) == 7:
            cleaned_number = "US" + series_code + serial_number[-6:]
        candidates.append(cleaned_number)

        return candidates

    if us_original_application_number_with_date_regex.fullmatch(us_number.replace(" ", "")):
        series_code = us_original_application_number_with_date_regex.fullmatch(us_number.replace(" ", "")).group(
            1
        ) + us_original_application_number_with_date_regex.fullmatch(us_number.replace(" ", "")).group(2)
        serial_number = us_original_application_number_with_date_regex.fullmatch(us_number.replace(" ", "")).group(3)
        cleaned_number = "US" + series_code + serial_number
        if len(serial_number) == 7:
            cleaned_number = "US" + series_code + serial_number[-6:]
        candidates.append(cleaned_number)

        return candidates

    if us_original_publication_number_regex.fullmatch(us_number.replace(" ", "")):
        cleaned_number = "US" + us_number.replace(" ", "")
        candidates.append(cleaned_number)
        return candidates

    if us_original_application_number_regex.fullmatch(
        replace_letters_by_numbers_ocr_issues(us_number.replace(" ", ""))
    ):
        series_code = us_original_application_number_regex.fullmatch(
            replace_letters_by_numbers_ocr_issues(us_number.replace(" ", ""))
        ).group(1) + us_original_application_number_regex.fullmatch(
            replace_letters_by_numbers_ocr_issues(us_number.replace(" ", ""))
        ).group(
            2
        )
        serial_number = us_original_application_number_regex.fullmatch(
            replace_letters_by_numbers_ocr_issues(us_number.replace(" ", ""))
        ).group(3)
        cleaned_number = "US" + series_code + serial_number
        if len(serial_number) == 7:
            cleaned_number = "US" + series_code + serial_number[-6:]
        candidates.append(cleaned_number)
        return candidates

    if us_original_publication_number_regex.fullmatch(
        replace_letters_by_numbers_ocr_issues(us_number.replace(" ", ""))
    ):
        cleaned_number = "US" + replace_letters_by_numbers_ocr_issues(us_number.replace(" ", ""))
        candidates.append(cleaned_number)
        return candidates

    if us_ocr_issues_regex.fullmatch(us_number.replace(" ", "")):
        series_code = (
            us_ocr_issues_regex.fullmatch(us_number.replace(" ", "")).group(3)
            + us_ocr_issues_regex.fullmatch(us_number.replace(" ", "")).group(4)[0]
        )
        serial_number = us_ocr_issues_regex.fullmatch(us_number.replace(" ", "")).group(4)[1:]
        cleaned_number = "US" + series_code + serial_number
        if len(serial_number) == 7:
            cleaned_number = "US" + series_code + serial_number[-6:]
        candidates.append(cleaned_number)
        return candidates
    return candidates


def cn_number_candidates(cn_number):
    candidates = []

    m_an = re.fullmatch(cn_original_application_number_regex, cn_number)
    if m_an:
        cn_number_cleaned = m_an.group(1)
        if len(cn_number_cleaned) == 13:
            candidates.append(f"CN{cn_number_cleaned[:12]}")
        elif len(cn_number_cleaned) == 9:
            candidates.append(f"CN{cn_number_cleaned[:8]}")
        else:
            candidates.append(f"CN{cn_number_cleaned}")
        return candidates

    m_an_ocr = re.fullmatch(cn_original_application_number_regex, replace_letters_by_numbers_ocr_issues(cn_number))
    if m_an_ocr:
        cn_number_cleaned = m_an_ocr.group(1)
        if len(cn_number_cleaned) == 13:
            candidates.append(f"CN{cn_number_cleaned[:12]}")
        elif len(cn_number_cleaned) == 9:
            candidates.append(f"CN{cn_number_cleaned[:8]}")
        else:
            candidates.append(f"CN{cn_number_cleaned}")
        return candidates

    return candidates


def mx_number_candidates(mx_number):
    candidates = []

    m_an = re.fullmatch(mx_original_application_number_regex, mx_number)
    if m_an:
        mx_number_cleaned = m_an.group(1)
        candidates.append(f"MX{mx_number_cleaned}")
        return candidates

    m_an_ocr = re.fullmatch(mx_original_application_number_regex, replace_letters_by_numbers_ocr_issues(mx_number))
    if m_an_ocr:
        mx_number_cleaned = m_an_ocr.group(1)
        candidates.append(f"MX{mx_number_cleaned}")
        return candidates

    return candidates


def my_number_candidates(my_number):
    candidates = []

    m_an = re.fullmatch(my_original_application_number_regex, my_number)
    if m_an:
        my_number_cleaned = m_an.group(1)[-10:]  # Equivalent to StringUtils.right in Java
        candidates.append(f"MYPI{my_number_cleaned}")
        return candidates

    m_an_ocr = re.fullmatch(my_original_application_number_regex, replace_letters_by_numbers_ocr_issues(my_number))
    if m_an_ocr:
        my_number_cleaned = m_an_ocr.group(1)[-10:]  # Equivalent to StringUtils.right in Java
        candidates.append(f"MYPI{my_number_cleaned}")
        return candidates

    return candidates


def ep_number_candidates(ep_number: str) -> List[str]:
    while ep_number.startswith("EP") or any(ep_number.startswith(code) for code in ep_country_codes):
        ep_number = ep_number[2:]

    candidates = []

    if ep_original_application_number_regex.fullmatch(ep_number):
        candidates.append("EP" + ep_number)
        return candidates

    match = ep_original_publication_number_regex.fullmatch(ep_number)
    if match:
        ep_number = ep_number[-8:] if len(ep_number) >= 8 else ep_number
        candidates.append("EP" + ep_number)
        return candidates

    ocr_fixed = replace_letters_by_numbers_ocr_issues(ep_number)
    if ep_original_application_number_regex.fullmatch(ocr_fixed):
        candidates.append("EP" + ocr_fixed)
        return candidates

    if ep_original_publication_number_regex.fullmatch(ocr_fixed):
        ep_number = ocr_fixed[-8:] if len(ocr_fixed) >= 8 else ocr_fixed
        candidates.append("EP" + ep_number)
        return candidates

    return candidates


def tw_number_candidates(tw_number):
    candidates = []
    m = re.fullmatch(tw_an_jap_publication_number_regex, tw_number)

    if m:
        tw_number_cleaned = m.group(1)
        candidates.append(f"TW{tw_number_cleaned}")
        return candidates

    return candidates


def jp_number_candidates(jp_number):
    candidates = []
    m = re.fullmatch(jp_an_jap_publication_number_regex, jp_number)

    if m:
        jp_number_cleaned = m.group(1)
        candidates.append(f"JP{jp_number_cleaned}")
        return candidates

    return candidates


def kr_number_candidates(kr_number):
    pct_flag = "PCT" in kr_number
    kc = "W" if pct_flag else ""

    candidates = []

    m_an = re.fullmatch(kr_original_application_number_regex, kr_number)
    if m_an:
        kr_number_cleaned = m_an.group(1)
        candidates.append(f"KR{kr_number_cleaned}{kc}")
        return candidates

    m_pn = re.fullmatch(kr_original_publication_number_regex, kr_number)
    if m_pn:
        kr_number_cleaned = m_pn.group(2)
        candidates.append(f"KR{kr_number_cleaned}{kc}")
        return candidates

    m_an_ocr = re.fullmatch(kr_original_application_number_regex, replace_letters_by_numbers_ocr_issues(kr_number))
    if m_an_ocr:
        kr_number_cleaned = m_an_ocr.group(1)
        candidates.append(f"KR{replace_letters_by_numbers_ocr_issues(kr_number_cleaned)}{kc}")
        return candidates

    m_pn_ocr = re.fullmatch(kr_original_publication_number_regex, replace_letters_by_numbers_ocr_issues(kr_number))
    if m_pn_ocr:
        kr_number_cleaned = m_pn_ocr.group(1)
        candidates.append(f"KR{replace_letters_by_numbers_ocr_issues(kr_number_cleaned)}{kc}")
        return candidates

    return candidates


def replace_numbers_by_letters_ocr_issues(misidentified_ocr: str) -> str:
    if not misidentified_ocr:
        return ""
    return misidentified_ocr.replace("0", "O").replace("1", "I")


def replace_letters_by_numbers_ocr_issues(misidentified_ocr: str) -> str:
    if not misidentified_ocr:
        return ""
    return (
        misidentified_ocr.replace("o", "0")
        .replace("O", "0")
        .replace("i", "1")
        .replace("I", "1")
        .replace("l", "1")
        .replace("L", "1")
        .replace("S", "5")
    )
