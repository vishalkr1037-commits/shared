import re
from typing import List

from src.declarations.patent_matching.cleaners.number_cleaner_helper import (
    contains_number_space,
)

_P_LETTER_FIRST_PART1 = re.compile(r"\b[A-Z]{1,2}\s*\d{5,}(?:\s*[A-Z]\d?)?\b")
_P_LETTER_FIRST_PART2 = re.compile(r"\b[A-Z]{2}\s\d{1,3}\s\d{2,3}\s\d{3}\s[A-Z]\d\b")
_SPECIAL_CASES = {"MXa2009007277": "MX2009007277"}


def clean_publication_as_to_declaration(publication: str) -> List[str]:
    clean_text = re.sub(r"[^a-zA-Z0-9\s]", "", publication)

    if not clean_text:
        return []

    if clean_text.isdigit():
        return [f"US{clean_text}"]

    if clean_text in _SPECIAL_CASES:
        return [_SPECIAL_CASES[clean_text]]

    if clean_text.replace(" ", "").isdigit():
        return contains_number_space(clean_text)

    if clean_text in {"PENDING", "Notice of allowance"}:
        return ["PENDING"]

    if clean_text[0].isalpha():
        return first_is_letter(clean_text)

    return [f"US{clean_text.replace(' ', '')}"]


def first_is_letter(clean_text: str) -> List[str]:
    if "PCT" in clean_text or "MXa" in clean_text:
        return [clean_text]

    matches = _P_LETTER_FIRST_PART1.findall(clean_text) + _P_LETTER_FIRST_PART2.findall(clean_text)
    return [match.replace(" ", "") for match in matches]


def clean_application_as_to_declaration(application: str) -> List[str]:
    return clean_publication_as_to_declaration(application)
