from datetime import datetime, timezone

BEGIN_YEAR = 1980
END_YEAR = datetime.now(tz=timezone.utc).year
YEARS = {str(year) for year in range(BEGIN_YEAR, END_YEAR + 1)}


def special_cases_captured():
    return {
        "961112": "EP96111548",
        "766478": "EP0766478",
        "US377138": "US37713899",
        "US098227": "US9822798",
        "US679925": "US67992596",
        "US810707": "US81070797",
        "US820552": "US82055297",
        "US872358": "US87235897",
        "US883959": "US88395997",
        "US415997": "US41599799",
        "US81449916": "US44991695",
        "SESWEDISH91023622": "SE9102362",
        "PCT9916223": "WO9916223",
        "PCTJ9802942": "JP9802942",
        "PCTW09914914": "WO9914914",
        "JP1999506866": "JPH0506866",
        "JP637344": "JPH07344",
        "JP90045941": "JPH045941",
        "JP91006150": "JPH006150",
        "JP92010878": "JPH010878",
        "JP92010879": "JPH010879",
        "JP93037745": "JPH037745",
        "JP93065242": "JPH065242",
        "JP93303003": "JPH0303003",
        "JP9366813": "JPH066813",
        "JP94026684": "JPH026684",
        "JP94035951": "JPH035951",
        "JP94076143": "JPH076143",
        "JP94078758": "JPH078758",
        "JP94094214": "JPH094214",
        "JP94094215": "JPH094215",
        "JP94094216": "JPH094216",
        "JP97046307": "JPH046307",
        "JP98093521": "JPH093521",
        "JP98106273": "JPH0106273",
    }


def get_jp_appropriate_year(app_num):
    if app_num.startswith("PH09"):
        return app_num.replace("PH09", "JP") + "97"
    elif app_num.startswith("PH06"):
        return app_num.replace("PH06", "JP") + "94"
    elif app_num.startswith("PH07"):
        return app_num.replace("PH07", "JP") + "95"
    elif app_num.startswith("PH110"):
        return app_num.replace("PH110", "JP") + "99"
    elif app_num.startswith("PH11"):
        return app_num.replace("PH11", "JP") + "99"
    else:
        return app_num


def kr_year_add_zeroes(patent_number):
    if len(patent_number) >= 10 and patent_number.startswith("KR") and patent_number[2:6] in YEARS:
        return patent_number[:6] + "00" + patent_number[6:]
    elif len(patent_number) == 9 and patent_number.startswith("KR9"):
        return patent_number[:2] + "19" + patent_number[2:4] + "00" + patent_number[4:]
    else:
        return patent_number


def clean_publication_as_to_declaration(publication_as_to_declaration):
    if not publication_as_to_declaration:
        return []

    result = []
    all_pns = publication_as_to_declaration.split(" | ")
    special_cases_handled = special_cases_captured()

    for tmp_pn in all_pns:
        if tmp_pn in special_cases_handled:
            result.append(special_cases_handled[tmp_pn])
        elif tmp_pn.startswith("EPC"):
            num = "EP" + tmp_pn[3:-1]
            result.append(num)
        elif tmp_pn.isnumeric() and len(tmp_pn) == 9:
            num = "EP" + tmp_pn[:-1]
            result.append(num)
        elif tmp_pn.startswith("PH"):
            result.append(get_jp_appropriate_year(tmp_pn))
        elif tmp_pn.startswith("KR"):
            result.append(kr_year_add_zeroes(tmp_pn))
        elif tmp_pn.startswith("GB") and len(tmp_pn) == 10:
            num = tmp_pn[:-1]
            result.append(num)
        else:
            result.append(tmp_pn)

    return result


def clean_application_as_to_declaration(application_as_to_declaration):
    return clean_publication_as_to_declaration(application_as_to_declaration)
