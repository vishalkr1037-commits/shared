import re
from typing import List

_SAME_CC_REMOVER_PATTERN = re.compile(r"[A-Z]{2}\s*\d{5,}\s?[A-Z]\d|[A-Z]{2}\s*\d{5,}[A-Z]|[A-Z]{2}\s*\d{5,}")
_CONTAINS_US_PUBLISHED_PATTERN = re.compile(r"\d{2}\/\d{5,}|\b\d{5,}\b|\b[A-Z]{2}\s*\d{3,}|\d+\s*[A-Z]{2}\b")
_CONTAINS_US_PATENT_PATTERN = re.compile(
    r"\b\w{2}\d{4}\w{4,5}\d{4,}\w?|\b\d{4,}\w{3,4}\d{4,}|\b[A-Z]{2}\s*\d{5,}\s*\b\w\d|\b[A-Z]{2}\s*\d{5,}\w?\d?|\b\d{8,}\b\s*\b\w{2}\b|\b\d{9,}|\b\w{4,5}\d{8,}"
)
_CONTAINS_EP_PUBLISHED_PATTERN = re.compile(r"(\w\w)EP(.*)")
_GENERIC_ITUT_PATTERN = re.compile(
    r"[A-Z]{2}\s*\d{5,}\.+\d|[A-Z]{2}\s*\d{5,}\s?[A-Z]\d|[A-Z]{2}\s*\d{5,}[A-Z]|[A-Z]{2}\s*\d{5,}"
)


def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> List[str]:
    publication_numbers = []
    cleaned = re.sub(r"[^a-zA-Z0-9\.]", "", publication_as_to_declaration).strip()

    special_cases_handled = {"IT27867BE2007": "IT27867BE2007", "MXpaa2000008564": "MX2000008564", "EPEP": ""}

    if cleaned == "None" or len(cleaned) == 2 or not cleaned:
        publication_numbers.append("")
    elif cleaned in special_cases_handled:
        publication_numbers.append(special_cases_handled[cleaned])
    elif "US Published Patent" in publication_as_to_declaration:
        publication_numbers.extend(contains_us_published(publication_as_to_declaration))
    elif is_application_type(publication_as_to_declaration):
        publication_numbers.extend(contains_us_patent(publication_as_to_declaration))
    elif cleaned[0].isalpha() and cleaned[2].isalpha():
        publication_numbers = has_two_cc(publication_numbers, cleaned)
    else:
        publication_numbers.extend(rest_of_cases(cleaned))

    return publication_numbers


def has_two_cc(publication_numbers, cleaned: str) -> bool:
    if cleaned[0] == cleaned[2] and cleaned[1] == cleaned[3]:
        publication_numbers.extend(same_cc_remover(cleaned))
    elif is_pct_number(cleaned):
        publication_numbers.append(cleaned)
    elif is_us_re_number(cleaned):
        publication_numbers.append(cleaned)
    elif len(cleaned) > 6:
        if is_jp_pct_jp(cleaned):
            publication_numbers.extend(special_japanese_case(cleaned))
        elif is_three_cc(cleaned):
            publication_numbers.extend(three_cc_splitter(cleaned))
        elif is_jph(cleaned):
            publication_numbers.extend(case_jph(cleaned))
        elif cleaned.startswith("CN"):
            publication_numbers.append(cleaned)
        elif _CONTAINS_EP_PUBLISHED_PATTERN.match(cleaned):
            return [cleaned]
        else:
            publication_numbers.extend(two_cc_splitter(cleaned))
    return publication_numbers


def is_pct_number(cleaned: str) -> bool:
    return cleaned.startswith("PCT")


def is_us_re_number(cleaned: str) -> bool:
    return cleaned.startswith("USRE")


def is_jp_pct_jp(cleaned: str) -> bool:
    return cleaned[0].isalpha() and cleaned[2].isalpha() and cleaned[4].isalpha() and cleaned[6].isalpha()


def special_japanese_case(cleaned: str) -> List[str]:
    return [f"{cleaned[:2]}{cleaned[7:].replace(' ', '')}", cleaned[2:].replace(" ", "")]


def is_three_cc(cleaned: str) -> bool:
    return cleaned[0].isalpha() and cleaned[2].isalpha() and cleaned[4].isalpha()


def three_cc_splitter(cleaned: str) -> List[str]:
    return [
        f"{cleaned[:2]}{cleaned[6:].replace(' ', '')}",
        f"{cleaned[2:4]}{cleaned[6:].replace(' ', '')}",
        cleaned[4:].replace(" ", ""),
    ]


def is_jph(cleaned: str) -> bool:
    return cleaned[0].isalpha() and cleaned[2].isalpha() and cleaned[3].isdigit()


def two_cc_splitter(cleaned: str) -> List[str]:
    return [f"{cleaned[:2]}{cleaned[4:].replace(' ', '')}", cleaned[2:].replace(" ", "")]


def same_cc_remover(cleaned: str) -> List[str]:
    if cleaned in ["USU59066075", "USU59510009", "USU59179157"]:
        return [f"{cleaned[:2]}{cleaned[3:]}"]
    return [m.group(0).strip().replace(" ", "") for m in _SAME_CC_REMOVER_PATTERN.finditer(cleaned)]


def case_jph(cleaned: str) -> List[str]:
    if "JPH" in cleaned:
        return [f"{cleaned[:2]}{cleaned[3:].replace(' ', '')}"]
    return [cleaned]


def rest_of_cases(cleaned: str) -> List[str]:
    return [m.group(0).strip().replace(" ", "") for m in _GENERIC_ITUT_PATTERN.finditer(cleaned)]


def contains_us_published(publication_as_to_declaration: str) -> List[str]:
    tmp = publication_as_to_declaration.replace(",", "")
    return publication_nr_matcher(_CONTAINS_US_PUBLISHED_PATTERN.finditer(tmp))


def publication_nr_matcher(matches) -> List[str]:
    special_cases_handling = {"20100306408A1": "US20100306408A1"}
    publication_numbers = []
    for m in matches:
        clean_tmp = m.group(0).strip().replace("/", "").replace(" ", "").replace("-", "")
        if clean_tmp.isnumeric() or clean_tmp in special_cases_handling:
            clean_tmp = f"US{clean_tmp}"
        publication_numbers.append(clean_tmp)
    return publication_numbers


def is_application_type(publication_as_to_declaration: str) -> bool:
    return "application number" in publication_as_to_declaration.lower()


def contains_us_patent(publication_as_to_declaration: str) -> List[str]:
    special_cases_handling = {
        "MXPAA2005008404": "MX2005008404",
        "MYPI20040499": "MY20040499",
        "1409CHE2015": "IN1409CHE2015",
        "1410CHE2015": "IN1410CHE2015",
        "1411CHE2015": "IN1411CHE2015",
    }
    tmp = (
        publication_as_to_declaration.replace(",", "")
        .replace("/", "")
        .replace(":", "")
        .replace(".", "")
        .replace("-", "")
    )
    publication_numbers = []
    for m in _CONTAINS_US_PATENT_PATTERN.finditer(tmp):
        clean_tmp = m.group(0).strip()
        if clean_tmp in special_cases_handling:
            publication_numbers.append(special_cases_handling[clean_tmp])
        else:
            clean_tmp = clean_tmp.replace(" ", "")
            clean_tmp = cc_adder(clean_tmp)
            publication_numbers.append(clean_tmp)
    return publication_numbers


def cc_adder(clean_publication_nr: str) -> str:
    stripped = clean_publication_nr.strip()

    if stripped.replace(" ", "").isnumeric() or stripped.isnumeric():
        return f"US{stripped}"
    elif stripped and stripped[0].isnumeric() and " " in stripped:
        idx = stripped.index(" ") + 1
        return stripped[idx:] + stripped[:idx]

    return stripped


def clean_application_as_to_declaration(application_as_to_declaration: str) -> List[str]:
    return clean_publication_as_to_declaration(application_as_to_declaration)
