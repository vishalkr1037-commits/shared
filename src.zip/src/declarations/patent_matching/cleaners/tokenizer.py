import re
from typing import List, Set


def tokenize(field: str) -> Set[str]:
    if not is_empty(field):
        tokens = re.split(r" AND | and |&|; |, |\|", field)
        return {token.strip() for token in tokens if token.strip()}
    else:
        return set()


def tokenize_list(fields: List[str]) -> Set[str]:
    return {token for field in fields for token in tokenize(field)}


def is_empty(entry: str) -> bool:
    return not entry or len(entry) <= 4
