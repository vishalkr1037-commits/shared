import re
from typing import Dict, List

_P_CC_SUFFIX = re.compile(r"(\d+[a-zA-Z]?\d)([a-zA-Z]{1,3})")
_P_US_ONLY_NUMBER = re.compile(r"\b\d+\b")
_US_TWENTY_NUMBER_PATTERN = re.compile(r"US(\d{18})")


def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> List[str]:

    if not publication_as_to_declaration:
        return ["not indicated"]

    special_cases_handled = special_cases_capturer()
    if publication_as_to_declaration in special_cases_handled:
        return [special_cases_handled[publication_as_to_declaration]]

    if match := _P_CC_SUFFIX.match(publication_as_to_declaration):
        local_country = match.group(2)
        p_number = match.group(1)

        if local_country == "Ja":
            return [f"JP{p_number}"]
        elif local_country == "En":
            return [f"EP{p_number}"]
        elif local_country == "US":
            if len(p_number) == 18:
                return us_twenty_char(f"US{p_number}")
            else:
                return [f"US{p_number}"]
        else:
            return [f"{local_country.upper()}{p_number}"]

    elif _P_US_ONLY_NUMBER.match(publication_as_to_declaration):
        return [f"US{publication_as_to_declaration}"]
    elif _US_TWENTY_NUMBER_PATTERN.match(publication_as_to_declaration):
        return us_twenty_char(publication_as_to_declaration)
    else:
        return [publication_as_to_declaration]


def us_twenty_char(pub_number: str) -> List[str]:
    if match := _US_TWENTY_NUMBER_PATTERN.match(pub_number):
        p_number = match.group(1)
        return [f"US{p_number[:11]}", f"US{p_number[11:]}"]
    return []


def special_cases_capturer() -> Dict[str, str]:
    return {
        "9810027609": "RU9810027609",
        "2989742Cl": "JP2989742",
        "011185105": "EP011185105",
        "2008107766": "WO2008107766",
        "7164359Cl": "US7164359",
        "411345 Ta": "TW411345",
        "427969 Ta": "TW427969",
        "102638806": "CN102638806B",
        "D337305": "US337305D",
        "2030404": "EP2030404",
        "865MUMNP2008": "IN865MUMNP2008",
        "2627609": "CA2627609",
        "602374518GE": "DE602374518",
        "A2004180307": "JP2004180307A",
        "A1503523": "CN1503523A",
        "A2005117656": "JP200511765A",
        "A12004": "US20040103275A1",
        "A12005": "US20050152305A1",
        "200900": "US20090092252",
        "1020040335818": "DE1020040335818",
        "6205362wa": "US6205362",
        "20090": "US20090263127",
        "118753": "US20100118753",
        "US2040234": "CA2040234",
        "013073044": "EP013073044",
        "009908856": "EP009908856",
        "779378": "AU779378",
        "1022874": "EP1022874",
    }


def clean_application_as_to_declaration(application_as_to_declaration: str) -> List[str]:
    return clean_publication_as_to_declaration(application_as_to_declaration)
