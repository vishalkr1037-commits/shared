import re

from src.declarations.patent_matching.cleaners.number_cleaner_helper import (
    contains_number_space,
)

_P_NUMBER_WITH_SPACES = re.compile(r"\d{5,}")
_P_GB_PATENT = re.compile(r"\d{2}[a-zA-Z]{5}\d{3}|\d{2}[A-Z]{2,3}\d{5,}|\d{5,}")
_P_GENERIC = re.compile(
    r"[A-Z]{3}\s*[A-Z]{2}\d{4,5}\s*\d{2,}|[A-Z]{2}\s*\d{5,}\s*[A-Z]{1}\d{1}|"
    r"[A-Z]{2}\s*\d{5,}|\d{5,}[A-Z]{1}\d{1}|\d{5,}"
)


def is_numeric_space(text):
    return all(c.isdigit() or c.isspace() for c in text)


def clean_match(match, prefix="US"):
    return prefix + match.strip().replace(" ", "")


def contains_jp_patents(clean_tmp):
    return ["JP" + match.strip().replace(" ", "") for match in _P_NUMBER_WITH_SPACES.findall(clean_tmp)]


def contains_gb_patents(clean_tmp):
    publication_nummer = []
    matches = _P_GB_PATENT.findall(clean_tmp)

    for match in matches:
        if match.isdigit():
            publication_nummer.append(f"US{match.strip().replace(' ', '')}")
        else:
            if match[:2].isdigit() and match[2:4] in {"GB", "EP"}:
                prefix = match[2:4]
                formatted_match = prefix + match[:2] + match[4:].replace("-", "").strip()

            elif match[:2].isdigit() and match[2:4] == "WO":
                formatted_match = "WOG" + match[:2] + match[5:].replace("-", "").strip()

            else:
                formatted_match = match.strip().replace(" ", "").replace("-", "")

            publication_nummer.append(formatted_match)

    return publication_nummer


def rest_of_cases(clean_tmp):
    return [
        clean_match(match) if match[0].isdigit() else match.replace(" ", "") for match in _P_GENERIC.findall(clean_tmp)
    ]


def clean_publication_as_to_declaration(publication_as_to_declaration):
    clean_tmp = re.sub(r"[^a-zA-Z0-9\s]", "", publication_as_to_declaration.replace(";", " ").replace("|", " ")).strip()

    if not clean_tmp:
        return []

    if clean_tmp.isdigit():
        return [clean_match(clean_tmp)]

    if is_numeric_space(clean_tmp):
        return contains_number_space(clean_tmp)

    if "Japanese Patent" in clean_tmp:
        return contains_jp_patents(clean_tmp)

    if "GB" in clean_tmp or "EP" in clean_tmp or "WO" in clean_tmp:
        return contains_gb_patents(clean_tmp)

    if "ZL941114619G06F 1200" in clean_tmp:
        return ["ZL941114619"]

    return rest_of_cases(clean_tmp)


def clean_application_as_to_declaration(application_as_to_declaration):
    return clean_publication_as_to_declaration(application_as_to_declaration)
