import re
from typing import List

from src.declarations.patent_matching.cleaners.number_cleaner_helper import (
    ep_country_codes,
)

_P_ONLY_NUMBER = re.compile(r"\b\d{3}[A-Z]{5}\s\d{4}\b|\d{5,}\s[A-Z]{2}|\d{5,}")
_P_ONLY_NUMBER_ENDING_WITH_CHAR = re.compile(r"\b\d{11}[A-Z]\d\b")


def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> List[str]:
    if not publication_as_to_declaration:
        return []

    original = publication_as_to_declaration
    normalized = re.sub(r"[^a-zA-Z0-9]", "", publication_as_to_declaration).upper()

    # Apply each rule in order
    for rule in CLEANING_RULES:
        result = rule(normalized, original)
        if result:
            return result

    return [original]


# ---- Rule Definitions ----


def rule_cnzl(number, _):
    if number.startswith("CNZL"):
        return ["CN" + number[4:]]


def rule_wopctkr(number, _):
    if number.startswith("WOPCTKR"):
        return ["KR" + number[7:]]


def rule_wopctfi(number, _):
    if number.startswith("WOPCTFI"):
        return ["FI" + number[7:]]


def rule_eppctfi(number, _):
    if number.startswith("EPPCTFI"):
        return ["FI" + number[7:]]


def rule_cnpctfi(number, _):
    if number.startswith("CNPCTFI"):
        return ["FI" + number[7:]]


def rule_in_cuenp(number, _):
    if number.startswith("IN") and "CUENP" in number:
        return [number.replace("CUENP", "CHENP")]


def rule_eo(number, _):
    if number.startswith("EO") and len(number[2:]) == 9:
        return ["EP" + number[4:-1]]


def rule_wopctib(number, _):
    if number.startswith("WOPCTIB"):
        return ["IB" + number[7:]]


def rule_only_number(number, original):
    if _P_ONLY_NUMBER.match(number):
        return [clean_cn_numeric(number, original)]


def rule_ca_numeric(number, original):
    if number.startswith("CA") and _P_ONLY_NUMBER.match(number[2:]):
        return [clean_cn_numeric(number[2:], original)]


def rule_number_a1(number, original):
    if _P_ONLY_NUMBER_ENDING_WITH_CHAR.match(number):
        return [clean_us_alphanumeric(number, original)]


def rule_de_format(number, _):  # Add the unused parameter with underscore
    if number.startswith("D") and number.endswith("E"):
        corrected = "DE" + number[1:9]
        if any(corrected.startswith(code) for code in ep_country_codes):
            return [clean_ep_patents(corrected)]


def rule_gh(number, _):  # Add the unused parameter with underscore
    if number.startswith("GH"):
        corrected = "GB" + number[2:]
        if any(corrected.startswith(code) for code in ep_country_codes):
            return [clean_ep_patents(corrected)]


def rule_fr(number, _):  # Add the unused parameter with underscore
    if number.startswith("F") and number.endswith("R"):
        corrected = "FR" + number[1:9]
        if any(corrected.startswith(code) for code in ep_country_codes):
            return [clean_ep_patents(corrected)]


def rule_epse(number, _):  # Add the unused parameter with underscore
    if number.startswith("EPSE"):
        corrected = "SE" + number[4:]
        if any(corrected.startswith(code) for code in ep_country_codes):
            return [clean_ep_patents(corrected)]


def rule_pctusa(number, _):
    if number.startswith("PCTUSA"):
        return ["US" + number[6:16]]


def rule_pctusl(number, _):
    if "PCTUSL" in number:
        digits = number[7:]
        return ["US0" + digits] if len(digits) < 7 else ["US" + digits]


def rule_pctus_extra(number, _):
    if re.match(r"PCTUS[A-Z]{2}\d+", number):
        digits = number[7:]
        return ["US0" + digits] if len(digits) < 7 else ["US" + digits]


def rule_i4_tw(number, _):
    if re.match(r"^I4\d{5}$", number):
        return ["TW" + number]


# ---- Rule List ----
CLEANING_RULES = [
    rule_cnzl,
    rule_wopctkr,
    rule_wopctfi,
    rule_eppctfi,
    rule_cnpctfi,
    rule_in_cuenp,
    rule_eo,
    rule_wopctib,
    rule_only_number,
    rule_ca_numeric,
    rule_number_a1,
    rule_de_format,
    rule_gh,
    rule_fr,
    rule_epse,
    rule_pctusa,
    rule_pctusl,
    rule_pctus_extra,
    rule_i4_tw,
]


def clean_application_as_to_declaration(application_as_to_declaration: str) -> List[str]:
    return clean_publication_as_to_declaration(application_as_to_declaration)


def clean_cn_numeric(cleaned_working_number: str, publication_as_to_declaration_number: str) -> str:
    if cleaned_working_number.isdigit() and len(cleaned_working_number) == 13:
        if cleaned_working_number.startswith(("19", "20")):
            cn_an_cleaned = cleaned_working_number[:12]
            return "CN" + cn_an_cleaned
    return publication_as_to_declaration_number


def clean_us_alphanumeric(cleaned_working_number: str, publication_as_to_declaration_number: str) -> str:
    if (
        len(cleaned_working_number) == 13
        and cleaned_working_number.startswith("20")
        and cleaned_working_number.endswith("A1")
    ):
        us_an_cleaned = cleaned_working_number[:11]
        return "US" + us_an_cleaned
    return publication_as_to_declaration_number


def clean_ep_patents(cleaned_working_number: str) -> str:
    patent_number_length = len(cleaned_working_number)
    number_without_po = cleaned_working_number[2:]
    number_without_po_length = len(number_without_po)

    if patent_number_length <= 9:
        missing_zeros = 9 - patent_number_length
        po_with_leading_zeros = "0" * missing_zeros
        return "EP" + po_with_leading_zeros + number_without_po
    else:  # This covers patent_number_length > 9
        ep_striped_number = number_without_po[: number_without_po_length - 1]
        return "EP" + ep_striped_number
