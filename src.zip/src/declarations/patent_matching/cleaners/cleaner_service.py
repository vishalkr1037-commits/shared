from typing import List

from pyspark.sql import types as T

import src.declarations.patent_matching.cleaners.ansi_number_cleaner as ANSINumberCleaner
import src.declarations.patent_matching.cleaners.atsc_number_cleaner as ATSCNumberCleaner
import src.declarations.patent_matching.cleaners.default_number_cleaner as DefaultNumberCleaner
import src.declarations.patent_matching.cleaners.hevc_access_advance_number_cleaner as HEVCAccessAdvanceNumberCleaner
import src.declarations.patent_matching.cleaners.ieee_declarations_number_cleaner as IEEENumberCleaner
import src.declarations.patent_matching.cleaners.ietf_number_cleaner as IETFNumberCleaner
import src.declarations.patent_matching.cleaners.iso_number_cleaner as ISONumberCleaner
import src.declarations.patent_matching.cleaners.itur_number_cleaner as ITURNumberCleaner
import src.declarations.patent_matching.cleaners.itut_number_cleaner as ITUTNumberCleaner
import src.declarations.patent_matching.cleaners.mpeg_la_number_cleaner as MPEGLANumberCleaner
import src.declarations.patent_matching.cleaners.oma_number_cleaner as OMANumberCleaner
import src.declarations.patent_matching.cleaners.sisvel_number_cleaner as SISVELNumberCleaner
import src.declarations.patent_matching.cleaners.velos_media_number_cleaner as VelosMediaNumberCleaner
import src.declarations.patent_matching.cleaners.via_licensing_number_cleaner as ViaLicensingNumberCleaner
import src.declarations.three_gpp_specifications_helper.standard_doc_udfs as wrapper_udf
from src.declarations.patent_matching.cleaners.tokenizer import tokenize_list

cleaners = {
    "ANSI": ANSINumberCleaner,
    "ETSI": DefaultNumberCleaner,
    "IEEE": IEEENumberCleaner,
    "IETF": IETFNumberCleaner,
    "ITUT": ITUTNumberCleaner,
    "ITUR": ITURNumberCleaner,
    "OMA": OMANumberCleaner,
    "ATSC": ATSCNumberCleaner,
    "MPEG LA": MPEGLANumberCleaner,
    "Access Advance": HEVCAccessAdvanceNumberCleaner,
    "SISVEL": SISVELNumberCleaner,
    "ISO": ISONumberCleaner,
    "Via Licensing": ViaLicensingNumberCleaner,
    "Velos Media": VelosMediaNumberCleaner,
    "default": DefaultNumberCleaner,
}


def clean_publication_as_to_declaration_service(
    data_provider: str, publication_as_to_declaration_original: str
) -> List[str]:
    if not publication_as_to_declaration_original:
        return list()
    data_provider = data_provider or ""
    number_cleaner = cleaners.get(data_provider, cleaners["default"])
    return list(
        tokenize_list(number_cleaner.clean_publication_as_to_declaration(publication_as_to_declaration_original))
    )


def clean_application_as_to_declaration_service(
    data_provider: str, application_as_to_declaration_original: str
) -> List[str]:
    if not application_as_to_declaration_original:
        return list()
    data_provider = data_provider or ""
    number_cleaner = cleaners.get(data_provider, cleaners["default"])
    return list(
        tokenize_list(number_cleaner.clean_application_as_to_declaration(application_as_to_declaration_original))
    )


publication_as_to_declaration_cleaner_udf = wrapper_udf.create_pandas_udf(
    clean_publication_as_to_declaration_service, output_type=T.ArrayType(T.StringType()), is_multi_column=True
)
application_as_to_declaration_cleaner_udf = wrapper_udf.create_pandas_udf(
    clean_application_as_to_declaration_service, output_type=T.ArrayType(T.StringType()), is_multi_column=True
)
