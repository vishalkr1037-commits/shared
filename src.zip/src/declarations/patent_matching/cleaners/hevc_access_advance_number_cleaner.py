import re

import src.declarations.patent_matching.cleaners.number_cleaner_helper as NumberCleanerHelper

_LOCAL_VERSION_OF_EP_PATENT = re.compile(r"[a-zA-Z]{2}-?EP.*")
_LOCAL_VERSION_OF_EP_CC_PATENT = re.compile(r"EP[a-zA-Z]{2}-?.*")
_CN_APPLICATION_NUMBER_WITH_VALIDATION_DIGIT = re.compile(r"CN\d+\.\d")


def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> list:
    if not publication_as_to_declaration:
        return []

    if any(publication_as_to_declaration.startswith(code) for code in NumberCleanerHelper.ep_country_codes):
        if _LOCAL_VERSION_OF_EP_PATENT.match(publication_as_to_declaration):
            local_po = publication_as_to_declaration[:2]
            number_without_po = publication_as_to_declaration.split("EP", 1)[-1]
            return [f"{local_po}EP{number_without_po}"]

    if _LOCAL_VERSION_OF_EP_CC_PATENT.match(publication_as_to_declaration):
        local_po = publication_as_to_declaration[2:4]
        number_without_po = publication_as_to_declaration[4:]
        return [f"{local_po}EP{number_without_po}"]

    if _CN_APPLICATION_NUMBER_WITH_VALIDATION_DIGIT.match(publication_as_to_declaration):
        return [publication_as_to_declaration.split(".")[0]]

    if publication_as_to_declaration.startswith("CNZL"):
        number_without_po = publication_as_to_declaration[4:]
        return [f"CN{number_without_po}"]

    if publication_as_to_declaration.startswith("TWL"):
        return [f"TWI{publication_as_to_declaration[3:]}"]

    # Default: return the original number
    return [publication_as_to_declaration]


def clean_application_as_to_declaration(application_as_to_declaration: str) -> list:
    if not application_as_to_declaration:
        return []
    elif application_as_to_declaration.startswith("ATE"):
        return ["EP00" + application_as_to_declaration[3:]]
    elif application_as_to_declaration.startswith("ESE"):
        return ["ES" + application_as_to_declaration[3:]]
    else:
        return clean_publication_as_to_declaration(application_as_to_declaration)
