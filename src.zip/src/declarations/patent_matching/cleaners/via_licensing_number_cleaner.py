def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> list:
    if not publication_as_to_declaration:
        return []
    elif publication_as_to_declaration.startswith("PI"):
        return ["BR" + publication_as_to_declaration]

    elif publication_as_to_declaration.startswith("RE"):
        return ["US" + publication_as_to_declaration]

    return [publication_as_to_declaration]


def clean_application_as_to_declaration(application_as_to_declaration: str) -> list:
    return clean_publication_as_to_declaration(application_as_to_declaration)
