def clean_publication_as_to_declaration(publication_as_to_declaration: str) -> list:
    return [publication_as_to_declaration]


def clean_application_as_to_declaration(application_as_to_declaration: str) -> list:
    return [application_as_to_declaration]
