from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as mod_helper

Rule = Tuple[str, List[Callable[[str], str]]]


def kr_provisional_with_zero_add_a(patent_number):
    """
    For formats: KR20xx0zzzzzz -> KR20xx0zzzzzzA
    """
    if (
        len(patent_number) >= 8
        and patent_number.startswith("KR")
        and mod_helper.has_cc_year(patent_number)
        and mod_helper.get_year(patent_number) >= 2000
        and patent_number[6] == "0"
    ):
        return patent_number.strip() + "A"
    else:
        return patent_number


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules for JP patent numbers.
    """
    rules: List[Rule] = []
    rules = [
        ("kr_provisional_with_zero_add_a", [kr_provisional_with_zero_add_a]),
    ]
    return rules
