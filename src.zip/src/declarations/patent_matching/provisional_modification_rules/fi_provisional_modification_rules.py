from typing import Callable, List, Tuple

Rule = Tuple[str, List[Callable[[str], str]]]


def fi_provisional_with_10_digits(patent_number):
    """
    Numbers in format FIxxxxxxxx (FI followed by 8 digits) - Just add "A" at the end.

    :param patent_number: The patent number
    :return: If FI + 8 digits, add "A". Else, return the original number.
    """
    if len(patent_number) == 10 and patent_number.startswith("FI") and patent_number[2:].isdigit():
        return patent_number.strip() + "A"
    else:
        return patent_number


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules for FI patent numbers.
    """
    rules: List[Rule] = []
    rules = [
        ("fi_provisional_with_10_digits", [fi_provisional_with_10_digits]),
    ]
    return rules
