from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as mod_helper
import src.declarations.patent_matching.provisional_modification_rules.provisional_modification_rules_helper as helper

Rule = Tuple[str, List[Callable[[str], str]]]


def has_provisional_series_code(patent_number):
    """
    Check if the patent number has a provisional series code.
    """
    return len(patent_number) >= 6 and patent_number[2:4] in helper.provisional_series_code


def us_provisional_number_perfect_match(patent_number):
    """
    For formats: US20xx6yzzzzzzP -> perfect match
    US201762608233P -> US201762608233P
    """
    if (
        len(patent_number) >= 8
        and patent_number.startswith("US")
        and mod_helper.has_cc_year(patent_number)
        and patent_number[6:8] in helper.provisional_series_code
        and patent_number.endswith("P")
    ):
        return patent_number.strip()[:-1]
    else:
        return patent_number


def us_provisional_number_add_p(patent_number):
    """
    For formats: US20xx6yzzzzzz -> US20xx6yzzzzzzP -> add P at the end
    """
    if (
        len(patent_number) >= 8
        and patent_number.startswith("US")
        and mod_helper.has_cc_year(patent_number)
        and mod_helper.get_year(patent_number) >= 2000
        and patent_number[6] == "6"
    ):
        return patent_number.strip().replace(get_kind_code(patent_number), "") + "P"
    else:
        return patent_number


def us_provisional_number_fill_year_add_p(patent_number):
    """
    For formats US6yzzzzzz (only application numbers!)
    Apply logic from the USPTO filing year rules.
    """
    if (
        8 <= len(patent_number) <= 14
        and patent_number.startswith("US")
        and has_provisional_series_code(patent_number)
        and patent_number.replace(get_kind_code(patent_number), "")[2:].isdigit()
    ):
        series_code = int(patent_number[2:4].strip())
        return helper.get_provisional_number(series_code, patent_number.replace(get_kind_code(patent_number), ""))
    else:
        return patent_number


def us_provisional_number_fill_year_add_p_minus_one(patent_number):
    """
    For formats US6yzzzzzz (only application numbers!)
    Apply logic from the USPTO filing year rules and subtract one year.
    """
    if (
        8 <= len(patent_number) <= 14
        and patent_number.startswith("US")
        and has_provisional_series_code(patent_number)
        and patent_number.replace(get_kind_code(patent_number), "")[2:].isdigit()
    ):
        series_code = int(patent_number[2:4])
        return helper.get_provisional_number_minus_one(
            series_code, patent_number.replace(get_kind_code(patent_number), "")
        )
    else:
        return patent_number


def us_provisional_number_fill_year_add_p_plus_one(patent_number):
    """
    For formats US6yzzzzzz (only application numbers!)
    Apply logic from the USPTO filing year rules and add one year.
    """
    if (
        8 <= len(patent_number) <= 14
        and patent_number.startswith("US")
        and has_provisional_series_code(patent_number)
        and patent_number.replace(get_kind_code(patent_number), "")[2:].isdigit()
    ):
        series_code = int(patent_number[2:4])
        return helper.get_provisional_number_plus_one(
            series_code, patent_number.replace(get_kind_code(patent_number), "")
        )
    else:
        return patent_number


def us_provisional_number_fill_year_add_p_without_removing_zero(patent_number):
    """
    For formats US6yzzzzzz (only application numbers!)
    Apply logic from the USPTO filing year rules without removing the leading zero.
    """
    if (
        8 <= len(patent_number) <= 14
        and patent_number.startswith("US")
        and has_provisional_series_code(patent_number)
        and patent_number.replace(get_kind_code(patent_number), "")[2:].isdigit()
    ):
        series_code = int(patent_number[2:4])
        return get_provisional_number_without_removing_zero(
            series_code, patent_number.replace(get_kind_code(patent_number), "")
        )
    else:
        return patent_number


def get_provisional_number_without_removing_zero(series_code, patent_number):
    """
    Get the provisional number without removing the leading zero.
    """
    if series_code == 62:
        return get_provisional_number_starting_with_62_without_removing_zero(patent_number, series_code)
    elif series_code == 63:
        return get_provisional_number_starting_with_63_without_removing_zero(patent_number, series_code)
    else:
        return patent_number


def get_provisional_number_starting_with_62_without_removing_zero(patent_number, series_code):
    """
    Get the provisional number for series code 62 without removing the leading zero.
    """
    digits = patent_number[4:]
    fill_year = get_fill_year_based_on_series_code_with_zero(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_provisional_number_starting_with_63_without_removing_zero(patent_number, series_code):
    """
    Get the provisional number for series code 63 without removing the leading zero.
    """
    digits = patent_number[4:]
    fill_year = get_fill_year_based_on_series_code_with_zero(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_fill_year_based_on_series_code_with_zero(series_code, value):
    """
    Get the fill year based on the series code and value, including zero.
    """
    if series_code == 62:
        return get_value_in_range_62_with_zero(value)
    elif series_code == 63:
        return get_value_in_range_63_with_zero(value)
    else:
        return ""


def get_value_in_range_62_with_zero(value):
    """
    Get the fill year for series code 62 based on the value, including zero.
    """
    ranges = [
        (0, 124715, "2014"),
        (124715, 387330, "2015"),
        (387330, 498538, "2016"),
        (498538, 708919, "2017"),
        (708919, 917758, "2018"),
        (917758, 974841, "2019"),
        (974841, float("inf"), "2020"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_63_with_zero(value):
    """
    Get the fill year for series code 63 based on the value, including zero.
    """
    ranges = [
        (0, 205597, "2020"),
        (205597, float("inf"), "2021"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


import re


def get_kind_code(publication_number):
    """
    Extract the kind code from the publication number.

    :param publication_number: The publication number
    :return: The kind code if it matches the pattern, otherwise an empty string
    """
    pattern = re.compile(r"^.+([A-Z]\d?)$")
    matcher = pattern.match(publication_number)
    if matcher:
        return matcher.group(1)
    else:
        return ""


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules for US and KR patent numbers.
    """
    rules: List[Rule] = []
    rules = [
        ("us_provisional_number_perfect_match", [us_provisional_number_perfect_match]),
        ("us_provisional_number_add_p", [us_provisional_number_add_p]),
        ("us_provisional_number_fill_year_add_p", [us_provisional_number_fill_year_add_p]),
        (
            "us_provisional_number_fill_year_add_p_minus_one",
            [us_provisional_number_fill_year_add_p_minus_one],
        ),
        (
            "us_provisional_number_fill_year_add_p_plus_one",
            [us_provisional_number_fill_year_add_p_plus_one],
        ),
        (
            "us_provisional_number_fill_year_Add_p_without_removing_zero",
            [us_provisional_number_fill_year_add_p_without_removing_zero],
        ),
    ]
    return rules
