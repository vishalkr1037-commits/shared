from typing import Callable, List, Tuple

Rule = Tuple[str, List[Callable[[str], str]]]


def cn_provisional_with_14_digits(patent_number):
    """
    Numbers in format CNxxxxxxxx (CN followed by 12 digits) - Just add "A" at the end.

    :param patent_number: The patent number
    :return: If CN + 12 digits, add "A". Else, return the original number.
    """
    if len(patent_number) == 14 and patent_number.startswith("CN") and patent_number[2:].isdigit():
        return patent_number.strip() + "A"
    else:
        return patent_number


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules for CN patent numbers.
    """
    rules: List[Rule] = []
    rules = [
        ("cn_provisional_with_14_digits", [cn_provisional_with_14_digits]),
    ]
    return rules
