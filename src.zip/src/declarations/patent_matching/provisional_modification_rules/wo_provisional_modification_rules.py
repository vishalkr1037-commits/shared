from typing import Callable, List, Tuple

from src.declarations.patent_matching.provisional_modification_rules.provisional_modification_rules_helper import (
    extract_year,
    has_cc_year,
    is_year_before_2000,
    replace_and_format,
)

Rule = Tuple[str, List[Callable[[str], str]]]


def modify_wo_provisional(patent_number: str, country_code: str, add_zero: bool = False) -> str:
    if patent_number.startswith("WO") and country_code in patent_number:
        if has_cc_year(patent_number):
            year = extract_year(patent_number)
            if is_year_before_2000(year):
                return patent_number
            suffix = f"{year}0" if add_zero else f"{year}"
            return replace_and_format(patent_number, country_code, f"{country_code}{suffix}")
        else:
            return patent_number
    return patent_number


def wo_provisional_with_cn_add_zero_w(patent_number: str) -> str:
    return modify_wo_provisional(patent_number, "CN", add_zero=True)


def wo_provisional_with_cn_w(patent_number: str) -> str:
    return modify_wo_provisional(patent_number, "CN")


def wo_provisional_with_ep_add_zero_w(patent_number: str) -> str:
    return modify_wo_provisional(patent_number, "EP", add_zero=True)


def get_provisional_number_modification_rules() -> List[Rule]:
    return [
        ("wo_provisional_with_cn_add_zero_w", [wo_provisional_with_cn_add_zero_w]),
        ("wo_provisional_with_cn_w", [wo_provisional_with_cn_w]),
        ("wo_provisional_with_ep_add_zero_w", [wo_provisional_with_ep_add_zero_w]),
    ]
