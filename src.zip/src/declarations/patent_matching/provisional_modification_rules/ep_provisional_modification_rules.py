from typing import Callable, List, Tuple

Rule = Tuple[str, List[Callable[[str], str]]]


def ep_provisional_with_10_digits(patent_number):
    """
    Numbers in format EPxxxxxxxx (EP followed by 8 digits) - Just add "A" at the end.

    :param patent_number: The patent number
    :return: If EP + 8 digits, add "A". Else, return the original number.
    """
    if len(patent_number) == 10 and patent_number.startswith("EP") and patent_number[2:].isdigit():
        return patent_number.strip() + "A"
    else:
        return patent_number


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules for EP patent numbers.
    """
    rules: List[Rule] = []
    rules = [
        ("ep_provisional_with_10_digits", [ep_provisional_with_10_digits]),
    ]
    return rules
