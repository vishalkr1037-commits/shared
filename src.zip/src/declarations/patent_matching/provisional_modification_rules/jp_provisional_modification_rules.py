from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as mod_helper

Rule = Tuple[str, List[Callable[[str], str]]]


def jp_provisional_with_12_digits(patent_number):
    """
    JP20 + 8 digits - 12 chars in total
    Rule: Just add "A" at the end.
    """
    if len(patent_number) == 12 and patent_number.startswith("JP20"):
        return patent_number.strip() + "A"
    else:
        return patent_number


def jp_provisional_with_13_digits(patent_number):
    """
    JP20 + 9 digits - 13 chars in total
    Rule: Delete "0" after the year and add "A" at the end.
    """
    if (
        len(patent_number) == 13
        and patent_number.startswith("JP20")
        and mod_helper.has_cc_year(patent_number)
        and patent_number[6] == "0"
    ):
        return patent_number[:6].strip() + patent_number[7:] + "A"
    else:
        return patent_number


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules for JP patent numbers.
    """
    rules: List[Rule] = []
    rules = [
        ("jp_provisional_with_12_digits", [jp_provisional_with_12_digits]),
        ("jp_provisional_with_13_digits", [jp_provisional_with_13_digits]),
    ]
    return rules
