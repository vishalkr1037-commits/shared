from typing import Callable, List, Tuple

import src.declarations.patent_matching.provisional_modification_rules.provisional_modification_rules_helper as helper

Rule = Tuple[str, List[Callable[[str], str]]]


def provisional_number_fill_year_add_p(patent_number):
    """
    For formats 60, 61, 62, 63 and 8 chars 60______ (only application numbers!)
    Apply logic from the USPTO filing year rules.
    """
    if len(patent_number) == 8 and patent_number[:2] in helper.provisional_series_code and patent_number.isdigit():
        tmp_patent_number = "US" + patent_number.strip()
        series_code = int(tmp_patent_number[2:4])
        return helper.get_provisional_number(series_code, tmp_patent_number)
    else:
        return patent_number


def provisional_number_fill_year_add_p_minus_one(patent_number):
    """
    For formats 60, 61, 62, 63 and 8 chars 60______ (only application numbers!)
    Apply logic from the USPTO filing year rules, minus one year.
    """
    if len(patent_number) == 8 and patent_number[:2] in helper.provisional_series_code and patent_number.isdigit():
        tmp_patent_number = "US" + patent_number.strip()
        series_code = int(tmp_patent_number[2:4])
        return helper.get_provisional_number_minus_one(series_code, tmp_patent_number)
    else:
        return patent_number


def provisional_number_fill_year_add_p_plus_one(patent_number):
    """
    For formats 60, 61, 62, 63 and 8 chars 60______ (only application numbers!)
    Apply logic from the USPTO filing year rules, plus one year.
    """
    if len(patent_number) == 8 and patent_number[:2] in helper.provisional_series_code and patent_number.isdigit():
        tmp_patent_number = "US" + patent_number.strip()
        series_code = int(tmp_patent_number[2:4])
        return helper.get_provisional_number_plus_one(series_code, tmp_patent_number)
    else:
        return patent_number


def pct_cn_provisional_numbers_remove_pct_add_w(patent_number):
    """
    Numbers starting with PCTCN20 + 8 digits - in total 15 chars
    Rule: Delete PCT, add "W" at the end.

    :param patent_number: The patent number
    :return: If PCTCN + 8 digits, remove PCT, add W. Else, return the original number.
    """
    if patent_number.startswith("PCTCN20") and len(patent_number) == 15:
        return patent_number.replace("PCT", "").strip() + "W"
    else:
        return patent_number


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules.
    """
    rules: List[Rule] = []
    rules = [
        ("provisional_number_fill_year_add_p", [provisional_number_fill_year_add_p]),
        (
            "provisional_number_fill_year_add_p_minus_one",
            [provisional_number_fill_year_add_p_minus_one],
        ),
        (
            "provisional_number_fill_year_add_p_plus_one",
            [provisional_number_fill_year_add_p_plus_one],
        ),
        (
            "pct_cn_provisional_numbers_remove_pct_add_w",
            [pct_cn_provisional_numbers_remove_pct_add_w],
        ),
    ]
    return rules
