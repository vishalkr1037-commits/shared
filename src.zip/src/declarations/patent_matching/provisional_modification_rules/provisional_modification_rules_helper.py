import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper

provisional_series_code = {"60", "61", "62", "63"}


def get_value_in_range_60_plus_one(value):
    """
    Get the fill year for series code 60 based on the value, plus one year.
    """
    ranges = [
        (1, 9474, "96"),
        (9474, 34487, "97"),
        (34487, 70310, "98"),
        (70310, 113787, "99"),
        (113787, 173038, "00"),
        (173038, 256739, "01"),
        (256739, 343564, "02"),
        (343564, 437173, "03"),
        (437173, 532638, "04"),
        (532638, 639450, "05"),
        (639450, 754464, "06"),
        (754464, 877460, "07"),
        (877460, float("inf"), "08"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_61_plus_one(value):
    """
    Get the fill year for series code 61 based on the value, plus one year.
    """
    ranges = [
        (9389, 203947, "09"),
        (203947, 335046, "10"),
        (335046, 460301, "11"),
        (460301, 631245, "12"),
        (631245, 848274, "13"),
        (848274, 964276, "14"),
        (964276, float("inf"), "15"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_62_plus_one(value):
    """
    Get the fill year for series code 62 based on the value, plus one year.
    """
    ranges = [
        (124715, 387330, "2016"),
        (387330, 498538, "2017"),
        (498538, 708919, "2018"),
        (708919, 917758, "2019"),
        (917758, 974841, "2020"),
        (974841, float("inf"), "2021"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_63_plus_one(value):
    """
    Get the fill year for series code 63 based on the value, plus one year.
    """
    ranges = [
        (0, 205597, "2021"),
        (205597, 343736, "2022"),
        (343736, 378145, "2023"),
        (378145, float("inf"), "2024"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_fill_year_based_on_series_code_plus_one(series_code, value):
    """
    Get the fill year based on the series code and value, plus one year.
    """
    if series_code == 60:
        return get_value_in_range_60_plus_one(value)
    elif series_code == 61:
        return get_value_in_range_61_plus_one(value)
    elif series_code == 62:
        return get_value_in_range_62_plus_one(value)
    elif series_code == 63:
        return get_value_in_range_63_plus_one(value)
    else:
        return ""


def get_provisional_number_starting_with_60_plus_one(patent_number, series_code):
    """
    Get the provisional number for series code 60, plus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code_plus_one(series_code, int(digits))
    return f"US{digits}{fill_year}P"


def get_provisional_number_starting_with_61_plus_one(patent_number, series_code):
    """
    Get the provisional number for series code 61, plus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    value = int(digits)
    fill_year = get_fill_year_based_on_series_code_plus_one(series_code, value)
    if value <= 423419:
        return f"US{digits}{fill_year}P"
    else:
        return f"US20{fill_year}{series_code}{digits}P"


def get_provisional_number_starting_with_62_plus_one(patent_number, series_code):
    """
    Get the provisional number for series code 62, plus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code_plus_one(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_provisional_number_starting_with_63_plus_one(patent_number, series_code):
    """
    Get the provisional number for series code 63, plus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code_plus_one(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_provisional_number_plus_one(series_code, patent_number):
    """
    Get the provisional number based on the series code, plus one year.
    """
    if series_code == 60:
        return get_provisional_number_starting_with_60_plus_one(patent_number, series_code)
    elif series_code == 61:
        return get_provisional_number_starting_with_61_plus_one(patent_number, series_code)
    elif series_code == 62:
        return get_provisional_number_starting_with_62_plus_one(patent_number, series_code)
    elif series_code == 63:
        return get_provisional_number_starting_with_63_plus_one(patent_number, series_code)
    else:
        return ""


def get_value_in_range_60(value):
    """
    Get the fill year for series code 60 based on the value.
    """
    ranges = [
        (1, 9474, "95"),
        (9474, 34487, "96"),
        (34487, 70310, "97"),
        (70310, 113787, "98"),
        (113787, 173038, "99"),
        (173038, 256739, "00"),
        (256739, 343564, "01"),
        (343564, 437173, "02"),
        (437173, 532638, "03"),
        (532638, 639450, "04"),
        (639450, 754464, "05"),
        (754464, 877460, "06"),
        (877460, float("inf"), "07"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_61(value):
    """
    Get the fill year for series code 61 based on the value.
    """
    ranges = [
        (9389, 203947, "08"),
        (203947, 335046, "09"),
        (335046, 460301, "10"),
        (460301, 631245, "11"),
        (631245, 848274, "12"),
        (848274, 964276, "13"),
        (964276, float("inf"), "14"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_62(value):
    """
    Get the fill year for series code 62 based on the value.
    """
    ranges = [
        (124715, 387330, "2015"),
        (387330, 498538, "2016"),
        (498538, 708919, "2017"),
        (708919, 917758, "2018"),
        (917758, 974841, "2019"),
        (974841, float("inf"), "2020"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_63(value):
    """
    Get the fill year for series code 63 based on the value.
    """
    ranges = [
        (0, 205597, "2020"),
        (205597, 343736, "2021"),
        (343736, 378145, "2022"),
        (378145, float("inf"), "2023"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_fill_year_based_on_series_code(series_code, value):
    """
    Get the fill year based on the series code and value.
    """
    if series_code == 60:
        return get_value_in_range_60(value)
    elif series_code == 61:
        return get_value_in_range_61(value)
    elif series_code == 62:
        return get_value_in_range_62(value)
    elif series_code == 63:
        return get_value_in_range_63(value)
    else:
        return ""


def get_provisional_number_starting_with_60(patent_number, series_code):
    """
    Get the provisional number for series code 60.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code(series_code, int(digits))
    return f"US{digits}{fill_year}P"


def get_provisional_number_starting_with_61(patent_number, series_code):
    """
    Get the provisional number for series code 61.
    """
    digits = get_digits_without_starting_zero(patent_number)
    value = int(digits)
    fill_year = get_fill_year_based_on_series_code(series_code, value)
    if value <= 423419:
        return f"US{digits}{fill_year}P"
    else:
        return f"US20{fill_year}{series_code}{digits}P"


def get_provisional_number_starting_with_62(patent_number, series_code):
    """
    Get the provisional number for series code 62.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_provisional_number_starting_with_63(patent_number, series_code):
    """
    Get the provisional number for series code 63.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_provisional_number(series_code, patent_number):
    """
    Get the provisional number based on the series code.
    """
    if series_code == 60:
        return get_provisional_number_starting_with_60(patent_number, series_code)
    elif series_code == 61:
        return get_provisional_number_starting_with_61(patent_number, series_code)
    elif series_code == 62:
        return get_provisional_number_starting_with_62(patent_number, series_code)
    elif series_code == 63:
        return get_provisional_number_starting_with_63(patent_number, series_code)
    else:
        return ""


def get_digits_without_starting_zero(patent_number):
    """
    Remove the starting zero from the digits after the series code.
    """
    if patent_number[4] == "0":
        return patent_number[5:]
    else:
        return patent_number[4:]


def get_value_in_range_60_minus_one(value):
    """
    Get the fill year for series code 60 based on the value, minus one year.
    """
    ranges = [
        (1, 9474, "94"),
        (9474, 34487, "95"),
        (34487, 70310, "96"),
        (70310, 113787, "97"),
        (113787, 173038, "98"),
        (173038, 256739, "99"),
        (256739, 343564, "00"),
        (343564, 437173, "01"),
        (437173, 532638, "02"),
        (532638, 639450, "03"),
        (639450, 754464, "04"),
        (754464, 877460, "05"),
        (877460, float("inf"), "06"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_61_minus_one(value):
    """
    Get the fill year for series code 61 based on the value, minus one year.
    """
    ranges = [
        (9389, 203947, "07"),
        (203947, 335046, "08"),
        (335046, 460301, "09"),
        (460301, 631245, "10"),
        (631245, 848274, "11"),
        (848274, 964276, "12"),
        (964276, float("inf"), "13"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_62_minus_one(value):
    """
    Get the fill year for series code 62 based on the value, minus one year.
    """
    ranges = [
        (124715, 387330, "2014"),
        (387330, 498538, "2015"),
        (498538, 708919, "2016"),
        (708919, 917758, "2017"),
        (917758, 974841, "2018"),
        (974841, float("inf"), "2019"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_value_in_range_63_minus_one(value):
    """
    Get the fill year for series code 63 based on the value, minus one year.
    """
    ranges = [
        (0, 205597, "2019"),
        (205597, 343736, "2020"),
        (343736, 378145, "2021"),
        (378145, float("inf"), "2022"),
    ]
    for start, end, year in ranges:
        if start <= value < end:
            return year
    return ""


def get_fill_year_based_on_series_code_minus_one(series_code, value):
    """
    Get the fill year based on the series code and value, minus one year.
    """
    if series_code == 60:
        return get_value_in_range_60_minus_one(value)
    elif series_code == 61:
        return get_value_in_range_61_minus_one(value)
    elif series_code == 62:
        return get_value_in_range_62_minus_one(value)
    elif series_code == 63:
        return get_value_in_range_63_minus_one(value)
    else:
        return ""


def get_provisional_number_starting_with_60_minus_one(patent_number, series_code):
    """
    Get the provisional number for series code 60, minus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code_minus_one(series_code, int(digits))
    return f"US{digits}{fill_year}P"


def get_provisional_number_starting_with_61_minus_one(patent_number, series_code):
    """
    Get the provisional number for series code 61, minus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    value = int(digits)
    fill_year = get_fill_year_based_on_series_code_minus_one(series_code, value)
    if value <= 423419:
        return f"US{digits}{fill_year}P"
    else:
        return f"US20{fill_year}{series_code}{digits}P"


def get_provisional_number_starting_with_62_minus_one(patent_number, series_code):
    """
    Get the provisional number for series code 62, minus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code_minus_one(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_provisional_number_starting_with_63_minus_one(patent_number, series_code):
    """
    Get the provisional number for series code 63, minus one year.
    """
    digits = get_digits_without_starting_zero(patent_number)
    fill_year = get_fill_year_based_on_series_code_minus_one(series_code, int(digits))
    return f"US{fill_year}{series_code}{digits}P"


def get_provisional_number_minus_one(series_code, patent_number):
    """
    Get the provisional number based on the series code, minus one year.
    """
    if series_code == 60:
        return get_provisional_number_starting_with_60_minus_one(patent_number, series_code)
    elif series_code == 61:
        return get_provisional_number_starting_with_61_minus_one(patent_number, series_code)
    elif series_code == 62:
        return get_provisional_number_starting_with_62_minus_one(patent_number, series_code)
    elif series_code == 63:
        return get_provisional_number_starting_with_63_minus_one(patent_number, series_code)
    else:
        return ""


def has_cc_year(patent_number: str) -> bool:
    return len(patent_number) >= 6 and patent_number[:2] in helper.country_codes and patent_number[2:6] in helper.years


def extract_year(patent_number: str) -> int:
    """
    Extracts the year from the patent number (characters 2 to 6).

    :param patent_number: The patent number
    :return: The extracted year as an integer
    """
    year_str = patent_number[2:6]
    if year_str.isdigit() and year_str in helper.years:
        return int(year_str)
    return 0


def is_year_before_2000(year: int) -> bool:
    """
    Checks if the given year is before 2000.

    :param year: The year to check
    :return: True if the year is before 2000, False otherwise
    """
    return year < 2000


def replace_and_format(patent_number: str, prefix: str, replacement: str) -> str:
    """
    Replaces a prefix in the patent number and formats it with a trailing "W".

    :param patent_number: The patent number
    :param prefix: The prefix to replace (e.g., "CN" or "EP")
    :param replacement: The replacement string (e.g., "CN0" or "EP0")
    :return: The modified patent number
    """
    rest = patent_number[6:].replace(prefix, "")
    return f"{replacement}{rest}W"
