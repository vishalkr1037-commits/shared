from typing import Callable, List, Tuple

Rule = Tuple[str, List[Callable[[str], str]]]


def gr_provisional_with_11_digits(patent_number):
    """
    GR (len = 13) -> Rule: Just add "A" at the end.

    :param patent_number: The patent number
    :return: If GR + 11 digits, add "A". Else, return the original number.
    """
    if len(patent_number) == 13 and patent_number.startswith("GR"):
        return patent_number.strip() + "A"
    else:
        return patent_number


def get_provisional_number_modification_rules() -> List[Rule]:
    """
    Returns a list of provisional modification rules for GR patent numbers.
    """
    rules: List[Rule] = []
    rules = [
        ("gr_provisional_with_11_digits", [gr_provisional_with_11_digits]),
    ]
    return rules
