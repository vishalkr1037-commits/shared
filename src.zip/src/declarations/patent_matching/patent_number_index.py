import logging
import os
from contextlib import contextmanager

logger = logging.getLogger("patents_index")
logger.setLevel(logging.INFO)
if not logger.handlers:
    handler = logging.StreamHandler()
    formatter = logging.Formatter("%(asctime)s %(levelname)s %(message)s")
    handler.setFormatter(formatter)
    logger.addHandler(handler)

try:
    import lucene
    from java.nio.file import Paths
    from org.apache.lucene.analysis.core import KeywordAnalyzer
    from org.apache.lucene.index import DirectoryReader
    from org.apache.lucene.queryparser.flexible.standard import StandardQueryParser
    from org.apache.lucene.search import IndexSearcher
    from org.apache.lucene.store import FSDirectory

    LUCENE_AVAILABLE = True
except ImportError:
    LUCENE_AVAILABLE = False


def is_valid_query(search_text):
    """
    Check if the search query is valid.

    Args:
        search_text: The search query text

    Returns:
        bool: True if the query is valid, False otherwise
    """
    return search_text and search_text.strip() and search_text != "AND"


class LuceneSearcher:
    def __init__(self):
        self.available = False
        self.directory = None
        self.reader = None
        self.searcher = None
        self.parser = None

        if not LUCENE_AVAILABLE:
            logger.error("Lucene is not available. Please ensure that the Lucene library is installed.")
            return None

        if not lucene.getVMEnv():
            lucene.initVM()

        self.path = os.getenv("LUCENE_PATH")
        if self.path is None:
            logger.error("LUCENE_PATH environment variable is not set.")
            return None
        if not os.path.exists(self.path):
            raise RuntimeError("The path specified in LUCENE_PATH does not exist: {}".format(self.path))

    def _initialize(self):
        """
        Initialize Lucene resources, only if they are not already initialized.
        """
        if not self.available:
            try:
                self.directory = FSDirectory.open(Paths.get(self.path))
                self.reader = DirectoryReader.open(self.directory)
                self.searcher = IndexSearcher(self.reader)
                self.parser = StandardQueryParser(KeywordAnalyzer())
                self.available = True
            except Exception as e:
                logger.error(f"Failed to initialize Lucene searcher: {e}")
                self.available = False

    def search(self, field, search_text, limit=10):
        """
        Search the already opened Lucene index.
        """
        try:

            if not self.available or self.reader is None or not self.reader.tryIncRef():
                self._initialize()

            if not self.available or not is_valid_query(search_text):
                raise ValueError("Lucene searcher is not available or the query is invalid.")

            query = self.parser.parse(search_text, field)
            hits = self.searcher.search(query, limit).scoreDocs

            results = []
            for hit in hits:
                doc = self.searcher.doc(hit.doc)
                publication_number = doc.get("publication_number_search")
                results.append(publication_number)

            return results

        except Exception as e:
            if "QueryNodeException" in str(type(e)):
                logger.error(f"Error parsing query: [{search_text}]")
                return []
            elif isinstance(e, ValueError):
                logger.error(f"Illegal argument in query: [{search_text}]")
                return []
            else:
                logger.error(f"Lucene search failed. Field: {field}, Query: '{search_text}' - Error: {e}")
                return []

    def close(self):
        """
        Close Lucene resources if they are open.
        """
        try:
            if self.reader:
                self.reader.close()
            if self.directory:
                self.directory.close()
        except Exception as e:
            logger.warning(f"Error closing Lucene resources: {e}")

    @contextmanager
    def managed_searcher(self):
        """
        Context manager to handle LuceneSearcher initialization and cleanup.
        Only opens the resources once and keeps them open during usage.
        """
        try:
            # Initialize the resources (only once)
            self._initialize()

            yield self  # Yield the searcher object to the caller

        finally:
            # Ensure resources are closed after use, once all searches are done
            self.close()
