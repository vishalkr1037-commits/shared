import re
from importlib import import_module
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.generic_modification_rules as generic
import src.declarations.patent_matching.provisional_modification_rules.generic_provisional_modification_rules as generic_provisional

Rule = Tuple[str, List[Callable[[str], str]]]

lst_of_publ_appl_country_codes = [
    "AR",
    "AT",
    "AU",
    "BR",
    "CA",
    "CL",
    "CN",
    "CO",
    "DE",
    "EA",
    "FI",
    "FR",
    "GB",
    "HK",
    "HR",
    "HU",
    "IN",
    "IT",
    "JP",
    "KR",
    "MA",
    "MX",
    "MY",
    "NO",
    "NZ",
    "PE",
    "PH",
    "PL",
    "SE",
    "SG",
    "SM",
    "TR",
    "TW",
    "UA",
    "US",
    "WO",
    "ZA",
]

lst_of_provisional_country_codes = ["CN", "EP", "FI", "GR", "IN", "JP", "KR", "US", "WO"]


def get_publication_number_modification_rules(number: str) -> List[Rule]:
    if not number:
        return []

    country_code = number[:2]

    if country_code in lst_of_publ_appl_country_codes:
        module_name = f"src.declarations.patent_matching.modification_rules.{country_code.lower()}_modification_rules"
        module = import_module(module_name)
        strategy = getattr(module, "get_publication_number_modification_rules")
        return strategy()
    else:
        return generic.get_publication_number_modification_rules()


def get_application_number_modification_rules(number: str) -> List[Rule]:
    if not number:
        return []

    country_code = number[:2]

    if country_code in lst_of_publ_appl_country_codes:
        module_name = f"src.declarations.patent_matching.modification_rules.{country_code.lower()}_modification_rules"
        module = import_module(module_name)
        strategy = getattr(module, "get_application_number_modification_rules")
        return strategy()
    else:
        return generic.get_application_number_modification_rules()


def get_provisional_number_modification_rules(number: str) -> List[Rule]:
    if not number:
        return []

    country_code = number[:2]

    if country_code in lst_of_provisional_country_codes:
        module_name = f"src.declarations.patent_matching.provisional_modification_rules.{country_code.lower()}_provisional_modification_rules"
        module = import_module(module_name)
        strategy = getattr(module, "get_provisional_number_modification_rules")
        return strategy()
    else:
        return generic_provisional.get_provisional_number_modification_rules()


def apply_rule(number: str, rule_functions: list) -> str:
    result = number
    for i, func in enumerate(rule_functions):
        if not callable(func):
            raise TypeError(
                f"Invalid rule at position {i}.\n"
                f"Input number: {number}\n"
                f"Rule functions list: {rule_functions}\n"
                f"Invalid rule type: {type(func)}\n"
                f"Invalid rule value: {func}"
            )
        result = func(result)
    return result


def country_code_exists(patent_number: str) -> bool:
    return patent_number[:2].isalpha()


def add_kind_code(patent_number):
    """Adds kind code regex pattern to a patent number for searching."""
    kind_code_regex = r"[A-Z][0-9]?"
    # Remove the (partial) kind code
    pattern = re.sub(kind_code_regex + r"$", "", patent_number)
    # Convert single wildcard to regex single wildcard
    pattern = pattern.replace("?", ".?")

    if pattern.startswith("/") and pattern.endswith("/"):
        return pattern[:-1] + kind_code_regex + pattern[-1:]
    else:
        return "/" + pattern + kind_code_regex + "/"


def get_kind_code(publication_number: str) -> str:
    pattern = re.compile(r"^.+([A-Z]\d?)$")
    matcher = pattern.fullmatch(publication_number)
    if matcher:
        return matcher.group(1)
    else:
        return ""


def kind_code_exists(patent_number: str) -> bool:
    kind_code = get_kind_code(patent_number)
    return is_kind_code(kind_code)


def is_kind_code(kind_code: str) -> bool:
    if not kind_code:
        return False

    if len(kind_code) == 1:
        return kind_code.isalpha()
    elif len(kind_code) == 2:
        return kind_code.isalnum()
    else:
        return False
