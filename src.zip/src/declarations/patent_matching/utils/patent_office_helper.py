import csv
from pathlib import Path


def init_patent_offices_map():
    patent_office_map = {}

    base_path = Path(__file__).resolve().parent.parent
    file_path = base_path / "resources" / "patent_office.csv"

    try:
        with open(file_path, mode="r", encoding="utf-8") as file:
            reader = csv.DictReader(file)

            for record in reader:
                # Filter out invalid rows based on size (should have 4 columns)
                if len(record) == 4:
                    code = record.get("Code")
                    if code:  # Ensure 'Code' is not empty
                        name = record.get("Name")
                        status = True if record.get("Status") == "ACTIVE" else False
                        other_codes = record.get("Other Codes", "")

                        # Directly store as a dictionary (no need for a class)
                        patent_office_map[code] = {"name": name, "status": status, "other_codes": other_codes}

    except Exception as e:
        print(f"Error reading Patent Office file: {e}")

    return patent_office_map


# Initialize patent offices map
patent_offices_map = init_patent_offices_map()


def get_patent_number_with_country_of_registration(patent_number: str, country_of_registration: str) -> str:
    """
    Get patent number with country of registration.
    """
    if patent_number and not patent_number[:2].isalpha() and country_of_registration:
        return get_patent_office_from_country_of_registration(country_of_registration) + patent_number
    else:
        return patent_number


def get_patent_office_from_country_of_registration(country_of_registration: str) -> str:
    """
    Get patent office from country of registration.
    """
    if not country_of_registration:
        return ""
    for code in country_of_registration.split():
        if len(code) == 2 and code in patent_offices_map:
            return code
    return ""


def get_list_patent_office_codes() -> list:
    """
    Get list of patent office codes.
    """
    return list(patent_offices_map.keys())
