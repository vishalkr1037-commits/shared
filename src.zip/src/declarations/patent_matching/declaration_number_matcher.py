import pyspark.sql.functions as F

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.safe_modification_rules as SafeModificationRules
import src.declarations.patent_matching.utils.declaration_number_matcher_helper as declaration_number_matcher_helper
import src.declarations.patent_matching.utils.patent_office_helper as PatentOfficeHelper
from src.declarations.patent_matching.patent_number_index import LuceneSearcher

indexer = LuceneSearcher()


def get_preprocessed_number(original_clean_number: str, country_of_registration: str) -> str:
    result = original_clean_number

    if not result:
        return ""

    if len(result) <= 2 or not helper.patent_contains_digits(result):
        return ""

    if result[:3].isdigit():
        result = PatentOfficeHelper.get_patent_number_with_country_of_registration(result, country_of_registration)

    if result.startswith("WO"):
        result = helper.pct_reformat_original_number_add_wo(result)

    if result.startswith("DE") or result.startswith("EP") or result.startswith("CN") or result.startswith("BR"):
        result = result.rsplit(".", 1)[0]

    result = helper.remove_non_alphanumeric_chars(result.upper())

    prefix_rules = SafeModificationRules.get_publication_number_modification_rules()

    for rule_name, rule_functions in prefix_rules:
        result = declaration_number_matcher_helper.apply_rule(result, rule_functions)

    return result


def try_matches(indexer: LuceneSearcher, field: str, number: str, modification_rule: list) -> list:
    pattern = number
    pattern = declaration_number_matcher_helper.apply_rule(pattern, modification_rule)

    # Search for the modified number if there is no modification_rule (first run) or if the modification_rule actually changed anything
    if not modification_rule or pattern != number:
        with indexer.managed_searcher() as searcher:  # Use the context manager
            result = searcher.search(field, pattern)
            if not result:
                # If we found no result, add a kind code
                pattern = declaration_number_matcher_helper.add_kind_code(pattern)
                result = searcher.search(field, pattern)
        return result
    else:
        return []


def try_matches_provisional(indexer: LuceneSearcher, field: str, number: str, modification_rule: list) -> list:
    pattern = number
    pattern = declaration_number_matcher_helper.apply_rule(pattern, modification_rule)

    if not modification_rule or pattern != number:
        priority_numbers = [field_part.strip() for field_part in field.split("|")]
        result = []

        with indexer.managed_searcher() as searcher:  # Use the context manager
            for priority_number in priority_numbers:
                result = searcher.search(priority_number, pattern)
                if not result:
                    pattern = declaration_number_matcher_helper.add_kind_code(pattern)
                    result = searcher.search(priority_number, pattern)

                if result:
                    break

        return result
    else:
        return []


def find_all_publication_numbers(indexer: LuceneSearcher, working_number: str, country_of_registration: str) -> list:
    """Finds all publication numbers based on the working number and country of registration."""
    patent_number = PatentOfficeHelper.get_patent_number_with_country_of_registration(
        working_number, country_of_registration
    )
    modification_rules = declaration_number_matcher_helper.get_publication_number_modification_rules(patent_number)

    all_matches = []
    seen_matches = set()  # This set will keep track of matches we've already added to maintain uniqueness.
    applied_rules = []

    with indexer.managed_searcher() as searcher:  # Use the context manager
        for rule_name, rule_functions in modification_rules:
            matches = try_matches(searcher, "publication_number_search", patent_number, rule_functions)
            if matches:
                applied_rules.append(rule_name)

                for match in matches:
                    if (
                        patent_number == match
                        and declaration_number_matcher_helper.country_code_exists(patent_number)
                        and declaration_number_matcher_helper.kind_code_exists(patent_number)
                    ):
                        return [[[match], ["perfect_match"]]]

                    # Ensure uniqueness while maintaining order
                    if match not in seen_matches:
                        seen_matches.add(match)  # Mark this match as seen
                        all_matches.append([[match], applied_rules.copy()])

    return all_matches


def find_all_application_numbers(indexer: LuceneSearcher, working_number: str, country_of_registration: str) -> list:
    """Finds all application numbers based on the working number and country of registration."""
    patent_number = PatentOfficeHelper.get_patent_number_with_country_of_registration(
        working_number, country_of_registration
    )

    modification_rules = declaration_number_matcher_helper.get_application_number_modification_rules(patent_number)
    all_matches = []
    seen_matches = set()  # To maintain uniqueness
    applied_rules = []

    with indexer.managed_searcher() as searcher:  # Use the context manager
        for rule_name, rule_functions in modification_rules:
            matches = try_matches(searcher, "application_number_search", patent_number, rule_functions)
            if matches:
                applied_rules.append(rule_name)
                for match in matches:
                    match_key = match

                    if match_key not in seen_matches:
                        seen_matches.add(match_key)
                        all_matches.append([[match], applied_rules.copy()])

                if (
                    len(applied_rules) == 1
                    and applied_rules[0] == "none"
                    and declaration_number_matcher_helper.country_code_exists(patent_number)
                    and declaration_number_matcher_helper.kind_code_exists(patent_number)
                ):

                    # Set all matches to have "perfect_match" as the applied rule
                    all_matches = [[[match[0][0]], ["perfect_match"]] for match in all_matches]
                    return all_matches

    provisional_matches = find_all_provisional_numbers(indexer, working_number, country_of_registration)
    all_matches.extend(provisional_matches)
    return all_matches


def find_all_provisional_numbers(indexer: LuceneSearcher, working_number: str, country_of_registration: str) -> list:
    """Finds all provisional numbers based on the working number and country of registration.
    Returns a set of tuples containing (applied_rules, matched_number)."""

    patent_number = PatentOfficeHelper.get_patent_number_with_country_of_registration(
        working_number, country_of_registration
    )

    modification_rules = declaration_number_matcher_helper.get_provisional_number_modification_rules(patent_number)
    all_matches = []
    seen_matches = set()  # To maintain uniqueness
    applied_rules = []

    with indexer.managed_searcher() as searcher:  # Use the context manager
        for rule_name, rule_functions in modification_rules:
            matches = try_matches_provisional(searcher, "all_priority_numbers_search", patent_number, rule_functions)

            if matches:
                applied_rules.append(rule_name)
                for match in matches:
                    match_key = match

                    if match_key not in seen_matches:
                        seen_matches.add(match_key)
                        all_matches.append([[match], applied_rules.copy()])

                if (
                    len(applied_rules) == 1
                    and applied_rules[0] == "provisional_perfect_match"
                    and declaration_number_matcher_helper.country_code_exists(patent_number)
                    and declaration_number_matcher_helper.kind_code_exists(patent_number)
                ):
                    all_matches = [[[match[0][0]], ["perfect_match"]] for match in all_matches]
                    return all_matches

    return all_matches


def find_all_publication_numbers_udf(working_number: str, country_of_registration: str) -> list:
    """UDF wrapper for find_all_publication_numbers."""
    matches = find_all_publication_numbers(indexer, working_number, country_of_registration)
    return matches


def find_all_application_numbers_udf(working_number: str, country_of_registration: str) -> list:
    """UDF wrapper for find_all_application_numbers."""
    matches = find_all_application_numbers(indexer, working_number, country_of_registration)
    return matches


def get_matches_struct(cleaned_field, working_field, matches_field, source, country_of_registration):
    return F.transform(
        F.arrays_zip(F.col(cleaned_field), F.col(working_field), F.col(matches_field)),
        lambda n: F.struct(
            source.alias("source"),
            country_of_registration.alias("country_of_registration"),
            n[cleaned_field].alias("original_clean_number"),
            n[working_field].alias("working_number"),
            n[matches_field].alias("number_and_rules"),
        ),
    )
