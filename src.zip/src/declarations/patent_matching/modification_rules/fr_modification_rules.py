from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def fr_drop_yr_and_zero(patent_number):
    if (
        patent_number.startswith("FR")
        and len(patent_number) == 13
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] == "00"
        and patent_number[8:13].isdigit()
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[8:13]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "fr_drop_yr_and_zero",
                [fr_drop_yr_and_zero],
            )
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
