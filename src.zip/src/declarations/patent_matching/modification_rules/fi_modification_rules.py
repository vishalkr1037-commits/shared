from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def fi_year_and_delete_in_between_zeros(patent_number):
    if (
        len(patent_number) == 13
        and patent_number.startswith("FI")
        and helper.has_cc_year(patent_number)
        and str(helper.get_year(patent_number)).startswith("2")
    ):
        return patent_number[:6] + patent_number[9:]
    elif (
        len(patent_number) == 13
        and patent_number.startswith("FI")
        and helper.has_cc_year(patent_number)
        and str(helper.get_year(patent_number)).startswith("1")
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[9:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "fi_year_and_delete_in_between_zeros",
                [fi_year_and_delete_in_between_zeros],
            )
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
