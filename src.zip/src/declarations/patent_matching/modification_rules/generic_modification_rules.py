import re
from typing import Callable, List, Tuple

Rule = Tuple[str, List[Callable[[str], str]]]

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

pct_patent_pattern = re.compile(r"PCT([A-Z]{2})(\d+)")


def cn_insert_cc_truncate_end(patent_number):
    if match := re.fullmatch(r"(\d+)[xX]", patent_number):
        return "CN" + match.group(1)
    else:
        return patent_number


def us_insert_cc(patent_number):
    if re.fullmatch(r"1\d+", patent_number):
        return "US" + patent_number
    else:
        return patent_number


def us_insert_cc_year_take_last_six_numbers(patent_number):
    if re.fullmatch(r"1\d+", patent_number) and len(patent_number) >= 6:
        return f"/US<{helper.start}-{helper.end}>{patent_number[-6:]}/"
    else:
        return patent_number


def pct_remove_pct_add_wo(patent_number):
    if re.fullmatch(r"^PCT\w{2}\d{10}$", patent_number):
        country_code = patent_number[3:5]
        year = patent_number[5:9]
        return "WO" + year + country_code + re.sub(r"^0+", "", patent_number[9:])
    else:
        return patent_number


def pct_remove_pct(patent_number):
    if re.fullmatch(r"^PCT\w{2}\d{10}$", patent_number):
        return patent_number[3:]
    else:
        return patent_number


def pct_remove_pct_add_w(patent_number):
    if re.fullmatch(r"^PCT[A-Z]{2}\d{10}$", patent_number):
        return patent_number[3:] + "W"
    else:
        return patent_number


def remove_non_alphanumeric_chars(name):
    return re.sub(r"[^0-9A-Z]", "", name)


def us_insert_us_before_numeric_publication_number(patent_number):
    non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
    if re.fullmatch(r"^20.*A1$", non_alpha_num_form):
        return "US" + non_alpha_num_form
    return patent_number


def us_insert_20_after_cc(patent_number):
    non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("PCTUS") and len(non_alpha_num_form) == 13:
        return "US" + "20" + non_alpha_num_form[5:]
    return patent_number


def cn_application_number_starts_with_zl_to_normalized_application_number(patent_number):
    non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("ZL"):
        return non_alpha_num_form.replace("ZL", "CN").strip()
    else:
        return patent_number


def drop_last_letters_based_on_num_length(patent_number):
    if patent_number is not None:
        non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
        if non_alpha_num_form.startswith("CN"):
            if len(non_alpha_num_form[2:]) == 12:
                return non_alpha_num_form
            elif len(non_alpha_num_form[2:]) == 13:
                return non_alpha_num_form[:-1]
            elif len(non_alpha_num_form[2:]) == 9 and non_alpha_num_form[2:4] in helper.short_years:
                return non_alpha_num_form[:-1]
            else:
                return patent_number
        else:
            return patent_number
    else:
        return None


def wo_replace_zero_with_letter_o(patent_number):
    non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("W0") and len(non_alpha_num_form) == 12:
        return non_alpha_num_form.replace("W0", "WO")
    else:
        return patent_number


def pi_add_br_delete_last_char(patent_number):
    non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("PI") and len(non_alpha_num_form) == 10:
        return "BR" + non_alpha_num_form[:-1]
    return patent_number


def delete_pct_add_w_at_end(patent_number):
    if m := pct_patent_pattern.fullmatch(patent_number):
        return m.group(1) + m.group(2) + "W"
    else:
        return patent_number


def add_ep_cc_for_bare_number_patents(patent_number):
    if patent_number.isnumeric():
        return "EP" + patent_number
    else:
        return patent_number


def add_us_cc_for_bare_number_patents(patent_number):
    if patent_number.isnumeric():
        return "US" + patent_number
    else:
        return patent_number


def remove_ep_last_letter(patent_number):
    if patent_number.startswith("EP") and len(patent_number) == 11:
        return patent_number[:-1]
    else:
        return patent_number


def remove_ep_last_letter_add_zero(patent_number):
    if patent_number.startswith("EP") and len(patent_number) == 10:
        return patent_number[:2] + "0" + patent_number[2:-1]
    else:
        return patent_number


def pct_us_remove_pct_expand_year(patent_number):
    if len(patent_number) == 12 and patent_number.startswith("PCT"):
        if short_year := helper.short_years.get(patent_number[5:7]):
            return patent_number[3:5] + short_year + "0" + patent_number[7:]
    return patent_number


def start_with_pi_followed_by_20_and_add_my_in_the_start(patent_number):
    if re.fullmatch(r"PI20\d{6}", patent_number):
        return "MY" + patent_number
    return patent_number


def start_with_pi_followed_by_9_and_add_my_in_the_start(patent_number):
    if re.fullmatch(r"PI9\d{6}", patent_number):
        return "MY" + patent_number
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            ("cnInsertCcTruncateEnd", [cn_insert_cc_truncate_end]),
            ("usInsertCc", [us_insert_cc]),
            ("usInsertCcYearTakeLastSixNumbers", [us_insert_cc_year_take_last_six_numbers]),
            ("pctRemovePctAddWo", [pct_remove_pct_add_wo]),
            ("pctRemovePct", [pct_remove_pct]),
            ("pctRemovePctAddW", [pct_remove_pct_add_w]),
            ("usInsertUSBeforeNumericPublicationNumber", [us_insert_us_before_numeric_publication_number]),
            ("usInsert20AfterCc", [us_insert_20_after_cc]),
            (
                "cnApplicationNumberStartsWithZLToNormalizedApplicationNumber , dropLastLettersBasedOnNumLength",
                [
                    cn_application_number_starts_with_zl_to_normalized_application_number,
                    drop_last_letters_based_on_num_length,
                ],
            ),
            ("woReplaceZeroWithLetterO", [wo_replace_zero_with_letter_o]),
            ("piAddBrDeleteLastChar", [pi_add_br_delete_last_char]),
            ("deletePCTAddWAtEnd", [delete_pct_add_w_at_end]),
            ("addEPCcForBareNumberPatents", [add_ep_cc_for_bare_number_patents]),
            ("addUSCcForBareNumberPatents", [add_us_cc_for_bare_number_patents]),
            ("removeEPLastLetter", [remove_ep_last_letter]),
            ("removeEPLastLetterAddZero", [remove_ep_last_letter_add_zero]),
            ("pctUSRemovePctExpandYear", [pct_us_remove_pct_expand_year]),
            ("startWithPIfolowedBy20AndAddMYInTheStart", [start_with_pi_followed_by_20_and_add_my_in_the_start]),
            ("startWithPIfolowedBy9AndAddMYInTheStart", [start_with_pi_followed_by_9_and_add_my_in_the_start]),
        ]
    )

    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
