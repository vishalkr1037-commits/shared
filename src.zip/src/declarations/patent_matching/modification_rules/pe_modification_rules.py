import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]

pe_substitute_year_and_four_digits_pattern = re.compile(r"PE(\d{4})(\d{4})A1")
pe_use_first_last_six_chars_pattern = re.compile(r"PE(\d{4})0(\d{6})")


def pe_substitute_year_and_four_digits(patent_number: str) -> str:
    """
    Substitute the year and four digits in a PE patent number if it matches the pattern.

    :param patent_number: The patent number.
    :param pe_substitute_year_and_four_digits_pattern: The regex pattern to match the PE patent format.
    :return: Modified patent number.
    """
    match = pe_substitute_year_and_four_digits_pattern.match(patent_number)
    if match:
        first_num_set = match.group(1)
        year = match.group(2)
        return f"PE{year}{first_num_set}A1"
    return patent_number


def pe_use_first_last_six_chars(patent_number: str) -> str:
    """
    Use the first year and last six characters in a PE patent number if it matches the pattern.

    :param patent_number: The patent number.
    :param pe_use_first_last_six_chars_pattern: The regex pattern to match the PE patent format.
    :return: Modified patent number.
    """
    match = pe_use_first_last_six_chars_pattern.match(patent_number)
    if match:
        year = match.group(1)
        last_num_set = match.group(2)
        return f"PE{year}{last_num_set}A"
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    """
    Get the list of publication number modification rules.

    :return: A list of rules for modifying publication numbers.
    """
    rules: List[Rule] = []

    # Add a default "none" rule
    rules.append(("none", []))

    # Add primary modification rules
    rules.extend(primary.get_primary_modification_rules())

    # Add specific PE patent modification rule
    rules.append(
        (
            "peSubstituteYearAndFourDigits",
            [pe_substitute_year_and_four_digits],
        )
    )

    # Add secondary modification rules
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    """
    Get the list of application number modification rules.

    :return: A list of rules for modifying application numbers.
    """
    rules: List[Rule] = []

    # Add a default "none" rule
    rules.append(("none", []))

    # Add primary modification rules
    rules.extend(primary.get_primary_modification_rules())

    # Add specific PE application modification rule
    rules.append(
        (
            "peUseFirstLastSixChars",
            [pe_use_first_last_six_chars],
        )
    )

    # Add secondary modification rules
    rules.extend(secondary.get_secondary_modification_rules())

    return rules
