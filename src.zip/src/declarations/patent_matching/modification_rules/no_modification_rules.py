from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def no_drop_zero_from_middle(patent_number: str) -> str:
    """
    Drop the zero from the middle of a Norwegian patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        len(patent_number) == 13
        and patent_number.startswith("NO")
        and helper.has_cc_year(patent_number)
        and int(patent_number[2:6]) <= 1999
        and patent_number[6:9] == "000"
        and patent_number[9:13].isdigit()
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[9:13]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "noDropZeroFromMiddle",
                [no_drop_zero_from_middle],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
