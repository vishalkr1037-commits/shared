from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def pl_drop_year_drop_zeroes(patent_number: str) -> str:
    """
    Drop the year and leading zeroes from a PL patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if len(patent_number) >= 7 and patent_number.startswith("PL") and helper.has_cc_year(patent_number):
        return patent_number[:2] + patent_number[7:].lstrip("0")
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    """
    Get the list of publication number modification rules.

    :return: A list of rules for modifying publication numbers.
    """
    rules: List[Rule] = []

    # Add a default "none" rule
    rules.append(("none", []))

    # Add primary modification rules
    rules.extend(primary.get_primary_modification_rules())

    # Add specific PL patent modification rule
    rules.append(
        (
            "plDropYearDropZeroes",
            [pl_drop_year_drop_zeroes],
        )
    )

    # Add secondary modification rules
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    """
    Get the list of application number modification rules.

    :return: A list of rules for modifying application numbers.
    """
    return get_publication_number_modification_rules()
