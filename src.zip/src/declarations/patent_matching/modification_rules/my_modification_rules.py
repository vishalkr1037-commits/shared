import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def my_expand_short_year_move_letters_pi_drop_zeroes(patent_number):
    if (
        len(patent_number) >= 6
        and patent_number.startswith("MY")
        and patent_number[2:4] == "PI"
        and patent_number[4:6] in helper.short_years
    ):
        return patent_number[:2] + helper.short_years[patent_number[4:6]] + "PI" + patent_number[6:].lstrip("0")
    return patent_number


def my_year_letters_pi_drop_zero(patent_number):
    if (
        len(patent_number) >= 9
        and patent_number.startswith("MY")
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] == "PI"
        and patent_number[8] == "0"
    ):
        return patent_number[:8] + patent_number[9:]
    return patent_number


def my_year_drop_last_letter_a(patent_number, p_my_pattern=re.compile(r".*")):
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if not non_alpha_num_form:  # Handle empty input
        return patent_number
    if p_my_pattern.match(non_alpha_num_form) and non_alpha_num_form[-1].isalpha():
        return non_alpha_num_form[:-1]
    return patent_number


def my_year_move_pi_drop_zero(patent_number):
    if (
        len(patent_number) == 13
        and patent_number.startswith("MY")
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] == "PI"
        and patent_number[8] == "0"
    ):
        return patent_number[:2] + "PI" + patent_number[2:6] + patent_number[9:]
    return patent_number


def my_year_move_pi_add_zero(patent_number):
    if (
        len(patent_number) == 13
        and patent_number.startswith("MY")
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] == "PI"
    ):
        return patent_number[:2] + "PI" + patent_number[2:6] + "0" + patent_number[8:]
    return patent_number


def my_year_move_pi_if_greater_than_1999(patent_number):
    if (
        len(patent_number) == 14
        and patent_number.startswith("MY")
        and helper.has_cc_year(patent_number)
        and int(patent_number[2:6]) > 1999
        and patent_number[6:8] == "PI"
        and re.match(r"\d{6}", patent_number[8:14])
    ):
        return patent_number[:2] + "PI" + patent_number[2:6] + patent_number[8:14]
    return patent_number


def my_add_pi_after_pi(patent_number):
    if patent_number.startswith("MY") and helper.has_cc_year(patent_number) and int(patent_number[2:6]) >= 2010:
        return patent_number[:2] + "PI" + patent_number[2:]
    return patent_number


def my_add_pi_after_pi_and_delete_zero(patent_number):
    if patent_number.startswith("MY") and helper.has_cc_year(patent_number) and int(patent_number[2:6]) <= 2010:
        return patent_number[:2] + "PI" + patent_number[2:6] + patent_number[8:]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []
    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())
    rules.extend(
        [
            (
                "myExpandShortYearMoveLettersPIDropZeroes",
                [my_expand_short_year_move_letters_pi_drop_zeroes],
            ),
            (
                "myYearLettersPIDropZero",
                [my_year_letters_pi_drop_zero],
            ),
            (
                "myYearDropLastLetterA",
                [my_year_drop_last_letter_a],
            ),
            (
                "myYearMovePIDropZero",
                [my_year_move_pi_drop_zero],
            ),
            (
                "myYearMovePIAddZero",
                [my_year_move_pi_add_zero],
            ),
            (
                "myYearMovePIIfGreaterThan1999",
                [my_year_move_pi_if_greater_than_1999],
            ),
            (
                "myAddPIAfterPI",
                [my_add_pi_after_pi],
            ),
            (
                "myAddPIAfterPIAndDeleteZero",
                [my_add_pi_after_pi_and_delete_zero],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())
    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
