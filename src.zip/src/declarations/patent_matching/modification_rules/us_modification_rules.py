import re
from datetime import datetime
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary
from src.declarations.patent_matching.modification_rules.modification_rules_helper import (
    category_special,
    has_cc_year,
    is_not_provisional_patent_number,
    series_code_to_year,
)

Rule = Tuple[str, List[Callable[[str], str]]]

begin = "1980"
end = str(datetime.now().year)


def us_insert_year_take_last_six_numbers(patent_number):
    """
    Inserts a year range and takes the last six numbers of the US patent number.

    Args:
        patent_number (str): The patent number to modify.
        begin (str): The beginning year of the range.
        end (str): The ending year of the range.

    Returns:
        str: The modified patent number or the original if no modification is applicable.
    """
    if re.fullmatch(r"US1\d+", patent_number) and len(patent_number) >= 8:
        patent_number = patent_number.replace("US", "")
        return f"/US<{begin}-{end}>{patent_number[-6:]}/"
    return patent_number


def us_insert_short_year_to_application_number(application_number):
    if re.fullmatch(r"US\d{8}", application_number) and is_not_provisional_patent_number(application_number):
        converted_numbers = convert_us_an_from_cleaned_original_to_short_epo(application_number)
        return "/" + "|".join(f"US{num}A" for num in converted_numbers) + "/"
    return application_number


def convert_us_an_from_cleaned_original_to_short_epo(cleaned_original_an):
    result = []

    if re.fullmatch(r"US\d{8}", cleaned_original_an):
        series_code = cleaned_original_an[2:4]
        serial_number = cleaned_original_an[4:]

        for year in series_code_to_year(series_code):
            short_year = year[2:4]
            result.append(f"{serial_number}{short_year}")

    return result


def us_insert_long_year_to_application_number(application_number):
    if re.fullmatch(r"US\d{8}", application_number):
        converted_numbers = convert_us_an_from_cleaned_original_to_long_epo(application_number)
        return "/" + "|".join(f"US{num}A" for num in converted_numbers) + "/"
    return application_number


def convert_us_an_from_cleaned_original_to_long_epo(cleaned_original_an):
    result = []

    if re.fullmatch(r"US\d{8}", cleaned_original_an):
        series_code = cleaned_original_an[2:4]
        serial_number = cleaned_original_an[4:]

        for long_year in series_code_to_year(series_code):
            result.append(f"{long_year}{series_code}{serial_number}")

    return result


def us_insert_re_publication_number(patent_number):
    match = re.fullmatch(r"US(\d{5})$", patent_number)
    if match:
        return f"USRE{match.group(1)}"
    return patent_number


def add_e_kind_code_in_usre_publication_numbers(patent_number):
    """
    Adds "E" kind code to USRE publication numbers.

    Args:
        patent_number (str): The patent number to modify.

    Returns:
        str: The modified patent number or the original if no modification is applicable.
    """
    if patent_number.startswith("USRE"):
        return f"{patent_number.strip()}E"
    return patent_number


def replace_us_country_code_with_in(patent_number):
    if 14 <= len(patent_number) <= 16 and patent_number.startswith("US") and category_special(patent_number):
        return re.sub(r"^US", "IN", patent_number, count=1)
    return patent_number


def us_remove_zeroes_add_short_year_end(patent_number):
    """
    Removes zeroes and adds a short year at the end of US patent numbers.

    Args:
        patent_number (str): The patent number to modify.
        has_cc_year (Callable): A function to check if the patent number has a valid year.

    Returns:
        str: The modified patent number or the original if no modification is applicable.
    """
    if (
        len(patent_number) == 13
        and patent_number.startswith("US")
        and has_cc_year(patent_number)
        and patent_number[6] == "0"
    ):
        return f"{patent_number[:2]}{patent_number[7:].lstrip('0')}{patent_number[4:6]}"
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    """
    Returns the list of US-specific modification rules.

    Returns:
        List[Rule]: A list of tuples containing rule names and their corresponding functions.
    """
    rules: List[Rule] = []
    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())
    rules.extend(
        [
            ("usInsertYearTakeLastSixNumbers", [us_insert_year_take_last_six_numbers]),
            ("usInsertShortYearToApplicationNumber", [us_insert_short_year_to_application_number]),
            ("usInsertLongYearToApplicationNumber", [us_insert_long_year_to_application_number]),
            ("usInsertREPublicationNumber", [us_insert_re_publication_number]),
            (
                "usInsertREPublicationNumber, addEKindCodeInUSREPublicationNumbers",
                [us_insert_re_publication_number, add_e_kind_code_in_usre_publication_numbers],
            ),
            ("replaceUSCountryCodeWithIN", [replace_us_country_code_with_in]),
            ("usRemoveZeroesAddShortYearEnd", [us_remove_zeroes_add_short_year_end]),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())
    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
