import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]

p_jp_pattern = re.compile(r"JP(\d{7,8})\w?")
p_jp_pattern2 = re.compile(r"JP(\d{8})\w$")
jp_patent_pattern = re.compile(r"^JP(\d{4})0(\d{6})$")


def jp_add_japanese_era_name(patent_number):
    match = p_jp_pattern.fullmatch(patent_number)
    if match:
        p_number = match.group(1)
        if len(p_number) == 7:
            return "JPH0" + p_number
        else:
            return "JPH" + p_number
    return patent_number


def jp_working_number_ending_with_t(patent_number):
    if patent_number.startswith("JP") and patent_number.endswith("T") and len(patent_number) == 13:
        return patent_number[:-1] + "A"
    else:
        return patent_number


def jp_remove_extra_chars_after_po(patent_number):
    match = p_jp_pattern2.fullmatch(patent_number)
    if match:
        p_number = match.group(1)
        if len(p_number) == 8:
            return "JPH" + p_number + "A"
    return patent_number


def category_special(patent_number):
    return any(keyword in patent_number for keyword in helper.instates)


def reformat_jp_with_in(patent_number):
    if 14 <= len(patent_number) <= 16 and patent_number.startswith("JP") and category_special(patent_number):
        return patent_number.replace("JP", "IN", 1)
    else:
        return patent_number


def remove_extra_zero_after_year_jp(patent_number):
    match = jp_patent_pattern.fullmatch(patent_number)
    if match:
        return "JP" + match.group(1) + match.group(2)
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            ("jpAddJapaneseEraName", [jp_add_japanese_era_name]),
            ("jpWorkingNumberEndingWithT", [jp_working_number_ending_with_t]),
            ("jpRemoveExtraCharsAfterPO", [jp_remove_extra_chars_after_po]),
            ("reformatJPWithIN", [reformat_jp_with_in]),
            ("removeExtraZeroAfterYearJP", [remove_extra_zero_after_year_jp]),
        ]
    )

    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
