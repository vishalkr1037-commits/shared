import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper

pCcGeneric = re.compile(r"\w\w(\d+)\w?")


def cc_insert_zero(patent_number):
    if len(patent_number) >= 2:
        return patent_number[:2] + "0" + patent_number[2:]
    else:
        return patent_number


def cc_drop_zeroes(patent_number):
    if len(patent_number) >= 3 and patent_number[2] == "0":
        return patent_number[:2] + re.sub(r"^0+", "", patent_number[2:])
    else:
        return patent_number


def cc_year_insert_zero(patent_number):
    if helper.has_cc_year(patent_number):
        return patent_number[:6] + "0" + patent_number[6:]
    else:
        return patent_number


def cc_short_year_expand(patent_number: str):
    if len(patent_number) >= 4 and not patent_number.startswith("JP"):
        short_year = patent_number[2:4]
        if short_year in helper.short_years:
            return patent_number[:2] + helper.short_years[short_year] + patent_number[4:]
    return patent_number


def cc_year_drop_zeroes(patent_number):
    if len(patent_number) >= 7 and helper.has_cc_year(patent_number) and patent_number[6] == "0":
        return patent_number[:6] + patent_number[6:].lstrip("0")
    else:
        return patent_number


def cc_short_expanded_year(patent_number):
    if helper.has_cc_year(patent_number) and len(patent_number) > 6 and pCcGeneric.fullmatch(patent_number):
        if patent_number[6] == "0":
            m = pCcGeneric.fullmatch(patent_number)
            if m:
                local_country = patent_number[:2]
                p_number = m.group(1)
                if len(p_number) >= 6:
                    return local_country + p_number[5:] + p_number[2:4]
        return patent_number
    else:
        return patent_number


Rule = Tuple[str, List[Callable[[str], str]]]


def get_primary_modification_rules() -> List[Rule]:
    return [
        ("ccInsertZero", [cc_insert_zero]),
        ("ccDropZeroes", [cc_drop_zeroes]),
        ("ccYearInsertZero", [cc_year_insert_zero]),
        ("ccYearDropZeroes", [cc_year_drop_zeroes]),
        ("ccShortYearExpand", [cc_short_year_expand]),
        (
            "ccShortYearExpand, ccYearInsertZero",
            [cc_short_year_expand, cc_year_insert_zero],
        ),
        (
            "ccShortYearExpand, ccYearDropZeroes",
            [cc_short_year_expand, cc_year_drop_zeroes],
        ),
        ("ccShortExpandedYear", [cc_short_expanded_year]),
    ]
