import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

cn_12_character_patent_pattern = re.compile(r"^CN(\d{4})([18])(\d{5})$")
cn_patent_pattern = re.compile(r"^CN(\d{4})11(\d{5})$")
cn_13_character_old_patent_pattern = re.compile(r"^CN(\d{4})([18])0(\d{5})$")


Rule = Tuple[str, List[Callable[[str], str]]]


def _cn_year_single_wildcard_fill_two_zeroes(patent_number):
    """
    Insert up to two zeroes into a chinese patent number

    :param patent_number: The patent number
    :return: If [CC] is "CN" + [YEAR] + [?] fill the rest of the number with '0' from the left (maximum: 2). Else, return the original
    :return: If [CC] is "CN" + [YEAR] + [?] fill the rest of the number with '0' from the left (maximum: 2). Else, return the original
    number.
    """
    if len(patent_number) >= 7 and patent_number.startswith("CN") and helper.has_cc_year(patent_number):
        if len(patent_number) == 12 and helper.get_year(patent_number) >= 2003:
            zeroes_to_insert = max(0, 2)
            return patent_number[:7] + "0" * zeroes_to_insert + patent_number[7:]
        else:
            existing_zeroes = len(patent_number[7:]) - len(patent_number[7:].lstrip("0"))
            zeroes_to_insert = max(0, 2 - existing_zeroes)
            return patent_number[:7] + "0" * zeroes_to_insert + patent_number[7:]
    else:
        return patent_number


def _cn_application_number_starts_with_zl_to_normalized_application_number(patent_number):
    """
    Convert a Chinese patent application number starting with "ZL" to a normalized application number starting with "CN"

    :param patent_number: The patent number
    :return: The normalized patent number if it starts with "ZL", otherwise the original patent number
    """
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("ZL"):
        return non_alpha_num_form.replace("ZL", "CN").strip()
    else:
        return patent_number


def _drop_last_letters_based_on_num_length(patent_number):
    """
    Drop the last letters of a Chinese patent number based on its length

    :param patent_number: The patent number
    :return: The modified patent number based on the specified rules
    """
    if patent_number is not None:
        non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
        if non_alpha_num_form.startswith("CN") and len(non_alpha_num_form[2:]) == 12:
            return non_alpha_num_form
        elif non_alpha_num_form.startswith("CN") and len(non_alpha_num_form[2:]) == 13:
            return non_alpha_num_form[:-1]
        elif (
            non_alpha_num_form.startswith("CN")
            and len(non_alpha_num_form[2:]) == 9
            and non_alpha_num_form[2:4] in helper.short_years
        ):
            return non_alpha_num_form[:-1]
        else:
            return patent_number
    else:
        return None


def _cn_remove_first_digits_year_and_8th_zero_digit(patent_number):
    """
    CN (length = 13) - remove the first two digits of a year (years before and 2003) and 8th (6th digit) character

    :param patent_number: The patent number
    :return: If [CC] is "CN" + [YEAR] + [?], remove first two digits of year and remove 8th digit if zero. Else, return the original
    number.
    """
    if (
        len(patent_number) == 13
        and patent_number.startswith("CN")
        and helper.has_cc_year(patent_number)
        and patent_number[7] == "0"
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[6:7] + patent_number[8:]
    else:
        return patent_number


def _cn_add_zeros_after_seventh_character(patent_number):
    """
    Add two zeros after the seventh character of a CN patent number if it matches the 12-character pattern

    :param patent_number: The patent number
    :return: The modified patent number with two zeros added after the seventh character if it matches the pattern, otherwise the original patent number
    """
    if cn_12_character_patent_pattern.fullmatch(patent_number):
        m = cn_12_character_patent_pattern.fullmatch(patent_number)
        return "CN" + m.group(1) + m.group(2) + "00" + m.group(3) + "A"
    else:
        return patent_number


def _cn_application_number_to_wo_application_number(patent_number):
    """
    Transforms CN Application Number to WO Application Number
    CN20170101962A -> WO2017CN0101962A

    :param patent_number: The patent number
    :return: If [CC] is year & has year then returns WO + Year + CN + number, else returns original number.
    """
    if patent_number.startswith("CN") and helper.has_cc_year(patent_number):
        cc = patent_number[:2]
        year = patent_number[2:6]
        number = patent_number[6:]

        return "WO" + year + cc + number
    else:
        return patent_number


def _cn_application_number_to_wo_application_number_without_zero(patent_number):
    """
    Transforms CN Application Number to WO Application Number and removes zero if number starts with it
    CN20170101962A -> WO2017CN101962A

    :param patent_number: The patent number
    :return: If [CC] is year & has year & hasZeroBetween [CC] - number, returns WO + Year + CN + number(without zero), else returns original number.
    """
    if patent_number.startswith("CN") and helper.has_cc_year(patent_number) and patent_number[6] == "0":
        cc = patent_number[:2]
        year = patent_number[2:6]
        number = patent_number[7:]

        return "WO" + year + cc + number
    else:
        return patent_number


def _cn_application_number_contains_zl_to_normalized_application_number(patent_number):
    """
    Transforms CN Application Number that contains ZL and .number to CN Application Number common format without ZL and .number
    CNZL200880121914.6 -> CN200880121914

    :param patent_number: The patent number
    :return: If contains ZL and dot number or ZL then it removes them and returns the resulted String,
    if none of these cases then returns the same patent number
    """
    if not patent_number:
        return ""

    if patent_number.startswith("CNZL") and "." in patent_number:
        return patent_number.rsplit(".", 1)[0].replace("ZL", "").strip()
    elif patent_number.startswith("CNZL") and "." not in patent_number:
        return patent_number.replace("ZL", "").strip()
    else:
        return patent_number


def _drop_last_letter(patent_number):
    """
    Remove the last character from the patent number if it starts with "BR" or "CN"

    :param patent_number: The patent number
    :return: The patent number with the last character removed if it starts with "BR" or "CN", otherwise the original patent number
    """
    if patent_number.startswith("BR") or patent_number.startswith("CN"):
        return patent_number[:-1]
    else:
        return patent_number


def _cn_drop_last_letter(patent_number):
    """
    CN numbers with length of 15:
    Delete the last number and you got the application number

    :param patent_number: The patent number
    :return: The patent number with the last character removed if it starts with "CN" and has a length of 15, otherwise the original patent number
    """
    if patent_number.startswith("CN") and len(patent_number) == 15:
        return patent_number[:-1]
    else:
        return patent_number


def _cn_application_number_with_thirteen_characters_rule(patent_number):
    """
    CN (length = 13) CN {4digits} 11 {5digits} - Add '0' after 11 and add 'A' at the end

    :param patent_number: The patent number
    :return: if [CC] is "CN" + 4digits + 11 + 5digits, add 0 after 11 and A at the end
    """
    if cn_patent_pattern.fullmatch(patent_number):
        m = cn_patent_pattern.fullmatch(patent_number)
        return "CN" + m.group(1) + "11" + "0" + m.group(2) + "A"
    else:
        return patent_number


def _cn_application_number_with_thirteen_characters_old_patents_rule(patent_number):
    """
    CN (length = 13) - For old patents, transform the number based on the year

    :param patent_number: The patent number
    :return: If the year is less than or equal to 2003, transform the number to the new format, else return the original number
    """
    if cn_13_character_old_patent_pattern.fullmatch(patent_number):
        m = cn_13_character_old_patent_pattern.fullmatch(patent_number)
        year = int(m.group(1))
        short_year = m.group(1)[-2:]

        if year <= 2003:
            return "CN" + short_year + m.group(2) + m.group(3) + "A"
        else:
            return patent_number
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "cnYearSingleWildcardFillTwoZeroes",
                [_cn_year_single_wildcard_fill_two_zeroes],
            ),
            (
                "cnApplicationNumberStartsWithZLToNormalizedApplicationNumber, dropLastLettersBasedOnNumLength",
                [
                    _cn_application_number_starts_with_zl_to_normalized_application_number,
                    _drop_last_letters_based_on_num_length,
                ],
            ),
            (
                "cnRemoveFirstDigitsYearAnd8thZeroDigit",
                [_cn_remove_first_digits_year_and_8th_zero_digit],
            ),
            (
                "cnAddZerosAfterSeventhCharacter",
                [_cn_add_zeros_after_seventh_character],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))

    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "cnYearSingleWildcardFillTwoZeroes",
                [_cn_year_single_wildcard_fill_two_zeroes],
            ),
            (
                "cnApplicationNumberToWOApplicationNumber",
                [_cn_application_number_to_wo_application_number],
            ),
            (
                "cnApplicationNumberToWOApplicationNumberWithoutZero",
                [_cn_application_number_to_wo_application_number_without_zero],
            ),
            (
                "cnApplicationNumberContainsZLToNormalizedApplicationNumber",
                [_cn_application_number_contains_zl_to_normalized_application_number],
            ),
            (
                "cnApplicationNumberContainsZLToNormalizedApplicationNumber , dropLastLetter",
                [
                    _cn_application_number_contains_zl_to_normalized_application_number,
                    _drop_last_letter,
                ],
            ),
            (
                "cnDropLastLetter",
                [_cn_drop_last_letter],
            ),
            (
                "cnRemoveFirstDigitsYearAnd8thZeroDigit",
                [_cn_remove_first_digits_year_and_8th_zero_digit],
            ),
            (
                "cnApplicationNumberWithThirteenCharactersRule",
                [_cn_application_number_with_thirteen_characters_rule],
            ),
            (
                "cnApplicationNumberWithThirteenCharactersOldPatentsRule",
                [_cn_application_number_with_thirteen_characters_old_patents_rule],
            ),
        ]
    )

    rules.extend(secondary.get_secondary_modification_rules())

    return rules
