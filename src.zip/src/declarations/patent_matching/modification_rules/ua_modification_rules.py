import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary
from src.declarations.patent_matching.modification_rules.modification_rules_helper import (
    get_year,
)

Rule = Tuple[str, List[Callable[[str], str]]]


def ua_remove_zeros_and_put_a_to_end(patent_number):
    """
    Modifies UA patent numbers by removing zeros and appending 'A' to the end if the year is >= 2005.

    Args:
        patent_number (str): The patent number to modify.

    Returns:
        str: The modified patent number or the original if no modification is applicable.
    """
    ua_pattern = re.compile(r"UA(\d{4})00(\d{5})")  # Updated pattern to match "UA<year>00<5-digit number>"
    match = ua_pattern.match(patent_number)

    if match:
        year = get_year(f"UA{match.group(1)}")
        if year >= 2005:
            last_num_set = match.group(2)
            return f"UAA{year}{last_num_set}A"

    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []
    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())
    rules.extend(
        [
            (
                "uaRemoveZerosAndPutAToEnd",
                [ua_remove_zeros_and_put_a_to_end],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())
    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
