from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def hr_with_p_reformat(patent_number):
    if (
        patent_number.startswith("HR")
        and len(patent_number) == 14
        and patent_number[6] == "P"
        and patent_number.endswith("T")
    ):
        return patent_number[:2] + patent_number[6] + patent_number[2:6] + patent_number[9:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "hrWithPReformat",
                [hr_with_p_reformat],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
