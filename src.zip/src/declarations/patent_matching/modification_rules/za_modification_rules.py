from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def drop_za_zero_after_year(patent_number: str) -> str:
    """
    Drop a single zero after the year in a South African patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("ZA") and helper.has_cc_year(patent_number) and len(patent_number) == 12:
        return patent_number[:6] + patent_number[7:]
    else:
        return patent_number


def drop_za_two_zero_after_year(patent_number: str) -> str:
    """
    Drop two zeros after the year in a South African patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        patent_number.startswith("ZA")
        and helper.has_cc_year(patent_number)
        and helper.get_year(patent_number) >= 2000
        and patent_number[6:8] == "00"
        and len(patent_number) == 13
    ):
        return patent_number[:6] + patent_number[8:]
    else:
        return patent_number


def drop_za_all_zero_after_year(patent_number: str) -> str:
    """
    Drop all zeros after the year in a South African patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        patent_number.startswith("ZA")
        and helper.has_cc_year(patent_number)
        and helper.get_year(patent_number) >= 1980
        and patent_number[6:10].startswith("0")
        and len(patent_number) == 13
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[7:].lstrip("0")
    else:
        return patent_number


def start_za_check_digit_ends_with_a(patent_number: str) -> str:
    """
    Modify the South African patent number to end with 'A' if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        len(patent_number) == 10
        and patent_number.startswith("ZA")
        and patent_number[2:9].isdigit()
        and patent_number.endswith("A")
    ):
        if patent_number[4:6] == "00":
            return patent_number[:4] + patent_number[6:10]
        elif patent_number[4:5] == "0":
            return patent_number[:4] + patent_number[5:10]
    return patent_number


def start_za_check_digit_ends_with_b(patent_number: str) -> str:
    """
    Modify the South African patent number to end with 'B' if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        len(patent_number) == 10
        and patent_number.startswith("ZA")
        and patent_number[2:9].isdigit()
        and patent_number.endswith("B")
    ):
        if patent_number[4:6] == "00":
            return patent_number[:4] + patent_number[6:10]
        elif patent_number[4:5] == "0":
            return patent_number[:4] + patent_number[5:10]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:

    rules: List[Rule] = []

    # Add a rule for no modification
    rules.append(("none", []))

    # Add primary modification rules
    rules.extend(primary.get_primary_modification_rules())

    # Add South African-specific rules
    rules.extend(
        [
            ("dropZAZeroAfterYear", [drop_za_zero_after_year]),
            ("dropZATwoZeroAfterYear", [drop_za_two_zero_after_year]),
            ("dropZAAllZeroAfterYear", [drop_za_all_zero_after_year]),
            ("startZACheckDigitEndsWithA", [start_za_check_digit_ends_with_a]),
            ("startZACheckDigitEndsWithB", [start_za_check_digit_ends_with_b]),
        ]
    )

    # Add secondary modification rules
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
