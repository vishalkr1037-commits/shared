from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def drop_sm_third_char(patent_number: str) -> str:
    """
    Drop the third character from an SM patent number if it meets the conditions.

    :param patent_number: The patent number.
    :param years: A set of valid years.
    :return: Modified patent number.
    """
    if (
        patent_number.startswith("SM")
        and len(patent_number) >= 7
        and patent_number[:3].isalpha()
        and patent_number[3:7] in helper.years
    ):
        return "SM" + patent_number[3:7] + "0" + patent_number[7:]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    """
    Get the list of publication number modification rules.

    :return: A list of rules for modifying publication numbers.
    """
    rules: List[Rule] = []

    # Add a default "none" rule
    rules.append(("none", []))

    # Add primary modification rules
    rules.extend(primary.get_primary_modification_rules())

    # Add specific SM patent modification rule
    rules.append(
        (
            "dropSMThirdChar",
            [drop_sm_third_char],
        )
    )

    # Add secondary modification rules
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
