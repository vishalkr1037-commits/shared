import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def ca_drop_yr_and_zero(patent_number):
    if helper.has_cc_year(patent_number) and (match := re.match(r"CA19.{2}0(\d{6,})", patent_number)):
        return "CA" + match.group(1)
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "ca_drop_yr_and_zero",
                [ca_drop_yr_and_zero],
            )
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
