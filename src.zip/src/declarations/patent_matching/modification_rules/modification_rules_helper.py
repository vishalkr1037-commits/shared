import re
from datetime import datetime, timezone

country_codes = {"WO", "EP", "IB", "EA"} | {
    "AE",
    "AF",
    "AG",
    "AI",
    "AL",
    "AM",
    "AN",
    "AO",
    "AQ",
    "AR",
    "AS",
    "AT",
    "AU",
    "AW",
    "AX",
    "AZ",
    "BA",
    "BB",
    "BD",
    "BE",
    "BF",
    "BG",
    "BH",
    "BI",
    "BJ",
    "BL",
    "BM",
    "BN",
    "BO",
    "BQ",
    "BR",
    "BS",
    "BT",
    "BV",
    "BW",
    "BY",
    "BZ",
    "CA",
    "CC",
    "CD",
    "CF",
    "CG",
    "CH",
    "CI",
    "CK",
    "CL",
    "CM",
    "CN",
    "CO",
    "CR",
    "CS",
    "CU",
    "CV",
    "CW",
    "CX",
    "CY",
    "CZ",
    "DE",
    "DJ",
    "DK",
    "DM",
    "DO",
    "DZ",
    "EC",
    "EE",
    "EG",
    "EH",
    "ER",
    "ES",
    "ET",
    "FI",
    "FJ",
    "FK",
    "FM",
    "FO",
    "FR",
    "GA",
    "GB",
    "GD",
    "GE",
    "GF",
    "GG",
    "GH",
    "GI",
    "GL",
    "GM",
    "GN",
    "GP",
    "GQ",
    "GR",
    "GS",
    "GT",
    "GU",
    "GW",
    "GY",
    "HK",
    "HM",
    "HN",
    "HR",
    "HT",
    "HU",
    "ID",
    "IE",
    "IL",
    "IM",
    "IN",
    "IO",
    "IQ",
    "IR",
    "IS",
    "IT",
    "JE",
    "JM",
    "JO",
    "JP",
    "KE",
    "KG",
    "KH",
    "KI",
    "KM",
    "KN",
    "KP",
    "KR",
    "KW",
    "KY",
    "KZ",
    "LA",
    "LB",
    "LC",
    "LI",
    "LK",
    "LR",
    "LS",
    "LT",
    "LU",
    "LV",
    "LY",
    "MA",
    "MC",
    "MD",
    "ME",
    "MF",
    "MG",
    "MH",
    "MK",
    "ML",
    "MM",
    "MN",
    "MO",
    "MP",
    "MQ",
    "MR",
    "MS",
    "MT",
    "MU",
    "MV",
    "MW",
    "MX",
    "MY",
    "MZ",
    "NA",
    "NC",
    "NE",
    "NF",
    "NG",
    "NI",
    "NL",
    "NO",
    "NP",
    "NR",
    "NU",
    "NZ",
    "OM",
    "PA",
    "PE",
    "PF",
    "PG",
    "PH",
    "PK",
    "PL",
    "PM",
    "PN",
    "PR",
    "PS",
    "PT",
    "PW",
    "PY",
    "QA",
    "RE",
    "RO",
    "RS",
    "RU",
    "RW",
    "SA",
    "SB",
    "SC",
    "SD",
    "SE",
    "SG",
    "SH",
    "SI",
    "SJ",
    "SK",
    "SL",
    "SM",
    "SN",
    "SO",
    "SR",
    "SS",
    "ST",
    "SV",
    "SX",
    "SY",
    "SZ",
    "TC",
    "TD",
    "TF",
    "TG",
    "TH",
    "TJ",
    "TK",
    "TL",
    "TM",
    "TN",
    "TO",
    "TR",
    "TT",
    "TV",
    "TW",
    "TZ",
    "UA",
    "UG",
    "UM",
    "US",
    "UY",
    "UZ",
    "VA",
    "VC",
    "VE",
    "VG",
    "VI",
    "VN",
    "VU",
    "WF",
    "WS",
    "YE",
    "YT",
    "ZA",
    "ZM",
    "ZW",
}

ep_country_codes = {
    "AL",
    "AT",
    "BE",
    "BG",
    "CH",
    "CY",
    "CZ",
    "DE",
    "DK",
    "EE",
    "ES",
    "FI",
    "FR",
    "GB",
    "GR",
    "HR",
    "HU",
    "IE",
    "IS",
    "IT",
    "LI",
    "LT",
    "LU",
    "LV",
    "MC",
    "ME",
    "MK",
    "MT",
    "NL",
    "NO",
    "PL",
    "PT",
    "RO",
    "RS",
    "SE",
    "SI",
    "SK",
    "SM",
    "TR",
    "UK",
}


instates = {"DELNP", "MUMNP", "CHENP", "KOLNP"}
_IN_STATE_RE = re.compile("|".join(instates))
mapping = {"11": ["2003", "2004", "2005", "2006", "2007", "2008"], "12": ["2007", "2008", "2009", "2010", "2011"]}


special_case_kind_codes = {"UA", "VA", "QA"}
tw_patent_pattern = re.compile(r"^TW(\d{4})0(\d+)(U?)$")

p_non_alpha_num = re.compile(r"[^0-9A-Z]")
start = 1980
end = datetime.now(tz=timezone.utc).year
years = set(map(str, range(start, end + 1)))
short_years = {year[-2:]: year for year in years}


# Check if the patent number has a year following the country code
def has_cc_year(patent_number):
    """
    Check if the patent number has a year following the country code

    :param patent_number: The patent number
    :return: True, if the patent number has a year after the country code. False otherwise.
    """
    return len(patent_number) >= 6 and patent_number[:2] in country_codes and patent_number[2:6] in years


def get_year(patent_number):
    """
    Get the year from the patent number

    :param patent_number: The patent number
    :return: The year as an integer if present, otherwise 0.
    """
    if len(patent_number) >= 6 and patent_number[2:6] in years:
        return int(patent_number[2:6])
    else:
        return 0


def remove_non_alphanumeric_chars(name):
    """
    Removes all non-alphanumeric characters from the given string and converts it to uppercase.

    This function uses a predefined regex pattern (`p_non_alpha_num`) to remove any characters
    that are not letters or digits. The resulting string is then returned in uppercase.

    :param name: The input string from which non-alphanumeric characters will be removed.
    :return: A new string containing only alphanumeric characters, all in uppercase.
    """
    return p_non_alpha_num.sub("", name.upper())


def patent_contains_digits(patent_number):
    """
    Check if the patent number contains any digits

    :param patent_number: The patent number
    :return: True if the patent number contains any digits, False otherwise.
    """
    return any(c.isdigit() for c in patent_number)


def pct_reformat_original_number_add_wo(patent_number):
    """
    Replace "PCT/CCYYYY/nnnnnn" or "PCT/CCYY/nnnnn" with "WOYYYYCCnnnnn<n>"

    :param patent_number: The patent number
    :return: If the number starts with "PCT", reformat it. Else, return the original number.
    """
    if match := re.fullmatch(r"^PCT/(\w{2})(\d{4})/(\d{6})$", patent_number):
        country_code = match.group(1)
        year = match.group(2)
        number = match.group(3).lstrip("0")
        return "WO" + year + country_code + number

    if match := re.fullmatch(r"^PCT/(\w{2})(\d{2})/(\d{5})$", patent_number):
        short_year = match.group(2)
        if year := short_years.get(short_year):
            country_code = match.group(1)
            number = match.group(3).lstrip("0")
            return "WO" + year + country_code + number

    return patent_number


def category_special(patent_number: str) -> bool:
    return bool(_IN_STATE_RE.search(patent_number))


def series_code_to_year(series_code: str) -> list[str]:
    mapping = {
        "1": range(1915, 1935),
        "2": range(1935, 1948),
        "3": range(1948, 1960),
        "4": range(1960, 1970),
        "5": range(1970, 1979),
        "6": range(1979, 1987),
        "7": range(1987, 1993),
        "8": ["1993", "1994", "1995", "1996", "1997"],
        "9": ["1997", "1998", "1999", "2000", "2001"],
        "10": range(2000, 2006),
        "11": range(2003, 2009),
        "12": range(2007, 2012),
        "13": range(2010, 2016),
        "14": range(2013, 2018),
        "15": ["2015", "2016", "2017", "2018", "2019", "2020"],
        "16": ["2017", "2018", "2019", "2020", "2021", "2022", "2023"],
        "17": ["2020", "2021", "2022", "2023"],
        "29": range(2001, 2005),
        "60": range(1995, 2009),
        "61": range(2006, 2016),
        "62": range(2013, 2021),
        "63": ["2019", "2020", "2021", "2022", "2023"],
    }

    years = mapping.get(series_code)
    if years is None:
        return []
    return [str(y) for y in years]


def is_not_provisional_patent_number(application_number):
    """
    Check if the application number is not provisional.

    :param application_number: The application number
    :return: True if the application number is not provisional, False otherwise.
    """
    return not any(application_number.startswith(code) for code in ("US60", "US61", "US62", "US63"))
