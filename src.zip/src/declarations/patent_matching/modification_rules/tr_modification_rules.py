from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def tr_drop_zero_from_7th_and_8th_position(patent_number: str) -> str:
    """
    Drops zeros from the 7th and 8th positions of a TR patent number if the conditions are met.

    Args:
        patent_number (str): The patent number to modify.

    Returns:
        str: The modified patent number or the original if no modification is applicable.
    """
    if len(patent_number) == 14 and patent_number.startswith("TR") and patent_number[6:8] == "00":
        return patent_number[:6] + patent_number[8:]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    """
    Returns the list of publication number modification rules for TR.

    Returns:
        List[Rule]: A list of tuples containing rule names and their corresponding functions.
    """
    rules: List[Rule] = []
    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())
    rules.extend(
        [
            (
                "trDropZeroFrom7thAnd8thPosition",
                [tr_drop_zero_from_7th_and_8th_position],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())
    return rules


def get_application_number_modification_rules() -> List[Rule]:
    """
    Returns the list of application number modification rules for TR.

    Returns:
        List[Rule]: A list of tuples containing rule names and their corresponding functions.
    """
    return get_publication_number_modification_rules()
