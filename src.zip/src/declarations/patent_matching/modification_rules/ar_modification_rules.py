from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def ar_year_drop_letter_p(patent_number: str) -> str:
    """
    Remove the letter "P" after the country code and a year from an Argentinian patent number.

    :param patent_number: The patent number
    :return: If [CC] is "AR" + [YEAR] + "P", drop this "P". Else, return the original number.
    """
    if (
        len(patent_number) >= 7
        and patent_number.startswith("AR")
        and helper.has_cc_year(patent_number)
        and patent_number[6] == "P"
    ):
        return patent_number[:6] + patent_number[7:]
    else:
        return patent_number


def ar_year_add_letter_p_shorten_year(patent_number: str) -> str:
    """
    Add the letter "P" after the country code and shorten the year in an Argentinian patent number.

    :param patent_number: The patent number
    :return: Modified patent number
    """
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if len(non_alpha_num_form) == 13 and non_alpha_num_form.startswith("AR") and helper.has_cc_year(non_alpha_num_form):
        return "ARP" + non_alpha_num_form[4:6] + non_alpha_num_form[6:]
    else:
        return patent_number


def ar_year_move_letter_p_shorten_year(patent_number: str) -> str:
    """
    Move the letter "P" after the country code and shorten the year in an Argentinian patent number.

    :param patent_number: The patent number
    :return: Modified patent number
    """
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if (
        len(non_alpha_num_form) == 14
        and non_alpha_num_form.startswith("AR")
        and helper.has_cc_year(non_alpha_num_form)
        and non_alpha_num_form[6] == "P"
    ):
        return "ARP" + non_alpha_num_form[4:6] + non_alpha_num_form[7:]
    else:
        return patent_number


def ar_year_add_letter_p_shorten_year_add_zero(patent_number: str) -> str:
    """
    Add the letter "P" after the country code, shorten the year, and add a zero in an Argentinian patent number.

    :param patent_number: The patent number
    :return: Modified patent number
    """
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if len(non_alpha_num_form) == 13 and non_alpha_num_form.startswith("AR") and helper.has_cc_year(non_alpha_num_form):
        return "ARP" + non_alpha_num_form[4:6] + "0" + non_alpha_num_form[7:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "arYearDropLetterP",
                [ar_year_drop_letter_p],
            ),
            (
                "arYearAddLetterPshortenYear",
                [ar_year_add_letter_p_shorten_year],
            ),
            (
                "arYearMoveLetterPshortenYear",
                [ar_year_move_letter_p_shorten_year],
            ),
            (
                "arYearAddLetterPshortenYearAddZero",
                [ar_year_add_letter_p_shorten_year_add_zero],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
