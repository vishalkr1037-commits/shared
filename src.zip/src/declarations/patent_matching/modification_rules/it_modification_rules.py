from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def it_move_mi_and_delete_ninth_character(patent_number):
    if (
        patent_number.startswith("IT")
        and len(patent_number) == 13
        and patent_number[6:8] == "MI"
        and patent_number[8:].isdigit()
    ):
        return patent_number[:2] + "MI" + patent_number[2:6] + patent_number[9:13]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "itMoveMiAndDeleteNinthCharacter",
                [it_move_mi_and_delete_ninth_character],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())
    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
