import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

p_wo_kr_pattern = re.compile(r"WO(\d{4})KR(\d+)")
wo_patent_pattern = re.compile(r"WO(\d{4})([A-Z]{2})(\d{6}|\d{5})")

Rule = Tuple[str, List[Callable[[str], str]]]


def wo_year_cc_drop_zeroes(patent_number: str) -> str:
    """
    Drop zeroes after the year and country code in a WO patent number if it meets the conditions.

    :param patent_number: The patent number.
    :param country_codes: A set of valid country codes.
    :return: Modified patent number.
    """
    if (
        len(patent_number) >= 9
        and patent_number.startswith("WO")
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] in helper.country_codes
        and patent_number[8] == "0"
    ):
        return patent_number[:8] + patent_number[8:].lstrip("0")
    else:
        return patent_number


def wo_expand_short_year_insert_zero(patent_number: str) -> str:
    """
    Expand the short year and insert a zero in a WO patent number if it meets the conditions.

    :param patent_number: The patent number.
    :param short_years: A dictionary mapping short years to full years.
    :return: Modified patent number.
    """
    if (
        len(patent_number) >= 4
        and patent_number.startswith("WO")
        and (val := helper.short_years.get(patent_number[2:4]))
    ):
        return patent_number[:2] + val + "0" + patent_number[4:]
    else:
        return patent_number


def reformat_wo_number_with_kr(patent_number: str) -> str:
    """
    Reformat a WO patent number with KR if it matches the pattern.

    :param patent_number: The patent number.
    :param p_wo_kr_pattern: The regex pattern to match the WO-KR format.
    :return: Reformatted patent number.
    """
    match = p_wo_kr_pattern.fullmatch(patent_number)
    if match:
        year = match.group(1)
        p_number = match.group(2)
        return f"KR{year}0{p_number}W"
    else:
        return patent_number


def reformat_wo_number(patent_number: str) -> str:
    """
    Reformat a WO patent number based on its pattern.

    :param patent_number: The patent number.
    :param wo_patent_pattern: The regex pattern to match the WO format.
    :return: Reformatted patent number.
    """
    match = wo_patent_pattern.fullmatch(patent_number)
    if match:
        if len(patent_number) == 14:
            return f"{match.group(2)}{match.group(1)}{match.group(3)}W"
        else:
            return f"{match.group(2)}{match.group(1)}0{match.group(3)}W"
    else:
        return patent_number


def reformat_wo_number_with_in(patent_number: str) -> str:
    """
    Reformat a WO patent number to IN if it meets the conditions.

    :param patent_number: The patent number.
    :param category_special: A callable to check if the patent number belongs to a special category.
    :return: Reformatted patent number.
    """
    if patent_number.startswith("WO") and len(patent_number) == 14 and helper.category_special(patent_number):
        return patent_number.replace("WO", "IN", 1)
    else:
        return patent_number


def replace_wo_12_with_cn(patent_number: str) -> str:
    """
    Replace 'WO' with 'CN' in a 12-character WO patent number and append 'W'.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("WO") and len(patent_number) == 12:
        return patent_number.replace("WO", "CN", 1) + "W"
    else:
        return patent_number


def replace_wo_12_with_jp(patent_number: str) -> str:
    """
    Replace 'WO' with 'JP' in a 12-character WO patent number and append 'W'.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("WO") and len(patent_number) == 12:
        return patent_number.replace("WO", "JP", 1) + "W"
    else:
        return patent_number


def replace_wo_12_with_us(patent_number: str) -> str:
    """
    Replace 'WO' with 'US' in a 12-character WO patent number and append 'W'.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("WO") and len(patent_number) == 12:
        return patent_number.replace("WO", "US", 1) + "W"
    else:
        return patent_number


def replace_wo_12_with_kr(patent_number: str) -> str:
    """
    Replace 'WO' with 'KR' in a 12-character WO patent number and append 'W'.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("WO") and len(patent_number) == 12:
        return patent_number.replace("WO", "KR", 1) + "W"
    else:
        return patent_number


def replace_wo_12_with_ep(patent_number: str) -> str:
    """
    Replace 'WO' with 'EP' in a 12-character WO patent number and append 'W'.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("WO") and len(patent_number) == 12:
        return patent_number.replace("WO", "EP", 1) + "W"
    else:
        return patent_number


def wo_year_cc_drop_and_short(patent_number: str) -> str:
    """
    Drop the year and shorten the WO patent number if it meets the conditions.

    :param patent_number: The patent number.
    :param country_codes: A set of valid country codes.
    :return: Modified patent number.
    """
    if (
        len(patent_number) == 13
        and patent_number.startswith("WO")
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] in helper.country_codes
        and helper.get_year(patent_number) <= 2003
    ):
        return patent_number[6:8] + patent_number[4:6] + patent_number[8:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "woYearCcDropZeroes",
                [wo_year_cc_drop_zeroes],
            ),
            (
                "woExpandShortYearInsertZero",
                [wo_expand_short_year_insert_zero],
            ),
            (
                "reformatWoNumberWithKr",
                [reformat_wo_number_with_kr],
            ),
            (
                "reformatWONumber",
                [reformat_wo_number],
            ),
            (
                "reformatWoNumberWithIn",
                [reformat_wo_number_with_in],
            ),
            (
                "replaceWo12WithCn",
                [replace_wo_12_with_cn],
            ),
            (
                "replaceWo12WithJp",
                [replace_wo_12_with_jp],
            ),
            (
                "replaceWo12WithUs",
                [replace_wo_12_with_us],
            ),
            (
                "replaceWo12WithKr",
                [replace_wo_12_with_kr],
            ),
            (
                "replaceWo12WithEp",
                [replace_wo_12_with_ep],
            ),
            (
                "woYearCcDropAndShort",
                [wo_year_cc_drop_and_short],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
