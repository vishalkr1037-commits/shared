import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper

p_cc_for_ep_patent = re.compile(r"[A-Z]{2}EP\d+")
ep_patent_iso_iec = re.compile(r"EP(\d{6})")
p_numeric_ep_patent = re.compile(r"EP(\d{9})")


def drop_cc_for_ep_patent(patent_number):
    if len(patent_number) > 2 and patent_number[:2] in helper.ep_country_codes:
        return "EP" + patent_number[2:]
    else:
        return patent_number


def replace_cc_for_ep_patent(patent_number):
    if re.fullmatch(r"[A-Z]{2}EP\d+", patent_number):
        return patent_number[2:]
    else:
        return patent_number


def reformat_ep_patents_for_iso_iec(patent_number):
    if re.fullmatch(r"^EP\d{6}$", patent_number):
        return f"EP0{patent_number[2:]}"
    else:
        return patent_number


def cc_drop_zeroes(patent_number):
    if len(patent_number) >= 3 and patent_number[2] == "0":
        return patent_number[:2] + patent_number[2:].lstrip("0")
    else:
        return patent_number


def has_cc_year(patent_number):
    return len(patent_number) >= 6 and patent_number[:2] in helper.country_codes and patent_number[2:6] in helper.years


def cc_year_first_two_digits_drop_for_ep_application_number(patent_number):
    if has_cc_year(patent_number):
        return patent_number[:2] + patent_number[4:]
    else:
        return patent_number


def cc_year_first_two_digits_drop_and_zero_for_ep_application_number(patent_number):
    if has_cc_year(patent_number) and len(patent_number) > 6:
        if patent_number[6] == "0":
            return patent_number[:2] + patent_number[4:6] + patent_number[7:]
        else:
            return patent_number
    else:
        return patent_number


def add_cc_year_zero_on_application_number(patent_number):
    if has_cc_year(patent_number) and len(patent_number) > 7:
        return patent_number[:7] + "0" + patent_number[7:]
    else:
        return patent_number


def cc_drop_year(patent_number):
    if has_cc_year(patent_number) and (
        patent_number.startswith("CA") or patent_number.startswith("NL") or patent_number.startswith("DE")
    ):
        return patent_number[:2] + patent_number[6:]
    else:
        return patent_number


def cc_insert_year_regex(patent_number):
    if (
        len(patent_number) >= 2
        and not has_cc_year(patent_number)
        and not patent_number.startswith("/")
        and not patent_number.endswith("/")
    ):
        return f"/{patent_number[:2]}<{helper.start}-{helper.end}>{patent_number[2:]}/"
    else:
        return patent_number


def drop_ep_for_cc_ep_patent(patent_number):
    if re.fullmatch(r"[A-Z]{2}EP\d+", patent_number):
        return patent_number.replace("EP", "")
    else:
        return patent_number


def drop_last_digit_for_ep_patent_application_number(patent_number):
    if re.fullmatch(r"^EP\d{9}$", patent_number):
        return patent_number[:2] + patent_number[2:10]
    else:
        return patent_number


def drop_last_digit_ep_patent(patent_number):
    if re.fullmatch(r"^EP\d{9}$", patent_number):
        return patent_number[:10]
    else:
        return patent_number


def add_zero_and_drop_last_digit_ep_patent(patent_number):
    if re.fullmatch(r"^EP\d{8}$", patent_number):
        return "EP0" + patent_number[2:9]
    else:
        return patent_number


def clean_ep_patents(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if any(non_alpha_num_form.startswith(code) for code in helper.ep_country_codes):
        if not any(non_alpha_num_form.startswith(state) for state in helper.instates):
            if len(non_alpha_num_form) <= 9:
                return "EP" + non_alpha_num_form[2:].zfill(7)
            else:
                return "EP" + non_alpha_num_form[2:-1]

    return patent_number


def replace_cc_in_patent_publication_number(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if re.fullmatch(r"I\d+", non_alpha_num_form):
        return "IN" + non_alpha_num_form[1:]
    else:
        return patent_number


def add_cc_before_state_in_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    local_state = next((state for state in helper.instates if non_alpha_num_form.startswith(state)), None)
    if local_state:
        number_without_local_state = re.sub(local_state, "", non_alpha_num_form)
        return "IN" + number_without_local_state[:-4] + local_state + number_without_local_state[-4:]
    else:
        return patent_number


def add_cc_before_number_state_in_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if re.match(r"^\d", non_alpha_num_form) and any(state in non_alpha_num_form for state in helper.instates):
        return "IN" + non_alpha_num_form
    return patent_number


def remove_extra_char_after_state_in_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if non_alpha_num_form.startswith("IN") and any(state in non_alpha_num_form for state in helper.instates):
        number_without_po = non_alpha_num_form[2:]
        local_state = next((s for s in helper.instates if s in non_alpha_num_form), None)
        if local_state:
            idx = number_without_po.find(local_state)
            before_state = number_without_po[:idx]
            if len(before_state) == 3:
                return non_alpha_num_form
            elif len(before_state) > 3:
                return "IN" + before_state[:3] + number_without_po[idx:]
    return patent_number


def remove_letter_a_in_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if non_alpha_num_form.startswith("IN") and non_alpha_num_form.endswith("A"):
        return re.sub(r"A$", "", non_alpha_num_form)
    else:
        return patent_number


def replace_full_state_with_state_initial_in_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if non_alpha_num_form.startswith("IN") and "CHENP" in non_alpha_num_form and len(non_alpha_num_form) == 14:
        return non_alpha_num_form.replace(r"CHENP", "CHN")
    else:
        return patent_number


def drop_last_char_in_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if (
        non_alpha_num_form.startswith("IN")
        and len(non_alpha_num_form) == 14
        and (non_alpha_num_form[2:4] == "19" or non_alpha_num_form[2:4] == "20")
    ):
        return non_alpha_num_form[:-1]
    else:
        return patent_number


def drop_pct_number_1_after_pct_fi_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if non_alpha_num_form.startswith("PCTF1"):
        return non_alpha_num_form.replace(r"PCTF1", "FI")
    else:
        return patent_number


def drop_pct_jp_patent(patent_number):
    non_alpha_num_form = re.sub(r"[^0-9A-Z]", "", patent_number)
    if non_alpha_num_form.startswith("PCTJP"):
        return non_alpha_num_form.replace(r"PCTJP", "JP")
    else:
        return patent_number


def drop_cc_for_oa_patent(patent_number):
    if re.fullmatch(r"[A-Z]{2}OA0\d+", patent_number):
        return patent_number[2:4] + patent_number[5:]
    else:
        return patent_number


Rule = Tuple[str, List[Callable[[str], str]]]


def get_secondary_modification_rules() -> List[Rule]:
    return [
        ("dropCcforEpPatent", [drop_cc_for_ep_patent]),
        ("replaceCcforEpPatent", [replace_cc_for_ep_patent]),
        (
            "replaceCcforEpPatent, reformatEpPatentsforIsoIec",
            [replace_cc_for_ep_patent, reformat_ep_patents_for_iso_iec],
        ),
        (
            "replaceCcforEpPatent, ccDropZeroes",
            [replace_cc_for_ep_patent, cc_drop_zeroes],
        ),
        ("ccYearFirstTwoDigitsDropForEPApplicationNumber", [cc_year_first_two_digits_drop_for_ep_application_number]),
        (
            "ccYearFirstTwoDigitsDropAndZeroForEPApplicationNumber",
            [cc_year_first_two_digits_drop_and_zero_for_ep_application_number],
        ),
        ("addCCYearZeroOnApplicationNumber", [add_cc_year_zero_on_application_number]),
        ("ccDropYear", [cc_drop_year]),
        ("ccInsertYearRegex", [cc_insert_year_regex]),
        ("dropEpforCcEpPatent", [drop_ep_for_cc_ep_patent]),
        ("dropLastDigitForEpPatentApplicationNumber", [drop_last_digit_for_ep_patent_application_number]),
        ("dropLastdigitEpPatent", [drop_last_digit_ep_patent]),
        ("addZeroAndDropLastDigitEpPatent", [add_zero_and_drop_last_digit_ep_patent]),
        ("cleanEpPatents", [clean_ep_patents]),
        ("replaceCCInPatentPublicationNumber", [replace_cc_in_patent_publication_number]),
        ("addCCBeforeStateInPatent", [add_cc_before_state_in_patent]),
        (
            "addCCBeforeNumberStateInPatent , removeExtraCharAfterStateInPatent",
            [add_cc_before_number_state_in_patent, remove_extra_char_after_state_in_patent],
        ),
        (
            "removeLetterAInPatent , removeExtraCharAfterStateInPatent , replaceFullStateWithStateInitialInPatent",
            [
                remove_letter_a_in_patent,
                remove_extra_char_after_state_in_patent,
                replace_full_state_with_state_initial_in_patent,
            ],
        ),
        ("dropLastCharInPatent", [drop_last_char_in_patent]),
        ("dropPCTNumber1AfterPCTFiPatent", [drop_pct_number_1_after_pct_fi_patent]),
        ("dropPCTJpPatent", [drop_pct_jp_patent]),
        ("dropCcForOAPatent", [drop_cc_for_oa_patent]),
    ]
