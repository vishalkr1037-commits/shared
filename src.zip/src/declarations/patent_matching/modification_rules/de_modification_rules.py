import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]

p_de_pattern = re.compile(r"DE(\d{9,}$)")
p_num_followed_by_letter_de_patent = re.compile(r"^DE\d+[A-Z]\d")
p_non_alpha_num = re.compile(r"[^0-9A-Z]")
old_de_patent_pattern = re.compile(r"DE(\d{4})(\d)0(\d{5})")
de_with_u_kind_code_patent_pattern = re.compile(r"DE(\d{4})20(\d{5})U")


def de_shorten_nineties_and_move_character(patent_number):
    if len(patent_number) >= 7 and patent_number.startswith("DE199"):
        return patent_number[0:2] + patent_number[6] + patent_number[4:6] + patent_number[7:].lstrip("0")
    else:
        return patent_number


def de_drop_last_digit(patent_number):
    if p_de_pattern.match(patent_number):
        return patent_number[:-1]
    else:
        return patent_number


def remove_non_alphanumeric_chars(name):
    return p_non_alpha_num.sub("", name)


def de_drop_last_two_letters(patent_number):
    if p_num_followed_by_letter_de_patent.match(patent_number):
        non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
        return non_alpha_num_form[:-2]
    return patent_number


def de_drop_letter_based_on_len(patent_number):
    non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
    if len(non_alpha_num_form) > 10 and non_alpha_num_form.startswith("DE"):
        limit = len(non_alpha_num_form) - 10
        return non_alpha_num_form[: len(non_alpha_num_form) - limit]
    else:
        return patent_number


def reformat_de_number(patent_number):
    if patent_number.startswith("DE") and len(patent_number) == 14:
        return "DE" + patent_number[6] + patent_number[4] + patent_number[5] + patent_number[8:]
    else:
        return patent_number


def reformat_de_number_with_13_characters(patent_number):
    if patent_number.startswith("DE") and len(patent_number) == 13:
        return "DE" + patent_number[6] + patent_number[4] + patent_number[5] + patent_number[7:]
    else:
        return patent_number


def de_old_patent_with_13_characters_rule(patent_number):
    match = old_de_patent_pattern.match(patent_number)
    if match:
        year = int(match.group(1))
        short_year = match.group(1)[-2:]

        if year <= 2003:
            return "DE" + match.group(2) + short_year + match.group(3) + "A"
        else:
            return patent_number
    else:
        return patent_number


def reformat_de_patent_numbers_with_14_characters(patent_number):
    match = de_with_u_kind_code_patent_pattern.match(patent_number)
    if match:
        year = int(match.group(1))
        short_year = match.group(1)[-2:]

        if year <= 2003:
            return "DE" + "2" + short_year + match.group(2) + "U"
        else:
            return "DE" + "20" + match.group(1) + "0" + match.group(2) + "U"
    else:
        return patent_number


def reformat_de_number_with_11_digits(patent_number):
    if patent_number.startswith("DE") and len(patent_number) == 14 and patent_number.endswith("T"):
        return "DE" + patent_number[6] + patent_number[7] + patent_number[2:6] + "0" + patent_number[8:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "de_shorten_nineties_and_move_character",
                [de_shorten_nineties_and_move_character],
            ),
            ("", [de_drop_last_digit]),
            ("", [de_drop_last_two_letters]),
            ("", [de_drop_letter_based_on_len]),
            ("", [reformat_de_number]),
            ("", [reformat_de_number_with_13_characters]),
            ("", [de_old_patent_with_13_characters_rule]),
            ("", [reformat_de_patent_numbers_with_14_characters]),
            ("", [reformat_de_number_with_11_digits]),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
