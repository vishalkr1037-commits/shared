from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary
from src.declarations.patent_matching.modification_rules.modification_rules_helper import (
    remove_non_alphanumeric_chars,
    tw_patent_pattern,
)

Rule = Tuple[str, List[Callable[[str], str]]]

years_map = {
    "1997": "86",
    "1998": "87",
    "1999": "88",
    "2000": "89",
    "2001": "90",
    "2002": "91",
    "2003": "92",
    "2004": "93",
    "2005": "94",
    "2006": "95",
    "2007": "96",
    "2008": "97",
    "2009": "98",
    "2010": "99",
    "2011": "100",
    "2012": "101",
    "2013": "102",
    "2014": "103",
    "2015": "104",
    "2016": "105",
    "2017": "106",
    "2018": "107",
    "2019": "108",
    "2020": "109",
    "2021": "110",
    "2022": "111",
    "2023": "112",
    "2024": "113",
}


def tw_add_letters_i_remove_extra_char_after_po_with_i(patent_number: str) -> str:
    if patent_number.startswith("TW"):
        non_alpha_num_form = remove_non_alphanumeric_chars(patent_number)
        if len(non_alpha_num_form) in {8, 9}:
            return f"TWI{non_alpha_num_form[-6:]}"

    return patent_number


def reformat_tw_with_short(patent_number: str) -> str:
    match = tw_patent_pattern.fullmatch(patent_number)
    if match:
        year, number, _ = match.groups()
        short_year = years_map.get(year)
        if short_year:
            return f"TW{short_year}{number}"
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []
    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())
    rules.extend(
        [
            (
                "twAddLettersIremoveExtraCharAfterPOwithI",
                [tw_add_letters_i_remove_extra_char_after_po_with_i],
            ),
            (
                "reformatTWWithShortYearMapping",
                [reformat_tw_with_short],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())
    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
