import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def cl_remove_zero_after_year(patent_number):
    if match := re.match(r"(CL.{4})0(.{6,})", patent_number):
        return match.group(1) + match.group(2)
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "cl_remove_zero_after_year",
                [cl_remove_zero_after_year],
            )
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
