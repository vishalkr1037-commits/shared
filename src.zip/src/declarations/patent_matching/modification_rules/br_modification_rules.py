import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

br11_patent_pattern = re.compile(r"^BR(\d{4})11(\d{5})$")
br20_patent_pattern = re.compile(r"^BR20(\d{2})PI(\d{5})$")

Rule = Tuple[str, List[Callable[[str], str]]]


def br_drop_letters_pi(patent_number: str) -> str:
    """
    Remove the letters "PI" from a Brazilian patent number if it starts with "BR".

    :param patent_number: The patent number
    :return: Modified patent number with "PI" removed if it starts with "BR", otherwise the original patent number
    """
    if patent_number.startswith("BR"):
        return patent_number.replace("PI", "")
    else:
        return patent_number


def cc_short_year_expand(patent_number: str) -> str:
    """
    Expand the short year in a patent number if it is not from Japan and the short year is in the shortYears dictionary.

    :param patent_number: The patent number
    :return: Modified patent number with the expanded year if conditions are met, otherwise the original patent number
    """
    if (
        len(patent_number) >= 4
        and not patent_number.startswith("JP")
        and (val := helper.short_years.get(patent_number[2:4]))
    ):
        return patent_number[:2] + val + patent_number[4:]
    else:
        return patent_number


def drop_last_letter(patent_number: str) -> str:
    """
    Drop the last letter of a patent number if it starts with "BR" or "CN".

    :param patent_number: The patent number
    :return: Modified patent number with the last letter dropped if conditions are met, otherwise the original patent number
    """
    if patent_number.startswith("BR") or patent_number.startswith("CN"):
        return patent_number[:-1]
    else:
        return patent_number


def drop_br_last_letter(patent_number: str) -> str:
    """
    Drop the last letter of a Brazilian patent number if it starts with "BR" and is 15 characters long.

    :param patent_number: The patent number
    :return: Modified patent number with the last letter dropped if conditions are met, otherwise the original patent number
    """
    if patent_number.startswith("BR") and len(patent_number) == 15:
        return patent_number[:-1]
    else:
        return patent_number


def drop_br_pi_last_letter(patent_number: str) -> str:
    """
    Drop the last letter of a Brazilian patent number if it starts with "BRPI" and is 12 characters long.

    :param patent_number: The patent number
    :return: Modified patent number with the last letter dropped if conditions are met, otherwise the original patent number
    """
    if patent_number.startswith("BRPI") and len(patent_number) == 12:
        return patent_number[:-1]
    else:
        return patent_number


def add_br_pi_application_number(patent_number: str) -> str:
    """
    Add the letters "PI" to a Brazilian patent number if it starts with "BR" and does not already contain "PI".

    :param patent_number: The patent number
    :return: Modified patent number with "PI" added if conditions are met, otherwise the original patent number
    """
    if patent_number.startswith("BR") and "PI" not in patent_number:
        return patent_number[:2] + "PI" + patent_number[2:]
    else:
        return patent_number


def drop_br_last_two_letters(patent_number: str) -> str:
    """
    Drop the last two letters of a Brazilian patent number if it starts with "BR" and is 15 characters long after removing non-alphanumeric characters.

    :param patent_number: The patent number
    :return: Modified patent number with the last two letters dropped if conditions are met, otherwise the original patent number
    """
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("BR") and len(non_alpha_num_form) == 15:
        return non_alpha_num_form[:-2]
    else:
        return patent_number


def reformat_br_patent_with_pi(patent_number: str) -> str:
    """
    Reformat a Brazilian patent number by adding "PI" if it matches the BR20 pattern.

    :param patent_number: The patent number
    :return: Reformatted patent number with "PI" added if conditions are met, otherwise the original patent number
    """
    match = br20_patent_pattern.fullmatch(patent_number)
    if match:
        return f"BRPI{match.group(1)}{match.group(2)}"
    else:
        return patent_number


def reformat_br_patent(patent_number: str) -> str:
    """
    Reformat a Brazilian patent number by adding "BR11" and a '0' if it matches the BR11 pattern.

    :param patent_number: The patent number
    :return: Reformatted patent number with "BR11" and a '0' added if conditions are met, otherwise the original patent number
    """
    match = br11_patent_pattern.fullmatch(patent_number)
    if match:
        return f"BR11{match.group(1)}0{match.group(2)}"
    else:
        return patent_number


def br_short_year_last_5_digits(patent_number: str) -> str:
    """
    Modify the Brazilian patent number by moving the short year to the last 5 digits if conditions are met.

    :param patent_number: The patent number
    :return: Modified patent number with the short year moved if conditions are met, otherwise the original patent number
    """
    if (
        len(patent_number) == 13
        and patent_number.startswith("BR")
        and helper.has_cc_year(patent_number)
        and helper.get_year(patent_number) <= 2003
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[8:]
    else:
        return patent_number


def br_move_yy_after_country_code(patent_number: str) -> str:
    """
    Move the short year to immediately after the country code in a Brazilian patent number if conditions are met.
    Format: BR20xxYYzzzzz -> BRYY20xx0zzzzz

    :param patent_number: The patent number
    :return: Modified patent number with the short year moved if conditions are met, otherwise the original patent number
    """

    if len(patent_number) == 13 and patent_number.startswith("BR20") and helper.has_cc_year(patent_number):
        return patent_number[:2] + patent_number[6:8] + patent_number[2:6] + "0" + patent_number[8:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "brDropLettersPI, ccShortYearExpand",
                [br_drop_letters_pi, cc_short_year_expand],
            ),
            (
                "brDropLettersPI",
                [br_drop_letters_pi],
            ),
            (
                "brDropLettersPI , dropLastLetter",
                [br_drop_letters_pi, drop_last_letter],
            ),
            (
                "dropBRLastLetter",
                [drop_br_last_letter],
            ),
            (
                "dropBRPILastLetter",
                [drop_br_pi_last_letter],
            ),
            (
                "addBRPIApplicationNumber",
                [add_br_pi_application_number],
            ),
            (
                "dropBRLastTwoLetters",
                [drop_br_last_two_letters],
            ),
            (
                "reformatBRPatentWithPI",
                [reformat_br_patent_with_pi],
            ),
            (
                "reformatBRPatten",
                [reformat_br_patent],
            ),
            (
                "brShortYearLast5Digits",
                [br_short_year_last_5_digits],
            ),
            (
                "brMoveYYAfterCountryCode",
                [br_move_yy_after_country_code],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
