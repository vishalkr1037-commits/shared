import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def se_delete_two_first_digits_of_the_year_and_zeros_after_the_year(patent_number: str) -> str:
    """
    Delete the first two digits of the year and zeros after the year in a Swedish patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        len(patent_number) == 13
        and patent_number.startswith("SE")
        and re.match(r"\d{4}", patent_number[2:6])
        and patent_number[6:8] == "00"
        and re.match(r"\d{5}", patent_number[8:13])
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[8:13]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "seDeleteTwoFirstDigitsOfTheYearAndZerosAfterTheYear",
                [se_delete_two_first_digits_of_the_year_and_zeros_after_the_year],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
