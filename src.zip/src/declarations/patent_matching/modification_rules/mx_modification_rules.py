import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

mx_pa_patent_pattern = re.compile(r"MX20(\d{2})PA(\d{5})")
mx_short_year_pattern = re.compile(r"MX(\d{4})00(\d{5})")
mx_patent_pattern = re.compile(r"MX(\d{4})0(\d{6})")

Rule = Tuple[str, List[Callable[[str], str]]]


def mx_expand_short_year_move_letters_pa(patent_number: str) -> str:
    """
    Expand the short year and move the letters 'PA' in a Mexican patent number.

    :param patent_number: The patent number.
    :param short_years: A dictionary mapping short years to full years.
    :return: Modified patent number.
    """
    if (
        len(patent_number) >= 6
        and patent_number.startswith("MXPA")
        and (val := helper.short_years.get(patent_number[4:6]))
    ):
        return patent_number[:2] + val + "PA" + patent_number[6:].lstrip("0")
    else:
        return patent_number


def mx_year_drop_letters_pa(patent_number: str) -> str:
    """
    Drop the letters 'PA' from a Mexican patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        len(patent_number) >= 8
        and patent_number.startswith("MX")
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] == "PA"
    ):
        return patent_number[:6] + patent_number[8:]
    else:
        return patent_number


def mx_drop_extra_a(patent_number: str) -> str:
    """
    Replace 'MXPAA' with 'MXPA' in a Mexican patent number if it starts with 'MXPAA'.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if len(patent_number) >= 8 and patent_number.startswith("MXPAA"):
        return patent_number.replace("MXPAA", "MXPA")
    else:
        return patent_number


def mx_drop_letter_a(patent_number: str) -> str:
    """
    Drop the letter 'A' from a Mexican patent number if it starts with 'MXA' and is 13 characters long.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("MXA") and len(patent_number) == 13:
        return "MX" + patent_number[3:]
    else:
        return patent_number


def mx_drop_yy_from_year(patent_number: str) -> str:
    """
    Drop the 'YY' part from the year in a Mexican patent number if it meets the conditions.
    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if len(patent_number) >= 8 and patent_number.startswith("MXPA") and patent_number[4:8] in helper.years:
        short_year = patent_number[6:8]
        return patent_number[:4] + short_year + patent_number[8:]
    else:
        return patent_number


def mx_reformat_pa(patent_number: str) -> str:
    """
    Reformat a Mexican patent number by adding 'MXPA', the short year, a '0', and the rest of the digits.

    :param patent_number: The patent number.
    :return: Reformatted patent number.
    """
    match = mx_pa_patent_pattern.match(patent_number)
    if match:
        return f"MXPA{match.group(1)}0{match.group(2)}"
    else:
        return patent_number


def mx_reformat_short_year(patent_number: str) -> str:
    """
    Reformat a Mexican patent number by shortening the year if it is before 2000.

    :param patent_number: The patent number.
    :return: Reformatted patent number.
    """
    match = mx_short_year_pattern.match(patent_number)
    if match:
        year = int(match.group(1))
        if year < 2000:
            short_year = match.group(1)[2:]  # Take the last two digits of the year
            return f"MX{short_year}{match.group(2)}"
        else:
            return patent_number
    else:
        return patent_number


def mx_delete_extra_zero_after_year(patent_number: str) -> str:
    """
    Delete the extra zero after the year in a Mexican patent number.

    :param patent_number: The patent number.
    :return: Reformatted patent number.
    """
    match = mx_patent_pattern.match(patent_number)
    if match:
        return f"MX{match.group(1)}{match.group(2)}"
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "mxExpandShortYearMoveLettersPA",
                [mx_expand_short_year_move_letters_pa],
            ),
            (
                "mxYearDropLettersPA",
                [mx_year_drop_letters_pa],
            ),
            (
                "mxDropExtraA , mxDropYYFromYear",
                [mx_drop_extra_a, mx_drop_yy_from_year],
            ),
            (
                "mxDropLetterA",
                [mx_drop_letter_a],
            ),
            (
                "mxReformatShortYear",
                [mx_reformat_short_year],
            ),
            (
                "mxReformatPA",
                [mx_reformat_pa],
            ),
            (
                "mxDeleteExtraZeroAfterYear",
                [mx_delete_extra_zero_after_year],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
