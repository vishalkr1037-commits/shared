import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]

hu_patent_pattern = re.compile(r"HU(\d{4})E(\d{6})")


def reformat_hu_modification_rule(patent_number):
    match = hu_patent_pattern.match(patent_number)
    if match:
        short_year = match.group(1)[-2:]
        return "HUE" + short_year + match.group(2) + "A"
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "hrWithPReformat",
                [reformat_hu_modification_rule],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
