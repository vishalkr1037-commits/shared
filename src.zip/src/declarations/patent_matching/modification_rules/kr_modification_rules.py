from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def kr_drop_letters_100(patent_number):
    """
    Remove the letters "100" after the country code from a Korean patent number.
    """
    if len(patent_number) >= 5 and patent_number.startswith("KR") and patent_number[2:5] == "100":
        return patent_number[:2] + patent_number[5:]
    else:
        return patent_number


def kr_drop_letters_10(patent_number):
    """
    Remove the letters "10" after the country code from a Korean patent number.
    """
    if len(patent_number) >= 4 and patent_number.startswith("KR") and patent_number[2:4] == "10":
        return patent_number[:2] + patent_number[4:]
    else:
        return patent_number


def kr_year_single_wildcard_drop_zero(patent_number):
    """
    Remove a "0" after the country code, a year, and a single arbitrary character from a Korean patent number.
    """
    if (
        len(patent_number) >= 8
        and patent_number.startswith("KR")
        and patent_number[2:6] in helper.years
        and patent_number[7] == "0"
    ):
        return patent_number[:7] + patent_number[8:]
    else:
        return patent_number


def kr_drop_letter_p(patent_number):
    """
    Remove the letter "P" after the country code from a Korean patent number.
    """
    if len(patent_number) > 4 and patent_number.startswith("KR") and patent_number[2] == "P":
        return patent_number[:2] + patent_number[3:]
    else:
        return patent_number


def kr_less_than_nine_digits_leading_add(patent_number):
    """
    If a KR patent number has less than 9 digits, transform it to have a length of 9 digits by adding a leading 10 or 100.
    """
    if len(patent_number) < 11 and patent_number.startswith("KR"):
        missing_zeros = 11 - len(patent_number)
        lead = "1" + "0" * (missing_zeros - 1)
        return patent_number[:2] + lead + patent_number[2:]
    else:
        return patent_number


def kr_drop_zero(patent_number):
    """
    If a KR patent number has 13 digits with 0000 at the end, transform it to have a length of 9 digits by removing the last four zeros.
    """
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("KR") and len(non_alpha_num_form) == 15 and non_alpha_num_form.endswith("0000"):
        return non_alpha_num_form[:11]
    else:
        return patent_number


def kr_insert_zero(patent_number):
    """
    Insert a "0" after "KR1" in a Korean patent number if it starts with "KR1" and has a length of 10.
    """
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("KR1") and len(non_alpha_num_form) == 10:
        return "KR1" + "0" + non_alpha_num_form[3:]
    else:
        return patent_number


def kr_change_three_specific_numbers_after_year(patent_number):
    """
    Working numbers start with "KR", followed by 11 digits (4 year digits after the "KR" are from 1994 to 1998,
    and 4 year digits are followed by 3 digits that are "007", "070", or "700") - in total of 13 characters.

    Rule: Change the mentioned 3 digits to the "070" format.

    Example:
    KR19950075880 -> KR19950705880A
    """
    if patent_number.startswith("KR") and len(patent_number) == 13 and patent_number[2:].isdigit():
        year = int(patent_number[2:6])
        next_three_digits = patent_number[6:9]

        if 1994 <= year <= 1998 and next_three_digits in {"007", "700"}:
            new_next_three_digits = "070"
            return patent_number[:6] + new_next_three_digits + patent_number[9:]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "krDropLetters100, krDropLetters10",
                [kr_drop_letters_100, kr_drop_letters_10],
            ),
            ("krYearSingleWildcardDropZero", [kr_year_single_wildcard_drop_zero]),
            (
                "krDropLetterP , krLessThanNineDigitsLeadingAdd",
                [kr_drop_letter_p, kr_less_than_nine_digits_leading_add],
            ),
            ("krDropZero", [kr_drop_zero]),
            ("krInsertZero", [kr_insert_zero]),
            ("krChangeThreeSpecificNumbersAfterYear", [kr_change_three_specific_numbers_after_year]),
        ]
    )

    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
