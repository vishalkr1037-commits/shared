from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def ma_delete_after_ma_except_last_five_digit(patent_number: str) -> str:
    """
    Delete everything after 'MA' except the last five digits if the patent number starts with 'MA',
    the substring from index 2 to 4 equals '20', and the substring from index 6 to 8 equals '00'.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("MA20") and patent_number[6:8] == "00":
        return patent_number[:2] + patent_number[8:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "maDeleteAfterMAExceptLastFiveDigit",
                [ma_delete_after_ma_except_last_five_digit],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
