from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def nz_drop_year_drop_zeros(patent_number: str) -> str:
    """
    Drop the year and leading zeros from a New Zealand patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if len(patent_number) >= 7 and patent_number.startswith("NZ") and helper.has_cc_year(patent_number):
        return patent_number[:2] + patent_number[7:].lstrip("0")
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "nzDropYearDropZeros",
                [nz_drop_year_drop_zeros],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
