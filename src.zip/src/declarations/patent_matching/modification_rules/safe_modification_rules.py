from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper

Rule = Tuple[str, List[Callable[[str], str]]]


def _move_country_code(patent_number):
    """
    Move the country code from the end to the beginning of a patent number

    :param patent_number: The patent number
    :param country_codes: Set of country codes
    :param special_case_kind_codes: Set of special case kind codes
    :return: If the country code is at the end, move it to the front. Else, return the original number.
    """
    if (
        len(patent_number) >= 2
        and patent_number.startswith("SG")
        and patent_number[-2:] in helper.special_case_kind_codes
    ):
        return patent_number
    elif len(patent_number) >= 2 and patent_number[-2:] in helper.country_codes:
        return patent_number[-2:] + patent_number[:-2]
    else:
        return patent_number


def _replace_usx_prefix(patent_number):
    """
    Replace "USA" or "USP" with "US" at the beginning of a patent number

    :param patent_number: The patent number
    :return: If the number starts with "USA" or "USP", drop the extra character. Else, return the original number.
    """
    if patent_number.startswith("USA") or patent_number.startswith("USP"):
        return "US" + patent_number[3:]
    else:
        return patent_number


def _replace_epo_prefix(patent_number):
    """
    Replace "EPO" with "EP" at the beginning of a patent number

    :param patent_number: The patent number
    :return: If the number starts with "EPO", drop the "O". Else, return the original number.
    """
    if patent_number.startswith("EPO"):
        return "EP" + patent_number[3:]
    else:
        return patent_number


def _replace_jhp_prefix(patent_number):
    """
    Replace "JHP" or "JPH" with "JP" at the beginning of a patent number

    :param patent_number: The patent number
    :return: If the number starts with "JHP", drop the "H". Else, return the original number.
    """
    if patent_number.startswith(("JHP", "JPH")):
        return "JP" + patent_number[3:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.extend(
        [
            ("moveCountryCode", [_move_country_code]),
            ("replaceUsxPrefix", [_replace_usx_prefix]),
            ("replaceEpoPrefix", [_replace_epo_prefix]),
            ("replaceJhpPrefix", [_replace_jhp_prefix]),
        ]
    )

    return rules
