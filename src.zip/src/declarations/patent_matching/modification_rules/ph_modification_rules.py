import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def ph_number_move_fifth_digit_to_the_first_place(patent_number: str) -> str:
    """
    Move the fifth digit to the first place in a PH patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("PH") and len(patent_number) == 13 and re.match(r"\d{11}", patent_number[2:]):
        fifth_digit = int(patent_number[6])
        if fifth_digit == 1:
            return patent_number[:2] + patent_number[6] + patent_number[2:6] + patent_number[7:]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    """
    Get the list of publication number modification rules.

    :return: A list of rules for modifying publication numbers.
    """
    rules: List[Rule] = []

    # Add a default "none" rule
    rules.append(("none", []))

    # Add primary modification rules
    rules.extend(primary.get_primary_modification_rules())

    # Add specific PH patent modification rule
    rules.append(
        (
            "phNumberMoveFifthDigitToTheFirstPlace",
            [ph_number_move_fifth_digit_to_the_first_place],
        )
    )

    # Add secondary modification rules
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    """
    Get the list of application number modification rules.

    :return: A list of rules for modifying application numbers.
    """
    return get_publication_number_modification_rules()
