import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]

in_remove_two_chars_and_move_year_to_end_patent_pattern = re.compile(r"IN(\d{4})([A-Z]{5})(\d{4})")
in_with_a_kind_code_patent_pattern = re.compile(r"IN(\d{4})([A-Z]{3})(\d{4})A")


def in_remove_two_chars_and_move_year_to_end(patent_number):
    match = in_remove_two_chars_and_move_year_to_end_patent_pattern.match(patent_number)
    if match:
        year = match.group(1)
        middle_chars = match.group(2)
        middle_chars = middle_chars[0] + middle_chars[1] + middle_chars[3]
        last_num_set = match.group(3)
        return "IN" + last_num_set + middle_chars + year + "A"
    else:
        return patent_number


def in_remove_eighth_char_add_zero_ninth(patent_number):
    match = in_with_a_kind_code_patent_pattern.match(patent_number)
    if match:
        first_num_set = match.group(1)
        middle_chars = match.group(2)
        middle_chars = middle_chars[0] + middle_chars[2]
        year = match.group(3)
        return "IN" + year + middle_chars + "0" + first_num_set + "A"
    else:
        return patent_number


def in_move_last_three_digits_after_the_country_code_and_reformat_the_number_sixteen_character(patent_number):
    if (
        len(patent_number) == 16
        and patent_number.startswith("IN")
        and patent_number[2:6].isdigit()
        and patent_number[6:11].endswith("P")
        and patent_number[11:16].isdigit()
    ):
        return patent_number[:2] + patent_number[11:16] + patent_number[6:8] + patent_number[9:10] + patent_number[2:6]
    return patent_number


def in_move_four_year_digits_after_the_country_code_and_reformat_the_number_thirteen_character(patent_number):
    if (
        len(patent_number) == 13
        and patent_number.startswith("IN")
        and patent_number[2:5].isdigit()
        and patent_number[5:8].isalpha()
        and patent_number[8:12].isdigit()
        and patent_number[12] == "A"
    ):
        return (
            patent_number[:2]
            + patent_number[8:12]
            + patent_number[5:6]
            + patent_number[7:8]
            + "00"
            + patent_number[2:5]
        )
    return patent_number


def in_move_four_year_digits_after_the_country_code_and_reformat_the_number_fifteen_character(patent_number):
    if (
        len(patent_number) == 15
        and patent_number.startswith("IN")
        and patent_number[2:7].isdigit()
        and patent_number[7:10].isalpha()
        and patent_number[10:14].isdigit()
        and patent_number[14] == "A"
    ):
        return patent_number[:2] + patent_number[10:14] + patent_number[7:8] + patent_number[9:10] + patent_number[2:7]
    return patent_number


def in_move_last_three_digits_after_the_country_code_and_reformat_the_number_fourteen_character(patent_number):
    if (
        len(patent_number) == 14
        and patent_number.startswith("IN")
        and patent_number[2:6].isdigit()
        and patent_number[6:11].endswith("P")
        and patent_number[11:14].isdigit()
    ):
        return patent_number[:2] + patent_number[11:14] + patent_number[6:8] + patent_number[9:10] + patent_number[2:6]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "inRemoveTwoCharsAndMoveYearToEnd",
                [in_remove_two_chars_and_move_year_to_end],
            ),
            (
                "removeEighthCharAddZeroNinth",
                [in_remove_eighth_char_add_zero_ninth],
            ),
            (
                "inMoveLastThreeDigitsAfterTheCountryCodeAndReformatTheNumberSixteenCharacter",
                [in_move_last_three_digits_after_the_country_code_and_reformat_the_number_sixteen_character],
            ),
            (
                "inMoveFourYearDigitsAfterTheCountryCodeAndReformatTheNumberThirteenCharacter",
                [in_move_four_year_digits_after_the_country_code_and_reformat_the_number_thirteen_character],
            ),
            (
                "inMoveFourYearDigitsAfterTheCountryCodeAndReformatTheNumberFifteenCharacter",
                [in_move_four_year_digits_after_the_country_code_and_reformat_the_number_fifteen_character],
            ),
            (
                "inMoveLastThreeDigitsAfterTheCountryCodeAndReformatTheNumberFourteenCharacter",
                [in_move_last_three_digits_after_the_country_code_and_reformat_the_number_fourteen_character],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
