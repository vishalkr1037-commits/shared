import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def au_move_and_expand_short_year(patent_number: str) -> str:
    """
    Move and expand the short year in an Australian patent number.

    :param patent_number: The patent number
    :return: Modified patent number
    """
    if (
        len(patent_number) >= 5
        and patent_number.startswith("AU")
        and not helper.has_cc_year(patent_number)
        and patent_number.endswith("A")
        and patent_number[-3:-1] in helper.short_years
    ):
        return patent_number[:2] + helper.short_years[patent_number[-3:-1]] + patent_number[2:-3] + patent_number[-1]
    else:
        return patent_number


def au_reformat_number_length_13_or_14(patent_number: str) -> str:
    """
    Reformat an Australian patent number if it starts with "AU" and has a length of 13 or 14 characters.

    :param patent_number: The patent number
    :return: Reformatted patent number
    """
    if patent_number.startswith("AU") and (len(patent_number) == 14 or len(patent_number) == 13):
        return patent_number[:2] + patent_number[8:13] + patent_number[4:6] + "A"
    else:
        return patent_number


def au_reformat_number_length_10(patent_number: str) -> str:
    """
    Reformat an Australian patent number if it starts with "AU", has a length of 10 characters,
    and matches the pattern of 7 digits followed by 'A'.

    :param patent_number: The patent number
    :return: Reformatted patent number
    """
    if (
        patent_number.startswith("AU")
        and len(patent_number) == 10
        and re.match(r"\d{7}A", patent_number[2:])
        and patent_number.endswith("A")
    ):
        new_two_digits = "20"
        new_one_digit = "2"
        return patent_number[:2] + new_two_digits + patent_number[-3:-1] + new_one_digit + patent_number[2:7]
    return patent_number


def au_remove_zero(patent_number: str) -> str:
    """
    Remove zeros from an Australian patent number if it starts with "AU", has a length of 13 characters,
    contains a valid year, and has "00" at positions 6 and 7 followed by 5 digits.

    :param patent_number: The patent number
    :return: Modified patent number
    """
    if (
        patent_number.startswith("AU")
        and len(patent_number) == 13
        and helper.has_cc_year(patent_number)
        and patent_number[6:8] == "00"
        and re.match(r"\d{5}", patent_number[8:13])
    ):
        return patent_number[:2] + patent_number[4:6] + patent_number[8:13]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "auMoveAndExpandShortYear",
                [au_move_and_expand_short_year],
            ),
            (
                "reformatAUNumber",
                [au_reformat_number_length_13_or_14],
            ),
            (
                "auReformatNumber",
                [au_reformat_number_length_10],
            ),
            (
                "auRemoveZero",
                [au_remove_zero],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
