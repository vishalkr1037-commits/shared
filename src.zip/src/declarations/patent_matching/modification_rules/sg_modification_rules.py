import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]

sg_patent_pattern = re.compile("SG(\\d{4})11(\\w{6})")


def sg_move_ten_digit_before_year(patent_number: str) -> str:
    """
    Move the ten-digit number before the year in a Singapore patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if (
        len(patent_number) == 14
        and patent_number.startswith("SG")
        and re.match(r"\d{11}", patent_number[2:13])
        and int(patent_number[2:6]) > 2013
        and patent_number[-1].isalpha()
    ):
        return patent_number[:2] + patent_number[6:8] + patent_number[2:6] + patent_number[8:14] + "A"
    return patent_number


def sg_drop_kind_code(patent_number: str) -> str:
    """
    Drop the kind code 'TA' from a Singapore patent number if it matches the pattern.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if re.match(r"^SG\d+TA$", patent_number):
        return patent_number[:-2]
    return patent_number


def sg_add_second_kind_letter(patent_number: str) -> str:
    """
    Add a second kind letter 'A' to a Singapore patent number if it meets the conditions.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("SG") and len(patent_number) == 14 and patent_number[-1].isalpha():
        return patent_number.strip() + "A"
    return patent_number


def reformat_sg_patent(patent_number: str) -> str:
    """
    Reformat a Singapore patent number if it matches the pattern.

    :param patent_number: The patent number.
    :param sg_patent_pattern: The regex pattern to match the Singapore patent format.
    :return: Reformatted patent number.
    """
    match = sg_patent_pattern.match(patent_number)
    if match:
        return f"SG11{match.group(1)}{match.group(2)}A"
    return patent_number


def sg_number_delete_5th_digit_if_it_is_zero(patent_number: str) -> str:
    """
    Delete the 5th digit if it is zero in a Singapore patent number.

    :param patent_number: The patent number.
    :return: Modified patent number.
    """
    if patent_number.startswith("SG") and len(patent_number) == 13 and re.match(r"\d{11}", patent_number[2:]):
        fifth_digit = int(patent_number[6])
        if fifth_digit == 0:
            return patent_number[:6] + patent_number[7:]
    return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    """
    Get the list of publication number modification rules.

    :return: A list of rules for modifying publication numbers.
    """
    rules: List[Rule] = []

    # Add a default "none" rule
    rules.append(("none", []))

    # Add primary modification rules
    rules.extend(primary.get_primary_modification_rules())

    # Add specific Singapore patent modification rules
    rules.extend(
        [
            ("sgMoveTenDigitBeforeYear", [sg_move_ten_digit_before_year]),
            ("sgDropKindCode", [sg_drop_kind_code]),
            ("sgAddSecondKindLetter", [sg_add_second_kind_letter]),
            ("reformatSGPatent", [reformat_sg_patent]),
            ("sgNumberDelete5thDigitIfItIsZero", [sg_number_delete_5th_digit_if_it_is_zero]),
        ]
    )

    # Add secondary modification rules
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:
    return get_publication_number_modification_rules()
