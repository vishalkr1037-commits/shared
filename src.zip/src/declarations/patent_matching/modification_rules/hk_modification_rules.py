from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def hk_drop_last_letter(patent_number):
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("HK") and len(non_alpha_num_form) == 11:
        return non_alpha_num_form[:-1]
    else:
        return patent_number


def hk_add_number_1(patent_number):
    non_alpha_num_form = helper.remove_non_alphanumeric_chars(patent_number)
    if non_alpha_num_form.startswith("HK") and len(non_alpha_num_form) >= 8:
        return non_alpha_num_form[:2] + "1" + non_alpha_num_form[2:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "hkDropLastLetter",
                [hk_drop_last_letter],
            ),
            (
                "hkAddNumber1",
                [hk_add_number_1],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
