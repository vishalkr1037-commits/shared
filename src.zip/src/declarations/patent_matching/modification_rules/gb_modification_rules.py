import re
from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]

gb_patent_pattern = re.compile(r"^GB(\d{4})00(\d{5})$")


def gb_fill_year_and_delete_last_character(patent_number):
    if (
        len(patent_number) == 10
        and patent_number.startswith("GB")
        and (val := helper.short_years.get(patent_number[2:4]))
    ):
        return patent_number[:2] + val + patent_number[4:-1]
    else:
        return patent_number


def gb_patent_delete_two_zeros(patent_number):
    match = gb_patent_pattern.fullmatch(patent_number)
    if match:
        year = int(match.group(1))
        short_year = match.group(1)[-2:]

        if year >= 2010:
            return "GB" + match.group(1) + match.group(2) + "A"
        else:
            return "GB" + short_year + match.group(2) + "A"
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "gb_fill_year_and_delete_last_character",
                [gb_fill_year_and_delete_last_character],
            ),
            (
                "gb_patent_delete_two_zeros",
                [gb_patent_delete_two_zeros],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
