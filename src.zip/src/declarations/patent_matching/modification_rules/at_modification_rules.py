from typing import Callable, List, Tuple

import src.declarations.patent_matching.modification_rules.modification_rules_helper as helper
import src.declarations.patent_matching.modification_rules.primary_modification_rules as primary
import src.declarations.patent_matching.modification_rules.secondary_modification_rules as secondary

Rule = Tuple[str, List[Callable[[str], str]]]


def at_add_e_and_t1(patent_number: str) -> str:
    """
    Add 'E' after the first two characters and '1' at the end of an Austrian patent number
    if it starts with "AT", has a length of 9 characters, and ends with "T".

    :param patent_number: The patent number
    :return: Modified patent number
    """
    if len(patent_number) == 9 and patent_number.startswith("AT") and patent_number.endswith("T"):
        return patent_number[:2] + "E" + patent_number[2:] + "1"
    else:
        return patent_number


def drop_cc_for_ep_patent(patent_number: str) -> str:
    """
    Replace the country code with 'EP' for a patent number if the country code is in the list of EP country codes.

    :param patent_number: The patent number
    :return: Modified patent number
    """
    if len(patent_number) > 2 and patent_number[:2] in helper.ep_country_codes:
        return "EP" + patent_number[2:]
    else:
        return patent_number


def get_publication_number_modification_rules() -> List[Rule]:
    rules: List[Rule] = []

    rules.append(("none", []))
    rules.extend(primary.get_primary_modification_rules())

    rules.extend(
        [
            (
                "atAddEAndT1",
                [at_add_e_and_t1],
            ),
            (
                "dropCcforEpPatent",
                [drop_cc_for_ep_patent],
            ),
        ]
    )
    rules.extend(secondary.get_secondary_modification_rules())

    return rules


def get_application_number_modification_rules() -> List[Rule]:

    return get_publication_number_modification_rules()
