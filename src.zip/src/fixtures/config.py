import os


def get_fixtures_path() -> str:
    return os.path.join(os.path.dirname(__file__))
