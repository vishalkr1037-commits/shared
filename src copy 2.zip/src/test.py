def test():
    print("hello world")


def test2():
    print("from shared libs")
