import pyspark.sql.functions as F
from pyspark.sql import DataFrame, SparkSession

# feat/100219:Firebolt Code Dependency - ReadDeltaTableTask


class ReadDeltaTableTask:
    def __init__(
        self,
        spark: SparkSession,
        fq_source_table: str,
        unmanaged_location: str = None,
        streaming: bool = True,
        max_bytes_per_trigger=None,
    ):
        self.spark = spark
        self.fq_source_table = fq_source_table
        self.unmanaged_location = unmanaged_location
        self.streaming = streaming
        self.max_bytes_per_trigger = max_bytes_per_trigger

    def read_unmanaged_delta_table(self):
        df = (
            self.spark.read.format("delta")
            .option("path", self.unmanaged_location)
            .table(self.fq_source_table)
        )

        # this is for testing, when read non-streaming its missing a field we need during
        # the transforms
        return df.withColumn("_commit_version", F.lit(""))

    def read_managed_delta_table(self):
        df = self.spark.read.format("delta").table(self.fq_source_table)

        # this is for testing, when read non-streaming its missing a field we need during
        # the transforms
        return df.withColumn("_commit_version", F.lit(""))

    def read_unmanaged_delta_table_streaming(self):
        df = self.spark.readStream.option("readChangeFeed", "true").option(
            "path", self.unmanaged_location
        )

        if self.max_bytes_per_trigger:
            # only if there is max bytes per trigger
            df = df.option("maxBytesPerTrigger", self.max_bytes_per_trigger)

        return df.table(self.fq_source_table).filter(
            F.col("_change_type").isin(["insert", "update_postimage"])
        )

    def read_managed_delta_table_streaming(self):
        df = self.spark.readStream.option("readChangeFeed", "true")

        if self.max_bytes_per_trigger:
            # only if there is max bytes per trigger
            df = df.option("maxBytesPerTrigger", self.max_bytes_per_trigger)

        return df.table(self.fq_source_table).filter(
            F.col("_change_type").isin(["insert", "update_postimage"])
        )

    def run(self, df: DataFrame = None):
        if self.streaming and self.unmanaged_location:
            df = self.read_unmanaged_delta_table_streaming()
        elif self.streaming and self.unmanaged_location is None:
            df = self.read_managed_delta_table_streaming()
        elif self.streaming is False and self.unmanaged_location:
            df = self.read_unmanaged_delta_table()
        else:
            df = self.read_managed_delta_table()

        return df
