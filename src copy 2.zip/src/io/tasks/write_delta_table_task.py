from functools import reduce

from delta.tables import DeltaTable
from lnip_data_platform_shared_libs.config.pipeline_config import PipelineConfig
from pyspark.sql import DataFrame, SparkSession
from pyspark.sql import functions as F

# from src.config.pipeline_config import PipelineConfig


# feat/100217:Firebolt Code Dependency - WriteDeltaTableTask
class WriteDeltaTableTask:
    def __init__(
        self,
        spark: SparkSession,
        fq_table_name: str,
        config: PipelineConfig,  # TODO: this parameter is assigned but never read, can it be removed?
        unmanaged_location: str = None,
        mode: str = "append",
    ):
        self.spark = spark
        # TODO: Does config require here?
        self.config = config
        self.unmanaged_location = unmanaged_location
        self.fq_table_name = fq_table_name
        self.mode = mode

    def write_managed(self, df: DataFrame):
        df.write.format("delta").mode(self.mode).option(
            "mergeSchema", "true"
        ).saveAsTable(self.fq_table_name)
        return df

    def enable_change_data_feed(self):
        self.spark.sql(
            f"ALTER TABLE {self.fq_table_name} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
        )

    def write_unmanaged(self, df: DataFrame):
        df.write.format("delta").mode(self.mode).option(
            "path", self.unmanaged_location
        ).saveAsTable(self.fq_table_name)
        self.spark.sql(
            f"ALTER TABLE {self.fq_table_name} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
        )
        return df

    def run(self, df: DataFrame):
        # if unmanaged location is not provided, we will write to managed table
        # we have to check for "Is None" because "if self.unmanaged_location"
        # will return False if the instance is defined but None
        if self.unmanaged_location is None:
            df = self.write_managed(df)
        else:
            df = self.write_unmanaged(df)

        self.enable_change_data_feed()
        return df


class WriteStreamedDeltaTableTask:
    def __init__(
        self,
        spark: SparkSession,
        fq_table_name: str,
        checkpoint_location: str,
        config: PipelineConfig,
        unmanaged_location: str = None,
    ):
        self.spark = spark
        self.config = config
        self.unmanaged_location = unmanaged_location
        self.checkpoint_location = checkpoint_location
        self.fq_table_name = fq_table_name

    def write_managed(self, df: DataFrame):
        spark_stream_object = (
            df.writeStream.outputMode("append")
            .trigger(availableNow=True)
            .format("delta")
            .option("checkpointLocation", self.checkpoint_location)
            .toTable(self.fq_table_name)
        )

        # await termination outside above block because it returns None
        spark_stream_object.awaitTermination()

    def enable_change_data_feed(self):
        self.spark.sql(
            f"ALTER TABLE {self.fq_table_name} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
        )

    def write_unmanaged(self, df: DataFrame):
        spark_stream_object = (
            df.writeStream.outputMode("append")
            .trigger(availableNow=True)
            .format("delta")
            .option("checkpointLocation", self.checkpoint_location)
            .option("path", self.unmanaged_location)
            .toTable(self.fq_table_name)
        )

        # await termination outside above block because it returns None
        spark_stream_object.awaitTermination()

    def run(self, df: DataFrame):
        if self.unmanaged_location is None:
            df = self.write_managed(df)
        else:
            df = self.write_unmanaged(df)

        self.enable_change_data_feed()
        return df


class MergeDeltaTableTask:
    def __init__(
        self,
        spark: SparkSession,
        fq_table_name: str,
        checkpoint_location: str,
        foreach_batch_write,
        config: PipelineConfig,
        # performance_monitor: MergePerformance = None,
        extra_foreach_params: list = None,
        trigger_once: bool = False,
        disable_checkpoint: bool = False,
    ):
        self.spark = spark
        self.config = config
        self.checkpoint_location = checkpoint_location
        self.fq_table_name = fq_table_name
        self.foreach_batch_write = foreach_batch_write
        # self.performance_logs_task = performance_monitor
        self.trigger_once = trigger_once
        self.disable_checkpoint = disable_checkpoint

        self.extra_foreach_params = extra_foreach_params

    def write(self, df: DataFrame):

        if self.trigger_once:
            spark_stream_object = df.writeStream.trigger(once=True)
        else:
            spark_stream_object = df.writeStream.trigger(availableNow=True)

        if not self.disable_checkpoint:
            spark_stream_object = spark_stream_object.option(
                "checkpointLocation", self.checkpoint_location
            )

        spark_stream_object = (
            spark_stream_object.format("delta")
            .foreachBatch(
                lambda df, batch_id: self.foreach_batch_write(
                    df, batch_id, *self.extra_foreach_params
                )
            )
            .start()
        )

        # await termination outside above block because it returns None
        spark_stream_object.awaitTermination()

        return spark_stream_object

    def enable_change_data_feed(self):
        self.spark.sql(
            f"ALTER TABLE {self.fq_table_name} SET TBLPROPERTIES (delta.enableChangeDataFeed = true)"
        )

    def run(self, df: DataFrame):
        self.write(df)
        self.enable_change_data_feed()
        return df


class CreateOrUpdateDeltaTableTask:
    def __init__(
        self,
        spark: SparkSession,
        target_table: str,
        config,
        merge_column_name: str,
        partition_col_names: list = None,
        partition_restriction_values: list = None,
    ):
        self.spark = spark
        self.target_table = target_table
        self.config = config
        self.merge_column_name = merge_column_name
        self.partition_col_names = partition_col_names
        self.partition_restriction_values = partition_restriction_values

    def delta_table_exists(self) -> bool:
        """Check if the Delta table exists in the catalog."""
        try:
            catalog_name, schema_name, table_name = self.target_table.split(".")
            tables = (
                self.spark.sql(f"SHOW TABLES IN {catalog_name}.{schema_name}")
                .filter(f"tableName = '{table_name}'")
                .collect()
            )
            return len(tables) > 0
        except Exception as e:
            if "Table or view not found" in str(e):
                return False
            raise e

    def run(self, df: DataFrame):
        """Main method to handle Delta table creation or update."""
        if self.delta_table_exists():
            if self.partition_col_names:
                partition_condition = self.get_partition_condition()
                partition_restriction_condition = (
                    self.get_partition_restriction_condition()
                )
                df = self.update_delta_table_with_partition(
                    df, partition_condition, partition_restriction_condition
                )
            else:
                df = self.update_delta_table(df)
        else:
            df = self.save_to_abfs(
                df,
                {
                    "saveMode": "error",
                    "partitionColNames": self.partition_col_names,
                    "options": {},
                },
            )
        return df

    def update_delta_table(self, dataframe: DataFrame):
        """Update the Delta table without partition-specific conditions."""
        delta_table = DeltaTable.forName(self.spark, self.target_table)
        delta_table.alias("table").merge(
            dataframe.alias("update_table"),
            F.col(f"table.{self.merge_column_name}")
            == F.col(f"update_table.{self.merge_column_name}"),
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

    def update_delta_table_with_partition(
        self,
        dataframe: DataFrame,
        partition_condition: F.Column,
        partition_restriction_condition: F.Column,
    ):
        """Update the Delta table with partition-specific conditions."""
        delta_table = DeltaTable.forName(self.spark, self.target_table)
        delta_table.alias("table").merge(
            dataframe.alias("update_table"),
            (
                F.col(f"table.{self.merge_column_name}")
                == F.col(f"update_table.{self.merge_column_name}")
            )
            & partition_condition
            & partition_restriction_condition,
        ).whenMatchedUpdateAll().whenNotMatchedInsertAll().execute()

    def save_to_abfs(self, dataframe: DataFrame, options: dict):
        """Save the DataFrame to Delta Lake."""
        partition_col_names = options.get("partitionColNames", [])
        save_mode = options.get("saveMode", "error")
        write_options = options.get("options", {})

        writer = (
            dataframe.write.format("delta").mode(save_mode).options(**write_options)
        )
        if partition_col_names:
            writer = writer.partitionBy(*partition_col_names)
        writer.saveAsTable(self.target_table)

    def get_partition_condition(self) -> F.Column:
        """Generate a partition condition for filtering the Delta table."""
        if not self.partition_col_names:
            return F.lit(True)

        conditions = [
            F.col(f"table.{col_name}") == F.col(f"update_table.{col_name}")
            for col_name in self.partition_col_names
        ]
        return reduce(lambda cond1, cond2: cond1 & cond2, conditions)

    def get_partition_restriction_condition(self) -> F.Column:
        """Generate a partition restriction condition for filtering the Delta table."""
        if not self.partition_restriction_values:
            return F.lit(True)

        conditions = [
            F.col(f"table.{self.partition_col_names[i]}")
            == self.partition_restriction_values[i]
            for i in range(len(self.partition_col_names))
        ]
        return reduce(lambda cond1, cond2: cond1 & cond2, conditions)
