from dataclasses import dataclass
from typing import Optional

from lnip_data_platform_shared_libs.config.source_config import Source

# from src.config.pipeline_config import Source


@dataclass(frozen=True)
class PipelineConfig:
    source: Optional[Source]
    env: str
    target_folder: str
    run_id: Optional[str] = None
