import json
import os

from lnip_data_platform_shared_libs.config.file_config.config import (
    FILE_READ_MODE,
    JSON_ENCODING,
    PATENTS_SCHEMA_PATH,
)
from lnip_data_platform_shared_libs.fixtures.config import get_fixtures_path

# from src.config.file_config.config import (
#     FILE_READ_MODE,
#     JSON_ENCODING,
#     PATENTS_SCHEMA_PATH,
# )
# from src.fixtures.config import get_fixtures_path


def load_json(file_path: str):
    if not file_path:
        return None

    with open(file_path, FILE_READ_MODE, encoding=JSON_ENCODING) as f:
        return json.load(f)


def get_path(
    layer: str,
    file_name: str,
    relative: str = PATENTS_SCHEMA_PATH,
) -> str:
    return os.path.join(get_fixtures_path(), relative, layer, file_name)
