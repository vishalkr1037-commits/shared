import os
from typing import Any, Dict, Union

import yaml
from lnip_data_platform_shared_libs.config.source_config import Source
from lnip_data_platform_shared_libs.fixtures.config import get_fixtures_path

# from src.config.source_config import Source
# from src.fixtures.config import get_fixtures_path


# TODO: Cleanup unnecessary constants, once table config is adjusted to new layer based approach
METADATA_PATH = "metadata"
SCHEMA_ROOT = "schemas"
DECLARATIONS_SCHEMA_PATH = "schemas/declarations"
FIRMOGRAPHICS_SCHEMA_PATH = "schemas/firmographics"
PATENTS_SCHEMA_PATH = "schemas/patents"
LITIGATION_SCHEMA_PATH = "schemas/litigations"
DATAPRODUCTS_SCHEMA_PATH = "schemas/dataproducts"
PARSING_SCHEMA_PATH = "parsing"
MAPPING_SCHEMA_PATH = "mapping"

# Define the encoding types, file read mode and file extension
ENCODING_UTF_16 = "utf-16"
ENCODING_UTF_8 = "utf-8"
JSON_ENCODING = "utf-8-sig"
XML_FILE_EXTENSION = ".xml"
JSON_FILE_EXTENSION = ".json"
FILE_READ_MODE = "r"

# Define the keys used in the file configuration
FRONTFILE_SUFFIX = "frontfile"
BACKFILE_SUFFIX = "backfile"
XSD_FILE_LOCATION = "xsd_file_location"
DTD_DIRECTORY = "dtd_directory"


def load_yml_file(file_path: str) -> Union[Dict[str, Any], None]:
    if not file_path:
        return None

    with open(file_path, FILE_READ_MODE) as file:
        yml_data = yaml.safe_load(file)

    return yml_data


def join_path(*args) -> str:
    return os.path.join(*args)


def prepare_files_definition(config: dict) -> dict:
    """
    Prepares the source files definition based on the provided file configuration.

    Parameters:
    - file_config (dict): A dictionary containing the file configuration details.

    Returns:
    - dict: A dictionary containing the source files definition.
    """
    response = {}

    # Load file section from yml configuration
    config = config["file"]

    # Extract directory paths and suffixes from the file configuration
    dir_ingestor = config.get("dir_ingestor", "")
    dir_xsd_dtd = config.get("dir_xsd", "")
    dir_archive = config.get("dir_archive", "")
    backfile_suffix = config.get("backfile_suffix", "")

    # Extract sources from the file configuration
    sources = config.get("sources", {})

    for source in sources:
        name = source.get("source", "")
        xsd_version = source.get("xsd_version", "")
        xsd_file = source.get("xsd_file", "")

        response[name] = {
            # Construct the DTD directory path
            DTD_DIRECTORY: join_path(dir_ingestor, name, dir_xsd_dtd, xsd_version),
            # Construct the XSD file location path
            XSD_FILE_LOCATION: join_path(
                dir_ingestor, name, dir_xsd_dtd, xsd_version, xsd_file
            ),
            # Construct the frontfile suffix path
            FRONTFILE_SUFFIX: join_path(*dir_archive.split("/")),
            # Construct the backfile suffix path
            BACKFILE_SUFFIX: join_path(*dir_archive.split("/"), backfile_suffix),
        }
    return response


# Get the current directory of the script
current_dir = os.path.dirname(__file__)

# Construct the path to the configuration file
config_file_path = join_path(current_dir, "config.yml")

# Load the file definition from the YAML configuration file
FILE_DEFINITION = prepare_files_definition(load_yml_file(config_file_path))


def get_xsd_file_location(source: Source) -> str:
    """
    Retrieves the XSD file location for a given source.

    Parameters:
    - source (Source): The data source name.

    Returns:
    - str: The XSD file location path.
    """
    return join_path(
        get_fixtures_path(),
        FILE_DEFINITION.get(source.value, {}).get(XSD_FILE_LOCATION, ""),
    )


def get_archive_file_location(
    source: Source, is_backfile: bool, target_folder: str
) -> str:
    """
    Retrieves the archive file location for a given source.

    Parameters:
    - source (Source): The data source name.
    - is_backfile (bool): Flag indicating whether the file is a backfile.
    - target_folder (str): The target folder path.

    Returns:
    - str: The archive file location path.
    """
    location = (
        FILE_DEFINITION.get(source.value, {}).get(FRONTFILE_SUFFIX, None)
        if not is_backfile
        else FILE_DEFINITION.get(source.value, {}).get(BACKFILE_SUFFIX, None)
    )
    return (
        f"{os.sep}{location.format(source=source.value, target_folder=target_folder)}"
        if location
        else None
    )


def get_dtd_directory(source: Source) -> str:
    """
    Retrieves the DTD directory for a given source.

    Parameters:
    - source (Source): The data source name.

    Returns:
    - str: The DTD directory path.
    """
    return join_path(
        get_fixtures_path(),
        FILE_DEFINITION.get(source.value, {}).get(DTD_DIRECTORY, ""),
    )
