from enum import Enum

# Bronze Table
TABLE_BRONZE_DOCDB = "patent_bronze_raw_docdb"
TABLE_BRONZE_DOCDB_AUDIT = "patent_bronze_raw_docdb_audit"
TABLE_BRONZE_PRS = "patent_bronze_raw_prs"
TABLE_BRONZE_UNUMBIO = "patent_bronze_raw_unumbio"


# NOTE: Migrate to StrEnum, when python version is upgraded to 3.11 on dbx cluster
# Data Source providers
class Source(Enum):
    DOCDB = "docdb"
    PRS = "prs"
    UNUMBIO = "unumbio"

    @property
    def table_value(self):
        """Returns the string used to represent this source in Databricks tables."""
        if self == Source.DOCDB:
            return "DocDB_st36"
        return self.value


def lookup_source_table(source: Source):
    if source == Source.DOCDB:
        return TABLE_BRONZE_DOCDB

    elif source == Source.UNUMBIO:
        return TABLE_BRONZE_UNUMBIO

    elif source == Source.PRS:
        return TABLE_BRONZE_PRS

    raise Exception(f"Invalid source. Cant lookup {source.value}")
