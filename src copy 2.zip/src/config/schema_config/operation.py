from lnip_data_platform_shared_libs.config.file_config.operation import load_json
from pyspark.sql.types import StructType

# from src.config.file_config.operation import load_json


def load_schema(file_path: str):
    if not file_path:
        return None

    json_schema = load_json(file_path)
    return StructType.fromJson(json_schema)
