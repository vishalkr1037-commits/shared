import os
from typing import Optional

from lnip_data_platform_shared_libs.config.file_config.config import (
    JSON_FILE_EXTENSION,
    SCHEMA_ROOT,
)
from lnip_data_platform_shared_libs.config.file_config.operation import get_path
from lnip_data_platform_shared_libs.config.schema_config.operation import load_schema
from lnip_data_platform_shared_libs.config.table_config.config import (
    CONFIG_CHANGE_DATA_FEED,
    CONFIG_CLUSTER_KEYS,
    CONFIG_DDL,
    CONFIG_DELETE_KEYS,
    CONFIG_DELETED_FILE_RETENTION_DURATION,
    CONFIG_LAYER,
    CONFIG_LAYER_BRONZE,
    CONFIG_LAYER_GOLD,
    CONFIG_LAYER_SILVER,
    CONFIG_LOCATION,
    CONFIG_LOG_RETENTION_DURATION,
    CONFIG_MANAGED,
    CONFIG_NAME,
    CONFIG_PARTITION,
    CONFIG_PRIMARY_KEYS,
    CONFIG_PROJECT,
    CONFIG_TABLE_NAME,
    TableConfig,
)

# from src.config.file_config.config import JSON_FILE_EXTENSION, SCHEMA_ROOT
# from src.config.file_config.operation import get_path
# from src.config.schema_config.operation import load_schema
# from src.config.table_config.config import (
#     CONFIG_CHANGE_DATA_FEED,
#     CONFIG_CLUSTER_KEYS,
#     CONFIG_DDL,
#     CONFIG_DELETE_KEYS,
#     CONFIG_DELETED_FILE_RETENTION_DURATION,
#     CONFIG_LAYER,
#     CONFIG_LAYER_BRONZE,
#     CONFIG_LAYER_GOLD,
#     CONFIG_LAYER_SILVER,
#     CONFIG_LOCATION,
#     CONFIG_LOG_RETENTION_DURATION,
#     CONFIG_MANAGED,
#     CONFIG_NAME,
#     CONFIG_PARTITION,
#     CONFIG_PRIMARY_KEYS,
#     CONFIG_PROJECT,
#     CONFIG_TABLE_NAME,
#     TableConfig,
# )


LAYER_BRONZE = CONFIG_LAYER_BRONZE
LAYER_SILVER = CONFIG_LAYER_SILVER
LAYER_GOLD = CONFIG_LAYER_GOLD


def table_exists(table_name):
    return TableConfig.get_table_config_map().get(table_name, None) is not None


def tables_by_project(project_name):
    return [
        value[CONFIG_TABLE_NAME]
        for _, value in TableConfig.get_table_config_map().items()
        if value[CONFIG_PROJECT] == project_name
    ]


def table_short_name(table_name):
    return TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_NAME, None)


def table_layer(table_name):
    return (
        TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_LAYER, None)
    )


def table_project(table_name):
    return (
        TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_PROJECT, None)
    )


def table_has_schema(table_name: str):
    schema_path = get_path(
        relative=os.path.join(
            SCHEMA_ROOT,
            TableConfig.get_table_config_map()
            .get(table_name, {})
            .get(CONFIG_PROJECT, "")
            .lower(),
        ),
        layer=table_layer(table_name),
        file_name=f"{table_name}{JSON_FILE_EXTENSION}",
    )

    return os.path.isfile(schema_path) == True


def table_schema(table_name: str):
    # Get schema file path
    schema_path = get_path(
        relative=os.path.join(
            SCHEMA_ROOT,
            TableConfig.get_table_config_map()
            .get(table_name, {})
            .get(CONFIG_PROJECT, "")
            .lower(),
        ),
        layer=table_layer(table_name),
        file_name=f"{table_name}{JSON_FILE_EXTENSION}",
    )

    # Load schema from json to struct
    return load_schema(schema_path)


def table_is_managed(table_name: str):
    return (
        TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_MANAGED, None)
        == True
    )


def table_unmanaged_location(
    table_name: str, environment: str, target_folder: str
) -> str:
    if table_is_managed(table_name=table_name) is True:
        raise Exception(f"Requesting storage location for managed table {table_name}")

    # Get location of table
    # Format location string with arg sequence (Layer, Environment, Target Folder, Table Name)

    return (
        TableConfig.get_table_config_map()
        .get(table_name, {})
        .get(CONFIG_LOCATION, "")
        .format(
            layer=table_layer(table_name),
            environment=environment,
            target_folder=target_folder,
            table_name=table_name,
        )
    )


def table_partition(table_name: str) -> list[str]:
    return (
        TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_PARTITION, [])
    )


def table_change_data_feed(table_name: str) -> bool:
    """Checks if change data feed (CDF) is enabled, defaults to True."""
    return (
        TableConfig.get_table_config_map()
        .get(table_name, {})
        .get(CONFIG_CHANGE_DATA_FEED, True)
    )


# TODO: in future consider whether we want a more generic way of managing table properties, vs. having separate
#       functions for each property.
def table_log_retention_duration(table_name: str, environment: str) -> Optional[str]:
    """Get the delta.logRetentionDuration property for the table.

    Retention policies are documented here: https://lnipsolutions.atlassian.net/wiki/spaces/DP/pages/21929164803/Delta+table+retention+policies

    Args:
        table_name: Name of the table to check.
        environment: Environment in which the table is being used (e.g., "prod", "dev").

    Returns:
        Value of the delta.logRetentionDuration property to set for that table, or None to use the default.
    """
    # If the table has explicit configuration, use that instead of any defaults.
    if (
        log_retention := TableConfig.get_table_config_map()
        .get(table_name, {})
        .get(CONFIG_LOG_RETENTION_DURATION)
    ):
        return log_retention

    # Only the production environment currently has non-default values for this property.
    if environment != "prod":
        return None

    # Default configuration should only apply to streaming tables.
    if not table_change_data_feed(table_name):
        return None

    # Set default value based on the table layer.
    layer = table_layer(table_name)
    if layer == LAYER_BRONZE:
        interval_days = 60
    elif layer == LAYER_SILVER:
        interval_days = 30
    elif layer == LAYER_GOLD:
        interval_days = 60
    else:
        # In theory this should never happen, but return None just in case.
        return None

    # Return the exact string that the Databricks delta.logRetentionDuration property expects.
    return f"interval {interval_days} days"


def table_deleted_file_retention_duration(
    table_name: str, environment: str
) -> Optional[str]:
    """Get the delta.deletedFileRetentionDuration property for the table.

    Retention policies are documented here: https://lnipsolutions.atlassian.net/wiki/spaces/DP/pages/21929164803/Delta+table+retention+policies

    Args:
        table_name: Name of the table to check.
        environment: Environment in which the table is being used (e.g., "prod", "dev").

    Returns:
        Value of the delta.deletedFileRetentionDuration property to set for that table, or None to use the default.
    """
    # If the table has explicit configuration, use that instead of any defaults.
    if (
        deleted_file_retention := TableConfig.get_table_config_map()
        .get(table_name, {})
        .get(CONFIG_DELETED_FILE_RETENTION_DURATION)
    ):
        return deleted_file_retention

    # Only the production environment currently has non-default values for this property.
    if environment != "prod":
        return None

    # Default configuration should only apply to tables that are both streaming and managed.
    if not (table_change_data_feed(table_name) and table_is_managed(table_name)):
        return None

    # Set default value based on the table layer.
    layer = table_layer(table_name)
    if layer == LAYER_BRONZE:
        interval_days = 30
    elif layer == LAYER_SILVER:
        interval_days = 15
    elif layer == LAYER_GOLD:
        interval_days = 30
    else:
        # In theory this should never happen, but return None just in case.
        return None

    # Return the exact string that the Databricks delta.deletedFileRetentionDuration property expects.
    return f"interval {interval_days} days"


def table_has_primary_keys(table_name: str):
    if (
        len(
            TableConfig.get_table_config_map()
            .get(table_name, {})
            .get(CONFIG_PRIMARY_KEYS, [])
        )
        > 0
    ):
        return True

    return False


def table_primary_keys(table_name: str):
    if not table_has_primary_keys(table_name):
        raise Exception(f"Table has no primary keys {table_name}")

    return (
        TableConfig.get_table_config_map()
        .get(table_name, {})
        .get(CONFIG_PRIMARY_KEYS, None)
    )


def table_has_cluster_keys(table_name: str):
    if (
        len(
            TableConfig.get_table_config_map()
            .get(table_name, {})
            .get(CONFIG_CLUSTER_KEYS, [])
        )
        > 0
    ):
        return True

    return False


def table_cluster_keys(table_name: str):
    if not table_has_cluster_keys(table_name):
        raise Exception(f"Table has no cluster keys {table_name}")

    return (
        TableConfig.get_table_config_map()
        .get(table_name, {})
        .get(CONFIG_CLUSTER_KEYS, None)
    )


def table_ddl(table_name: str) -> Optional[str]:
    """Get the DDL statement for the table, or None if no DDL for the given table is found."""
    return TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_DDL)


def table_required_fields(table_name: str):

    # this is ugly, but works, perhaps we can move the ddl in the config file to a
    # list of values with required True/False

    ddl = TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_DDL, "")

    ddl_lines = [
        line.strip("\n").split() for line in ddl.split("(")[1].split(")")[0].split(",")
    ]

    fields = [
        row[0]
        for row in ddl_lines
        if row[0][0] != "_" and row[-2] == "NOT" and row[-1] == "NULL"
    ]

    return fields


def table_name_from_short_name(layer: str, short_name: str):
    found_table_name = None
    for key, value in TableConfig.get_table_config_map().items():
        if value[CONFIG_NAME] == short_name and value[CONFIG_LAYER] == layer:
            if found_table_name:
                raise ValueError(
                    f"Duplicate short name: {short_name} used for {found_table_name} and {key}"
                )
            found_table_name = key

    if found_table_name:
        return found_table_name

    raise Exception(
        f"Invalid short name: {short_name}, unable to lookup a valid table name"
    )


def table_lookup_keys(table_name: str):
    pass


def table_lookup__update_keys(table_name: str):
    pass


def table_upsert_exclude_keys(table_name: str):
    pass


def table_has_delete_keys(table_name: str):
    return bool(
        TableConfig.get_table_config_map().get(table_name, {}).get(CONFIG_DELETE_KEYS)
    )


def table_delete_keys(table_name: str):
    if not table_has_delete_keys(table_name):
        raise Exception(f"Table has no delete keys {table_name}")

    return (
        TableConfig.get_table_config_map()
        .get(table_name, {})
        .get(CONFIG_DELETE_KEYS, None)
    )
