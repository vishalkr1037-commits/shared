import warnings
from enum import Enum
from pathlib import Path
from typing import Union

import yaml

# All CONFIG fields are internal and should not be used in the codebase,
# instead an api is supplied in table_config_interface
CONFIG_NAME = "name"
CONFIG_TABLES = "tables"
CONFIG_TABLE_NAME = "table_name"
CONFIG_LAYER = "layer"
CONFIG_PROJECT = "project"
CONFIG_PRIMARY_KEYS = "primary_keys"
CONFIG_DELETE_KEYS = "delete_keys"
CONFIG_CLUSTER_KEYS = "cluster_keys"
CONFIG_LOCATION = "location"
CONFIG_MANAGED = "managed"
CONFIG_DDL = "ddl"
CONFIG_DEPENDENCIES = "dependencies"
CONFIG_CHANGE_DATA_FEED = "change_data_feed"
CONFIG_PARTITION = "partition"
CONFIG_LOG_RETENTION_DURATION = "log_retention_duration"
CONFIG_DELETED_FILE_RETENTION_DURATION = "deleted_file_retention_duration"

warnings.warn(
    "CONFIG_LAYER_BRONZE is deprecated. Use Layer.BRONZE instead.",
    DeprecationWarning,
    stacklevel=2,
)
CONFIG_LAYER_BRONZE = "bronze"

warnings.warn(
    "CONFIG_LAYER_SILVER is deprecated. Use Layer.SILVER instead.",
    DeprecationWarning,
    stacklevel=2,
)
CONFIG_LAYER_SILVER = "silver"

warnings.warn(
    "CONFIG_LAYER_GOLD is deprecated. Use Layer.GOLD instead.",
    DeprecationWarning,
    stacklevel=2,
)
CONFIG_LAYER_GOLD = "gold"


class Layer(Enum):
    """
    Enum representing different medallion layers.
    """

    BRONZE = "bronze"
    SILVER = "silver"
    GOLD = "gold"


def set_layer(cfg_text: str):
    if cfg_text.lower() == CONFIG_LAYER_BRONZE.lower():
        return CONFIG_LAYER_BRONZE

    elif cfg_text.lower() == CONFIG_LAYER_SILVER.lower():
        return CONFIG_LAYER_SILVER

    elif cfg_text.lower() == CONFIG_LAYER_GOLD.lower():
        return CONFIG_LAYER_GOLD

    raise Exception(f"Unknown layer in config: {cfg_text}")


def transform_config(config: dict, cfg: str):
    table_config = {}

    if CONFIG_PROJECT not in config:
        raise Exception(f"Badly formatted config file missing project {cfg}")

    if CONFIG_LOCATION not in config:
        raise Exception(f"Badly formatted config file missing location {cfg}")

    project = config[CONFIG_PROJECT]
    default_location = config[CONFIG_LOCATION]

    for layer, tables in config[CONFIG_TABLES].items():
        for table in tables:
            table_name = table[CONFIG_TABLE_NAME]

            # Add fields from top level of YAML to per-table configuration.
            table[CONFIG_LAYER] = set_layer(layer)
            table[CONFIG_PROJECT] = project

            # Allow for the location to be overridden at the table level.
            if CONFIG_LOCATION not in table:
                table[CONFIG_LOCATION] = default_location

            table_config[table_name] = table

    return table_config


def load_and_parse_table_config(config_files):
    config = {}

    for cfg in config_files:
        with open(cfg, "r") as fp:
            yml_data = yaml.safe_load(fp)
            config |= transform_config(yml_data, cfg)

    return config


class TableConfig:
    loaded_projects = {}
    table_config_map = {}

    @classmethod
    def get_table_config_map(cls):
        return cls.table_config_map

    @classmethod
    def add_config_from_files(cls, file_list):
        cls.table_config_map |= load_and_parse_table_config(file_list)
        return cls.table_config_map

    @classmethod
    def add_table_config_map(cls, config):
        cls.table_config_map |= config

    @classmethod
    def add_config_from_directory(cls, path: Union[Path, str]):
        """Load all table configuration files from YAML files in given directory.

        Convenience method for listing all YAML files in a directory, and calling `add_config_from_files` on them.
        """
        path = path if isinstance(path, Path) else Path(path)
        if not path.is_dir():
            raise ValueError(f"Path {path} is not a directory.")

        files = []
        for ext in ("yml", "yaml"):
            files.extend(path.glob(f"*.{ext}"))

        if files:
            cls.add_config_from_files(files)
