"""
Collection of truly global table name utility functions.
"""

from enum import Enum

_RAW_TABLE_SUFFIX = "_raw"


# NOTE: Following enum can be moved to appropriate file in future.
# Migrate to StrEnum, when python version is upgraded to 3.11 on dbx cluster
class Catalog(Enum):
    TEST = "test"
    DEV = "dev"
    PROD = "prod"
    PERSONAL_DEV = "personal_dev"


def fully_qualified_table_name(catalog: str, database: str, table: str):
    return f"{catalog}.{database}.{table}"


def table_schema_name(database: str, table: str):
    return f"{database}.{table}"


def table_scheme_path(catalog: str, database: str):
    return f"{catalog}.{database}"


def is_silver_raw_table(table_name: str):
    """Check if given table name is a raw table."""
    return table_name.endswith(_RAW_TABLE_SUFFIX) and "silver" in table_name


def silver_raw_table_to_silver_table(table_name: str) -> str:
    """Convert a silver raw table name to its corresponding silver table name.

    If a non-silver or non-raw table name is provided, it will be returned unchanged.
    """
    if is_silver_raw_table(table_name):
        return table_name.removesuffix(_RAW_TABLE_SUFFIX)
    return table_name
