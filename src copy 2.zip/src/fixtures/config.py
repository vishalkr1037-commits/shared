import os

# def get_fixtures_path() -> str:
#     return os.path.join(os.path.dirname(__file__))


def get_fixtures_path() -> str:
    return os.environ.get(
        "FIXTURES_PATH",
        os.path.join(os.path.dirname(__file__)),  # fallback to shared lib fixtures
    )
